/**
 * Created by Neil Pullen on 5/6/15.
 */
var makePaymentControllers = angular.module('makePaymentControllers', []);
makePaymentControllers.controller('MakePaymentIndex', ['$scope', '$location', '$routeParams', 'urlService','makePaymentService','makePaymentThistleService','errorLoggingService','currentBillService', 'primaryContactService', '$timeout','kcimEmailConfirmationService','paymentFriendlyNameService', 'stateService', 'utilityService',
    function ($scope, $location, $routeParams, urlService,makePaymentService,makePaymentThistleService,errorLoggingService,currentBillService,primaryContactService, $timeout,kcimEmailConfirmationService,paymentFriendlyNameService, stateService, utilityService) {

        $scope.loading = true;

        if($location.path().indexOf('logoutmakepaymentindex')!==-1){
               connection.userType = '';
               makePaymentService.loggedOut=true;
            }

        if (connection.userType == constants.CUSTOMER && (makePaymentService.loggedOut == false || makePaymentService.loggedOut == undefined)) {

            var getPaymentFriendlyNameResponse = utilityService.getPaymentFriendlyName(paymentFriendlyNameService, primaryContactService, errorLoggingService);
            getPaymentFriendlyNameResponse.then(function (result) {

                $scope.userFriendlyName= result.userFriendlyName;

                utilityService.getCustomerEmailAddress($routeParams.accKey, errorLoggingService);
            });
        }

        var actionTabs =makePaymentService.getTabpanels();

         $scope.userFriendlyName=primaryContactService.userFriendlyName;
          var viewLastestBill=connection.viewLatestBill;

        if(angular.isDefined(viewLastestBill)){

            //  TODO: We need to fix the issue with acckey and accKey. I think the issue is related to the value
            //        we pass to Thistle
            if ($routeParams.accKey != undefined) {
                $scope.viewLastestBill = viewLastestBill.replace(/%ACC_KEY/g, $routeParams.accKey);
            }
            else if ($routeParams.acckey != undefined) {
                $scope.viewLastestBill = viewLastestBill.replace(/%ACC_KEY/g, $routeParams.acckey);
            }
        }
        if($(window).width()<=980){
            $scope.tooltipClick=false;
        }
        else
        {
            $scope.tooltipClick=true;
        }
        if(makePaymentService.instalmentPlan){
           $scope.instalmentPlan= true;
           $scope.lastInstalment = makePaymentService.lastInstalment;
           $scope.instalmentPaymentDueDate = makePaymentService.instalmentPaymentDueDate;
           $scope.amount= $scope.outstandingBalance= makePaymentService.instalmentAmount;
           $scope.paymentDueDate =makePaymentService.instalmentPaymentDueDate===null?null: moment(makePaymentService.instalmentPaymentDueDate).format('DD MMM YYYY');
         }else{                 
            $scope.lastInstalment =false;
         }
        $scope.userType =connection.userType;
        //Change to support mybt app. If the page is loaded in app, disable installment plan link
        $scope.showInstalmentPlanLink = true;
        $scope.isUsingMobileApp = false;

        if($scope.userType === "customer" && typeof mybtApp !== "undefined"){
            $scope.showInstalmentPlanLink = mybtApp.showInstalmentPlanLink;
            $scope.isUsingMobileApp = mybtApp.usingMobileApp;
        }
        // Change end
        $scope.loggedOut  = makePaymentService.loggedOut;
        $scope.onEmailClick = function() {
            $scope.email_notification=true;
            $scope.email_confirmed =false;
        }
        $scope.sendEmail=function(){
            $scope.email_confirmed =true;
            $scope.email_notification=false;
        }
        $scope.notifyEmailOrSms=function(notify){
            $scope.loggedOutSuccessEnable =true;
            $scope.notify=notify;
        }
        $scope.notifyEmailOrSmsForAdvisor=function(notify){
            $scope.email_confirmed=false;
            makePaymentService.notifyEmailOrSmsForAdvisor(notify,$scope);

        }
        $scope.hideSMS = function (){
            $scope.advisor_sms_notification = false;
        };
        $scope.hideEmail = function (){
            $scope.advisor_email_notification = false;
        };
        $scope.sendEmailOrSms=function(user){
            var post= makePaymentService.notificationPost($scope,$('#loggedoutemail').val()),allRequest;
            if(user==='advisor'){
                 allRequest = kcimEmailConfirmationService.agentkciEmailRequest(post);
            }else if(user==='loggedOut'){
                 allRequest = kcimEmailConfirmationService.customerkciEmailRequest(post);
                $scope.loggedOutSuccessEnable = false;
                $scope.loggedOutSuccess = false;
            }


            allRequest.then(function (result) {
                $scope.email_confirmed=true;
                $scope.loggedOutSuccessEnable=$scope.advisor_email_sms_notification=false;
            },function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });
        };
        //  paymentSuccessful   Controller  start //
        $scope.close=function(user){
            if(user==="advisor"){
                $scope.advisor_email_sms_notification=false;
            }else{
                $scope.loggedOutSuccessEnable=false;
            }
        }
         $scope.getNextInstalment=function($event){
              $event.stopPropagation();
              $scope.amount=$scope.activeInstalmentAmount;
              $('#amount').val($scope.activeInstalmentAmount);
              $scope.paymentDueDate=moment($scope.activeInstalmentDueDate).format('DD MMM YYYY');
              $scope.nextInstalmentAmountActive=true;
         }

        $scope.tryAnotherCard = function() {
            $location.path('/agentmakepaymentindex');

        }
              if($location.path().indexOf(constants.MAKE_PAYMENT_SUCCESS)!=-1){
                  $scope.tabPanel = constants.PAYMENT_SUCCESSFUL;
                  $scope.loading = false;
                  makePaymentService.getPaymentThisleSessionLogged($routeParams,$scope,actionTabs);
                  makePaymentService.addClass(['confirmAccountTab_h2','enterAmountTab_h2','paymentIframeTab_h2'],'accordion__header--complete');
                  angular.extend($scope,{
                      paymentReference:  $routeParams.paymentReferenceId,
                      paymentDateTime : $routeParams.paymentDateTime,
                      accountNumber : $routeParams.bac,
                      amount : $routeParams.amount,
                      currency : $routeParams.currency,
                      cardType : $routeParams.cardType===constants.CARD_DELTA?constants.CARD_VISA_DEBIT:$routeParams.cardType,
                      nameOnCard : $routeParams.cardHolderName,
                      cardNumber : $routeParams.cardNumber,
                      expiryDate : $routeParams.expiryDate,
                      securityCode : '***',
                      paymenttoken : $routeParams.paymenttoken,
                      notificationtoken :  $routeParams.notificationtoken,
                      postCode : $routeParams.cardHolderPostCode,
                      email : $routeParams.email
                  });
                  if ($scope.loggedInSuccess && $routeParams.email) {
                      $scope.email = $routeParams.email;
                      stateService.set("contactEmail", $routeParams.email);
                  }
                  if($scope.advisorSuccess){
                      var primaryContactRequest = primaryContactService.getContactDetails();
                      primaryContactRequest.then(function (result) {
                          $scope.email = result.email;
                          $scope.mobilePhoneNumber = result.mobilePhoneNumber;

                      },function(errorResult) {
                          console.log(errorLoggingService.errorToString(errorResult));
                          $location.path(urlService.getErrorUrl());
                      });
                  }

                  $scope.complete = function () {
                      makePaymentService.searchParameter($location);
                      $location.path(urlService.getHomeUrl());
                  };
              }else if($location.path().indexOf('makepaymentfailed')!=-1){
                  makePaymentService.routeParams =$routeParams;
            $scope.loading = false;      
            $scope.makepaymentfailed=true;
                  $scope.tabPanel = 'paymentIframeTab';
                  makePaymentService.getPaymentThisleSessionLogged($routeParams,$scope,actionTabs);
                   
              }else{

                  if(makePaymentService.loggedOut){
                      $scope.loading = false;
                      $scope.actionTabs = actionTabs;
                      $scope.tabPanel = 'confirmAccountTab';
                  }else{
                      $scope.actionTabs = actionTabs.slice(1);
                      $scope.loading = false;
                      $scope.confirmationBac = $routeParams.bac;


                      var allRequest = makePaymentService.getAllLoggedInRequest();
                      allRequest.then(function (result) {
                           $scope.loading = false;
                          var currentBill = result.currentBill;
                          $scope.tabPanel = 'enterAmountTab';
                          var _fn_currentBill= function(currentBill){
                              makePaymentService.currentBillUsage(currentBill,$scope);
                              var credit=currentBill.credit,outstandingBalance = currentBill.balance.amount.toFixed(2);
                              if( $scope.userType==="customer" && credit==="N" && outstandingBalance>0){
                                    var allRequest = makePaymentService.getNextInstalmentRequest(makePaymentService.bac);
                                      allRequest.then(function (result) {
                                        var nextInstalment= result.nextInstalment;
                                        makePaymentService.nextInstalmentBillUsage(nextInstalment,$scope);

                                  },function(errorResult) {
                                      $location.path(urlService.getErrorUrl());
                                  });  
                              }

                          };
                           
                          if(makePaymentService.instalmentPlan && !makePaymentService.instalmentMissed){
                              $scope.amount = makePaymentService.instalmentAmount;
                              $scope.lastInstalment = makePaymentService.lastInstalment;
                              $scope.paymentDueDate =makePaymentService.instalmentPaymentDueDate==null?null: moment(makePaymentService.instalmentPaymentDueDate).format('DD MMM YYYY');
                              $scope.paymentDueDateDisplay =!($scope.paymentDueDate ==null || $scope.paymentDueDate==undefined);
                          }else{
                              $scope.lastInstalment =false;
                              _fn_currentBill(currentBill);
                              
                                
                          }


                      },function(errorResult) {
                          console.log(errorLoggingService.errorToString(errorResult));
                          $location.path(urlService.getErrorUrl());
                      });
                  }
              }


        function postEncodedXml(){
            $timeout(function(){
                document.payform.submit();
            },500);
        };

        $scope.loaded =function(){
            $scope.loading = false;

            $scope.hideframe=false;
        },

        $scope.applyClass=function(){
            if($scope.tabPanel==="paymentSuccessful"){
                setTimeout(function(){ 
                     makePaymentService.addClass(['confirmAccountTab_h2','enterAmountTab_h2','paymentIframeTab_h2','paymentSuccessful_h2'],'accordion__header--complete');
                makePaymentService.removeClass(['confirmAccountTab_edit_icon','enterAmountTab_edit_icon','paymentIframeTab_edit_icon','paymentSuccessful_edit_icon'],'ng-hide');
          
                   }, 1);
            
            }else if($scope.tabPanel==="paymentIframeTab"){
                if($location.path().indexOf('makepaymentfailed')!=-1){
                setTimeout(function(){ 
                     makePaymentService.addClass(['confirmAccountTab_h2','enterAmountTab_h2'],'accordion__header--complete');
                     makePaymentService.addClass(['paymentIframeTab_h2'],'accordion__header--warning');
                     makePaymentService.removeClass(['confirmAccountTab_edit_icon','enterAmountTab_edit_icon','paymentIframeTab_edit_icon'],'ng-hide');
                    makePaymentService.addClass(['confirmAccountTab_edit','enterAmountTab_edit'],'ng-hide');
                     angular.element('#paymentIframeTab_edit_icon span').removeClass('icon-clock-white').addClass('icon-exclaimation-white');

                   }, 1);
                     
                }else{
                    makePaymentService.addClass(['confirmAccountTab_h2','enterAmountTab_h2'],'accordion__header--complete');
                    makePaymentService.addClass(['paymentIframeTab_h2'],'accordion__header--current');
                }
            }else if($scope.tabPanel==="confirmAccountTab"){
                setTimeout(function(){ 
                     $('#confirmAccountTab_h2').addClass('accordion__header--current');
                  }, 1);
            }else if($scope.tabPanel==="enterAmountTab"){
                setTimeout(function(){ 
                $('#enterAmountTab_h2').addClass('accordion__header--current');
                 }, 1);
            } 

        };
        $scope.tabEdit=false;

        $scope.warningMessage=function(){
            var amount =  $('#amount').val(),allowed ='/^\d+\.\d{2}$/', maskRe = new RegExp('[' + allowed + ']');
            if(makePaymentService.instalmentPlan){
                if(isNaN(amount)|| amount==""){
                    $scope.amountValidationType = true;
                    $scope.warningMessageOutstandingBalance =false;
                    return false;
                }
                if(amount.indexOf(".")==-1){
                    amount = amount+".00";
                }
                if(!isNaN(amount)&& maskRe.test(amount)){
                    $scope.amountValidationType = false;
                    if(makePaymentService.instalmentMissed){
                        makePaymentService.minAmount = $scope.outstandingBalance;
                    }
                    $scope.warningMessageOutstandingBalance =+makePaymentService.minAmount>+amount;
                    $scope.warningMessageGreaterthan =+makePaymentService.minAmount<+amount;

                }
            }else{
                //advisor/customer
                if(isNaN(amount)|| amount=="" ){
                    $scope.amountValidationType = true;
                    $scope.finalBillReceivedWarning = $scope.warningMessageOutstandingBalance = false;
                    return false;
                }
                if(amount.indexOf(".")==-1){
                    amount = amount+".00";
                }
                if(!isNaN(amount)&& maskRe.test(amount)){
                    makePaymentService.amountValidation($scope,amount);
                   
                }else{
                    $scope.amountValidationType = true;
                    $scope.finalBillReceivedWarning =$scope.finalBillReceivedWarningBln=$scope.warningMessageOutstandingBalance= false;
                    return false;
                }
            }

        };

        //  LoggedOutMakePayment   Controller start  //
        $scope.onConfirmAccountSubmit = function() {
            //$scope.bac="GB09842843";
            $scope.confirmationBac = makePaymentService.bac=this.bac;
            var allRequest = makePaymentService.getAllLoggedOutRequest(makePaymentService.bac);
            allRequest.then(function (result) {
                var accountValidation = result.accountValidation;
                $scope.loading = false;
                var _fn_accountValidation = function(accountValidation){
                    if((accountValidation.status.indexOf("residential")!=-1)&& makePaymentService.bac===accountValidation.billingAccountNumber)
                    {
                        $('#confirmAccountTab_cBac').removeClass('ng-hide');
                        makePaymentService.setBillingAccount(makePaymentService.bac);
                        $scope.tabPanel = 'enterAmountTab';
                        makePaymentService.removeClass(['confirmAccountTab_edit','confirmAccountTab_edit_icon'],'ng-hide');
                        $('#confirmAccountTab_h2').addClass('accordion__header--complete');
                        $scope.amount="";

                    }
                    else if(accountValidation.status==="invalid" && makePaymentService.bac===accountValidation.billingAccountNumber) {
                        $scope.invalidAccount=true;
                        $scope.errortextboxcolor='red';
                    }
                    else if(accountValidation.status==="business" && makePaymentService.bac===accountValidation.billingAccountNumber) {
                        $scope.business = true;
                    }
                };

                _fn_accountValidation(accountValidation);

            },function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });
        };
        //  LoggedOutMakePayment   Controller end  //
        //  enterAmountTab    Controller start //
        $scope.disabledBtn = function(eventl){
            var allowed =/^(\w+)([\-+.][\w]+)*@(\w[\-\w]*\.){1,5}([A-Za-z]){2,6}$/,email= $('#loggedoutemail').val(),btn =$('#agent_email') ;
            if(email!=null && email!="" && email!=undefined && allowed.test(email)){
                btn.removeAttr('disabled');
            }else{
                btn.attr('disabled', 'disabled');
            }

        },
         $scope.emailValidation = function(eventl){

            var allowed =/^(\w+)([\-+.][\w]+)*@(\w[\-\w]*\.){1,5}([A-Za-z]){2,6}$/,email= $('#l_email_address').val(),continueBtn=angular.element('#submitButton');

             if((email!=null && email!="" && email!=undefined && allowed.test(email))|| email==""){
                $scope.emailWarningMessage=false;
            }else{
                  $scope.emailWarningMessage=true;
            }

        },

        $scope.emailChanged = function() {

            $scope.emailWarningMessage = false;
        }
        
        $scope.onAmountSubmit = function() {

            //  Validate the logged out customer's email

            if ($scope.loggedOut == true) {

                $scope.emailValidation();
            }

            // Remain on same page for logged out user and email valid validation
            if ($scope.emailWarningMessage == true && $scope.loggedOut == true) {

                return;
            }

            var amount =  $('#amount').val(),allowed ='/^\d+\.\d{2}$/', maskRe = new RegExp('[' + allowed + ']');
            if(makePaymentService.instalmentPlan){
                if(isNaN(amount)|| amount==""){
                    $scope.amountValidationType = true;
                    $scope.warningMessageOutstandingBalance =false;
                    return false;
                }
                if(amount.indexOf(".")==-1){
                    amount = amount+".00";
                }
                if(!isNaN(amount)&& maskRe.test(amount)){
                    $scope.amountValidationType = false;
                    if(makePaymentService.instalmentMissed){
                        makePaymentService.minAmount = $scope.outstandingBalance;
                    }
                    $scope.warningMessageOutstandingBalance =+makePaymentService.minAmount>+amount;
                    if($scope.warningMessageOutstandingBalance){
                        //return false;
                    }

                }
            }else{
                //advisor/customer
                if(isNaN(amount)|| amount=="" ){
                    $scope.amountValidationType = true;
                    $scope.finalBillReceivedWarning = $scope.warningMessageOutstandingBalance = false;
                    return false;
                }
                if(amount.indexOf(".")==-1){
                    amount = amount+".00";
                }
                if(!isNaN(amount)&& maskRe.test(amount)){
                    $scope.amountValidationType = false;
                    if($scope.userType===constants.AGENT|| $scope.userType===constants.CUSTOMER){

                        if($scope.finalBillReceived!=undefined && $scope.finalBillReceived!=null){
                            if( $scope.finalBillReceived==='N'){
                                if($scope.nextInstalmentAmountActive && $scope.activeInstalmentAmount!=null && $scope.activeInstalmentAmount!=undefined && +amount < +$scope.activeInstalmentAmount){
                                    $scope.warningMessageOutstandingBalance =true;
                                   // return false;
                                }else if(!(amount>=1)){
                                    $scope.finalBillReceivedWarning = $scope.finalBillReceivedWarningBln=true;
                                    $scope.warningMessageOutstandingBalance = false;
                                    return false;
                                }
                            }else{
                                if($scope.nextInstalmentAmountActive && $scope.activeInstalmentAmount!=null && $scope.activeInstalmentAmount!=undefined && +amount < +$scope.activeInstalmentAmount){
                                        $scope.warningMessageOutstandingBalance =true;
                                       // return false;
                                }else if(!(amount>0))
                                {
                                    $scope.finalBillReceivedWarning = $scope.finalBillReceivedWarningBln=true;
                                    $scope.warningMessageOutstandingBalance = false;
                                    return false;
                                }
                            }

                        }


                    }else{
                        if(isNaN(amount)|| amount=="" || amount<1 ){
                            $scope.amountValidationType = true;
                            return false;
                        }
                    }
                }else{
                    $scope.amountValidationType = true;
                    $scope.finalBillReceivedWarning =  $scope.finalBillReceivedWarningBln= $scope.warningMessageOutstandingBalance=false;
                    return false;
                }

            }

            $scope.loading = true;

            makePaymentService.removeClass(['confirmAccountTab_edit','enterAmountTab_edit','confirmAccountTab_edit_icon','enterAmountTab_edit_icon','enterAmountTab_cAmount'],'ng-hide');
            makePaymentService.addClass(['confirmAccountTab_h2','enterAmountTab_h2'],'accordion__header--complete');
            $scope.confirmationAmount =$('#amount').val();

            var isLoggedOut = makePaymentService.loggedOut;
            makePaymentService._amount = $('#amount').val();
            makePaymentService._email = stateService.get("contactEmail");

            var thistleSuccessUrl;
            var thistleFailureUrl;
            var thistleCancelUrl;

            if($scope.userType === "customer" && typeof mybtApp !== "undefined"  && mybtApp.usingMobileApp){

                thistleSuccessUrl = constants.MOBILE_APP_MAKE_A_PAYMENT_THISTLE_SUCCESS_URL;
                thistleFailureUrl = constants.MOBILE_APP_MAKE_A_PAYMENT_THISTLE_FAILED_URL;
                thistleCancelUrl  = constants.MOBILE_APP_MAKE_A_PAYMENT_THISTLE_CANCELLED_URL;
            }
            else {

                thistleSuccessUrl = constants.MAKE_A_PAYMENT_THISTLE_SUCCESS_URL;
                thistleFailureUrl = constants.MAKE_A_PAYMENT_THISTLE_FAILED_URL;
                thistleCancelUrl = constants.MAKE_A_PAYMENT_THISTLE_CANCELLED_URL;
            }

            if (isLoggedOut) {
                thistlePaymentRequest = makePaymentThistleService.getInsecurePaymentRequest(makePaymentService.bac, $('#amount').val(), "GBP", $('#l_email_address').val()||null, null,
                    thistleSuccessUrl,
                    thistleFailureUrl,
                    thistleCancelUrl);
            } else {
                thistlePaymentRequest = makePaymentThistleService.getPaymentRequest($('#amount').val(), "GBP", stateService.get("contactEmail"), null,
                    thistleSuccessUrl,
                    thistleFailureUrl,
                    thistleCancelUrl,
                    makePaymentService.accKey);
            }
            $scope.hideframe=true;
            thistlePaymentRequest.then(function (result) {

                    //  Define the size of the Thistle iFrame
                    utilityService.defineThistleIframeHeight($scope);

                    $scope.thistleUrl = result.thistleUrl;
                    $scope.encodedXml = result.encodedXml;
                    $scope.tabPanel = 'paymentIframeTab';
                    $scope.loading = false;
                    postEncodedXml();
                },
                function(errorResult) {
                    console.log(errorLoggingService.errorToString(errorResult));
                    $location.path('/error');
                });


        };


        function postEncodedXml(){
            $timeout(function(){
                document.payform.submit();
            },500);
        };

        $scope.loaded =function(){
            $scope.loading = false;

            $scope.hideframe=false;
        }

        //  enterAmountTab    Controller end //
        //  paymentIframeTab   Controller  start //
        //  paymentIframeTab   Controller  end //
        //  paymentFailure   Controller  start //

        //  paymentFailure   Controller  end //


        $scope.onEditClick=function(tab) {
            $scope.tabPanel = tab;
            if (tab === 'confirmAccountTab') {
                makePaymentService.addClass([tab + '_edit',tab + '_edit_icon','enterAmountTab_edit','enterAmountTab_edit_icon'],'ng-hide');
                $('#' + tab + '_h2').addClass('accordion__header--current');
                $('#enterAmountTab_cAmount').addClass('ng-hide');
                $('#enterAmountTab_h2').removeClass('accordion__header--complete');
                $('#enterAmountTab_h2').removeClass('accordion__header--current');
                $('#paymentIframeTab_h2').removeClass('accordion__header--current--red').removeClass('accordion__header--current');
            }
            if (tab === 'enterAmountTab') {
                $('#' + tab + '_h2').removeClass('accordion__header--complete');
                makePaymentService.addClass([tab + '_edit',tab + '_edit_icon','paymentIframeTab_edit','paymentIframeTab_edit_icon'],'ng-hide');
                $('#' + tab + '_h2').addClass('accordion__header--current');
                $('#paymentIframeTab_h2').removeClass('accordion__header--complete');
                $('#paymentIframeTab_h2').removeClass('accordion__header--current--red');
                $('#paymentIframeTab_h2').removeClass('accordion__header--current');
            }

        }
    }


]);


instalmentPlanControllers.controller('MakePaymentThistleFailed', ['$scope', '$http', '$location','makePaymentService','makePaymentThistleService',
    function ($scope, $http, $location,makePaymentService,makePaymentThistleService) {
        $scope.connectionDetails = connection;

    }]);


