/**
 * Created by Neil Pullen on 5/6/15.
 */
var makePaymentServices = angular.module('makePaymentServices',[]);

makePaymentServices.factory('makePaymentService', ['$q', 'ajaxService', 'urlService', 'stateService','currentBillService', 
    function ($q, ajaxService, urlService, stateService,currentBillService) {
    var billingAccount = null;
    var minimumPaymentAmount = null;
    var minimumPaymentAmountCurrencyCode = null;
    var amount = null;
    var email = null;
    var phoneNumber = null;
    var loggedOut = false;

    return {
        getTabpanels:function(){
            return [
                {
                    'tabLabel':'confirm.account.tab',
                    'includeHtml':'templates/makepayment/loggedOutEnterBac.html',
                    'tab':constants.CONFIRM_ACCOUNT_TAB
                },{
                    'tabLabel':'enter.amount.tab',
                    'includeHtml':'templates/makepayment/enterAmount.html',
                    'tab':constants.ENTER_AMOUNT_TAB
                },{
                    'tabLabel':'make.payment.tab',
                    'includeHtml':'templates/makepayment/paymentIframe.html',
                    'tab':constants.PAYMENT_IFRAME_TAB
                },{
                    'tabLabel':'payment.summary.tab',
                    'includeHtml':'templates/makepayment/paymentSuccessful.html',
                    'tab':constants.PAYMENT_SUCCESSFUL
                }
            ];
        },
        searchParameter:function(location){
            location.search(constants.PAYMENT_REFERENCE_ID, null);
            location.search(constants.PAYMENT_DATE_TIME, null);
            location.search(constants.AMOUNT, null);
            location.search(constants.CURRENCY, null);
            location.search(constants.CARDHOLDER_NAME, null);
            location.search(constants.CARD_NUMBER, null);
            location.search(constants.PHONE_NUMBER, null);
            location.search(constants.EMAIL_SMALL, null);
            location.search(constants.CANCEL_URL, null);
            location.search(constants.FAILURE_URL, null);
            location.search(constants.SUCCESS_URL, null);
        },
        addClass:function(tabs,_class){
          angular.forEach(tabs,function(key,value){
              $('#'+key).addClass(_class);
          });
        },
        removeClass:function(tabs,_class){
            angular.forEach(tabs,function(key,value){
                $('#'+key).removeClass(_class);
            });
        },
        getPaymentThisleSessionLogged:function(routeParam,scope,actionTabs){
            var bac= routeParam.bac,conk= routeParam.conk,cak=routeParam.cak,acckey=routeParam.acckey;
            var advisorSuccess=false,loggedInSuccess=false,loggedOutSuccess=false,email=routeParam.email;
            if(bac!=null && bac!=undefined && conk!=null && conk!=undefined && cak!=null && cak!=undefined ){
                scope.advisorSuccess= !advisorSuccess;
            }else if(acckey!=null && acckey!=undefined){
                scope.loggedInSuccess= !loggedInSuccess;
            }else{
                scope.loggedOutSuccessAndEmailNotNull=!loggedOutSuccess && email!=="null";
                scope.loggedOutSuccess=!loggedOutSuccess;
            }
            if(conk!=null || conk!=undefined || cak!=null || cak!=undefined ||acckey!=null || acckey!=undefined){
                scope.actionTabs = actionTabs.slice(1);
            }else{
                scope.actionTabs = actionTabs;
            }
        },
        currentBillUsage:function(currentBill,_scope){
            _scope.paymentDueDate =currentBill.paymentDueDate==null?null: moment(currentBill.paymentDueDate).format('DD MMM YYYY');
            _scope.paymentDueDateDisplay =!(_scope.paymentDueDate ==null || _scope.paymentDueDate==undefined);
            _scope.finalBillReceived=currentBill.finalBillReceived;
            _scope.credit=currentBill.credit;
            _scope.outstandingBalance = currentBill.balance.amount.toFixed(2);
            _scope.accountNumber = _scope.confirmationBac;
            if(_scope.credit==="Y" && +_scope.outstandingBalance<0){
                _scope.excessAmount = true;
                _scope.amount="0.00";
                _scope.outstandingBalance = Math.abs(_scope.outstandingBalance);
                angular.element('#submitButton').attr("disabled", "disabled");
            }else if (_scope.credit==="Y" && Math.abs(_scope.outstandingBalance) === 0){
                _scope.outstandingBalanceZero = true; 
                _scope.amount="0.00";
            }else{
                _scope.excessAmount = false;
                _scope.amount=currentBill.balance.amount.toFixed(2);
            }
          
        },
        nextInstalmentBillUsage:function(nextInstalment,_scope){
           var _len=0,eligible= nextInstalment.eligible,accountStatus= nextInstalment.status,instalments =nextInstalment.instalments;
              if(instalments!=null ||instalments!=undefined){
               _len=instalments.length;
               if(accountStatus===constants.ACTIVE){
                   if(_len>0){
               for(var i=0;i<_len;i++){
                 var _row= instalments[i];
                 if(_row.status===constants.UNPAID && !_scope.activeInstalment){
                     _scope.activeInstalmentAmount = _row.amount.amount;
                      _scope.activeInstalmentDueDate = _row.date;
                     _scope.activeInstalment=true;
                 }
               }
           }
               }
               
              }
              
           
        },
        getPaymentDetails: function () {

            return {
                "billingAccount": billingAccount,
                "minimumPaymentAmount": minimumPaymentAmount,
                "amount": amount,
                "currencyCode": minimumPaymentAmountCurrencyCode,
                "email": email,
                "phoneNumber": phoneNumber,
                "loggedOut": loggedOut
            };
        },
        getAllLoggedInRequest:function(){
             var request ={
                currentBill: currentBillService.getBalanceForMakePayment()    
            };
            
            var deferred = $q.defer();
            $q.all(request).then(function(results) {
                    deferred.resolve(results);
                },
                function (errorResult) {
                    deferred.reject(errorResult);
                });
            return deferred.promise;
        },
        getNextInstalmentRequest:function(bac){
             var request ={
                nextInstalment: currentBillService.getNextInstalment(bac)    
            };
            var deferred = $q.defer();
            $q.all(request).then(function(results) {
                    deferred.resolve(results);
                },
                function (errorResult) {
                    deferred.reject(errorResult);
                });
            return deferred.promise;
        },
        getAllLoggedOutRequest:function(bac){
            var deferred = $q.defer();
           /* deferred.resolve({
                'status':'residential',
                'billingAccountNumber':'GB12345678'
            });*/
           $q.all({
                accountValidation: this.checkLoggedOutAccountValidation({"id":bac})
            }).then(function(results) {
                    deferred.resolve(results);
                },
                function (errorResult) {
                    deferred.reject(errorResult);
                });
            return deferred.promise;
        },
        getAllLoggedMinimumPaymentAmount:function(bac){
            var deferred = $q.defer();
            $q.all({
                paymentAmount: this.getMinimumPaymentAmount(bac)
            }).then(function(results) {
                    deferred.resolve(results);
                },
                function (errorResult) {
                    deferred.reject(errorResult);
                });
            return deferred.promise;
        },
        checkLoggedOutAccountValidation: function(postData) {

             var deferred = $q.defer();
             var url = urlService.getPublicPath() + urlService.checkLoggedOutAccountValidation();
             var checkLoggedOutAccountValidation = ajaxService.doPost(url, {}, postData);
             checkLoggedOutAccountValidation.then(function (result) {
                deferred.resolve(result);
             },function (errorResult) {
                deferred.reject(errorResult);
             });
             return deferred.promise;
        },
        getMinimumPaymentAmount: function(bac) {

            var deferred = $q.defer();
            minimumPaymentAmount = stateService.get('minimumPaymentAmount');
            minimumPaymentAmountCurrencyCode = stateService.get('minimumPaymentAmountCurrencyCode');
            if (minimumPaymentAmount != null) {

                //  Already have the minimum payment amount so return
                var cachedResult = {
                    "minimumPayment": minimumPaymentAmount,
                    "currencyCode": minimumPaymentAmountCurrencyCode
                };

                deferred.resolve(cachedResult);
            }
            else {
                var url = urlService.getPublicPath() + urlService.getMinimumPaymentAmountUrl(bac);
                var minimumPaymentAccountResponse = ajaxService.doGet(url, {});
                minimumPaymentAccountResponse.then(function (result) {

                    minimumPaymentAmount = result.minimumPayment;
                    minimumPaymentAmountCurrencyCode = result.currencyCode;
                    stateService.set('minimumPaymentAmount',minimumPaymentAmount);
                    stateService.set('minimumPaymentAmountCurrencyCode',minimumPaymentAmountCurrencyCode);
                    deferred.resolve(result);
                });
            }
            return deferred.promise;
        },
        setBillingAccount: function(bac) {
            billingAccount = bac;
        },
        notificationPost:function(scope,loggedoutemailVal){
                    var  postData={
                        "media":scope.notify===constants.EMAIL?'email':'sms',
                        "paymentToken": scope.paymenttoken,
                        "notificationToken":scope.notificationtoken
                    };
                    if(scope.loggedOutSuccess){
                        postData.recipient=loggedoutemailVal;
                    }
                    return postData;



        },
        notifyEmailOrSmsForAdvisor:function(notify,scope){

            scope.notify=notify;
            if(notify==='SMS'){
                scope.displayLabel="Mobile number";
                scope.emailPhone =scope.mobilePhoneNumber;
                scope.advisor_sms_notification=true;
                scope.advisor_email_notification=false;
            }else{
                scope.displayLabel ="Email address";
                scope.emailPhone =scope.email;
                scope.advisor_email_notification=true;
                scope.advisor_sms_notification=false;
            }

            scope.emailPhoneSelected =(scope.emailPhone!=""  &&  scope.emailPhone!=null && scope.emailPhone!=undefined)?false:true;

            if(scope.emailPhoneSelected){
                $('#email_agent').attr('disabled', 'disabled');
                $('#advisor_sms').attr('disabled', 'disabled');
            }else{
                $('#advisor_email').removeAttr('disabled');
                $('#advisor_sms').removeAttr('disabled');
            }


        },
        amountValidation:function(scope,amount){
             scope.amountValidationType = false;
             var submitBtn =angular.element('#submitButton');
             if(+amount===0){
               submitBtn.attr("disabled","disabled");  
             }else{
                  submitBtn.removeAttr("disabled");
             }
                 if(scope.userType===constants.CUSTOMER && scope.credit==="Y"){
                      
                  if(+amount>=1){
                        submitBtn.removeAttr("disabled");
                      }else{
                        submitBtn.attr("disabled","disabled");
                     }
                 }
                if(scope.excessAmount && +amount>=1){
                    submitBtn.removeAttr("disabled");
                }
                    if(scope.userType===constants.AGENT|| scope.userType===constants.CUSTOMER){
                        if(scope.finalBillReceived!=undefined && scope.finalBillReceived!=null){
                            if( scope.finalBillReceived==='N'){
                                if(amount>=1){
                                    scope.finalBillReceivedWarning =scope.finalBillReceivedWarningBln= false;
                                    if(scope.activeInstalmentAmount!=null ||scope.activeInstalmentAmount!=undefined){
                                        scope.warningMessageOutstandingBalance =!scope.excessAmount && +amount < +scope.activeInstalmentAmount;
                                     }else{
                                     scope.warningMessageOutstandingBalance =!scope.excessAmount && +amount < +scope.outstandingBalance;
  
                                    }

                                }else{
                                    scope.finalBillReceivedWarning = scope.finalBillReceivedWarningBln=true;
                                    scope.warningMessageOutstandingBalance = false;
                                    return false;
                                }
                            }else{
                                if(amount>0){
                                    scope.finalBillReceivedWarning =scope.finalBillReceivedWarningBln= false;
                                    if(scope.activeInstalmentAmount!=null ||scope.activeInstalmentAmount!=undefined){
                                        scope.warningMessageOutstandingBalance =!scope.excessAmount && +amount < +scope.activeInstalmentAmount;
                                     }else{
                                       scope.warningMessageOutstandingBalance =!scope.excessAmount && +amount < +scope.outstandingBalance;
                                    }
                                    submitBtn.removeAttr("disabled");
                                }else{
                                    scope.finalBillReceivedWarning = scope.finalBillReceivedWarningBln=true;
                                    scope.warningMessageOutstandingBalance = false;
                                    return false;
                                }
                            }

                        }


                    }else{//loggedout

                        if (isNaN(amount) || amount === "") {
                            scope.amountValidationType = true;
                            return false;
                        } else if (+amount < 1) {
                            scope.finalBillReceivedWarning = true;
                            return false;
                        }
                    }
        }

    };

}]);


makePaymentServices.factory('kcimEmailConfirmationService',['ajaxServiceWithToken','$q', 'urlService', 'ajaxService', 
    function(ajaxServiceWithToken,$q, urlService,ajaxService) {

    return {
        agentkciEmailRequest: function (post) {

            var deferred = $q.defer();

            var url = urlService.getSecurePath() + urlService.getKcimEmailConfirmationForUserUrl();

            var kcimEmailConfirmationResponse = ajaxServiceWithToken.doPost(url, {}, post);
            kcimEmailConfirmationResponse.then(function (result) {
                deferred.resolve(result);
            },function(error){
                deferred.reject(error);
            });

            return deferred.promise;
        },
        customerkciEmailRequest: function (post) {

            var deferred = $q.defer();

            var url = urlService.getPublicPath() + urlService.getKcimEmailConfirmationForCustomerUrl();

            var kcimEmailConfirmationResponse = ajaxService.doPost(url, {}, post);
            kcimEmailConfirmationResponse.then(function (result) {

                deferred.resolve(result);
            },function(error){
                deferred.reject(error);
            });

            return deferred.promise;
        }
    }
}]);


makePaymentServices.factory('paymentFriendlyNameService', ['ajaxServiceWithToken', '$q', 'urlService', function(ajaxServiceWithToken, $q, urlService) {

    return {
        getPaymentFriendlyDetails: function () {

            var deferred = $q.defer();
                var url = urlService.getSecurePath() + urlService.getAccountFriendlyNameUrl();
                var friendlyNameResponse = ajaxServiceWithToken.doGet(url, {});
                friendlyNameResponse.then(function (result) {
                    deferred.resolve(result);
                }, function (errorResult) {
                    deferred.reject(errorResult);
                });
            

            return deferred.promise;
        }
    }

}]);

instalmentPlanServices.factory('makePaymentThistleService', ['$q', 'ajaxServiceWithToken', 'urlService', 'ajaxService', function($q, ajaxServiceWithToken, urlService, ajaxService) {
    return {

        getInsecurePaymentRequest: function(bac, amount, currencyCode, email, sms, successUrl, failureUrl, cancelUrl) {

            var deferred = $q.defer();
            var url = urlService.getPublicPath() + urlService.getMakeInsecurePaymentRequestUrl(bac, amount, currencyCode, email, sms, successUrl, failureUrl, cancelUrl);

            var paymentRequestResponse = ajaxService.doGet(url, {});
            paymentRequestResponse.then(function (result) {
                deferred.resolve(result);
            }, function (errorResult) {
                deferred.reject(errorResult);
            });

            return deferred.promise;
        },

        getPaymentRequest: function (amount, currencyCode, email, phoneNumber, successUrl, failureUrl, cancelUrl,accKey) {

            var deferred = $q.defer();

            var url = urlService.getSecurePath() + urlService.getMakePaymentRequestUrl(amount, currencyCode, email, phoneNumber, successUrl, failureUrl, cancelUrl,accKey);

            var paymentRequestResponse = ajaxServiceWithToken.doGet(url, {});
            paymentRequestResponse.then(function (result) {
                deferred.resolve(result);
            }, function (errorResult) {
                deferred.reject(errorResult);
            });

            return deferred.promise;
        }
    }
}]);

makePaymentServices.factory('currentBillService', ['$q', 'ajaxServiceWithToken', 'urlService', 'stateService', function ($q, ajaxServiceWithToken, urlService, stateService) {
    return {

        getBalanceForMakePayment: function () {

            var deferred = $q.defer();
            var currentBill = stateService.get(constants.STATE_SERVICE_CURRENT_BALANCE);
            if (currentBill == null) {

                var url = urlService.getSecurePath() + urlService.getBalanceUrl();

                var currentBillResponse = ajaxServiceWithToken.doGet(url, {});
                currentBillResponse.then(function (result) {
                    stateService.set(constants.STATE_SERVICE_CURRENT_BALANCE, result);
                    deferred.resolve(result);
                }, function (errorResult) {
                    deferred.reject(errorResult);
                });
            }
            else {
                deferred.resolve(currentBill);
            }

            return deferred.promise;
        },
        getNextInstalment: function () {

             var deferred = $q.defer();
            // Check whether there is a stored instalment plan eligibility before making a ReST request
            var instalmentPlanEligibility = stateService.get(constants.STATE_SERVICE_VIEW_NEXT_INSTALMENT_PLAN);
            if (instalmentPlanEligibility === null ||instalmentPlanEligibility === undefined) {
               var url = urlService.getSecurePath() + urlService.viewNextInstalmentPlan();
                var instalmentPlanEligibilityResponse = ajaxServiceWithToken.doGet(url, {});
                instalmentPlanEligibilityResponse.then(function (result) {
                    // Store the instalment plan eligibility in state service for future use
                    stateService.set(constants.STATE_SERVICE_VIEW_NEXT_INSTALMENT_PLAN, result);
                    deferred.resolve(result);
                }, function (errorResult) {
                    deferred.reject(errorResult);
                });
            }
            else {
                deferred.resolve(instalmentPlanEligibility);
            }
            return deferred.promise;
        }
    };
}]);


