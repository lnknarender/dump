var homePageControllers = angular.module('homePageControllers', []);

appControllers.controller('LandingCtrl', ['$scope', 'stateService', '$location','verifyUserService', 'accessTokenService', 'removeSessionService', '$window', 'errorLoggingService', 'urlService', '$routeParams','makePaymentService',
    function ($scope, stateService, $location, verifyUserService, accessTokenService, removeSessionService, $window, errorLoggingService, urlService, $routeParams,makePaymentService) {

        $scope.agent ={
            cak: $routeParams.cak,
            conk: $routeParams.contact_id,
            bac: $routeParams.bill_num,
            telephone_num: $routeParams.telephone_num,
            agentEin: $routeParams.ein
        };
        $scope.user ={
            acc:'42497'
        };

        $scope.loginAsAgent = function(){

            $scope.agentSuccess = true;
            connection.userType = 'agent';
            $scope.loading = true;
            var verifyUserResponse = verifyUserService.verifyAgent( $scope.agent.cak , $scope.agent.conk, $scope.agent.bac);
            verifyUserResponse.then(function (result) {
                var userCredentials = result;

                if(userCredentials.verified == true){
                    var tokenResponse = accessTokenService.getToken();
                    tokenResponse.then(function (token) {

                        $location.path('/agentBillingHome/').search({bac: $scope.agent.bac ,cak: $scope.agent.cak, conk: $scope.agent.conk, telephone_num: $scope.agent.telephone_num, agentEin: $scope.agent.agentEin});
                    });
                }
                else{
                    $scope.agentSuccess = false;
                }
                $scope.loading = false;
            },

            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });

        };
        $scope.loginAsCustomer = function(){

            $scope.customerSuccess = true;
            connection.userType = 'customer';
            makePaymentService.loggedOut =false;
            var verifyUserResponse = verifyUserService.verifyCustomer($scope.user.acc);
            verifyUserResponse.then(function (result) {
                if (result.verified) {
                    $location.path('/customerBillingHome/').search({accKey: result.accKey});
                    stateService.set("contactEmail", result.emailAddress);
                }
                else {
                    $scope.customerSuccess = false;
                }
            },
            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });

        };
        $scope.loggedOutMakePayment = function(){
            connection.userType = '';
            makePaymentService.loggedOut=true;
            $location.path('/logoutmakepaymentindex');

        };

        $scope.reSetApp = function () {

            var removeSessionServiceResponse = removeSessionService.removeSession();
            removeSessionServiceResponse.then(function (result) {
                var userSessionData = result;
                if(userSessionData.sessions.length == 0) {
                    accessTokenService.removeToken();
                    var uri = window.location.pathname + "#/start";
                    $window.location = uri;
                    $window.location.reload(true);

                }
            });
        };

        //Reset service data on journey start
        stateService.reset();
    }
]);

appControllers.controller('CustomerHomeCtrl', ['$scope', '$http', '$location', 'removeSessionService', 'accessTokenService','$route', '$window','billAccountService','paymentFriendlyNameService','primaryContactService','makePaymentService', 'errorLoggingService','$routeParams','instalmentPlanEligibilityService',
    function ($scope, $http, $location, removeSessionService, accessTokenService, $route, $window,billAccountService,paymentFriendlyNameService,primaryContactService,makePaymentService, errorLoggingService,$routeParams,instalmentPlanEligibilityService) {
            var paymentFriendlyName = paymentFriendlyNameService.getPaymentFriendlyDetails();
             makePaymentService.accKey = instalmentPlanEligibilityService.accKey = $routeParams.accKey;
             paymentFriendlyName.then(function (result) {
                    var name = result.friendlyName;
                    if(name!=null && name!=undefined && name.length > 10){
                        name = name.substr(1, 10) + "...";
                    }
                    var billingAccount = result.billingAccount;
                     primaryContactService.userFriendlyName =   name + " - " + billingAccount;
                     primaryContactService.primaryContactBillingAccount = result.billingAccount;
                },function(errorResult) {
                    console.log(errorLoggingService.errorToString(errorResult));
                   });

        $scope.customerMakePayment = function () {
         makePaymentService.loggedOut=false;
            $location.path('/customermakepaymentpaymentindex');

        };

        $scope.customerBillPrefs = function () {
            billAccountService.confirmation=false;
            $location.path('/viewbillprefs/');

        };

        $scope.customerInstalmentPlan = function () {

            $location.path('/moretimetopay/');

        };

        $scope.customerViewPaymentMethod = function () {

            $location.path('/viewPaymentMethod/');

        },

        $scope.customerSignOut = function () {

            var removeSessionServiceResponse = removeSessionService.removeSession();
            removeSessionServiceResponse.then(function (result) {
                var userSessionData = result;
                if(userSessionData.sessions.length == 0) {
                    accessTokenService.removeToken();

                    var uri = window.location.pathname + "#/start";
                    $window.location = uri;
                    $window.location.reload(true);

                }
            });
        };
    }
]);

appControllers.controller('AgentHomeCtrl', ['$scope', '$http', '$location', 'removeSessionService', 'accessTokenService','$route', '$window','billAccountService','makePaymentService',
    function ($scope, $http, $location, removeSessionService, accessTokenService, $route, $window,billAccountService,makePaymentService) {

        $scope.agentMakePayment = function(){
            makePaymentService.loggedOut=false;
            $location.path('/agentmakepaymentindex');
        };

        $scope.agentBillPrefs = function(){
            billAccountService.confirmation=false;
            $location.path('/viewbillprefs/');
        };

        $scope.agentInstalmentPlan = function(){
            $location.path('/moretimetopay/');
        };
        
        $scope.isLive = function(){
            return connection.bptaLaunchUrl.indexOf("live.advisor.nat.bt.com") > 0;
        };

        $scope.agentSignOut = function () {

            var removeSessionServiceResponse = removeSessionService.removeSession();
            removeSessionServiceResponse.then(function (result) {
                var userSessionData = result;
                if(userSessionData.sessions.length == 0) {
                    accessTokenService.removeToken();

                    var uri = window.location.pathname + "#/start";
                    $window.location = uri;
                    $window.location.reload(true);

                }
            });
        };

        $scope.agentInviteCustomerOnline = function() {

            $location.path('/invitecustomeronline/');
        }

        $scope.agentViewPaymentMethod = function() {

            $location.path('/viewPaymentMethod/');
        }
    }
]);

