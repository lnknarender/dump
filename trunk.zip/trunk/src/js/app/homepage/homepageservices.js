var homePageServices = angular.module('homePageServices', []);

homePageServices.factory('verifyUserService', ['ajaxServiceWithToken', 'urlService', function(ajaxServiceWithToken, urlService) {
    return {
        verifyAgent: function (cak, conk, bac) {
            var url = urlService.getSecurePath() + urlService.verifyAgent(cak, conk, bac);
            return ajaxServiceWithToken.doGet(url, {});
        },
        verifyCustomer: function (acckey) {
            var url = urlService.getSecurePath() + urlService.verifyCustomer(acckey);
            return ajaxServiceWithToken.doGet(url, {});
        }
    };
}]);

homePageServices.factory('removeSessionService', ['ajaxServiceWithToken', 'urlService', function(ajaxServiceWithToken, urlService) {
    return {
        removeSession: function () {
            var url = urlService.getSecurePath() + urlService.removeAccessToken();
            return ajaxServiceWithToken.doGet(url, {});
        }
    };
}]);
