/**
 * Created by Andrew on 24/03/2016.
 */

(function () {

    angular.module('billingdashboardServices')
        .factory('billingdashboardHeadlineCustomKeyMessagesServices', BillingDashboardCustomKeyMessagesServices);

    BillingDashboardCustomKeyMessagesServices.$inject = ['utilityService'];

    function BillingDashboardCustomKeyMessagesServices(utilityService) {

        var displayMakePaymentButton = false;
        var displayMakePaymentLink = false;
        var displayDontNeedToDoAnything = false;
        var displayLastPaymentText = false;
        var displayDontNeedToUsingDebitCreditCard = false;
        var displayBeforeFirstBillText = true;

        return {

            /**
             * Get the display make payment button in the custom key message
             * @returns {string} Returns language bundle key
             */
            getDisplayMakePaymentButton: function () {

                return this.displayMakePaymentButton;
            },
            getDisplayMakePaymentLink: function () {

                return this.displayMakePaymentLink;
            },
            getDisplayDontNeedToDoAnything: function () {

                return this.displayDontNeedToDoAnything;
            },
            getDisplayLastPaymentText: function () {

                return this.displayLastPaymentText;
            },
            getDisplayDontNeedToUsingDebitCreditCard: function () {

                return this.displayDontNeedToUsingDebitCreditCard;
            },
            getDisplayBeforeFirstBillText: function () {

                return this.displayBeforeFirstBillText;
            },

            init: function(billingDashboardData) {

                //  Initialise flags to false
                this.displayMakePaymentButton = false;
                this.displayMakePaymentLink = false;
                this.displayDontNeedToDoAnything = false;
                this.displayLastPaymentText = false;
                this.displayDontNeedToUsingDebitCreditCard = false;
                this.displayBeforeFirstBillText = true;

                if (utilityService.isObjectNotUndefinedOrNotNull(billingDashboardData) &&
                    billingDashboardData.billType === constants.BEFORE_FIRST_BILL) {

                        this.displayBeforeFirstBillText = true;
                }

                //  Cash/Cheque and first/standard bill
                else if ((utilityService.isObjectNotUndefinedOrNotNull(billingDashboardData) &&
                          billingDashboardData.owe.paymentMethod === constants.PAYMENT_METHOD_CHEQUE_CASH) &&
                         (billingDashboardData.billType === constants.FIRST_BILL ||
                          billingDashboardData.billType === constants.STANDARD_BILL)) {

                              this.displayMakePaymentButton = (billingDashboardData.owe.balance.amount < 0) ? true : false;
                              this.displayMakePaymentLink = (billingDashboardData.owe.balance.amount >= 0) ? true : false;
                }
                //  Cash/Cheque and final bill
                else if (utilityService.isObjectNotUndefinedOrNotNull(billingDashboardData) &&
                         billingDashboardData.owe.paymentMethod === constants.PAYMENT_METHOD_CHEQUE_CASH &&
                         billingDashboardData.billType === constants.FINAL_BILL) {

                            this.displayMakePaymentButton = (billingDashboardData.owe.balance.amount < 0) ? true : false;
                }
                //  WBDD/MPP and first/standard bill
                else if (utilityService.isObjectNotUndefinedOrNotNull(billingDashboardData) &&
                        (billingDashboardData.owe.paymentMethod === constants.PAYMENT_METHOD_DIRECT_DEBIT ||
                         billingDashboardData.owe.paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN) &&
                        (billingDashboardData.billType === constants.FIRST_BILL ||
                         billingDashboardData.billType === constants.STANDARD_BILL)) {

                            this.displayDontNeedToDoAnything = true;
                }
                //  WBDD/MPP and final bill
                else if (utilityService.isObjectNotUndefinedOrNotNull(billingDashboardData) &&
                        (billingDashboardData.owe.paymentMethod === constants.PAYMENT_METHOD_DIRECT_DEBIT ||
                         billingDashboardData.owe.paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN) &&
                         billingDashboardData.billType === constants.FINAL_BILL) {

                            this.displayLastPaymentText = true;
                }
                //  CCRA and first/standard bill
                else if (utilityService.isObjectNotUndefinedOrNotNull(billingDashboardData) &&
                         billingDashboardData.owe.paymentMethod === constants.PAYMENT_METHOD_CCRA &&
                        (billingDashboardData.billType === constants.FIRST_BILL ||
                         billingDashboardData.billType === constants.STANDARD_BILL)) {

                            this.displayDontNeedToUsingDebitCreditCard = true;
                }
            }
        };
    }
})();
