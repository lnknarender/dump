/**
 * Created by Andrew on 08/03/2016.
 */

angular.module('billingdashboardServices', []);