/**
 * Created by Andrew on 24/03/2016.
 */

(function () {

    angular.module('billingdashboardServices')
        .factory('billingdashboardHeadlineNotificationServices', BillingDashboardHeadlineNotificationServices);

    function BillingDashboardHeadlineNotificationServices() {

       var languageKey;
       var alertType;

        return {

            /**
             * Get the language bundle key for the headline notification
             * @returns {string} Returns language bundle key
             */
            getLanguageBundleKey: function () {

                return this.languageKey;
            },

            /**
             * Determines the headline notification banner
             * @param billingDashboardData
             * @returns {string}
             */
            getAlertType: function () {

                return this.alertType;
            },

            isMakePaymentCta: function () {

                //TODO: Logic need to be added here when the headline notification data is available
                return false;
            },

            isAccountInCredit: function (billingDashboardData) {

                if (billingDashboardData.owe.balance.amount > 0) {

                    return true;
                }

                return false;
            },

            init: function(billingDashboardData) {
                // Test in credit and first/standard bill
                if (this.isAccountInCredit(billingDashboardData) &&
                    (billingDashboardData.billType === constants.FIRST_BILL ||
                    billingDashboardData.billType === constants.STANDARD_BILL)) {

                    this.languageKey = constants.HEADING_NOTIFICATION_CREDIT_FIRST_STANDARD_BILL;
                    this.alertType = constants.AMBER_WARNING_ALERT;
                }
                // Test in credit and final bill
                else if (this.isAccountInCredit(billingDashboardData) &&
                    billingDashboardData.billType === constants.FINAL_BILL) {

                    this.languageKey = constants.HEADING_NOTIFICATION_CREDIT_FINAL_BILL;
                    this.alertType = constants.AMBER_WARNING_ALERT;
                }
            }
        };
    }
})();
