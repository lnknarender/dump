/**
 * Created by Andrew on 23/11/2015.
 */

(function () {


    angular.module('billingdashboardServices')
           .factory('billingdashboardServices', BillingDashboardServices);

    BillingDashboardServices.$inject = ['$q', 'ajaxServiceWithToken', 'stateService', 'utilityService', 'billingdashboardUrlServices', 'billingdashboardHeadlineNotificationServices', 'billingdashboardHeadlineCustomKeyMessagesServices'];

    function BillingDashboardServices($q, ajaxServiceWithToken, stateService, utilityService, billingdashboardUrlServices, billingdashboardHeadlineNotificationServices, billingdashboardHeadlineCustomKeyMessagesServices) {

        return {
            /**
             * Get the billing dashboard data. First call retrieves from server, subsequent call retrieves from
             * local storage
             * @returns {promise} Returns billing dashboard response as a promise
             */
            getBillingDashboard: function () {

                var deferred = $q.defer();

                var billingDashboard = stateService.get(constants.STATE_SERVICE_BILLING_DASHBOARD);

                if (billingDashboard) {

                    //  Already have a billing dashboard so return it
                    deferred.resolve(billingDashboard);
                }
                else {

                    var url = billingdashboardUrlServices.getBillingDashboardUrl();

                    var billingPaymentResponse = ajaxServiceWithToken.doGet(url, {});

                    billingPaymentResponse.then(function (result) {

                            stateService.set(constants.STATE_SERVICE_BILLING_DASHBOARD, result);
                            deferred.resolve(result);
                        },
                        function (errorResult) {
                            deferred.reject(errorResult);
                        });
                }

                return deferred.promise;
            },

            getPaymentMethodTitleSuffix: function (billingDashboard) {

                if (billingDashboard.owe.paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN &&
                    billingDashboard.owe.balance.amount === 0) {

                    return "mpp.zero.pound";
                }
                else if (billingDashboard.owe.paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN &&
                    billingDashboard.owe.balance.amount < 0) {

                    return "mpp.debit";
                }
                else if (billingDashboard.owe.paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN &&
                    billingDashboard.owe.balance.amount > 0) {

                    return "mpp.credit";
                }
                else if (billingDashboard.owe.paymentMethod !== constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN &&
                    billingDashboard.owe.balance.amount > 0) {

                    return "non.mpp.credit";
                }
                else if (billingDashboard.owe.paymentMethod !== constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN &&
                    billingDashboard.owe.balance.amount === 0) {

                    return "non.mpp.zero.pound";
                }

                return "non.mpp.debit";
            },

            /**
             * Determines whether the customer is billed quarterly
             * @param billingDashboard Billing dashboard data
             * @returns {boolean} Returns true when the customer is billed quarterly
             */
            isQuarterlyBill: function (billingDashboard) {

                if (billingDashboard !== undefined && billingDashboard.billFrequency === constants.BILL_QUARTERY) {

                    return true;
                }

                return false;
            },

            getCustomKeyMessage: function (billingDashboardData) {

                billingdashboardHeadlineCustomKeyMessagesServices.init(billingDashboardData);

                var customKeyMessage = {
                    "displayMakePaymentButton": billingdashboardHeadlineCustomKeyMessagesServices.getDisplayMakePaymentButton(),
                    "displayMakePaymentLink": billingdashboardHeadlineCustomKeyMessagesServices.getDisplayMakePaymentLink(),
                    "displayDontNeedToDoAnything": billingdashboardHeadlineCustomKeyMessagesServices.getDisplayDontNeedToDoAnything(),
                    "displayLastPaymentText": billingdashboardHeadlineCustomKeyMessagesServices.getDisplayLastPaymentText(),
                    "displayDontNeedToUsingDebitCreditCard": billingdashboardHeadlineCustomKeyMessagesServices.getDisplayDontNeedToUsingDebitCreditCard(),
                    "displayBeforeFirstBillText": billingdashboardHeadlineCustomKeyMessagesServices.getDisplayBeforeFirstBillText()
                };

                return customKeyMessage;
            },

            /**
             * Returns true when the account balance should be shown
             * @param billingDashboardData
             * @returns {boolean}
             */
            isShowAccountBalance: function (billingDashboardData) {

                //  Logic for "Before first bill"
                if (billingDashboardData.billType === constants.BEFORE_FIRST_BILL) {

                    return false;
                }
                //  Logic for "First or standard bill"
                else if (billingDashboardData.billType === constants.FIRST_BILL || billingDashboardData.billType === constants.STANDARD_BILL) {

                    return true;
                }
                //  Logic for "Final bill"
                else if (billingDashboardData.billType === constants.FINAL_BILL &&
                        (billingDashboardData.owe.paymentMethod === constants.PAYMENT_METHOD_CHEQUE_CASH ||
                         billingDashboardData.owe.paymentMethod === constants.PAYMENT_METHOD_DIRECT_DEBIT)) {

                    return true;
                }

                return false;
            },

            isAccountInCredit: function (billingDashboardData) {

                if (billingDashboardData.owe.balance.amount > 0) {

                    return true;
                }

                return false;
            },

            getHeadlineNotification: function (billingDashboardData) {

                //  Initialise the headline notification services. May be a clearer may of implementing this
                billingdashboardHeadlineNotificationServices.init(billingDashboardData);

                // Create headline notification
                var headlineNotification = {
                    "key":            billingdashboardHeadlineNotificationServices.getLanguageBundleKey(),
                    "alertType":      billingdashboardHeadlineNotificationServices.getAlertType(),
                    "ctaMakePayment": billingdashboardHeadlineNotificationServices.isMakePaymentCta()
                };

                return headlineNotification;
            }
        };
    }
})();