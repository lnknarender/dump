/**
 * Created by Andrew on 16/03/2016.
 */

(function () {


    angular.module('billingdashboardServices')
        .factory('billingdashboardUrlServices', BillingDashboardUrlServices);

    BillingDashboardUrlServices.$inject = ['$routeParams', 'urlService'];

    function BillingDashboardUrlServices($routeParams, urlService) {

        return {

            /**
             * Get the ReST URL for billing dashboard
             * @returns {string} Returns customer or agent ReST URL for billing dashboard
             */
            getBillingDashboardUrl: function () {

                if (angular.isDefined(connection.useMockData) && connection.useMockData === 'true' && connection.userType === constants.AGENT) {

                    return "http://consumer.bt.com/static/bpta/test/mockFiles/billingdashboard/billingdashboard_" + $routeParams.bac + ".json";
                }
                else if (angular.isDefined(connection.useMockData) && connection.useMockData === 'true' && connection.userType === constants.CUSTOMER) {

                    return "http://consumer.bt.com/static/bpta/test/mockFiles/billingdashboard/billingdashboard_" + $routeParams.accKey + ".json";
                }


                if (connection.userType === constants.AGENT) {
                    return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/billingdashboard';
                }

                return urlService.getSecurePath() + '/acckey/' + $routeParams.accKey + '/billingdashboard';
            }
        };
    }
})();