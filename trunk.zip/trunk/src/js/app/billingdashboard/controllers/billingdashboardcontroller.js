/**
 * Created by Andrew on 03/03/2016.
 */

(function () {

    angular.module('billingDashboardController').controller('billingDashboardCtrl', BillingDashboardController);

    BillingDashboardController.$inject = ['$location', 'accessTokenService', 'billingdashboardServices', 'errorLoggingService', 'utilityService', 'stateService', 'commonPaymentMethodServices', 'changePaymentMethodServices', 'urlService'];

    function BillingDashboardController($location, accessTokenService, billingdashboardServices, errorLoggingService, utilityService, stateService, commonPaymentMethodServices, changePaymentMethodServices, urlService) {

        var vm = this;

        //  Properties used by the HTML
        vm.userType = connection.userType;
        vm.isAdvsior = connection.userType === constants.AGENT ? true : false;
        vm.waitingForPageToLoad = true;
        vm.paymentMethodTitleSuffix = undefined;
        vm.paymentDay = undefined;
        vm.isPaymentQuarterly = undefined;
        vm.amountOwed = undefined;
        vm.invoiceAmount = undefined;
        vm.showAccountBalance = undefined;
        vm.isCashAndCheque = undefined;
        vm.headlineNotification = undefined;
        vm.constants = constants;

        //  Constants used by the HTML
        vm.amberBannerAlert = constants.AMBER_WARNING_ALERT;
        vm.firstBill = constants.BEFORE_FIRST_BILL;

        vm.timelinePaymentSuccessEventType = constants.BILLING_TIMELINE_EVENT_TYPE_PAYMENT;
        vm.timelinePaymentFailedEventType = constants.BILLING_TIMELINE_EVENT_TYPE_PAYMENT_FAILED;
        vm.timelinePaymentCancelledEventType = constants.BILLING_TIMELINE_EVENT_TYPE_PAYMENT_CANCELLED;
        vm.timelineRefundEventType = constants.BILLING_TIMELINE_EVENT_TYPE_REFUND;
        vm.timelineIndemnityEventType = constants.BILLING_TIMELINE_EVENT_TYPE_INDEMNITY;
        vm.timelineBillEventType = constants.BILLING_TIMELINE_EVENT_TYPE_BILL;
        vm.timelineInstalmentPlanEventType = constants.BILLING_TIMELINE_EVENT_TYPE_INSTALMENT_PLAN;
        vm.timelinePaymentMethodEventType = constants.BILLING_TIMELINE_EVENT_TYPE_PAYMENT_METHOD;

        //  Internal methods (functions)
        vm.init = init;

        //  Methods (functions) used by the HTML
        vm.clickMakePayment = clickMakePayment;
        vm.clickPaymentMethods = clickPaymentMethods;
        vm.customKeyMessage = customKeyMessage;
        vm.clickChangeHowIamBilled = clickChangeHowIamBilled;
        vm.clickSetupDirectDebit = clickSetupDirectDebit;
        vm.clickChangeBillingAddress = clickChangeBillingAddress;
        vm.clickViewInstalmentPlans = clickViewInstalmentPlans;

        //  Call function to initialise the controller
        init();

        /**
         * Initialise this controller
         */
        function init() {

            //  Clear previous billing dashboard data
            stateService.reset("constants.STATE_SERVICE_BILLING_DASHBOARD");

            //  Get a token then get the billing dashboard data
            accessTokenService.getToken().then(getBillingDashboardData).then(dashboardSuccess, dashboardError);
        }

        /**
         * Make an Ajax call to retrieve the billing dashboard data
         * @returns {*|promise}
         */
        function getBillingDashboardData() {

            return billingdashboardServices.getBillingDashboard();
        }

        /**
         * Function call when successful promise returned by getBillingDashboard function
         * @param response Response from Ajax call to get billing dashboard data
         */
        function dashboardSuccess(response) {

            vm.billingDashboardData = response;

            vm.paymentMethodTitleSuffix = billingdashboardServices.getPaymentMethodTitleSuffix(vm.billingDashboardData);
            vm.paymentDay = utilityService.getOrdinalNumber(vm.billingDashboardData.owe.paymentDay);

            vm.isPaymentQuarterly = billingdashboardServices.isQuarterlyBill(vm.billingDashboardData);
            vm.amountOwed = utilityService.splitMoneyPoundsAndPence(vm.billingDashboardData.owe.balance.amount);
            vm.invoiceAmount = utilityService.splitMoneyPoundsAndPence(vm.billingDashboardData.billing.invoiceAmount.amount);
            vm.showAccountBalance = billingdashboardServices.isShowAccountBalance(vm.billingDashboardData);
            vm.isCashAndCheque = (vm.billingDashboardData.paymentMethod === constants.PAYMENT_METHOD_CHEQUE_CASH) ? true : false;
            vm.headlineNotification = billingdashboardServices.getHeadlineNotification(vm.billingDashboardData);

            //  Disable the spinner
            vm.waitingForPageToLoad = false;
        }

        /**
         * Function call when unsuccessful promise returned by getBillingDashboard function
         * @param response Unsuccessful response from Ajax call to get billing dashboard data
         */
        function dashboardError(response) {

            vm.loading = false;
            errorLoggingService.errorToString(response);

            $location.path(urlService.getErrorUrl());
        }

        /**
         * Returns an object with custom key data
         * @returns {*|{displayMakePaymentButton, displayMakePaymentLink, displayDontNeedToDoAnything, displayLastPaymentText, displayDontNeedToUsingDebitCreditCard}}
         */
        function customKeyMessage() {

            console.log("customKeyMessage = " + billingdashboardServices.getCustomKeyMessage(vm.billingDashboardData));

            return billingdashboardServices.getCustomKeyMessage(vm.billingDashboardData);
        }

        /**
         * Function called when clicking "Make payment" button
         */
        function clickMakePayment() {

            if (vm.userType === constants.AGENT) {
                $location.path('/agentmakepaymentindex');
            }

            $location.path('/customermakepaymentpaymentindex');
        }

        /**
         * Function called on click of "Manage payment method" link
         */
        function clickPaymentMethods() {

            $location.path('/viewPaymentMethod');
        }

        /**
         * Function called on click of "Change how I'm billed" link
         */
        function clickChangeHowIamBilled() {

            $location.path('/viewbillprefs');
        }

        /**
         * Function called when clicking "Setup Direct Debit" button
         */
        function clickSetupDirectDebit() {

            commonPaymentMethodServices.getAllRequest(connection.userType).then(setupDirectDebit);
        }

        function setupDirectDebit(result) {

            //  TODO: This is duplicated code as per viewpaymentmethodcontroller (clickChangeToWbdd),
            //  TODO: hence this code should be refactored into a common service
            commonPaymentMethodServices.paymentMethods = result.viewPaymentMethods;

            if (connection.userType === constants.AGENT) {
                commonPaymentMethodServices.primaryContactDetails = result.primaryContactDetails;
                stateService.set("contactEmail", result.primaryContactDetails.email);
            }
            var eligiblePaymentMethod = changePaymentMethodServices.displayEligiblePaymentMethods(commonPaymentMethodServices.paymentMethods, {});
            commonPaymentMethodServices.newSetupPaymentMethod = eligiblePaymentMethod.wbdd;
            commonPaymentMethodServices.newPaymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;

            $location.path('/setupWbddPaymentMethod');
        }

        /**
         * Function called on click of "Change billing address" link
         */
        function clickChangeBillingAddress() {

            //TODO: Implement Change billing address
        }

        function clickViewInstalmentPlans() {

            $location.path('/moretimetopay');
        }
    }
})();
