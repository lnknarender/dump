/**
 * Created by Mahesh Mandapati on 19/05/15.
 */

appServices.factory('stateService', function () {
    var data = {};
    return{
        set: function (key, value) {
            data[key] = value;
            return data[key];
        },
        get: function (key) {
            return data[key];
        },
        reset: function (key) {
            if (key) {
                delete data[key];
            } else {
                data = {};
            }
        }
    };
});