appServices.factory('thistleService', ['$q', 'ajaxServiceWithToken', 'urlService', 'stateService','ajaxService', function($q, ajaxServiceWithToken, urlService, stateService,ajaxService) {
    return {
        getGenericPaymentRequest: function (amount, currency, params, successUrl, failureUrl, cancelUrl) {

            var deferred = $q.defer();
            var url = urlService.getSecurePath() + urlService.getGenericPaymentRequestUrl(amount, currency, params, successUrl, failureUrl, cancelUrl);

            var paymentRequestResponse = ajaxServiceWithToken.doGet(url, {});
            paymentRequestResponse.then(function (result) {
                stateService.set('thistle', result);
                deferred.resolve(result);
            }, function (errorResult) {
                deferred.reject(errorResult);
            });

            return deferred.promise;
        },

        getPaymentRequest: function (amount, currency, startDate, endDate, frequency, instalmentTotal, instalmentTotalCurrency, successUrl, failureUrl, cancelUrl) {

            var deferred = $q.defer();

            var url = urlService.getSecurePath() + urlService.getPaymentRequestUrl(amount, currency, startDate, endDate, frequency, instalmentTotal, instalmentTotalCurrency, successUrl, failureUrl, cancelUrl);

            var paymentRequestResponse = ajaxServiceWithToken.doGet(url, {});
            paymentRequestResponse.then(function (result) {
                stateService.set('thistle', result);
                deferred.resolve(result);
            }, function (errorResult) {
                deferred.reject(errorResult);
            });

            return deferred.promise;
        },

        getInstalmentPaymentRequest: function (amount, currency, successUrl, failureUrl, cancelUrl, repaymentPlan) {

            var deferred = $q.defer();

            var url = urlService.getSecurePath() + urlService.getInstalmentPaymentRequestUrl(amount, currency, successUrl, failureUrl, cancelUrl, repaymentPlan);

            var instalmentPaymentRequestResponse = ajaxServiceWithToken.doGet(url, {});
            instalmentPaymentRequestResponse.then(function (result) {
                stateService.set('thistle', result);
                deferred.resolve(result);
            }, function (errorResult) {
                deferred.reject(errorResult);
            });

            return deferred.promise;
        },

        getInstalmentPaymentRequestByPost: function (amount, currency,email, successUrl, failureUrl, cancelUrl, repaymentPlan) {

            var deferred = $q.defer();

            var url = urlService.getSecurePath() + urlService.getInstalmentPaymentRequestUrlByPost(amount, currency,email,successUrl, failureUrl, cancelUrl);
            
            var instalmentPaymentRequestResponse = ajaxServiceWithToken.doPost(url, {}, repaymentPlan);
            instalmentPaymentRequestResponse.then(function (result) {
                stateService.set('thistle', result);
                deferred.resolve(result);
            }, function (errorResult) {
                deferred.reject(errorResult);
            });

            return deferred.promise;
        },

        getCardManagementRequest: function (successUrl, failureUrl, cancelUrl) {

            var deferred = $q.defer();
            var url = urlService.getSecurePath() + urlService.getCardManagementRequest(successUrl, failureUrl, cancelUrl);

            var response = ajaxServiceWithToken.doGet(url, {});
            response.then(function (result) {
                stateService.set('thistle', result);
                deferred.resolve(result);
            }, function (errorResult) {
                deferred.reject(errorResult);
            });

            return deferred.promise;
        },

        getValidateCardRequest: function (params, successUrl, failureUrl, cancelUrl) {

            var deferred = $q.defer();
            var url = urlService.getSecurePath() + urlService.getValidateCardRequest(params, successUrl, failureUrl, cancelUrl);

            var response = ajaxServiceWithToken.doGet(url, {});
            response.then(function (result) {
                stateService.set('thistle', result);
                deferred.resolve(result);
            }, function (errorResult) {
                deferred.reject(errorResult);
            });

            return deferred.promise;
        }

    };
}]);