appServices.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.interceptors.push('httpErrorInterceptor');
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
    $httpProvider.defaults.headers.put['Content-Type'] = 'application/json; charset=utf-8';
}]);

appServices.factory('httpErrorInterceptor', ['$q', 'urlService', 
    function ($q, urlService) {

        function getLoginURL() {
            return urlService.getSecurePath() +
                urlService.getRedirectURL() +
                '?url=' + encodeURIComponent(window.top.location.href);
        }

        return {
            'request': function(config) {
                // do something on success
                if(connection.userType === "agent"){
                    $.removeCookie("SMSESSION", {
                        domain : '.bt.com',
                        path : '/'
                    });
                }
                return config;
            },
            'responseError': function (rejection) {
                // Gets executed for all ajax errors.
                // Handle the error and return the error response for bespoke handling in services/controllers
                if (rejection.status === 401 && rejection.data && rejection.data.status === "302") {
                    //Take the user to login page
                    if (rejection.data.location.indexOf("accessdenied.html") > -1) {
                        location.href = rejection.data.location;
                    } else if (connection.userType === "agent" && $.cookie("SMSESSION") && $.cookie("SMSESSION") !== "LOGGEDOFF") {
                        rejection.data.refresh = true;
                    } else {
                        //Take the user to login page
                        window.top.location.href = getLoginURL();
                    }
                }

                return $q.reject(rejection);
            }
        };
    }]);

appServices.factory('ajaxService', ['$http', '$q','$timeout', 'urlService',
    function ($http, $q, $timeout, urlService) {

        var config = {
            //withCredentials: true, commented this as IE8 doesn't support this property when native xml http is disabaled.
            timeout: 30000
        };

        function doPerform(method, url, params, postData, def, retry) {
            if (IframeHelper.busy) {
                $timeout(function () {
                    doPerform(method, url, params, postData, def);
                }, 500);
            } else {
                $http({
                    method: method,
                    url: url,
                    params: params,
                    data: postData,
                    //withCredentials: config.withCredentials,
                    timeout: config.timeout
                }).
                    success(function (data, status, headers, config) {
                        def.resolve(data);
                    }).
                     error(function (data, status, headers, config) {
                        if (data && data.refresh && !retry) {
                            IframeHelper.refresh(function () {
                                doPerform(method, url, params, postData, def, true);
                            }, urlService.getSecurePath() +  urlService.getAccessTokenUrl());
                        } else {
                            def.reject(data);
                        }
                    });
            }
        }

        return {
            doGet: function (url, params) {
                var deferred = $q.defer();
                doPerform("GET", url, params, null, deferred);
                return deferred.promise;
            },
            doDelete: function (url, params) {
                var deferred = $q.defer();
                doPerform("DELETE", url, params, null, deferred);
                return deferred.promise;
            },
            doPost: function (url, params, data) {
                var deferred = $q.defer();
                doPerform("POST", url, params, data, deferred);
                return deferred.promise;
            },
            doPut: function (url, params, data) {
                var deferred = $q.defer();
                doPerform("PUT", url, params, data, deferred);
                return deferred.promise;
            }
        };
    }]);

appServices.factory('ajaxServiceWithToken',
    ['$q', 'ajaxService', 'accessTokenService', 'stateService',
        function ($q, ajaxService, accessTokenService, stateService) {
            var loadingAccessToken = false;
            var ajaxRequestQueue = [];
            return{
                doGet: function (uri, params) {
                    var deferred = $q.defer();
                    doPerform(function (accessToken) {
                        params.tok = accessToken;
                        ajaxService.doGet(uri, params).then(
                                function(data){
                                    deferred.resolve(data);
                                },function(error){
                                    deferred.reject(error);
                                });
                    }, function (error) {
                        
                    });

                    return deferred.promise;
                },
                doDelete: function (uri, params) {
                    var deferred = $q.defer();
                    doPerform(function (accessToken) {
                        params.tok = accessToken;
                        ajaxService.doDelete(uri, params).then(
                                function(data){
                                    deferred.resolve(data);
                                },function(error){
                                    deferred.reject(error);
                                });
                    }, function (error) {
                        deferred.reject(error);
                    });

                    return deferred.promise;
                },
                doPost: function (uri, params, data) {
                    var deferred = $q.defer();
                    doPerform(function (accessToken) {
                        params.tok = accessToken;
                        ajaxService.doPost(uri, params, data).then(
                                function(data){
                                    deferred.resolve(data);
                                },function(error){
                                    deferred.reject(error);
                                });
                    }, function (error) {
                        deferred.reject(error);
                    });

                    return deferred.promise;
                },
                doPut: function (uri, params, data) {
                    var deferred = $q.defer();
                    doPerform(function (accessToken) {
                        params.tok = accessToken;
                        ajaxService.doPut(uri, params, data).then(
                                function(data){
                                    deferred.resolve(data);
                                },function(error){
                                    deferred.reject(error);
                                });
                    }, function (error) {
                        deferred.reject(error);
                    });

                    return deferred.promise;
                }
            };

            function doPerform(res, rej) {
				var accessTokenResult = stateService.get('accessToken');
				if (accessTokenResult === undefined || accessTokenResult === null) {
					if (loadingAccessToken) {
						ajaxRequestQueue.push({
							success: res,
							error: rej
						});
					} else {
						loadingAccessToken = true;
						ajaxRequestQueue.push({
							success: res,
							error: rej
						});
						accessTokenService.getToken().then(function (result) {
							loadingAccessToken = false;
							angular.forEach(ajaxRequestQueue, function (request) {
								request.success(result.accessToken);
							});
                            ajaxRequestQueue = [];
						}, function (errorResult) {
							loadingAccessToken = false;
							angular.forEach(ajaxRequestQueue, function (request) {
								request.error(errorResult);
							});
                            ajaxRequestQueue = [];
						});
					}
				} else {
					res(accessTokenResult.accessToken);
				}
			}
        }]);
