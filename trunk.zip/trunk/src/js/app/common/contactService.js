appServices.factory('primaryContactService', ['$q', 'ajaxServiceWithToken', 'urlService', function($q, ajaxServiceWithToken, urlService) {

    var contactDetails = null;

    return {

        getContactDetails: function () {

            var deferred = $q.defer();

            if (contactDetails != null) {

                //  Already have a contact details so return it
                deferred.resolve(contactDetails);
            }
            else {
                var url = urlService.getSecurePath() + urlService.getPrimaryContactUrl();

                ajaxServiceWithToken.doGet(url, {}).then(function (result) {
                    contactDetails = result;
                    deferred.resolve(result);
                }, function (errorResult) {
                    deferred.reject(errorResult);
                });
            }
            return deferred.promise;
        }
    };
}]);