/**
 * Created by Andrew on 26/11/2015.
 */
appServices.factory('utilityService', ['$q', 'stateService', 'verifyUserService', '$filter', function($q, stateService, verifyUserService, $filter) {

    return {

        /**
         * Convert to an ordinal number (e.g 1 => 1st, 2 => 2nd, 3 => 3rd etc)
         * @returns an ordinal number
         */
        getOrdinalNumber: function (number) {

            if (angular.isDefined(number) && number != null) {
                var suffix = ["th", "st", "nd", "rd"];
                var v = number % 100;
                var ordinalNumber = number + (suffix[(v - 20) % 10] || suffix[v] || suffix[0]);

                return ordinalNumber;
            }

            return "";
        },

        /**
         * Formats the date as a credit card expiry date (e.g. 2015-10-13 => 10/15)
         * @param creditCardDate Credit card date, format should be YYYY-MM-DD (e.g. 2015-10-13)
         * @returns {*} Returns date in credit card format (e.g. 10/15)
         */
        getCreditCardExpiryDate: function(creditCardDate) {

            // The isDefined function does not check for NULL, at least using the version 1.2.28 of AngularJS
            if (angular.isDefined(creditCardDate) && creditCardDate != null) {
                var date = moment(creditCardDate, "YYYY-MM-DD");
                var formattedDate = date.format('MM') + '/' + date.format('YY');

                return formattedDate;
            }

            return undefined;
        },
        getBankAccountNumber:function(bankAccountNumber){
            return ["****",bankAccountNumber.substring(4)].join("");
        },
        /**
         * Returns the appropriate CSS class for the accordion tab
         * @param status Accordion status (i.e. not started, current, complete or error)
         * @returns {string} Returns CSS class
         */
        getAccordionCSSClass: function(status) {

            if (status == constants.ACCORDION_NOT_STARTED) {

                return constants.ACCORDION_CSS_NOT_STARTED;
            }
            else if (status == constants.ACCORDION_CURRENT) {

                return constants.ACCORDION_CSS_CURRENT;
            }
            else if (status == constants.ACCORDION_WARNING) {

                return constants.ACCORDION_CSS_WARNING;
            }

            return constants.ACCORDION_CSS_COMPLETE;
        },
        getButtonCSSClass: function(status) {

            if (status === constants.BUTTON_SELECTED) {

                return constants.BUTTON_CSS_SELECTED;
            }
            else if (status === constants.BUTTON_UNSELECTED) {

                return constants.BUTTON_CSS_UNSELECTED;
            }else if (status === constants.BUTTON_ICON_TICK_SELECTED) {

                return constants.BUTTON_CSS_ICON_TICK;
            }else if (status === constants.BUTTON_ICON_TICK_UNSELECTED) {

                return constants.BUTTON_CSS_UN_ICON_TICK;
            }else if (status === constants.BUTTON_BLUE_SELECTED) {

                return constants.BUTTON_CSS_BLUE;
            }

        },
        getCssIconTick:function(status){
            if (status === constants.ACCORDION_WARNING_ICON_TICK) {

                return constants.ACCORDION_WARNING_CSS_ICON_TICK;
            }else if (status === constants.ACCORDION_COMPLETE_ICON_TICK) {

                return constants.ACCORDION_COMPLETE_CSS_ICON_TICK;
            }
        },
        /**
         * Shows or hides the accordion via the HTML id depending on the status
         * @param status Accordion status (ACCORDION_NOT_STARTED, ACCORDION_CURRENT, ACCORDION_COMPLETE)
         * @param htmlId HTML id of the accordion tab
         */
        expandOrCollapseAccordionBasedOnStatus: function(status, htmlId) {
            var item = $("#" + htmlId);
            if (status === constants.ACCORDION_CURRENT ||status===constants.ACCORDION_WARNING) {
                item.collapse('show');
            }
            else {
                item.collapse('hide');
            }
        },
        removeAndAddClass: function(item,removeClass,addClass) {
            if(removeClass!==null){
                item.removeClass(this.getButtonCSSClass(removeClass));
            }
            if(addClass!==null){
                item.addClass(this.getButtonCSSClass(addClass));
            }


        },
        onSelectionButton:function(buttonSelected,iconTick,idCompair,_idCompair){
            if(idCompair===_idCompair){
                this.removeAndAddClass(buttonSelected,constants.BUTTON_UNSELECTED,constants.BUTTON_SELECTED);
                this.removeAndAddClass(iconTick,null,constants.BUTTON_ICON_TICK_SELECTED);
            }else{
                if(buttonSelected.hasClass(constants.BUTTON_CSS_SELECTED)){
                    this.removeAndAddClass(buttonSelected,constants.BUTTON_SELECTED,constants.BUTTON_UNSELECTED);
                    this.removeAndAddClass(iconTick,constants.BUTTON_ICON_TICK_SELECTED,null);
                }

            }
        },
        defaultSelectionButton:function(buttonSelected,iconTick){

            this.removeAndAddClass(buttonSelected,constants.BUTTON_SELECTED,constants.BUTTON_UNSELECTED);
            this.removeAndAddClass(iconTick,constants.BUTTON_ICON_TICK_SELECTED,null);

        },
        /**
         * Define the size of the Thistle iFrame. The iFrame needs to be higher for login customer as
         * this will display saved cards
         * @param scope AngularJS scope
         */
        defineThistleIframeHeight: function(scope) {

            scope.thistleIFrameHeight = constants.THISTLE_IFRAME_HEIGHT_LOGIN_CUSTOMER;

            if (scope.loggedOut == true || scope.userType === constants.AGENT) {

                scope.thistleIFrameHeight = constants.THISTLE_IFRAME_HEIGHT;
            }
        },

        /**
         * Toogles the chevron for the 'accordion' link
         * @param number HTML id of the chevron
         */
        toggleChevron: function (number, scope) {

            var chevronId = "#chevron" + number;

            if ($(chevronId).hasClass('icon-down-chevron')) {
                $(chevronId).removeClass('icon-down-chevron').addClass('icon-up-chevron');

                scope.displayHorizontalRule = false;
            }
            else {
                $(chevronId).removeClass('icon-up-chevron').addClass('icon-down-chevron');
                scope.displayHorizontalRule = true;
            }
        },
        isEqual: function(val1,val2){
            return val1===val2;
        },
        getCreditCardInformation:function(scope,routeParams){
            angular.extend(scope,{
                paymentReference:  routeParams.paymentReferenceId,
                paymentDateTime : routeParams.paymentDateTime,
                accountNumber : routeParams.bac,
                amount : routeParams.amount,
                currency : routeParams.currency,
                cardType : routeParams.cardType===constants.CARD_DELTA?constants.CARD_VISA_DEBIT:routeParams.cardType,
                nameOnCard : routeParams.cardHolderName,
                cardNumber : routeParams.cardNumber,
                expiryDate : routeParams.expiryDate,
                securityCode : '***',
                paymenttoken : routeParams.paymenttoken,
                notificationtoken :  routeParams.notificationtoken,
                postCode : routeParams.cardHolderPostCode,
                email : routeParams.email
            });

        },
        getBankDetailsInformation: function (scope, paymentDay, paymentFrequency, bankDetails) {
            scope.directDebit = {};
            var sortCode = bankDetails.sortCode;
            if (sortCode.code1 && sortCode.code2 && sortCode.code3) {
                sortCode = [sortCode.code1, sortCode.code2, sortCode.code3].join("-");
            } else if (sortCode.length === 6) {
                sortCode = sortCode.match(/\d{1,2}/g).join("-");
            }
            angular.extend(scope.directDebit, {
                paymentDay: this.getOrdinalNumber(paymentDay),
                paymentFrequency: constants[paymentFrequency],
                accountHolderName: bankDetails.accountHolderName,
                bankAccountNumber: bankDetails.bankAccountNumber,
                sortCode: sortCode
            });
        },
        getBankDetailsOnly:function(scope,bankDetails){
            scope.directDebit={};
            var sortCode =bankDetails.sortCode;
            angular.extend(scope.directDebit,{
                accountHolderName : bankDetails.accountHolderName,
                bankAccountNumber : bankDetails.bankAccountNumber,
                sortCode : [sortCode.code1,sortCode.code2,sortCode.code3].join("-")
            });

        },
        getAddressInformation:function(scope,address){
            scope.address={};
            angular.extend(scope.address,{
                name: address.name,
                addressLine1 : address.buildingName,
                addressLine2 : address.buildingNumber,
                townOrCity : address.postTown,
                county : address.county,
                postCode : address.postCode
            });
        },
        isEmptyObject:function(object){
            return (object!==null  && object!=="" && object!==undefined);
        },

        //  Returns true if the object is undefined or null
        isObjectUndefinedOrNull:function(object){
            return (object === undefined || object === null);
        },

        //  Returns true if the object is not undefined or not null
        isObjectNotUndefinedOrNotNull:function(object){
            return (!this.isObjectUndefinedOrNull(object));
        },

        getPaymentFriendlyName: function(paymentFriendlyNameService, primaryContactService, errorLoggingService) {

            var deferred = $q.defer();

            var paymentFriendlyName = stateService.get(constants.STATE_SERVICE_PAYMENT_FRIENDLY_NAME);

            if (paymentFriendlyName) {

                //  Already have a paymentFriendlyName so return it
                deferred.resolve(paymentFriendlyName);
            }
            else {
                paymentFriendlyName = paymentFriendlyNameService.getPaymentFriendlyDetails();

                paymentFriendlyName.then(function (result) {
                    var name = result.friendlyName;
                    if(name!=null && name!=undefined && name.length > 10){
                        name = name.substr(0, 10) + "...";
                    }

                    var billingAccount = result.billingAccount;
                    primaryContactService.userFriendlyName =   name + " - " + billingAccount;
                    primaryContactService.primaryContactBillingAccount = result.billingAccount;
                    stateService.set(constants.STATE_SERVICE_PAYMENT_FRIENDLY_NAME, primaryContactService);
                    deferred.resolve(primaryContactService);
                },function(errorResult) {
                    console.log(errorLoggingService.errorToString(errorResult));
                    deferred.reject(errorResult);
                });
            }
            return deferred.promise;
        },

        getCustomerEmailAddress: function(userAccount) {

            var deferred = $q.defer();

            var contactEmail = stateService.get(constants.STATE_SERVICE_CONTACT_EMAIL);

            if (contactEmail) {
                deferred.resolve(contactEmail);
            } else {

                var verifyUserResponse = verifyUserService.verifyCustomer(userAccount);
                verifyUserResponse.then(function (result) {
                    if (result.verified) {
                        stateService.set(constants.STATE_SERVICE_CONTACT_EMAIL, result.emailAddress);
                        deferred.resolve(result.emailAddress);
                    }
                },
                function (errorResult) {
                    deferred.reject(errorResult);
                });
            }

            return deferred.promise;
        },

        closeThis: function(thisId){

            $("#" + thisId).hide();

        },

        /**
         * Derive the bill cycle from the next bill date
         * @param nextPaymentDate (.i.e. 2015-10-20)
         * @returns Return the bill cycle
         */
        getBillCycle: function(nextPaymentDate) {

            if (nextPaymentDate != null && nextPaymentDate !== undefined && nextPaymentDate.length === 10) {
                return parseInt(nextPaymentDate.substring(8, 10), 10);
            }

            return null;
        },

        // nextPaymentDate is a string of format YYYY-MM-DD
        getBillCyclePlusDays: function(nextPaymentDate, days) {

            if (nextPaymentDate) {
                var theDateInMs = moment(nextPaymentDate, "YYYY-MM-DD").toDate().getTime();
                var daysInMs = days * constants.MILLISECONDS_IN_A_DAY;
                var theDatePlusDays = new Date(theDateInMs + daysInMs);

                return theDatePlusDays.getDate();
            }

            return null;
        },

        isTwoDatesWithinDifference: function(firstDate, secondDate, differenceInDays) {

            var endDate = moment(secondDate, "YYYY-MM-DD");

            var startDatePlusDifference = moment(firstDate, "YYYY-MM-DD").add(differenceInDays, 'days');

            if (startDatePlusDifference >= endDate) {

                return true;
            }

            return false;
        },

        //  Look-up error type, error prefix and message using the errorkey
        getOmnitureError: function(errorKey) {

            //  Get the Omniture error message from the language bundle (i.e. locale-en.json)
            var message = $filter("translate")(errorKey);

            //  Get the Omniture error type and error prefix from the Omniture.json
            var typeKey = errorKey + ".type";
            var prefixKey = errorKey + ".prefix";

            var type = omniture[typeKey];
            var prefix = omniture[prefixKey];

            return ([{errorType:    type,
                errorPrefix:  prefix,
                errorMessage: message}]);
        },

        splitMoneyPoundsAndPence: function(amount) {

            if (this.isObjectNotUndefinedOrNotNull(amount)) {

                // Convert to positive number before converting to a string
                var splitAmount = Math.abs(amount).toString().split(".");

                if (splitAmount.length > 1) {

                    var pence = splitAmount[1] + "0";

                    return {"pounds": splitAmount[0],
                        "pence":  pence.substring(0, 2)};
                }
                else {

                    return {"pounds": splitAmount[0],
                        "pence":  "00"};
                }
            }

            return undefined;
        }

    };
}]);