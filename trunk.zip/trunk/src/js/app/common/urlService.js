appServices.factory('hostService', function() {

    function isXDomain() {
        var e = -1;
        if ("Microsoft Internet Explorer" == navigator.appName) {
            var r = navigator.userAgent,
                t = new RegExp("MSIE ([0-9]{1,}[.0-9]{0,})");
            null != t.exec(r) && (e = parseFloat(RegExp.$1));
        }
        return window.XDomainRequest && e <= 9;
    }

    return {
        getHost: function () {
            if (isXDomain) {
                return connection.iehost;
            }
            return connection.host;
        }
    };

});

appServices.factory('urlService', ['$routeParams', 'hostService', function($routeParams, hostService) {

    return {
        getSecurePath: function(){
            return hostService.getHost() + connection.protectedTypeUri + connection.version;
        },
        
        getPublicPath: function(){
            return hostService.getHost() + connection.publicTypeUri + connection.version;
        },

        getBillAccountUrl: function () {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac;
            }

            return '/acckey/' + this.getAccountKeyFromUrl();
        },
        getMediaAndFormatOptions: function () {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac +'/mediaandformatoptions';
            }

            return '/acckey/' + $routeParams.accKey+'/mediaandformatoptions';
        },
        getDaysUntilNextBillUrl: function () {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/bill/next';
            }

            return '/acckey/' + $routeParams.accKey + '/bill/next';
        },

        getChargesUrl: function () {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/charges';
            }

            return '/acckey/' + $routeParams.accKey + '/charges';
        },

        getPaymentRequestUrl: function(amount, currency, startDate, endDate, frequency, instalmentTotal, instalmentTotalCurrency, successUrl, failureUrl, cancelUrl) {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/payment/' + amount + '/' + currency + '?telephone_num=' + $routeParams.telephone_num + '&ein=' + ($routeParams.agentEin||$routeParams.ein) + '&startDate=' + startDate + '&endDate=' + endDate + '&frequency=' + frequency + '&instalmentTotal=' + instalmentTotal + '&instalmentTotalCurrencyCode=' + instalmentTotalCurrency + '&successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl;
            }

            //TODO: Move this out into a service as it will be used in many places. The issue is
            //      due to EIM using accKey on the URL but BPTA passes acckey between the
            //      client and Java ReST service
            var accountKey;
            if ($routeParams.accKey != undefined) {

                accountKey = $routeParams.accKey;
            }
            else {
                accountKey = $routeParams.acckey;
            }

            return '/acckey/' + accountKey + '/payment/' + amount + '/' + currency + '?startDate=' + startDate + '&endDate=' + endDate + '&frequency=' + frequency + '&instalmentTotal=' + instalmentTotal + '&instalmentTotalCurrencyCode=' + instalmentTotalCurrency + '&successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl;
        },

        getGenericPaymentRequestUrl: function(amount, currency, params, successUrl, failureUrl, cancelUrl) {

            urlParams = "";

            for (var prop in params) {
                urlParams = urlParams + "&" + prop + "=" + params[prop];
            }

            if (connection.userType === 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/payment/' + amount + '/' + currency + '?telephone_num=' + $routeParams.telephone_num + '&ein=' + ($routeParams.agentEin||$routeParams.ein) + '&successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl + urlParams;
            }

            //TODO: Move this out into a service as it will be used in many places. The issue is
            //      due to EIM using accKey on the URL but BPTA passes acckey between the
            //      client and Java ReST service
            var accountKey;
            if ($routeParams.accKey != undefined) {

                accountKey = $routeParams.accKey;
            }
            else {
                accountKey = $routeParams.acckey;
            }

            return '/acckey/' + accountKey + '/payment/' + amount + '/' + currency + '?successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl + urlParams;
        },

        getInstalmentPaymentRequestUrl: function(amount, currency, successUrl, failureUrl, cancelUrl, repaymentPlan) {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/payment/' + amount + '/' + currency + '?successUrl=' + successUrl +'&telephone_num=' + $routeParams.telephone_num + '&ein=' +($routeParams.agentEin||$routeParams.ein) +'&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl + '&repaymentPlan=' + repaymentPlan;
            }

            return '/acckey/' + $routeParams.accKey + '/payment/' + amount + '/' + currency + '?successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl + '&repaymentPlan=' + repaymentPlan;
        },
           getInstalmentPaymentRequestUrlByPost: function(amount, currency, email, successUrl, failureUrl, cancelUrl) {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/payment/' + amount + '/' + currency + '?successUrl=' + successUrl +'&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl+'&telephone_num=' + $routeParams.telephone_num + '&ein=' + ($routeParams.agentEin||$routeParams.ein);
            }

            return '/acckey/' + $routeParams.accKey + '/payment/' + amount + '/' + currency + '?successUrl=' + successUrl +'&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl+'?email=' + email;
        },

        getCardManagementRequest: function(successUrl, failureUrl, cancelUrl) {

            // Card management request has only a cancel button in the thistle iframe,
            // so need to pass the cancel url as the success url.
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/cardmanagement?telephone_num=' + $routeParams.telephone_num + '&ein=' + ($routeParams.agentEin||$routeParams.ein) + '&successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl;
            }

            //TODO: Move this out into a service as it will be used in many places. The issue is
            //      due to EIM using accKey on the URL but BPTA passes acckey between the
            //      client and Java ReST service
            var accountKey;
            if ($routeParams.accKey != undefined) {

                accountKey = $routeParams.accKey;
            }
            else {
                accountKey = $routeParams.acckey;
            }

            return '/acckey/' + accountKey + '/cardmanagement?successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + successUrl;
        },

        getValidateCardRequest: function(params, successUrl, failureUrl, cancelUrl) {

            urlParams = "";

            for (var prop in params) {
                urlParams = urlParams + "&" + prop + "=" + params[prop];
            }

            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/validatecard?telephone_num=' + $routeParams.telephone_num + '&ein=' + ($routeParams.agentEin||$routeParams.ein) + '&successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl + urlParams;
            }

            //TODO: Move this out into a service as it will be used in many places. The issue is
            //      due to EIM using accKey on the URL but BPTA passes acckey between the
            //      client and Java ReST service
            var accountKey;
            if ($routeParams.accKey != undefined) {

                accountKey = $routeParams.accKey;
            }
            else {
                accountKey = $routeParams.acckey;
            }

            return '/acckey/' + accountKey + '/validatecard?successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl + urlParams;
        },

        getCancelReasonsUrl: function() {
            if (connection.userType == 'agent') {
                return '/account/cancellation/reasons/online?a'; // required to identify the request to traffic manager as an agent request
            }

            return '/account/cancellation/reasons/online';
        },

        getAccessTokenUrl: function() {
            if (connection.userType == 'agent') {
                return '/accesstoken?a'; // required to identify the request to traffic manager as an agent request
            }

            return '/accesstoken';
        },

        getBalanceUrl: function() {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/balance';
            }

            return '/acckey/' + this.getAccountKeyFromUrl() + '/balance';
        },
        queryRepaymentPlanBillUrl: function() {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/bill/repaymentplan/current';
            }

            return '/acckey/' + $routeParams.accKey + '/bill/repaymentplan/current';
        },

        getImpairmentUrl: function() {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/impairment';
            }

            return '/acckey/' + $routeParams.accKey + '/impairment';
        },
        getKcimEmailConfirmationForUserUrl: function() {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/notification';
            }

        },
          getKcimEmailConfirmationForCustomerUrl: function() {

            return  '/notification';

    },
        getPrimaryContactUrl: function() {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/primarycontact';
            }

            return ''; // primary contact for a customer is not supported; it's handled on the bpta web app
        },

        getAccountFriendlyNameUrl: function() {
            return '/acckey/' + this.getAccountKeyFromUrl() + '/friendly';
        },
        checkLoggedOutAccountValidation: function() {
            return  '/validatebillingaccount';
        },
        getMinimumPaymentAmountUrl: function(bac) {
            if (connection.userType == 'agent') {
                return '/minimumpaymentamount/' + bac + '?a'; // required to identify the request to traffic manager as an agent request
            }
            return '/minimumpaymentamount/' + bac;
        },

        verifyAgent: function(cak, conk, bac) {

            return '/verify/cak/' + cak + '/conk/' + conk + '/bac/' + bac;
        },

        verifyCustomer: function(accKey) {

            return '/verify/acckey/'+ this.getAccountKeyFromUrl();
        },

        getHomeUrl: function() {
            if (connection.userType == 'agent') {
                return '/agentBillingHome';
            }
            else if (connection.userType == 'customer') {
                return '/customerBillingHome';
            }
            return '/start';
        },
        getStartUrl: function() {
            return '/start';
        },
        getErrorUrl: function() {
            return '/error';
        },

        getMakePaymentRequestUrl: function(amount, currencyCode, email, phoneNumber, successUrl, failureUrl, cancelUrl,accKey) {

            if (connection.userType == 'agent') {

                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/payment/' + amount + '/' + currencyCode + '?telephone_num=' + $routeParams.agentDN + '&ein=' + ($routeParams.agentEin || $routeParams.ein) + '&email=' + email + '&phoneNumber=' + phoneNumber + '&successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl;
            }

            var accountKey;
            if ($routeParams.accKey != undefined) {

                accountKey = $routeParams.accKey;
            }
            else {
                accountKey = $routeParams.acckey;
            }

            return '/acckey/' + accountKey + '/payment/' + amount + '/' + currencyCode + '?email=' + email + '&phoneNumber=' + phoneNumber  + '&successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl;
        },

        getMakeInsecurePaymentRequestUrl: function(bac, amount, currencyCode, email, phoneNumber, successUrl, failureUrl, cancelUrl) {

            return '/bac/' + bac + '/payment/' + amount + '/' + currencyCode + '?email=' + email + '&phoneNumber=' + phoneNumber  + '&successUrl=' + successUrl + '&failureUrl=' + failureUrl + '&cancelUrl=' + cancelUrl;
        },

        removeAccessToken: function(){
            return '/accesstoken/remove';
        },

        getRedirectURL: function(){
            return '/redirect';
        },

         instalmentPlanFrequenciesUrl: function() {
            if (connection.userType == 'agent') {
                return '/frequencies/instalmentplan?a';
            }

            return '/frequencies/instalmentplan';
        },

        getInstalmentPlanEligibilityUrl: function(accKey) {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/eligible/instalmentplan';
            }
              var _accKey =$routeParams.accKey||accKey;
            return '/acckey/' + _accKey + '/eligible/instalmentplan';
        },

        createInstalmentPlanUrl: function() {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/create/instalmentplan';
            }

            return '/acckey/' + $routeParams.acckey + '/create/instalmentplan';
        },
         viewNextInstalmentPlan: function(accKey) {
             var _accKey =$routeParams.accKey||accKey;
            return '/acckey/' + _accKey + '/instalmentplan';
        },

        getAccountKeyFromUrl: function() {

            if ($routeParams.accKey != undefined) {

                return $routeParams.accKey;
            }
            else {
                return $routeParams.acckey;
            }
        }
    };
}]);