/**
 * Created by Andrew on 26/11/2015.
 */
appServices.factory('viewLatestBillService', ['$routeParams', function($routeParams) {

    return {

        /**
         * Get the customer's view payment URL
         * @returns Returns customer's view payment URL, returns undefined for advisor
         */
        getLatestBillLink: function () {

            var viewLatestBill=connection.viewLatestBill;
            if(angular.isDefined(viewLatestBill)  && connection.userType == constants.CUSTOMER){
                viewLatestBill = viewLatestBill.replace(/%ACC_KEY/g, $routeParams.accKey);

                return viewLatestBill;
            }

            return undefined;
        }

    };
}]);