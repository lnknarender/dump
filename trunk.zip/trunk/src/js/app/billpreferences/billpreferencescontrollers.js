/**
 * Created by Neil Pullen on 04/03/15.
 */

var appControllers = angular.module('appControllers', []);

appControllers.controller('ViewBillPrefsCtrl', ['$scope', 'billAccountService', '$location', 'cancelEBillService', 'accessTokenService', 'urlService', 'errorLoggingService','getModifiedPreferencesChargesService','primaryContactService', 'stateService','$routeParams', 'paymentFriendlyNameService', 'utilityService',
    function ($scope, billAccountService, $location, cancelEBillService, accessTokenService, urlService, errorLoggingService,getModifiedPreferencesChargesService,primaryContactService, stateService,$routeParams, paymentFriendlyNameService, utilityService) {

        if (connection.userType == constants.CUSTOMER) {

            var getPaymentFriendlyNameResponse = utilityService.getPaymentFriendlyName(paymentFriendlyNameService, primaryContactService, errorLoggingService);
            getPaymentFriendlyNameResponse.then(function (result) {

                $scope.userFriendlyName= result.userFriendlyName;
            });

            utilityService.getCustomerEmailAddress($routeParams.accKey, errorLoggingService);
        }

        var viewLastestBill=connection.viewLatestBill;
        if(angular.isDefined(viewLastestBill)){
            $scope.viewLastestBill = viewLastestBill.replace(/%ACC_KEY/g, $routeParams.accKey);
        }

        $scope.loading = true;
        $scope.userFriendlyName=primaryContactService.userFriendlyName;
        $scope.connectionDetails = connection;

        $scope.userType = connection.userType;

        if(billAccountService.confirmation){
            billAccountService.confirmation=false;
            //after confirm of change preferences
            $scope.modifiedAccount = billAccountService.getModifiedAccount();
            $scope.modifiedMedia = billAccountService.originalData.originalMedia!==billAccountService.modifiedData.media;
            $scope.modifiedFormat = billAccountService.originalData.originalFormat!==billAccountService.modifiedData.format;
            $scope.modifiedLanguage = billAccountService.originalData.originalLanguage!==billAccountService.modifiedData.language;
            $scope.modifiedBillItemisation = billAccountService.originalData.originalItemisation!==billAccountService.modifiedData.billItemisation;
            var _stateDivider= $scope.modifiedMedia+$scope.modifiedFormat+$scope.modifiedLanguage+$scope.modifiedBillItemisation;
            if(_stateDivider>1){
                $scope.stateDivider=true;
            }
            billAccountService.reset('account');
            var billAccountServiceResponse = billAccountService.submitModifiedAccount();
            billAccountServiceResponse.then(function (result) {
                    $scope.modifiedAccount = result;

                    $scope.modifyBillAccountDetails = billAccountService.getModifiedAccount();
                    var journey = billAccountService.getJourney(result.format!=constants.BLUE_BILL && $scope.connectionDetails.userType === constants.AGENT);
                    journey.then(function (result) {


                            angular.extend($scope,{
                                loading : false,
                                daysUntilNextBill :result.daysUntilNextBill,
                                charges :result.charges,
                                impairment : result.impairment,
                                billAccountDetails : $scope.modifiedAccount
                            });
                            //Logic after  the success call
                            var  display=billAccountService.displayMethod();

                            if ($scope.modifiedAccount != null) {
                                angular.extend($scope,{
                                    language :display[$scope.modifiedAccount.language],
                                    format : display[$scope.modifiedAccount.format],
                                    media : display[$scope.modifiedAccount.media]===constants.BY_POST?constants.IN_THE_POST:display[$scope.modifiedAccount.media],
                                    itemisationOption:billAccountService.getItemisationSuccessDisplay($scope.modifiedAccount)
                                });

                            }
                           $scope.itemisationSuccessThresholdAmount =billAccountService.getThresholdAmount($scope.modifiedAccount);
                           
                            var daysUntilNextBill = $scope.daysUntilNextBill;
                            angular.extend($scope,{
                                conditionDate :daysUntilNextBill>2?constants.GREATER_TWO_DAYS:constants.LESS_TWO_DAYS,
                                impairmentFlag :($scope.impairment && !$scope.impairment.impairmentFlag && $scope.billAccountDetails.format!=constants.BLUE_BILL)?true:false,
                                helpDeskReason : billAccountService.helpDeskReason,
                                chargesApply  :billAccountService.chargeApply($scope,billAccountService.originalCharges.amount,billAccountService.appliedCharges)
                            });

                            
                                var updatedFormat =$scope.modifiedAccount.media;
                                $scope.billingAddress =(updatedFormat===constants.PAPER || updatedFormat===constants.DUAL )||false;
                                if($scope.billingAddress){
                                    var address =$scope.modifiedAccount.address;
                                    var billingAddressDetails=[
                                        {'displayLabel':[address.buildingNumber,address.buildingName,address.thoroughfareName].join(" ")},
                                        {'displayLabel':address.dependentLocality},
                                        {'displayLabel':address.postTown},
                                        {'displayLabel':address.country},

                                        {'displayLabel':address.postCode}
                                    ];
                                    $scope.billingAddressDetails = billingAddressDetails;
                                }
                            
                            $scope.showAfterSuccess = function(){
                                return billAccountService.confirmation;
                            };

                            $scope.chargeMatrix = function(){
                                return billAccountService.chargeMatrix($scope.chargesApplicability, $scope.chargesApply, $scope.conditionDate);
                            };


                            var accessTokenResponse = accessTokenService.getToken();
                            accessTokenResponse.then(function (token) {
                                    var  modifyDetails= function(_token,_scope){

                                        return {
                                            "accessToken": _token.accessToken,
                                            "media": _scope.modifiedAccount.media,
                                            "format": _scope.modifiedAccount.format,
                                            "language": _scope.modifiedAccount.language,
                                            "itemisationOption":_scope.modifiedAccount.itemisationOption,
                                            "charges":{
                                                "amount":_scope.billAccountDetails.charges.amount,
                                                "currencyCode":_scope.billAccountDetails.charges.currencyCode,
                                                "applicable":_scope.billAccountDetails.charges.applicable
                                            },
                                            "cancel": {"media": null,
                                                "reason": { "code": null,
                                                    "reason": null
                                                }
                                            }
                                        };
                                    };
                                    var buttonClick= function(cancelBill,path){
                                        $scope.modifyBillAccountDetails = modifyDetails(token,$scope);
                                        billAccountService.setModifiedAccount($scope.modifyBillAccountDetails);
                                        cancelEBillService.setIsCancelEBill(cancelBill);
                                        $location.path(path);
                                    };
                                    $scope.changePreferences = function () {

                                        buttonClick(false,'/managebillprefs');

                                    };
                                    $scope.canceleBilling = function () {

                                        buttonClick(true,'/managebillprefssummary');

                                    };
                                },
                                function (errorResult) {
                                    console.log(errorLoggingService.errorToString(errorResult));
                                    $location.path(urlService.getErrorUrl());
                                });

                        },
                        function(errorResult) {
                            console.log(errorLoggingService.errorToString(errorResult));
                            $location.path(urlService.getErrorUrl());
                        });
                },
                function(errorResult) {
                    console.log(errorLoggingService.errorToString(errorResult));
                    $location.path(urlService.getErrorUrl());
                });

            $scope.backToMyBt= function(){
                return connection.backToMyBtUrl;
            };

            $scope.customerEmailAddress= function(){
                return stateService.get("contactEmail");
            };
        }else{
            $scope.billAccountDetails = null;

            var billAccountDetailsResponse = billAccountService.getAccount();

            billAccountDetailsResponse.then(function (result) {
                    if(result!=null && result.barred!=null && result.barred.status==="Closed"){
                        $scope.accountClosed=true;
                        $scope.loading = false;
                        return false;
                    }
                    
                    $scope.billAccountDetails = result;
                    var  display=billAccountService.displayMethod();

                    if ($scope.billAccountDetails != null) {
                        $scope.language =display[$scope.billAccountDetails.language];
                        $scope.format =display[$scope.billAccountDetails.format];
                        $scope.media =display[$scope.billAccountDetails.media]===constants.BY_POST?constants.IN_THE_POST:display[$scope.billAccountDetails.media];
                        $scope.itemisationOption=$scope.billAccountDetails.itemisationOption;
                        $scope.itemisation=billAccountService.getItemisationValue($scope.billAccountDetails.itemisationOption);
                        $scope.itemisationThresholdAmount =billAccountService.getThresholdAmount($scope.billAccountDetails);
                       
                        $scope.itemisationLabel=billAccountService.getItemisationLabel($scope.billAccountDetails.itemisationOption);
                        var accessTokenResponse = accessTokenService.getToken();
                        accessTokenResponse.then(function (token) {
                                var  modifyDetails= function(_token,_scope){

                                    return {
                                        "accessToken": _token.accessToken,
                                        "media": _scope.billAccountDetails.media,
                                        "format": _scope.billAccountDetails.format,
                                        "language": _scope.billAccountDetails.language,
                                        "itemisationOption":_scope.itemisationOption,
                                        "charges":{
                                            "amount":_scope.billAccountDetails.charges.amount,
                                            "currencyCode":_scope.billAccountDetails.charges.currencyCode,
                                            "applicable":_scope.billAccountDetails.charges.applicable
                                        },
                                        "cancel": {"media": null,
                                            "reason": { "code": null,
                                                "reason": null
                                            }
                                        },
                                        "billDetailsToken": _scope.billAccountDetails.billDetailsToken
                                    };
                                };
                                $scope.changePreferences = function () {
                                    $scope.modifyBillAccountDetails = modifyDetails(token,$scope);
                                    if($scope.modifyBillAccountDetails.itemisationOption===constants.BILL_ITEMISATION_CUSTOM_VIEW){
                                        $scope.modifyBillAccountDetails.itemisationThreshold=$scope.billAccountDetails.itemisationThreshold;
                                    }
                                    billAccountService.setModifiedAccount($scope.modifyBillAccountDetails);

                                    cancelEBillService.setIsCancelEBill(false);
                                    $location.path('/managebillprefs');
                                }
                                $scope.canceleBilling = function () {

                                    $scope.modifyBillAccountDetails = billAccountService.getModifiedAccount();

                                    $scope.modifyBillAccountDetails = modifyDetails(token,$scope);

                                    cancelEBillService.setIsCancelEBill(true);

                                    billAccountService.setModifiedAccount($scope.modifyBillAccountDetails);

                                    $location.path('/managebillprefssummary');
                                }
                            },
                            function (errorResult) {
                                console.log(errorLoggingService.errorToString(errorResult));
                                $location.path(urlService.getErrorUrl());
                            });

                    }
                    $scope.loading = false;
                },
                function(errorResult) {
                    console.log(errorLoggingService.errorToString(errorResult));
                    $location.path(urlService.getErrorUrl());
                })


        }
        $scope.back = function () {
            billAccountService.confirmation=false;
            $location.path(urlService.getHomeUrl());
        },

        $scope.closeThis=function(thisId){

            $("#" + thisId).hide();
        }
        
    }]);

appControllers.controller('ManageBillPrefsCtrl', ['$q','$scope', 'billAccountService', '$location', 'modifyBillPreferencesService', 'billingAccountStatusService', 'urlService', 'errorLoggingService','$routeParams', 'paymentFriendlyNameService', 'utilityService', 'primaryContactService',
    function ($q,$scope, billAccountService, $location, modifyBillPreferencesService, billingAccountStatusService, urlService, errorLoggingService,$routeParams,paymentFriendlyNameService, utilityService, primaryContactService) {
        $scope.loading = true;

        if (connection.userType == constants.CUSTOMER) {

            var getPaymentFriendlyNameResponse = utilityService.getPaymentFriendlyName(paymentFriendlyNameService, primaryContactService, errorLoggingService);
            getPaymentFriendlyNameResponse.then(function (result) {

                $scope.userFriendlyName= result.userFriendlyName;
            });

            utilityService.getCustomerEmailAddress($routeParams.accKey, errorLoggingService);
        }

        $scope.billPrefFormatChanged=true;
       $scope.billPrefLanguageChanged=true;
         var viewLastestBill=connection.viewLatestBill;
        if(angular.isDefined(viewLastestBill)){
            $scope.viewLastestBill = viewLastestBill.replace(/%ACC_KEY/g, $routeParams.accKey);
        }
        $scope.confirmationButton =true;
        var media_tick =[constants.PAPER_FREE,constants.DUAL,constants.PAPER],
            format_tick=[constants.BLUE_BILL,constants.BILL_LARGE_PRINT,constants.BILL_MEDIA_BRAILLE,constants.BILL_AUDIO_CD],
            language_tick=[constants.WEL,constants.ENG];
        $scope.inviteCustomeOnline=function(){
            $location.path('/invitecustomeronline/');
        };
        var results = billAccountService.getAllRequest();
        results.then(function (result) {
                var billAccountDetailsResponse = result.billAccountService;
                var mediaAndFormatOptions =result.mediaAndFormatOptions;
                   
                angular.extend($scope,{
                    billAccountDetails : billAccountDetailsResponse,
                    userType :connection.userType,
                    modifyBillAccountDetails : billAccountService.getModifiedAccount()
                });
                var originalMedia = $scope.billAccountDetails.media,originalFormat = $scope.billAccountDetails.format,
                    originalLanguage=$scope.billAccountDetails.language,originalItemisation=$scope.billAccountDetails.itemisationOption;
                angular.extend($scope,{
                    originalMedia :originalMedia,
                    originalFormat :originalFormat,
                    originalLanguage :originalLanguage,
                    originalItemisation:originalItemisation,
                    itemisationOptionValue:billAccountService.getManageItemisationDisplay({itemisationOption:originalItemisation}),
                    thresholdValue:$scope.billAccountDetails.itemisationThreshold.amount
                });
                 $scope.itemisationThresholdAmount =billAccountService.getThresholdAmount($scope.billAccountDetails);
                
                var formats=billAccountService.getFormatRules(mediaAndFormatOptions);
                billAccountService.setDefaultBillItemisation($scope,originalItemisation);
                billAccountService.originalCharges ={
                    amount:formats[originalMedia][originalLanguage][originalFormat],
                    currencyCode:$scope.billAccountDetails.charges.currencyCode,
                    applicable:$scope.billAccountDetails.charges.applicable
                };
                billAccountService.originalData ={
                    originalMedia:originalMedia,
                    originalFormat:originalFormat,
                    originalLanguage:originalLanguage,
                    originalItemisation:originalItemisation
                };
                $scope.showForAgentOnly =function(){
                    var   _modifiedMedia = $scope.modifyBillAccountDetails.media,
                        _modifiedLanguage = $scope.modifyBillAccountDetails.language,
                        _modifiedFormat =$scope.modifyBillAccountDetails.format,
                       _modifiedBillItemisation =$scope.modifyBillAccountDetails.itemisationOption;
                 billAccountService.modifiedData ={
                    media:$scope.modifyBillAccountDetails.media,
                    format:$scope.modifyBillAccountDetails.format,
                    language:$scope.modifyBillAccountDetails.language,
                    billItemisation:$scope.modifyBillAccountDetails.itemisationOption
                };
                    return ($scope.userType===constants.AGENT && (originalMedia!=_modifiedMedia || originalFormat !=_modifiedFormat || originalLanguage!=_modifiedLanguage || originalItemisation!=_modifiedBillItemisation));
                };
                $scope.checkMediaFormatRule=function(delivery,event,value,css){
                    if(!$scope.billPrefFormatChanged ||!$scope.billPrefLanguageChanged){
                        event.preventDefault();
                        return;
                    }
                    var formats=billAccountService.getFormatRules(mediaAndFormatOptions),
                            _modifiedMedia = $scope.modifyBillAccountDetails.media,
                        _modifiedLanguage = $scope.modifyBillAccountDetails.language,
                        _modifiedFormat =$scope.modifyBillAccountDetails.format,
                       _modifiedBillItemisation=$scope.modifyBillAccountDetails.itemisationOption;
                    var rulee =$('[id^="delivery-format"]'),length=rulee.length;
                        
                         billAccountService.deliveryChanged=delivery;
                         
                            if(delivery===constants.MEDIA_CHANGE){
                               _modifiedMedia = $scope.modifyBillAccountDetails.media =value;
                               var exist = formats[_modifiedMedia][_modifiedLanguage][_modifiedFormat];
                              if(exist===undefined || exist===null){
                                 $scope.formatPositionChanged =['decision-box-position-',$scope.copyFormatChanged].join("");
                                 $scope.formatChanged =$scope.copyFormatChanged;
                                  var formatObj =$('[id^="delivery-format"]  span' ),len=formatObj.length;
                                  for(var j=0;j<len;j++){
                                    var obj =$(formatObj[j]),exist = formats[_modifiedMedia][_modifiedLanguage][_modifiedFormat];
                                      if((exist===undefined || exist===null)&&$scope.copyFormatChanged===billAccountService.displayCSS()[_modifiedFormat]){
                                              var _cls=['decision-box-',$scope.copyFormatChanged].join("");
                                              obj.parent().addClass(_cls);
                                               obj.addClass($scope.copyFormatChanged);
                                      }

                                  } 
                            }
                         }else if(delivery===constants.LANGUAGE_CHANGE){
                               _modifiedLanguage = $scope.modifyBillAccountDetails.language=value;
                                 var exist = formats[_modifiedMedia][_modifiedLanguage][_modifiedFormat];
                              if(exist===undefined || exist===null){
                                    $scope.languagePositionChanged =['decision-box-position-',css].join("");
                                    $scope.languageChanged =css;
                                }
                                
                         }else if(delivery===constants.FORMAT_CHANGE){
                               _modifiedFormat = $scope.modifyBillAccountDetails.format=value;
                               $scope.copyFormatChanged=css;
                                 var exist = formats[_modifiedMedia][_modifiedLanguage][_modifiedFormat];
                              if(exist===undefined || exist===null){
                                $scope.formatPositionChanged =['decision-box-position-',css].join("");
                                $scope.formatChanged =css;
                            }
                             
                         }  
                         
                        
                        billAccountService.appliedCharges =formats[$scope.modifyBillAccountDetails.media][$scope.modifyBillAccountDetails.language][$scope.modifyBillAccountDetails.format];
                  var  ruleeMedia =$('[id^="delivery-method"]'),
                  ruleeFormat =$('[id^="delivery-format"]'),
                  ruleeLanguage =$('[id^="delivery-language"]'),
                  ruleeBillItemisation =$('[id^="bill_itemisation"]');
              var disableDeliverys=function(){
                         
                           billAccountService.disableDeliverys(ruleeFormat,_modifiedFormat);
                           billAccountService.disableDeliverys(ruleeMedia,_modifiedMedia);
                           billAccountService.disableDeliverys(ruleeLanguage,_modifiedLanguage);
                           billAccountService.disableDeliverys(ruleeBillItemisation,$scope.modifyBillAccountDetails.itemisationOption);
              };
                    if(delivery===constants.LANGUAGE_CHANGE){
                          $scope.billPrefFormatChanged=true;
                          
                        if(!angular.isDefined(formats[_modifiedMedia][_modifiedLanguage][_modifiedFormat])){
                            $scope.billPrefLanguageChanged=false;
                            $scope.confirmationButton =true;
                            disableDeliverys();
                           $scope.languageDecisionBox ="decision-box-space--language";
                        }else{   
                            $scope.billPrefLanguageChanged=true; 
                            $scope.confirmationButton =false;
                        }
                         
                    }else if(delivery===constants.FORMAT_CHANGE ||delivery===constants.MEDIA_CHANGE){
                        
                         
                         $scope.billPrefLanguageChanged=true;
                        
                        if(!angular.isDefined(formats[_modifiedMedia][_modifiedLanguage][_modifiedFormat])){
                            $scope.billPrefFormatChanged=false;
                            $scope.confirmationButton =true;
                            disableDeliverys();
                              $scope.formatDecisionBox ="decision-box-space--format";
                              if(_modifiedLanguage===constants.WEL && (constants.BILL_AUDIO_CD||constants.BILL_LARGE_PRINT||constants.BILL_LARGE_PRINT)){
                                  $scope.displayBoxLanguage= true;
                                   $scope.displayBoxFormat= false;
                              }else{
                                  $scope.displayBoxFormat= true;
                                  $scope.displayBoxLanguage= false;
                              }
                           
                        }else{   
                            $scope.billPrefFormatChanged=true; 
                            $scope.confirmationButton =false;
                        }
                        
                    }else{
                         $scope.billPrefFormatChanged=true;
                         $scope.billPrefLanguageChanged=true;
                    }
                   
                    $scope.mediaAndFormatRule =false;
                    $scope.mediaAndFormatCharge =0.0;
                    $scope.showMsgErrorDisplayDirective = false;
                    $scope.showSaveMsgDirective = $scope.showMsgErrorDisplay= false;
                     //    billAccountService.checkRulesForFormatMediaAndLanguage($scope.modifyBillAccountDetails,rulee,formats,_modifiedMedia,_modifiedLanguage,length);
                    billAccountService.applyBooleanForMsgAndErrorDirective($scope,billAccountService.originalCharges.amount,billAccountService.appliedCharges);
                    //check for the
                   var  _modifiedFormat =$scope.modifyBillAccountDetails.format;
                    angular.extend($scope,{
                        displayNewMedia :display[_modifiedMedia],
                        displayNewFormat : display[_modifiedFormat],
                        displayNewlanguage :display[_modifiedLanguage],
                        displayNewBillItemisation:billAccountService.getItemisationDisplay({itemisationOption:_modifiedBillItemisation})
                    });
                   
                    //right tick
                    var deliveryTick=$('[id^="delivery-method"]  span '),formatTick=$('[id^="delivery-format"]  span '),
                        languageTick=$('[id^="delivery-language"]  span '),deliveryTickLen=deliveryTick.length,
                        formatTickLen=formatTick.length,languageTicklen =languageTick.length,
                        _css=['decision-box-postonly','decision-box-online-only','decision-box-online-post','decision-box-standard','decision-box-large-print','decision-box-braille','decision-box-audiocd','decision-box-english','decision-box-welsh'];
                    var addRemoveClass=function(name,len,objList){
                        for(var j=0;j<len;j++){
                            var obj =$(objList[j]),data=obj.data()['name'];
                            if(data===name){
                                var exist = formats[_modifiedMedia][_modifiedLanguage][_modifiedFormat];
                              if(exist===undefined || exist===null){
                                  var _cls=['decision-box-',css].join("");
                                  obj.parent().addClass(_cls);
                              }
                                 
                                  obj.parent().removeClass('btn-main-unselected').addClass('btn-main-selected');
                              
                                obj.removeClass('ng-hide');
                                
                                 
                            }else{
                                var _parent = obj.parent();
                                 for(var ii=0,jj=_css.length;ii<jj;ii++){
                                     if(_parent.hasClass(_css[ii])){
                                         _parent.removeClass(_css[ii]);
                                     }
                                 }
                                
                                obj.addClass('ng-hide');
                                obj.parent().removeClass('btn-main-selected').addClass('btn-main-unselected');
                                
                            }
                        }
                    };

                    if(language_tick.indexOf(value)!=-1){
                        addRemoveClass(value,languageTicklen,languageTick);
                    }
                    if(media_tick.indexOf(value)!=-1){
                        addRemoveClass(value,deliveryTickLen,deliveryTick);
                      //  addRemoveClass($scope.modifyBillAccountDetails.format,formatTickLen,formatTick);

                    }
                    if(format_tick.indexOf(value)!=-1){
                        addRemoveClass(value,formatTickLen,formatTick);
                        
                    }
                    
      if(constants.BILL_ITEMISATION_CUSTOM_VIEW===$scope.modifyBillAccountDetails.itemisationOption && $scope.modifyBillAccountDetails.itemisationOption!=$scope.originalItemisation){
             var _item= angular.element('#custom_itemisation_warning');
                if(_item.val()>=+constants.BILL_ITEMISATION_THRESHOLD_MIN && _item.val()<+constants.BILL_ITEMISATION_THRESHOLD_MAX){
                      $scope.confirmationButton= false;     
            }else{
                $scope.confirmationButton=true;
            }
        }
                };

                var  arrayList=billAccountService.deliveryMethod(originalMedia),
                    format=billAccountService.formatMethod($scope,mediaAndFormatOptions,originalMedia,originalLanguage,originalFormat),
                    language=billAccountService.languageMethod(originalLanguage),
                    display=billAccountService.displayMethod();

                $scope.showAgentOldOnly=billAccountService.showAgentOldOnlyMethod(display,originalMedia,originalFormat,originalLanguage,originalItemisation);

                var barredStatus = $scope.billAccountDetails.barred;
                $scope.isAccountBarred = billingAccountStatusService.isAccountBarred(barredStatus);
                var  deliveryMethod =billAccountService.getDeliveredMethod($scope,arrayList,barredStatus);
                var formats=billAccountService.getFormatRules(mediaAndFormatOptions);
                billAccountService.appliedCharges =formats[$scope.modifyBillAccountDetails.media][$scope.modifyBillAccountDetails.language][$scope.modifyBillAccountDetails.format];
                if ($scope.modifyBillAccountDetails == null || $scope.modifyBillAccountDetails == undefined) {
                    $scope.modifyBillAccountDetails =
                    {
                        "media": $scope.billAccountDetails.media,
                        "format": $scope.billAccountDetails.format,
                        "language": $scope.billAccountDetails.language,
                        "itemisationOption":$scope.billAccountDetails.itemisationOption,
                        "cancel": {
                            "media": null,
                            "reason": {
                                "code": null,
                                "reason": null
                            }
                        }
                    }
                }
$scope.onBillPrefChange=function(change,btn){
        $scope.billPrefFormatChanged=true;
        $scope.billPrefLanguageChanged=true;
        var ruleeMedia =$('[id^="delivery-method"] '),
                  ruleeFormat =$('[id^="delivery-format"] '),
                  ruleeLanguage =$('[id^="delivery-language"] '),
                  ruleeBillItemisation =$('[id^="bill_itemisation"]'),
                 _defaultMedia = billAccountService.originalData.originalMedia,
                 _defaultFormat = billAccountService.originalData.originalFormat,
                _defaultLanguage = billAccountService.originalData.originalLanguage;
         billAccountService.enableDeliverys(ruleeFormat);
         billAccountService.enableDeliverys(ruleeMedia);
	billAccountService.enableDeliverys(ruleeLanguage);
        billAccountService.enableDeliverys(ruleeBillItemisation);
        $scope.languageDecisionBox ="";
        $scope.formatDecisionBox ="";
        $scope.languagePositionChanged ="";
        $scope.languageChanged ="";
	$scope.formatPositionChanged ="";
        $scope.formatChanged ="";
          if(change===constants.FORMAT_CHANGE){
              
              if(btn===constants.YES){
                  $scope.confirmationButton =false;
                 billAccountService.setDefaultOptions($scope.modifyBillAccountDetails,ruleeMedia,constants.DUAL,constants.MEDIA_CHANGE);
                 billAccountService.setDefaultOptions($scope.modifyBillAccountDetails,ruleeLanguage,constants.ENG,constants.LANGUAGE_CHANGE);
                 angular.extend($scope,{
                        displayNewMedia :constants.ONLINE_AND_BY_POST_DISPLAY,
                        displayNewlanguage :constants.ENGLISH
                    });      
        }
          }else if(change===constants.LANGUAGE_CHANGE){
              if(btn===constants.YES){
                  $scope.confirmationButton =false;
                   billAccountService.setDefaultOptions($scope.modifyBillAccountDetails,ruleeFormat,constants.BLUE_BILL,constants.FORMAT_CHANGE);
                    angular.extend($scope,{
                        displayNewFormat : constants.STANDARD
                    });
           }
          }
          
           if(btn===constants.NO){
                billAccountService.setDefaultOptions($scope.modifyBillAccountDetails,ruleeMedia,_defaultMedia,constants.MEDIA_CHANGE);
                billAccountService.setDefaultOptions($scope.modifyBillAccountDetails,ruleeFormat,_defaultFormat,constants.FORMAT_CHANGE);
                billAccountService.setDefaultOptions($scope.modifyBillAccountDetails,ruleeLanguage,_defaultLanguage,constants.LANGUAGE_CHANGE);
                $scope.confirmationButton=!($scope.modifyBillAccountDetails.itemisationOption!=$scope.originalItemisation || $scope.modifyBillAccountDetails.media!=$scope.originalMedia||$scope.modifyBillAccountDetails.format!=$scope.originalFormat || $scope.modifyBillAccountDetails.language!=$scope.originalLanguage);
           var display=billAccountService.displayMethod();        
           angular.extend($scope,{
                    displayNewMedia : display[$scope.originalMedia],
                    displayNewFormat :display[$scope.originalFormat],
                    displayNewlanguage :display[$scope.originalLanguage]
	});
        
        } 
             //right tick
             $scope.copyFormatChanged=billAccountService.displayCSS()[$scope.modifyBillAccountDetails.format];
            var media_tick =[constants.PAPER_FREE,constants.DUAL,constants.PAPER],
            format_tick=[constants.BLUE_BILL,constants.BILL_LARGE_PRINT,constants.BILL_MEDIA_BRAILLE,constants.BILL_AUDIO_CD],
            language_tick=[constants.WEL,constants.ENG];
                    var deliveryTick=$('[id^="delivery-method"]  span '),formatTick=$('[id^="delivery-format"]  span '),
                        languageTick=$('[id^="delivery-language"]  span '),deliveryTickLen=deliveryTick.length,
                        formatTickLen=formatTick.length,languageTicklen =languageTick.length,
                        _css= ['decision-box-postonly','decision-box-online-only','decision-box-online-post','decision-box-standard','decision-box-large-print','decision-box-braille','decision-box-audiocd','decision-box-english','decision-box-welsh'];
                    var addRemoveClass=function(name,len,objList){
                        for(var j=0;j<len;j++){
                            var obj =$(objList[j]),data=obj.data()['name'];
                            if(data===name){
                               obj.removeClass('ng-hide').parent().removeClass('btn-main-unselected').addClass('btn-main-selected');
                            }else{
                                obj.addClass('ng-hide').parent().removeClass('btn-main-selected').addClass('btn-main-unselected');
                            }
                            var _parent = obj.parent();
                                 for(var ii=0,jj=_css.length;ii<jj;ii++){
                                         _parent.removeClass(_css[ii]);
                                    
                                 }
                        }
                    };

                    if(language_tick.indexOf($scope.modifyBillAccountDetails.language)!=-1){
                        addRemoveClass($scope.modifyBillAccountDetails.language,languageTicklen,languageTick);
                    }
                    if(media_tick.indexOf($scope.modifyBillAccountDetails.media)!=-1){
                        addRemoveClass($scope.modifyBillAccountDetails.media,deliveryTickLen,deliveryTick);

                    }
                    if(format_tick.indexOf($scope.modifyBillAccountDetails.format)!=-1){
                        addRemoveClass($scope.modifyBillAccountDetails.format,formatTickLen,formatTick);
                    }      
    
        if(constants.BILL_ITEMISATION_CUSTOM_VIEW===$scope.modifyBillAccountDetails.itemisationOption && $scope.modifyBillAccountDetails.itemisationOption!=$scope.originalItemisation){
             var _item= angular.element('#custom_itemisation_warning');
                if(_item.val()>=+constants.BILL_ITEMISATION_THRESHOLD_MIN && _item.val()<+constants.BILL_ITEMISATION_THRESHOLD_MAX){
                      $scope.confirmationButton= false;     
            }else{
                $scope.confirmationButton=true;
            }
        }
   
        };
                angular.extend($scope,{
                    deliveryMethod :deliveryMethod,
                    deliveryFormat :format,
                    deliveryLanguage :language,
                    displayNewMedia : display[$scope.originalMedia],
                    displayNewFormat :display[$scope.originalFormat],
                    displayNewlanguage :  display[$scope.originalLanguage],
                    displayNewBillItemisation:billAccountService.getItemisationDisplay({itemisationOption:$scope.originalItemisation}),
                    displayMedia :display[$scope.originalMedia],
                    displayFormat :display[$scope.originalFormat],
                    displaylanguage :display[$scope.originalLanguage],
                    loading:false,
                    back:function(){
                        billAccountService.confirmation=false;
                        $location.path('/viewbillprefs');
                    },
                    showMsgInfoDialog:function(){
                        return $scope.showErrorMsgDirective;
                    },
                    showMsgErrorDialog :function(){

                        return $scope.showMsgErrorDisplayDirective;
                    },
                     showMsgSaveDialog:function(){
                         //_scope,oldApplicability,oldCharge,newApplicability,newCharge
                          return $scope.showSaveMsgDirective;
                    },
                    confirmTheCharge:function(){
                        if ($scope.showMsgErrorDisplay) {
                            billAccountService.confirmation=true;
                            modifyBillPreferencesService.checkRadioButtons($scope, billAccountService, $location);
                        }else{
                            $scope.showMsgErrorDisplayDirective=true;
                        }
                    },
                    onSelectBillItemisation:function(billItemisation){
                        $scope.modifyBillAccountDetails.itemisationOption= billItemisation;
                        
                        $scope.displayNewBillItemisation=billAccountService.getItemisationDisplay({itemisationOption:billItemisation});
                        $scope.showMsgErrorDisplay =true;
                        $scope.thresholdError=false;
                        if(billItemisation===constants.BILL_ITEMISATION_CUSTOM_VIEW &&!($scope.originalItemisation===constants.BILL_ITEMISATION_CUSTOM_VIEW)){
                            $scope.customBillItemisation=true;
                            $scope.confirmationButton = true;
                        }else{
                            $scope.confirmationButton=!($scope.originalItemisation!=billItemisation || $scope.modifyBillAccountDetails.media!=$scope.originalMedia||$scope.modifyBillAccountDetails.format!=$scope.originalFormat || $scope.modifyBillAccountDetails.language!=$scope.originalLanguage);
                            $scope.customBillItemisation=false;
                        }
                         billAccountService.setBillItemisationOption(billItemisation);
                    },
                    onChangeCustomItemisationWarning:function(billItemisation){
                        if(billItemisation===constants.BILL_ITEMISATION_CUSTOM_VIEW){
                         var _item= angular.element('#custom_itemisation_warning');
                            if(_item.val()>=+constants.BILL_ITEMISATION_THRESHOLD_MIN && _item.val()<=+constants.BILL_ITEMISATION_THRESHOLD_MAX){
                                
                                 $scope.thresholdError=false;
                                $scope.confirmationButton=false;
                                _item.removeClass('error');
                                $scope.modifyBillAccountDetails.itemisationThreshold={
                                    currencyCode:"GBP",
                                    amount:_item.val()
                                };
                            }else{
                                 $scope.thresholdError=true;
                                _item.addClass('error');
                                $scope.confirmationButton=true;
                            }   
                        }
                        
                    }
                });
            },
            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });



    }]);
appControllers.controller('ErrorCtrl', ['$scope', '$http', '$location', 'errorLoggingService',
    function ($scope, $http, $location, errorLoggingService) {
        $scope.errorMessage = errorLoggingService.getErrorMessage();
    }]);