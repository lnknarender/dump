/**
 * Created by Neil Pullen on 05/03/15.
 */

var appServices = angular.module('appServices', []);


appServices.factory('accessTokenService', ['$q', 'ajaxService', 'urlService', 'stateService', function ($q, ajaxService, urlService, stateService) {

    return{
        getToken : function() {

            var deferred = $q.defer();
            var accessToken = stateService.get('accessToken');
            if (accessToken === undefined || accessToken === null) {

                var url = urlService.getSecurePath() + urlService.getAccessTokenUrl();

                ajaxService.doGet(url, {}).then(function (result) {
                    stateService.set('accessToken', result);
                    deferred.resolve(result);
                }, function(errorResult) {
                    deferred.reject(errorResult);
                });
            }
            else {
                deferred.resolve(accessToken);
            }
            return deferred.promise;
        },
        removeToken: function () {
            //Dont use this function. stateService is being used to reset the data
            //accessToken = null
        }
    };
}]);

appServices.factory('cancellationReasonsService', ['$q', 'ajaxService', 'urlService', 'stateService', function ($q, ajaxService, urlService, stateService) {


    var getCancelReasons = function() {

        var deferred = $q.defer();
        var cancelReasons = stateService.get("cancelReasons");

        if (cancelReasons === undefined || cancelReasons === null) {
            var url = urlService.getPublicPath() + urlService.getCancelReasonsUrl();

            ajaxService.doGet(url, {}).then(function (result) {
                stateService.set("cancelReasons",result);
                deferred.resolve(result);
            }, function(errorResult) {
                deferred.reject(errorResult);
            });
        }
        else {
            deferred.resolve(cancelReasons);
        }

        return deferred.promise;
    };

    return { getCancelReasons: getCancelReasons };
}]);

appServices.factory('impairmentService', ['$q', 'ajaxServiceWithToken', 'urlService', 'stateService', function ($q, ajaxServiceWithToken, urlService, stateService) {
    var getImpairment = function() {

        var deferred = $q.defer();
        var impairment = stateService.get("impairment");
        if (impairment == null) {

            var url = urlService.getSecurePath() + urlService.getImpairmentUrl();

            var impairmentResponse = ajaxServiceWithToken.doGet(url, {});
            impairmentResponse.then(function (result) {

                // clemitsj 2015.04.28
                // i think impairment is based on the customer (conk) not the billing format
                stateService.set("impairment",result);
                deferred.resolve(result);
            }, function(errorResult) {
                deferred.reject(errorResult);
            });
        }
        else {
            deferred.resolve(impairment);
        }

        return deferred.promise;
    };

    return { getImpairment: getImpairment };
}]);

appServices.factory('nextBillDateService', ['$q', 'ajaxServiceWithToken', 'urlService', 'stateService', function ($q, ajaxServiceWithToken, urlService, stateService) {
    var getDaysUntilNextBill = function() {
        var deferred = $q.defer();
        var daysUntilNextBill = stateService.get("daysUntilNextBill");

        if (daysUntilNextBill == null) {
            var url = urlService.getSecurePath() + urlService.getDaysUntilNextBillUrl();
            var nextBillDateResponse = ajaxServiceWithToken.doGet(url, {});
            nextBillDateResponse.then(function (result) {

                daysUntilNextBill = result.daysToCreationDate;
                stateService.set("daysUntilNextBill",daysUntilNextBill);
                deferred.resolve(daysUntilNextBill);

            }, function(errorResult) {
                deferred.reject(errorResult);
            });
        }
        else {
            deferred.resolve(daysUntilNextBill);
        }

        return deferred.promise;
    };

    return { getDaysUntilNextBill: getDaysUntilNextBill };
}]);

appServices.factory('billAccountService', ['$q', 'ajaxServiceWithToken', 'urlService', 'stateService', 'getModifiedPreferencesChargesService','nextBillDateService','impairmentService','utilityService', '$filter',
    function ($q, ajaxServiceWithToken, urlService, stateService,getModifiedPreferencesChargesService,nextBillDateService,impairmentService,utilityService, $filter) {


    return {
        getAccount: function() {

            var deferred = $q.defer();
            var account=stateService.get('account');

            if (account) {
                //  Already have an account so return it
                deferred.resolve(account);
            }
            else {
                var url = urlService.getSecurePath() + urlService.getBillAccountUrl();

                var billAccountResponse = ajaxServiceWithToken.doGet(url, {});
                billAccountResponse.then(function (result) {
                    stateService.set('account',result);
                    deferred.resolve(result);
                }, function (errorResult) {
                    deferred.reject(errorResult);
                });
            }

            return deferred.promise;
        },
        getMediaAndFormatOptionsList:function(){
            var deferred = $q.defer();
            var mediaFormatOption=stateService.get('mediaFormatOption');

            if (mediaFormatOption) {
                //  Already have an account so return it
                deferred.resolve(mediaFormatOption);
            }
            else {
                var url = urlService.getSecurePath() + urlService.getMediaAndFormatOptions();

                var billAccountResponse = ajaxServiceWithToken.doGet(url, {});
                billAccountResponse.then(function (result) {
                  stateService.set('mediaFormatOption',result);
                    deferred.resolve(result);
                }, function (errorResult) {
                    deferred.reject(errorResult);
                });
            }

            return deferred.promise;
        },
        reset:function(key){
            stateService.reset(key);
        },
        getAllRequest:function(){
            var deferred = $q.defer();
            $q.all({
                billAccountService: this.getAccount(),
                mediaAndFormatOptions: this.getMediaAndFormatOptionsList()
            }).then(function(results) {
                    deferred.resolve(results);
                },
                function (errorResult) {
                    deferred.reject(errorResult);
                });
            return deferred.promise;
        },
        setModifiedAccount: function(modifiedAccount) {
            this.modifiedAccount = modifiedAccount;
        },
        getJourney :function(impairment){
            var request ={
                daysUntilNextBill: nextBillDateService.getDaysUntilNextBill(),
                charges: getModifiedPreferencesChargesService.getCharges()
            };
            if(impairment){
                request.impairment =impairmentService.getImpairment();
            }
            var deferred = $q.defer();
            $q.all(request).then(function(results) {
                    deferred.resolve(results);
                },
                function (errorResult) {
                    deferred.reject(errorResult);
                });
            return deferred.promise;
        },
        getModifiedAccount: function() {
            return this.modifiedAccount;
        },

        submitModifiedAccount: function() {

            var deferred = $q.defer();
            var url = urlService.getSecurePath() + urlService.getBillAccountUrl();

            var modifyBillAccountResponse = ajaxServiceWithToken.doPut(url, {}, this.modifiedAccount);

            modifyBillAccountResponse.then(function (result) {
                deferred.resolve(result);
            }, function(errorResult) {
                deferred.reject(errorResult);
            });

            return deferred.promise;
        },
        getFormatRules:function(mediaandformatrules){
            //based on the display rule change the logic
            //create rule for display format
            var formats={},len=mediaandformatrules.length;
            for(var i=0;i<len;i++){
                var rule= mediaandformatrules[i];
                if(formats[rule.media]==undefined){
                    var setRule = {};
                    setRule[rule.language]={};
                    setRule[rule.language][rule.format] =rule.charge;
                    formats[rule.media]=setRule;
                }else{
                    var language =formats[rule.media][rule.language] ;
                    if(language!=undefined){
                        language[rule.format]=rule.charge;
                    }else{
                        formats[rule.media][rule.language]={};
                        formats[rule.media][rule.language][rule.format] =rule.charge;
                    }
                }
            }
            return formats;
        },
        deliveryMethod:function(media){
            return  [{'displayLabel':constants.PAPER,'id':constants.POST_RADIO,'value':constants.PAPER,'media_tick':media===constants.PAPER?true:false,'selected':media===constants.PAPER?'btn-main-selected':'btn-main-unselected'},
                {'displayLabel':constants.PAPER_FREE,'id':constants.ONLINE_RADIO,'value':constants.PAPER_FREE,'media_tick':media===constants.PAPER_FREE?true:false,'selected':media===constants.PAPER_FREE?'btn-main-selected':'btn-main-unselected'} ,
                {'displayLabel':constants.DUAL,'id':constants.ONLINE_AND_RADIO,'value':constants.DUAL,'media_tick':media===constants.DUAL?true:false,'selected':media===constants.DUAL?'btn-main-selected':'btn-main-unselected'}];
        },
        checkMediaFormatRule: function(formatSelection,scope,mediaAndFormatOptions,originalMedia,originalLanguage){
            var formats=this.getFormatRules(mediaAndFormatOptions);
            scope.mediaAndFormatRule =false;
            scope.mediaAndFormatCharge =0.0;
            scope.showMsgErrorDisplay =true;

            return !(formats[originalMedia][originalLanguage][formatSelection]!=undefined?true:false);
        },
        formatMethod:function(_$scope,mediaAndFormatOptions,originalMedia,originalLanguage,format){
           
            return [{'displayLabel':constants.BLUE_BILL,'id':constants.BLUE_BILL,'value':constants.BLUE_BILL,'format_tick':format===constants.BLUE_BILL?true:false,'selected':format===constants.BLUE_BILL?'btn-main-selected':'btn-main-unselected','css':constants.CSS_STANDARD},
                {'displayLabel':constants.BILL_LARGE_PRINT,'id':constants.BILL_LARGE_PRINT,'value':constants.BILL_LARGE_PRINT,'format_tick':format===constants.BILL_LARGE_PRINT?true:false,'selected':format===constants.BILL_LARGE_PRINT?'btn-main-selected':'btn-main-unselected','css':constants.CSS_LARGE_PRINT} ,
                {'displayLabel':constants.BILL_MEDIA_BRAILLE,'id':constants.BILL_MEDIA_BRAILLE,'value':constants.BILL_MEDIA_BRAILLE,'format_tick':format===constants.BILL_MEDIA_BRAILLE?true:false,'selected':format===constants.BILL_MEDIA_BRAILLE?'btn-main-selected':'btn-main-unselected','css':constants.CSS_BRAILLE},
                {'displayLabel':constants.BILL_AUDIO_CD,'id':constants.BILL_AUDIO_CD,'value':constants.BILL_AUDIO_CD,'format_tick':format===constants.BILL_AUDIO_CD?true:false,'selected':format===constants.BILL_AUDIO_CD?'btn-main-selected':'btn-main-unselected','css':constants.CSS_AUDIOCD}];
        },
        languageMethod:function(value){
            return  [{'displayLabel':constants.ENG,'id':constants.ENG_ID,'value':constants.ENG,language_tick:value===constants.ENG?true:false,'selected':value===constants.ENG?'btn-main-selected':'btn-main-unselected','css':constants.CSS_ENGILSH},
                {'displayLabel':constants.WEL,'id':constants.WEL_ID,'value':constants.WEL,language_tick:value===constants.WEL?true:false,'selected':value===constants.WEL?'btn-main-selected':'btn-main-unselected','css':constants.CSS_WELSH}];
        },
        displayMethod:function(){
            var display=  {
                "Paper":constants.BY_POST.toLowerCase(),
                "Paper-free":constants.ONLINE.toLowerCase(),
                "Dual":constants.ONLINE_AND_BY_POST_DISPLAY.toLowerCase(),
                "Blue Bill":constants.STANDARD.toLowerCase(),
                "Large-Print":constants.LARGE_PRINT.toLowerCase(),
                "Braille Bill":constants.BILL_MEDIA_BRAILLE.toLowerCase(),
                "Audio CD":constants.BILL_AUDIO_CD.toLowerCase(),
                "ENG":constants.ENGLISH,
                "WEL":constants.WELSH
            };
            return display;
        },
        displayCSS:function(){
        return {  
              "Paper":  'postonly',
              "Paper-free": 'online-only',
              "Dual": 'online-post',
              "Blue Bill":'standard',
              "Large-Print": 'large-print',
              "Braille Bill": 'braille',
              "Audio CD": 'audiocd',
              "ENG": 'english',
              "WEL":'welsh'
          };
        },
        
        showAgentOldOnlyMethod:function(display,originalMedia,originalFormat,originalLanguage,originalItemsation){
            return [
                {'displayLabel':constants.DELIVERY_METHOD,'value':display[originalMedia],'classLabel':'text-right left bolder col','classValue':'left col'},
                {'displayLabel':constants.FORMAT,'value':display[originalFormat],'classLabel':'text-right left bolder col','classValue':'left col'} ,
                {'displayLabel':constants.LANGUAGE,'value':display[originalLanguage],'classLabel':'text-right left bolder col','classValue':'left col'},
                {'displayLabel':constants.BILL_ITEMISATION,'value':this.getItemisationDisplayForAgent({itemisationOption:originalItemsation}),'classLabel':'text-right left bolder col','classValue':'left col'}];
        },
        checkRulesForFormatMediaAndLanguage:function(modifyBillAccountDetails,rulee,formats,_modifiedMedia,_modifiedLanguage,length){
            for(var k=0;k<length;k++){
                var obj = $(rulee[k]);

                //  Get the HTML for the radio button label
                var formatHtmlId = obj.prop('id');

                if(formats[_modifiedMedia][_modifiedLanguage][obj.attr('value')]!=undefined){
                    obj.prop('disabled',false);

                    //  Using this statement format as the HTML Ids contain spaces
                    $("[id='" + formatHtmlId + "']").removeAttr("disabled");

                    if(_modifiedMedia===constants.PAPER_FREE|| _modifiedLanguage===constants.WEL){
                        obj.prop('checked',true);
                        modifyBillAccountDetails.format=constants.BLUE_BILL;
                    }
                }else{
                    obj.prop('disabled',true);

                    //  Using this statement format as the HTML Ids contain spaces
                    $("[id='" + formatHtmlId + "']").attr("disabled", "disabled");

                    if(_modifiedMedia===constants.PAPER_FREE|| _modifiedLanguage===constants.WEL){
                        obj.prop('checked',false);
                        modifyBillAccountDetails.format=constants.BLUE_BILL;
                    }

                }
            }

        },
        setDefaultOptions:function(modifyBillAccountDetails,rulee,defaultOptions,format){
            for(var k=0,length=rulee.length;k<length;k++){
                var obj = $(rulee[k]),value =obj.data("name");

                //  Get the HTML for the radio button label
                var formatHtmlId = obj.prop('id');

                if(value===defaultOptions){
                    obj.prop('disabled',false);
                    modifyBillAccountDetails[format]=value;
                    //  Using this statement format as the HTML Ids contain spaces
                    $("[id='" + formatHtmlId + "']").removeAttr("disabled");

                }
            }
        },
        disableDeliverys:function(rulee,value){
            for(var k=0,length=rulee.length;k<length;k++){
                var obj = $(rulee[k]),_value =obj.data("name");

                //  Get the HTML for the radio button label
                var formatHtmlId = obj.prop('id');
                    if(value!==_value){
                      obj.prop('disabled',true);
                      $("[id='" + formatHtmlId + "']").attr("disabled", "disabled"); 
                        
                    }
                    

            }
        },
         enableDeliverys:function(rulee){
            for(var k=0,length=rulee.length;k<length;k++){
                var obj = $(rulee[k]);

                //  Get the HTML for the radio button label
                var formatHtmlId = obj.prop('id');

                  obj.prop('disabled',false);

                    //  Using this statement format as the HTML Ids contain spaces
                    $("[id='" + formatHtmlId + "']").removeAttr("disabled");
                    

            }
        },
        applyBooleanForMsgAndErrorDirective:function(_$scope,oldCharge,newCharge){
            var difference = newCharge-oldCharge;
            var setBtn= function(scop,showSaveMsgDirective,showErrorMsgDirective,showMsgErrorDisplay){
                scop.showSaveMsgDirective = showSaveMsgDirective;
                scop.showErrorMsgDirective =showErrorMsgDirective;
                scop.showMsgErrorDisplay=showMsgErrorDisplay;
            };
            if(difference<0){
                 setBtn(_$scope,true,false,true);
            }else if(difference>0){
                setBtn(_$scope,false,true,false);
                _$scope.showMsgErrorDisplayDirective= false;
            }else{
                setBtn(_$scope,false,false,true);
            }
        },
        getDeliveredMethod:function(_$scope,arrayList,barred){
            var deliveryMethod =arrayList;
            /*
             if user agent/advisor and media is Paper show Paper with online button
             if user agent/advisor and media is Online/Dual show Post Online and Dual
             if user customer and media is Paper show Post Online and Dual
             if user customer and media is Online/Dual  show Online and Dual
             * */
            _$scope.showOnlineButton=false;

            if(_$scope.userType===constants.AGENT ){
                if (_$scope.billAccountDetails.media===constants.PAPER){
                    deliveryMethod = [arrayList[0]];
                    _$scope.showOnlineButton=true;
                }
            }else{
                if(_$scope.billAccountDetails.media===constants.PAPER){
                    if(barred!=null && barred.status==constants.ACTIVE && (barred.substatus===constants.ACTIVE ||barred.substatus===constants.AWAITING_TARIFF_SETUP ||barred.substatus===constants.SALES_RECONTRACT_NOT_ALLOWED ||barred.substatus===constants.FINAL_BILL_PRODUCED ||barred.substatus===constants.FIRST_REMINDER ||barred.substatus===constants.SECOND_REMINDER) ) {
                        deliveryMethod = arrayList;
                    }else{
                        deliveryMethod = [arrayList[0]];
                    }
                }else{
                    deliveryMethod = arrayList.slice(1);
                }
            }
            return deliveryMethod;
        },
        chargeApplyForManageBillPreferences:function(_scope,oldCharge,newCharge){
            var difference = newCharge-oldCharge;
            if(difference>0){
                return true;
            }else if(difference<0){
                return true;
            }else{
                return false;
            }
        },
        chargeApply :function(_scope,oldCharge,newCharge){

            var difference = newCharge-oldCharge;
            if(difference>0){
                _scope.chargesApplicability =true;
                return constants.CHARGED;
            }else if(difference<0){
                _scope.chargesApplicability =true;
                return constants.SAVED;
            }else{
                _scope.chargesApplicability =false;
            }
        },

        chargeMatrix: function(chargesApplicability, chargesApply, conditionalDate) {

            if (chargesApplicability == true && chargesApply == constants.CHARGED && conditionalDate == constants.LESS_TWO_DAYS) {

                return constants.CHARGES_APPLY_LESS_THAN_TWO_DAYS;
            }
            else if (chargesApplicability == true && chargesApply == constants.CHARGED && conditionalDate == constants.GREATER_TWO_DAYS) {

                return constants.CHARGES_APPLY_GREATER_THAN_TWO_DAYS;
            }
            else if (chargesApplicability == true && chargesApply == constants.SAVED && conditionalDate == constants.LESS_TWO_DAYS) {

                return constants.SAVINGS_APPLY_LESS_THAN_TWO_DAYS;
            }
            else if (chargesApplicability == true && chargesApply == constants.SAVED && conditionalDate == constants.GREATER_TWO_DAYS) {

                return constants.SAVING_APPLY_GREATER_THAN_TWO_DAYS;
            }
            if (chargesApplicability == false && conditionalDate == constants.LESS_TWO_DAYS) {

                return constants.NO_CHARGES_APPLY_LESS_THAN_TWO_DAYS;
            }

            return constants.NO_CHARGES_GREATER_LESS_THAN_TWO_DAYS;
        },
        getItemisationValue:function(item){
            var itemisation={
                "NONE":"none",
                "not itemised at all":constants.BILL_ITEMISATION_NONE_1,
                "CUSTOM":"custom",
                "itemises all calls over":constants.BILL_ITEMISATION_CUSTOM_1,
                "DESTINATION":"destination",
                "summarised by phone number":constants.BILL_ITEMISATION_DESTINATION_1,
                "DETAILED":"detailed",
                "every single call":constants.BILL_ITEMISATION_DETAILED_1
            };
            return itemisation[item];
        },
        getItemisationLabel:function(itemisation){
            if(itemisation===constants.BILL_ITEMISATION_NONE_VIEW||itemisation===constants.BILL_ITEMISATION_DESTINATION_VIEW){
                return "your.bill.is";
            }else if(itemisation===constants.BILL_ITEMISATION_DETAILED_VIEW){
                 return "your.bill.lists";
            }
            return "your.bill";
        },
        getItemisationDisplay:function(modifiedAccount){
            var display = modifiedAccount.itemisationOption;
           var item = {
              "NONE":"none",
              "CUSTOM":"custom",
              "DESTINATION":"destination",
              "DETAILED":"detailed"
              };
              return item[display];
        },
        getItemisationDisplayForAgent:function(modifiedAccount){
            var display = modifiedAccount.itemisationOption;
           var item = {
              "NONE":constants.BILL_ITEMISATION_NONE_1,
              "CUSTOM":constants.BILL_ITEMISATION_CUSTOM_1,
              "DESTINATION":constants.BILL_ITEMISATION_DESTINATION_1,
              "DETAILED":constants.BILL_ITEMISATION_DETAILED_1
              };
              return item[display];
          },
          getThresholdAmount:function(account){
             if(account.itemisationOption===constants.BILL_ITEMISATION_CUSTOM_VIEW){
               return "£"+$filter('currency')(account.itemisationThreshold.amount, "", 2);
            } 
            return "";
          },
          
        getItemisationSuccessDisplay:function(modifiedAccount){
            var display = modifiedAccount.itemisationOption ,custom="custom";
            if(display===constants.BILL_ITEMISATION_CUSTOM_VIEW){
                custom= "custom.amount";
            }
           ;
           var item = {
              "NONE":"none",
              "CUSTOM":custom,
              "DESTINATION":"destination",
              "DETAILED":"detailed"
              };
              return item[display];
        },
        getManageItemisationDisplay:function(modifiedAccount){
            var display = modifiedAccount.itemisationOption, custom="custom";
            if(display===constants.BILL_ITEMISATION_CUSTOM_VIEW){
                custom= "custom.amount";
            }
           
              return custom;
        },
        defaultBillItemisationSelectedOption: function (billItemisation) {
            this.setDefaultBillItemisationSelectedOption(billItemisation);
        },
        setBillItemisationOption: function (billItemisation) {
            var billItemisationBtns = $("[id*='bill_itemisation_']");
            angular.forEach(billItemisationBtns, function (_billItemisation) {
                var _this = $(_billItemisation), id = _this.attr('id');
                utilityService.onSelectionButton(_this, _this.children(), id, "bill_itemisation_" + billItemisation);

            });
        },
        setDefaultBillItemisation:function(scope,originalItemisation){
            scope.noneSelected =scope.customSelected =scope.destinationSelected =scope.detailesSelected ="btn-main-unselected";
            scope.noneIcon =scope.customIcon =scope.destinationIcon =scope.detailedIcon ="";
            if(originalItemisation===constants.BILL_ITEMISATION_NONE_VIEW){
                   scope.noneSelected="btn-main-selected";
                   scope.noneIcon="icon-tick";
             }else if(originalItemisation===constants.BILL_ITEMISATION_CUSTOM_VIEW){
                     scope.customSelected="btn-main-selected";
                     scope.customIcon="icon-tick";
            } else if(originalItemisation===constants.BILL_ITEMISATION_DESTINATION_VIEW){
                      scope.destinationSelected="btn-main-selected";
                      scope.destinationIcon="icon-tick";
            } else if(originalItemisation===constants.BILL_ITEMISATION_DETAILED_VIEW){
                    scope.detailesSelected="btn-main-selected";
                    scope.detailedIcon="icon-tick";
            } 
                
        }
    };
}]);

appServices.factory('cancelEBillService', function() {

    return {
        setIsCancelEBill: function (cancelEBill) {
            this.cancelEBill = cancelEBill
        },

        getIsCancelEBill: function () {

            return this.cancelEBill;
        }
    };

});



appServices.factory('modifyBillPreferencesService', function() {

    return {
        checkRadioButtons: function($scope, billAccountService, $location) {
            billAccountService.setModifiedAccount($scope.modifyBillAccountDetails);
            $location.path('/successbillprefs');
        }
    };
});

appServices.factory('billingAccountStatusService', function() {

    return {
        isAccountBarred: function (barred) {

            var accountStatusList = accountStatus.accountStatus;
            var accountSubStatusList = accountStatus.accountSubStatus;

            var i;
            for (i = 0; i < accountStatusList.length; i++) {
                if (angular.equals(accountStatusList[i], barred.status)) {
                    return true;
                }
            }
            for (i = 0; i < accountSubStatusList.length; i++) {
                if (angular.equals(accountSubStatusList[i], barred.substatus)) {
                    return true;
                }
            }
            return false;
        }
    }

});


appServices.factory('getModifiedPreferencesChargesService', ['$q', 'ajaxServiceWithToken', 'urlService', 'stateService', 
    function ($q, ajaxServiceWithToken, urlService, stateService) {
    return {
        getCharges: function() {
            var deferred = $q.defer();
            var charges=stateService.get("charges");
            if (charges) {

                //  Already have the charges so return
                deferred.resolve(charges);
            }
            else {
                charges = [];

                var url = urlService.getSecurePath() + urlService.getChargesUrl();

                var chargesResponse = ajaxServiceWithToken.doGet(url, {});
                chargesResponse.then(function (result) {
                    stateService.set("charges",result);
                    deferred.resolve(result);
                }, function (errorResult) {
                    deferred.reject(errorResult);
                });
            }
            return deferred.promise;
        }
    };
}]);

appServices.factory('errorLoggingService', function() {

    var errorMessage = null;

    return {
        errorToString: function (errorResult) {

            errorMessage = "Error \n";

            if (errorResult) {

                if (errorResult.message != undefined) {
                    errorMessage += errorResult.message + '\n';
                }

                var errors = errorResult.errors;

                if (errors != undefined) {

                    for (i = 0; i < errors.length; i++) {
                        errorMessage += errors[i].code + " - " + errors[i].message + '\n';
                    }
                }
            }

            return errorMessage;

        },

        getErrorMessage : function() {
            if (errorMessage == null) {
                return '';
            }

            return errorMessage;
        }

    }

});