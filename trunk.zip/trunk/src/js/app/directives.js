var appDirectives = angular.module('appDirectives', []);


/*appDirectives.directive('datepicker', function () {
 return {
 restrict: 'A',
 require : 'ngModel',
 scope: {
 maxDate: "@"
 },
 link : function (scope, element, attrs, ngModelCtrl) {
 scope.$watch('loading', function (val) {
 console.log(attrs);
 element.datepicker({
 dateFormat:'dd/mm/yy',
 minDate: +1,
 maxDate: scope.maxDate,
 onSelect:function (date) {
 ngModelCtrl.$setViewValue(date);
 scope.$apply();
 
 }
 });
 });
 }
 }
 });*/

appDirectives.directive('restricteddatepicker', function () {
    return {
        restrict: 'A',
        require: 'ngModel',
        scope: {
            dates: "="
        },
        link: function (scope, element, attrs, ngModelCtrl) {
            scope.$watch('loading', function (val) {
                console.log(attrs);
                element.datepicker({
                    dateFormat: 'dd/mm/yy',
                    minDate: scope.dates[0],
                    maxDate: scope.dates[scope.dates.length - 1],
                    beforeShowDay:
                            function (d) {
                                var dmy = "";
                                dmy += ("00" + d.getDate()).slice(-2) + "/";
                                dmy += ("00" + (d.getMonth() + 1)).slice(-2) + "/";
                                dmy += d.getFullYear();
                                if (jQuery.inArray(dmy, scope.dates) != -1) {
                                    return [true, "", "Available"];
                                } else {
                                    return [false, "", "unAvailable"];
                                }
                            },
                    onSelect: function (date) {
                        ngModelCtrl.$setViewValue(date);
                        scope.$apply();

                    }
                });
            });
        }
    };
});

appDirectives.directive('btLoad', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, elem, attrs) {
                var fn = $parse(attrs.btLoad);
                elem.on('load', function (event) {
                    scope.$apply(function () {
                        fn(scope);
                    });
                });
            }
        };
    }]);

appDirectives.directive('loading', function () {
    return {
        restrict: 'EA',
        replace: true,
        template: '<div class="loading"><img src="images/ajax-loader.gif" alt="loading ticker" width="50" height="50" /><span><br>Loading</span></div>',
        link: function (scope, element, attr) {
            scope.$watch('loading', function (val) {
                if (val)
                    $(element).show();
                else
                    $(element).hide();
            });
        }
    };
});

appDirectives.directive('msgdailog', function () {
    return {
        restrict: 'E',
        replace: true,
        scope: false,
        template: function (elem, attr) {
            return  '<div class="alert-status--charge alert-detailsnotice">' +
                    '<fieldset class="billing right margin-right40">' +
                    '<input type="checkbox" id="radio1" class="" ng-checked="showMsgInfoChecked()">' +
                    '<label class="ng-binding" for="radio1"><span><span></span></span>' +
                    attr.ok + '</label></fieldset><p class="alert-detailsnotice--text-indent">' +
                    '<span class="sprite med money1"></span><strong>' +
                    attr.note + '</strong>' + attr.charge + '</p></div>';
        },
        link: function (scope, element) {
            element.bind('click', function () {
                scope.$parent.showMsgErrorDisplay = $('#radio1').prop('checked');
                var modifiedMedia = scope.$parent.modifyBillAccountDetails.media, originalMedia = scope.$parent.originalMedia;
                if (scope.$parent.showMsgErrorDisplay) {
                    $('#msgerrordailog').hide();
                } else {
                    $('#msgerrordailog').show();
                }

            });

        }
    };
});
appDirectives.directive('msgsavedailog', function () {
    return {
        restrict: 'E',
        replace: true,
        scope: false,
        template: function (elem, attr) {
            return '<div id ="msgsavedailog" class="alert-status--nocharge alert-detailsnotice">' +
                    '<p class="alert-detailsnotice--text-indent"><span class="sprite med money2"></span>' +
                    attr.info + '</p></div>';
        }

    };
});
//app.directive('customPopover',['$compile',function($compile){
//       var popoverBodyData = "<div  id='popover-directive'><span> {{tooltiplabel}}</span> </div>";
//   return {
//       restrict: 'A',
//       link: function(scope,element,attribute,controller){
//               scope.tooltiplabel = attribute.popoverBody;
//			   console.log(attribute.popoverBody);
//               var compliedData = $compile(popoverBodyData)(scope);
//               var getTitle = "<button id='closebtn' type='button' class='close'>&times;</button>";
//               var proc = $compile(getTitle)(scope);
//
//           return $(element).bind('click',function(){
//               var popoverDiv = $(element).next();
//               $('#closebtn').bind('click',function(){
//
//               });
//             });
//       }
//
//   };
//  }]);

app.directive('customTooltip', ['$compile', '$window', function ($compile, $window) {
        return {
            restrict: 'AE',
            link: function (scope, element, attribute, controller) {
                var popoverBodyData = "<div  id='popover-directive'><span> {{tooltiplabel}}</span> </div>";
                var windowWidth = angular.element($window).width();
                var triggerMode = 'hover';
                var _placement = attribute.placement;
                scope.tooltiplabel = attribute.popoverBody;
                scope.isMobileView = false;
                console.log(attribute.popoverBody);
                var compliedData = $compile(popoverBodyData)(scope), getTitle;
                if (windowWidth <= 768) {
                    scope.isMobileView = true;
                    getTitle = "<button id='closebtn' type='button' class='close'>&times;</button>";
                    triggerMode = 'click';
                    angular.element('#popover-directive').addClass('spinner-modal');
                }
                var proc = $compile(getTitle)(scope);
                $(element).popover({
                    'placement': _placement,
                    'html': true,
                    'title': proc,
                    'content': compliedData,
                    'trigger': triggerMode
                });

                /* close  functionality with tooltip*/
                return $(element).bind('click', function () {
                    var popoverDiv = $(element).next();
                    $('#closebtn').bind('click', function () {
                        $(popoverDiv).popover('hide');
                    });
                });
            }

        };
    }]);


app.directive('dantegh', ['urlService', function (urlService) {
        var loaded = false;
        var defvalues = {
            "searchStatus": "web",
            "displayMegaDropdown": "Y",
            "displayMastHead": "Y",
            "displayLogin": "Y",
            "displayPrimary": "Y",
            "displaySecondaryFlyouts": "Y",
            "siteArea": "presales",
            "header_rule": 0,
            "externalLogoutPageURL": "http://home.bt.com/?TARGET=mybtlogout"
        };
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                if (connection.userType === 'customer') {
                    $.ajax({
                        url: '//img01.bt.co.uk/s/assets/js/dantegh.api-1.1.js',
                        dataType: "script",
                        cache: true,
                        success: function () {
                            //Load Dante header
                            DanteGH.init(defvalues);
                        }
                    });
                }
            }
        };
    }]);

app.directive('omniture', function () {
    return {
        restrict: 'A',
        scope: {
            omniture: '@',
            omnitureErrors: '@'
        },
        controller: ['$scope', '$attrs', 'utilityService',
        function ($scope, $attrs, utilityService) {

            if (!$attrs.omniture || typeof _satellite === "undefined")
                return;

            var omniPrefix = "Con:YA:AM:B:";

            if (connection.userType.toLowerCase() === 'agent') {
                omniPrefix = "Agent:AM:B:";
            }

            /*
                 Do not set the Omniture page name when invoked from the error page. When this directive
                 is invoked from the error page, the previous page name (i.e. page that caused the error) will be
                 used, hence the check not to override the page name.
              */
            if ($attrs.omniture !== 'errorPage') {
                _satellite.setVar("pageName", omniPrefix + $attrs.omniture);
            }

            function inlineError(errors) {

                var errorType, errorPrefix, errorMessage;

                if (errors) {
                    angular.forEach(errors, function (error) {

                        errorType = errorType ? errorType + "|" + error.errorType : error.errorType;  // e.g. CE
                        errorPrefix = errorPrefix ? errorPrefix + "|" + error.errorPrefix : error.errorPrefix;
                        errorMessage = errorMessage ? errorMessage + "|" + error.errorMessage : error.errorMessage;
                    });

                    _satellite.setVar("errorType", errorType);
                    _satellite.setVar("errorPrefix", errorPrefix);
                    _satellite.setVar("errorMessage", errorMessage);

                    _satellite.track("error_message");
                }
            }

            if ($scope.omnitureErrors !== undefined) {

                var omnitureError = utilityService.getOmnitureError($scope.omnitureErrors);
                inlineError(omnitureError);
            }
            else {

                _satellite.track('screen_load');
            }
        }]
    };
});
appDirectives.directive('customerBanner', function () {
    return {
        restrict: 'A',
        replace: true,
        templateUrl: 'templates/homepage/customerbanner.html',
        controller: ['$scope', 'utilityService', 'paymentFriendlyNameService', 'primaryContactService', 'errorLoggingService',
            function ($scope, utilityService, paymentFriendlyNameService, primaryContactService, errorLoggingService) {
                $scope.isCustomer = connection.userType === "customer";
                if ($scope.isCustomer) {
                    var getPaymentFriendlyNameResponse = utilityService.getPaymentFriendlyName(paymentFriendlyNameService, primaryContactService, errorLoggingService);
                    getPaymentFriendlyNameResponse.then(function (result) {
                        $scope.userFriendlyName = result.userFriendlyName;
                    });
                }
            }]
    };
});
appDirectives.directive('backToBt', function () {
    return {
        restrict: 'A',
        template: function (elem, attr) {
            if (connection.userType === "customer")
                return  '<a id="BackMyBtLink" ng-href="{{url}}" target="_self" class="btn btn-primary btn-lg btn-billing">' +
                        '<span class="icon-right-chevron right"></span>{{"back.to.bt" | translate}}</a>';
            else
                return null;
        },
        controller: ['$scope', function ($scope) {
                if (connection.userType === "customer") {
                    $scope.url = connection.backToMyBtUrl;
                }
            }]
    };
});