/**
 * Created by Andrew on 10/22/15.
 */

var inviteCustomerOnlineController = angular.module('inviteCustomerOnlineController', []);

inviteCustomerOnlineController.controller('inviteCustomerOnlineCtrl', ['$scope', '$location', 'urlService', 'errorLoggingService', 'linkedAccountsService', '$routeParams', 'forgottenPasswordService', 'inviteOnlineService', 'linkedAccountsEmailService',
    function ($scope, $location, urlService, errorLoggingService, linkedAccountsService, $routeParams, forgottenPasswordService, inviteOnlineService, linkedAccountsEmailService) {

        $scope.loading = true;

        var linkedAccountResponse = linkedAccountsService.getLinkedAccount();
        linkedAccountResponse.then(function (result) {

            var primaryAccountItem = null;
            var secondaryAccountItem = null;

            $scope.otherEmails=[];

            $scope.currentAccount = "GB" + ($routeParams.bac).substr(2);
           angular.forEach(result.emailLinkedAccounts,function(item){
               if(item.email.isPrimary === "Y"){
                    primaryAccountItem = item;
                }
                else{
                    secondaryAccountItem = item;
                }
                $scope.loading = false;
           });
            $scope.otherEmails = result.otherEmails;

            angular.extend($scope, {
                loading : false,
                primaryAccount : primaryAccountItem,
                secondaryAccount : secondaryAccountItem,
                emailLinkedAccounts: result.emailLinkedAccounts,
                otherEmails: result.otherEmails,
                linkedAccountsToken: result.linkedAccountsToken
            });
        },
        function(errorResult) {
            $scope.loading = false;
            $("#inviteFailed").show();
            $("#inviteCustomerContent").hide();
        }),

        $scope.resetPassword=function(emailToken, emailAddress, linkedAccountsToken, marker){

            var resetPasswordObj =
            {
                "emailToken": emailToken,
                "account": {
                    "conk": $routeParams.conk,
                    "email": emailAddress,
                    "linkedAccountsToken": linkedAccountsToken
                }
            };

            var forgottenPasswordResponse = forgottenPasswordService.forgottenPassword(resetPasswordObj);
            forgottenPasswordResponse.then(function (result) {
                $("#sendResetSuccess" + marker).show();
                $("#resetPasswordLink" + marker).hide();
                $("#disableResetPassword" + marker).show();
            },
            function(errorResult) {
                $("#sendResetError" + marker).show();
            })
        },

        $scope.sendEmail=function(emailToken, emailAddress, linkedAccountsToken, marker){

            var sendEmailObj =
            {
                "emailToken": emailToken,
                "account": {
                    "conk": $routeParams.conk,
                    "email": emailAddress,
                    "linkedAccountsToken": linkedAccountsToken
                }
            };

            var inviteOnlineServiceResponse = inviteOnlineService.inviteCustomerOnline(sendEmailObj);
            inviteOnlineServiceResponse.then(function (result) {
                    $("#sendEmail" + marker).prop('disabled', true);
                    $("#sendEmail" + marker).addClass("disabled");
                    $("#sendEmailSuccess" + marker).show();
                },
                function(errorResult) {
                    $("#sendEmailError" + marker).show();
                })
        },
        $scope.getDetails=function(emailAddress, linkedAccountsToken, marker){

            var getDetailsObj =
            {
                    "conk": $routeParams.conk,
                    "email": emailAddress,
                    "linkedAccountsToken": linkedAccountsToken

            };

            var linkedAccountsEmailServiceResponse = linkedAccountsEmailService.getLinkedAccountEmail(getDetailsObj);
            linkedAccountsEmailServiceResponse.then(function (result) {

                    var otherEmailInfo =
                    {
                        "emailAddress": emailAddress,
                        "btId": result.btId,
                        "emailTemplate": result.emailTemplate,
                        "emailToken": result.emailToken,
                        "status": result.status,
                        "profileAccounts": result.profileAccounts
                    };

                    $scope.otherEmails[marker] = otherEmailInfo;
                    $("#getDetails" + marker).hide();
                    $("#info" + marker).show();
                },
                function(errorResult) {
                    $("#getDetailsFailed" + marker).show();
                })
        },

        $scope.closeThis=function(thisId){

            $("#" + thisId).hide();
        }
    }
]);