/**
 * Created by Andrew on 10/22/15.
 */

var inviteCustomerOnlineServices = angular.module('inviteCustomerOnlineServices',[]);

inviteCustomerOnlineServices.factory('linkedAccountsService', ['$q', 'ajaxServiceWithToken', 'urlService', 'inviteOnlineUrlService', 'stateService', function ($q, ajaxServiceWithToken, urlService, inviteOnlineUrlService, stateService) {

        return {
            getLinkedAccount: function () {

                var deferred = $q.defer();
                var linkedAccount = stateService.get(constants.STATE_SERVICE_LINKED_ACCOUNT);

                if (linkedAccount) {
                    //  Already have an account so return it
                    deferred.resolve(linkedAccount);
                }
                else {
                    var url = urlService.getSecurePath() + inviteOnlineUrlService.getLinkedAccountsUrl();

                    var linkedAccountResponse = ajaxServiceWithToken.doGet(url, {});

                    linkedAccountResponse.then(function (result) {
                        stateService.set(constants.STATE_SERVICE_LINKED_ACCOUNT, result);
                        deferred.resolve(result);
                    },
                    function (errorResult) {
                        deferred.reject(errorResult);
                    });
                }

                return deferred.promise;
            },

            resetLinkedAccount: function () {

                stateService.reset(constants.STATE_SERVICE_LINKED_ACCOUNT);
            }
        }
    }]
);

inviteCustomerOnlineServices.factory('linkedAccountsEmailService', ['$q', 'ajaxServiceWithToken', 'urlService', 'inviteOnlineUrlService', 'stateService', function ($q, ajaxServiceWithToken, urlService, inviteOnlineUrlService, stateService) {

        return {
            getLinkedAccountEmail: function (linkedAccountsEmailDetails) {

                var deferred = $q.defer();

                    var url = urlService.getSecurePath() + inviteOnlineUrlService.getLinkedAccountsEmailUrl();

                    var linkedAccountResponse = ajaxServiceWithToken.doPost(url, {}, linkedAccountsEmailDetails);

                    linkedAccountResponse.then(function (result) {
                            stateService.set(constants.STATE_SERVICE_LINKED_ACCOUNT_EMAIL, result);
                            deferred.resolve(result);
                        },
                        function (errorResult) {
                            deferred.reject(errorResult);
                        });

                return deferred.promise;
            },

            resetLinkedAccountEmail: function () {

                stateService.reset(constants.STATE_SERVICE_LINKED_ACCOUNT_EMAIL);
            }
        }
    }]
);

inviteCustomerOnlineServices.factory('forgottenPasswordService', ['$q', 'ajaxServiceWithToken', 'urlService', 'inviteOnlineUrlService', 'stateService', function ($q, ajaxServiceWithToken, urlService, inviteOnlineUrlService, stateService) {

        return {
            forgottenPassword: function (forgetPasswordDetails) {

                var deferred = $q.defer();

                var url = urlService.getSecurePath() + inviteOnlineUrlService.getForgottenPasswordUrl();

                var forgottenPasswordResponse = ajaxServiceWithToken.doPost(url, {}, forgetPasswordDetails);

                    forgottenPasswordResponse.then(function (result) {
                            deferred.resolve(result);
                        },
                        function (errorResult) {
                            deferred.reject(errorResult);
                        });

                return deferred.promise;
            }
        }
    }]
);

inviteCustomerOnlineServices.factory('inviteOnlineService', ['$q', 'ajaxServiceWithToken', 'urlService', 'inviteOnlineUrlService', function ($q, ajaxServiceWithToken, urlService, inviteOnlineUrlService) {

        return {

            inviteCustomerOnline: function (inviteCustomerOnlineDetails) {

                var deferred = $q.defer();

                var url = urlService.getSecurePath() + inviteOnlineUrlService.getInviteCustomerOnlineUrl();

                var inviteCustomerOnlineResponse = ajaxServiceWithToken.doPost(url, {}, inviteCustomerOnlineDetails);

                inviteCustomerOnlineResponse.then(function (result) {
                    deferred.resolve(result);
                },
                function (errorResult) {
                   deferred.reject(errorResult);
                });

                return deferred.promise;
            }
        }
    }]
);

inviteCustomerOnlineServices.factory('inviteOnlineUrlService', ['$routeParams', function($routeParams) {

    return {

        getLinkedAccountsUrl: function() {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/linkedaccounts';
            }
        },

        getLinkedAccountsEmailUrl: function() {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/linkedaccounts/email';
            }
        },

        getForgottenPasswordUrl: function() {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/passwordrecovery';
            }
        },
        getInviteCustomerOnlineUrl: function() {
            if (connection.userType == 'agent') {
                return '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/invitetoebilling';
            }
        }
    }
}]);

