/**
 *
 *   Date picker for instalment plans
 */

