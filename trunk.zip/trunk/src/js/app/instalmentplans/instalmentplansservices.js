var instalmentPlanServices = angular.module('instalmentPlanServices', []);

instalmentPlanServices.factory('instalmentPlanEligibilityService', ['$q', 'ajaxServiceWithToken', 'urlService', 'stateService', 
    function ($q, ajaxServiceWithToken, urlService, stateService) {

    return {
        getInstalmentPlanEligibility: function () {
            var deferred = $q.defer();
            // Check whether there is a stored instalment plan eligibility before making a ReST request
            var instalmentPlanEligibility = stateService.get(constants.STATE_SERVICE_INSTALMENT_PLAN_ELIGIBILITY);
            if (instalmentPlanEligibility === null ||instalmentPlanEligibility === undefined) {
               var url = urlService.getSecurePath() + urlService.getInstalmentPlanEligibilityUrl(this.accKey);
                var instalmentPlanEligibilityResponse = ajaxServiceWithToken.doGet(url, {});
                instalmentPlanEligibilityResponse.then(function (result) {
                    // Store the instalment plan eligibility in state service for future use
                    stateService.set(constants.STATE_SERVICE_INSTALMENT_PLAN_ELIGIBILITY, result);
                    deferred.resolve(result);
                }, function (errorResult) {
                    deferred.reject(errorResult);
                });
            }
            else {
                deferred.resolve(instalmentPlanEligibility);
            }
            return deferred.promise;
        },
        createInstalmentPlan: function (data) {
            var deferred = $q.defer();
            // Check whether there is a stored instalment plan eligibility before making a ReST request
                var url = urlService.getSecurePath() + urlService.createInstalmentPlanUrl();
                var instalmentPlanEligibilityResponse = ajaxServiceWithToken.doPost(url, {},data);
                instalmentPlanEligibilityResponse.then(function (result) {
                    // Store the instalment plan eligibility in state service for future use
                    stateService.set(constants.STATE_SERVICE_CREATE_INSTALMENT_PLAN, result);
                    deferred.resolve(result);
                }, function (errorResult) {
                    deferred.reject(errorResult);
                });
            
            return deferred.promise;
        },
        addClass:function(tabs,_class){
            angular.forEach(tabs,function(key,value){
                $('#'+key).addClass(_class);
            });
        },
        removeClass:function(tabs,_class){
            angular.forEach(tabs,function(key,value){
                $('#'+key).removeClass(_class);
            });
        },
     getInstalmentTabpanels:function(view,setup){
            return [
                {
                    'id':'viewInstalmentPlan',
                    'includeHtml':'templates/instalmentplans/view/viewinstalmentplan.html',
                    'eligibility':view
                },{
                    'id':'setupInstalmentPlan',
                    'includeHtml':'templates/instalmentplans/setup/setupinstalmentplan.html',
                    'eligibility':setup

                }
            ];
        },

        isInstalmentPlanHistory: function (instalmentPlan){
            //  Get the instalment plan eligibility from state service
            return instalmentPlan.instalmentHistory != null && instalmentPlan.instalmentHistory != undefined && instalmentPlan.instalmentHistory.length>0;
        },
        getInstalmentPlan: function (){
         return stateService.get(constants.STATE_SERVICE_INSTALMENT_PLAN_ELIGIBILITY);
        },
        amountValidation:function(amount,scope){
            var allowed ='/^\d+\.\d{2}$/', maskRe = new RegExp('[' + allowed + ']');
            if(amount.indexOf(".")===-1){
                amount = amount+".00";
            }
            if(scope.userType==='customer'){
                if(+amount<+scope.paymentAmount){
                 scope.upfrontAmountValidateForCustomer=true;
                }else{
                 scope.upfrontAmountValidateForCustomer=false;
                }
            }
             if(amount > (scope.outstandingAmount - 1.00) ){
                scope.amountValidationAmount = true;
                scope.maximumAmount = scope.outstandingAmount - 1.00;
            }
            else{
                scope.amountValidationAmount = false;
            }
            if(isNaN(amount)&& maskRe.test(amount)){
                scope.amountValidationType = true;
            }else{
                scope.amountValidationType = false;
            }
            scope.balanceAmount= scope.outstandingAmount-amount;
        },
        amountValidationForContinue:function(amount,scope){
            var allowed ='/^\d+\.\d{2}$/', maskRe = new RegExp('[' + allowed + ']'),success=true;
            if(amount.indexOf(".")===-1){
                amount = amount+".00";
            }
            if(scope.userType==='customer'){   
                if(+amount<+scope.paymentAmount){
                 scope.upfrontAmountValidateForCustomer=true;
                 success= false;
                }else{
                 scope.upfrontAmountValidateForCustomer=false;
                }
            }
            if(isNaN(amount)&& maskRe.test(amount)){
                scope.amountValidationType = true;
                success= false;
            }
            if(amount > (scope.outstandingAmount - 1.00) ){

                scope.amountValidationAmount = true;
                scope.maximumAmount = $scope.outstandingAmount - 1.00;
                success= false;
            }
            return success;
        },
        setFrequencyData:function(instlDate,format,frequency,scope){
            this.instalmentPreview= scope.instalmentPreview= instlDate;
            this.selectedPayFormat= scope.selectedPayFormat =format;
            scope.frequency=scope.frequencySelectedByUser=frequency;
        },
        getInstalmentPlanInstalmentPlan: function (instalmentPlan){
            return instalmentPlan.instalmentPlan;
        }
    };
}]);
instalmentPlanServices.factory('instalmentPlanStartDateService', function() {
    return {

        getPotentialStartDates: function (lastPaymentDateIn, frequencyIn, remainingBalance, minimumAmount) {

            var frequency;

            if (frequencyIn == '1M'){
                frequency = 28
            }
            else if (frequencyIn == '2W'){
                frequency = 14
            }
            else{
                frequency = 7
            }

            var selectableDates = [];

            var tomorrow = moment().add(1, 'd');
            tomorrow = moment(tomorrow).startOf('day');

            var lastPaymentDate = moment(lastPaymentDateIn, 'DD/MM/YYYY');

            var potentialDate = lastPaymentDate.subtract(frequency, 'd');

            while (potentialDate.isAfter(tomorrow)) {

                selectableDates[selectableDates.length] = moment(potentialDate).format('DD/MM/YYYY');

                potentialDate = potentialDate.subtract(frequency, 'd');
            }

            //Work out what the maximum number of payments can be in order to satisfy the instalment plan payment must
            //be greater than th minimum payment amount
            var roundedMaximumNumberOfPayments;
            var maximumNumberOfPayments = remainingBalance/minimumAmount;
            if(maximumNumberOfPayments > 0) {
                roundedMaximumNumberOfPayments = Math.floor(maximumNumberOfPayments) - 1;
            }
            else{
                roundedMaximumNumberOfPayments = 0;
            }

            selectableDates.splice(roundedMaximumNumberOfPayments);

            //If there are no available payment dates then default to the last payment date
            if (selectableDates.length == 0){
                var onlyDate = moment(lastPaymentDateIn, 'DD/MM/YYYY');
                selectableDates[selectableDates.length] = moment(onlyDate).format('DD/MM/YYYY');
            }

            return selectableDates.reverse();
        }
    }
});

instalmentPlanServices.factory('instalmentPlanSetupService', ['instalmentPlanEligibilityService', function(instalmentPlanEligibilityService) {

    return {
        setupInstalmentPlan:function(scope){
            var instalmentPlan = instalmentPlanEligibilityService.getInstalmentPlan();
            instalmentPlanEligibilityService.instalmentPlan = instalmentPlan;
            scope.outstandingAmount =instalmentPlan.outstandingBalance.amount;
			if(scope.outstandingAmount>constants.INSTALMENT_PLAN_SETUP_LIMIT && instalmentPlan.credit==="N"){
			   return true;	
			}
            scope.paymentDueDate =moment(instalmentPlan.paymentDueDate).format('D MMM YYYY');
            scope.setupActionTabs= this.setupInstalmentPlanActionTabs();
            return false;

        },
        setupInstalmentPlanActionTabs:function(){
            return [
                {
                    'id':'setupviewmakepayment',
                    'includeHtml':'templates/instalmentplans/setup/proceed/makepayment.html',
                    'tabLabel':'make.payment',
                    'tab':constants.SET_UP_MAKE_PAYMENT,
                    'icannot':'make.payment.icannot'
                },{
                    'id':'setupviewsetupAutomated',
                    'includeHtml':'templates/instalmentplans/setup/proceed/setupAutomated.html',
                    'tabLabel':'automated.payment',
                    'tab':constants.SET_UP_AUTOMATED,
                    'icannot':'automated.payment.icannot'

                },{
                    'id':'setupviewsetupinstalmentplanStarted',
                    'includeHtml':'templates/instalmentplans/setup/proceed/setupinstalmentplanStarted.html',
                    'tabLabel':'instalmentplan',
                    'tab':constants.SET_UP_INSTALMENT_STARTED,
                    'icannot':'instalmentplan.icannot'

                }
            ];
        }
    }
}]);
instalmentPlanServices.factory('instalmentPlanViewService', ['instalmentPlanEligibilityService', 'makePaymentService', function(instalmentPlanEligibilityService, makePaymentService) {

    return {
        viewInstalmentPlan:function(scope){

            var instalmentPlan = instalmentPlanEligibilityService.getInstalmentPlan(),instalmentPlanHistory =instalmentPlanEligibilityService.isInstalmentPlanHistory(instalmentPlan),
                instalmentPlanInstalmentPlan =instalmentPlanEligibilityService.getInstalmentPlanInstalmentPlan(instalmentPlan),nextBillDate=false;
            if (instalmentPlanHistory) {
                scope.outstandingAmount =instalmentPlanInstalmentPlan.outstanding.amount;

                if(instalmentPlan.nextBillDate!=null){
                    scope.nextBillDate =!nextBillDate;
                    scope.newTotalAmount ="10";//TODO call service to get the next bill amount
                }

                this.setInstalmentPlanRow(instalmentPlanInstalmentPlan.instalments,scope);
            }
            else {

                //  Return an error. Controller will redirect to an error page
                return false;
            }

        },
        setInstalmentPlanRow:function(instalments,scope){
            scope.paymentSchedule =[];
            var len=instalments.length,missedPlan= false,amountDisable=false,lastInstalmentDate,instalmentClosed=false,instalmentMissed=false,instalmentClosedOrMissed=false,_index= 0,lastInstalment=false;
            for(var i=0;i<len;i++){
                var payment ={},row=instalments[i];
                
                row.date =moment(row.date).format('D MMM YYYY');
                if(row.status==='Unpaid' && !amountDisable){
                    amountDisable =!amountDisable;
                    scope.number =row.number;
		    row.future = "schedule-row--instalment";
		    row.instalment=true;
                }
		if(i==len-1 && row.status==="Unpaid" && !amountDisable){
                    lastInstalment= true;
                }
		if(amountDisable){
		row.future="schedule-row future";
		}
                if(row.status==='Defaulted'){
                    row.plan ='missed-payment';
                    row.future ='schedule-row missed-payment';
                    if(!missedPlan){
                        row.displayLabel="missing";
                        missedPlan=!missedPlan;
                    }else{
                        row.displayLabel="dot";
                    }

                    scope.instalmentMissed=!instalmentMissed;
                    scope.instalmentClosedOrMissed=!instalmentClosedOrMissed;
                }else if(row.status==='Paid'){
                    row.plan ='paid';
                    row.future ='schedule-row';
                    row.displayLabel="paid";
					
                    _index =_index+1;
                    scope.instalmentClosedOrMissed=!instalmentClosedOrMissed;
                    lastInstalmentDate= moment(row.date).format('Do MMM YYYY');
                }
                row.amount=row.amount.amount;
                scope.instalmentClosedOrMissed=!instalmentClosedOrMissed;
                scope.paymentSchedule.push(row);
            }
            if(_index===len){
                scope.instalmentClosed=!instalmentClosed;
                scope.instalmentClosedOrMissed=!instalmentClosedOrMissed;
                scope.lastInstalmentDate = lastInstalmentDate;
                scope.enclosingAmount ="0.00";
            }
            scope.lastInstalment=lastInstalment;
        },
        instalmentMakepayment:function(makePayment,amount,scope,makePaymentService,date){
            makePaymentService.instalmentAmount =amount;
            makePaymentService.instalmentMissed= scope.instalmentMissed ;
            makePaymentService.instalmentPlan= true;
            makePaymentService.minAmount=amount;
            makePaymentService.lastInstalment=scope.lastInstalment;
            makePaymentService.instalmentPaymentDueDate=date;

        }
    }
}]);
instalmentPlanServices.factory('instalmentPlanSetupCreateService', ['instalmentPlanSetupService', 'instalmentPlanEligibilityService', function(instalmentPlanSetupService,instalmentPlanEligibilityService) {
    return {
        setupCreateActionTabs:function(){
            
            
            var list =[
                {
                    'tabLabel':'upfront.amount',
                    'includeHtml':'templates/instalmentplans/setup/create/createUpfrontAmount.html',
                    'tab':constants.CREATE_UP_FRONT_AMOUNT
                },{
                    'tabLabel':'when.to.pay',
                    'includeHtml':'templates/instalmentplans/setup/create/createChooseWhenToPay.html',
                    'tab':constants.CREATE_CHOOSE_WHEN_TO_PAY
                },{
                    'tabLabel':'make.payment',
                    'includeHtml':'templates/instalmentplans/setup/create/createMakePayment.html',
                    'tab':constants.CREATE_MAKE_PAYMENT
                },{
                    'tabLabel':'summary',
                    'includeHtml':'templates/instalmentplans/setup/create/createSummary.html',
                    'tab':constants.CREATE_SUMMARY
                }
            ];
            var _instalmentPlan =instalmentPlanEligibilityService.getInstalmentPlan();
           var billFrequency = (_instalmentPlan!== null && _instalmentPlan!==undefined) && (_instalmentPlan.billFrequency!==null && _instalmentPlan.billFrequency!==undefined) &&  _instalmentPlan.billFrequency===constants.BILL_MONTHLY;
   
               if(billFrequency){
                var filter=function(key,index){
                    return index!==1;
                };
                list= list.filter(filter);
            }
            return list ;
        },
        /**
         * "CREATE_UP_FRONT_AMOUNT": "createUpfrontAmount",
         "CREATE_CHOOSE_WHEN_TO_PAY": "createChooseWhenToPay",
         "CREATE_MAKE_PAYMENT": "createMakePayment",
         "CREATE_SUMMARY": "createSummary"
         * @param tab
         * @param scope
         */
        onSetupCreateEditClick : function(tab,scope){
            scope.tabPanel = tab;
            if (tab === 'createUpfrontAmount') {
                instalmentPlanEligibilityService.addClass([tab + '_edit',tab + '_edit_icon','createChooseWhenToPay_edit','createChooseWhenToPay_edit_icon','createMakePayment_edit','createMakePayment_edit_icon'],'ng-hide');
                $('#' + tab + '_h2').removeClass('accordion__header--complete').addClass('accordion__header--current');
                $('#createChooseWhenToPay_h2').removeClass('accordion__header--complete').removeClass('accordion__header--current');
                $('#createMakePayment_h2').removeClass('accordion__header--complete').removeClass('accordion__header--current');
                instalmentPlanEligibilityService.addClass(['createChooseWhenToPay_frequency','createChooseWhenToPay_upfront','createUpfrontAmount_upfront','createUpfrontAmount_frequency'],'ng-hide');
            }
            if (tab === 'createChooseWhenToPay') {
                instalmentPlanEligibilityService.addClass([tab + '_edit',tab + '_edit_icon','createMakePayment_edit','createMakePayment_edit_icon'],'ng-hide');
                $('#' + tab + '_h2').removeClass('accordion__header--complete').addClass('accordion__header--current');
                $('#createMakePayment_h2').removeClass('accordion__header--complete').removeClass('accordion__header--current');
                instalmentPlanEligibilityService.addClass(['createChooseWhenToPay_frequency','createChooseWhenToPay_upfront'],'ng-hide');
                
            }
        },
        applyClass:function(scope){
            if(scope.tabPanel==="createUpfrontAmount"){
                $('#createUpfrontAmount_h2').addClass('accordion__header--current');
            }else if(scope.tabPanel==="createChooseWhenToPay"){
                instalmentPlanEligibilityService.addClass(['createUpfrontAmount_h2'],'accordion__header--complete');
                instalmentPlanEligibilityService.addClass(['createChooseWhenToPay_h2'],'accordion__header--current');
                instalmentPlanEligibilityService.removeClass(['createUpfrontAmount_header','createUpfrontAmount_edit','createUpfrontAmount_edit_icon'],'ng-hide');
            }else if(scope.tabPanel==="setupinstalmentstarted"){
                instalmentPlanEligibilityService.addClass(['setupmakepayment_h2','setupautomated_h2'],'accordion__header--complete');
                instalmentPlanEligibilityService.addClass(['setupinstalmentstarted_h2'],'accordion__header--current');
                instalmentPlanEligibilityService.removeClass(['setupinstalmentstarted_header','setupmakepayment_cannot','setupmakepayment_edit','setupmakepayment_edit_icon',
                    'setupautomated_cannot','setupautomated_edit','setupautomated_edit_icon'],'ng-hide');

            }
        },
        getInstalmentTabs:function(scope,obj){
         return [
             {
                 'tabLabel':'weekly',
                 'icontick':true,
                 'id':'weekly',
                  'amount':obj._wa,
                 'disable':!obj._wl>0
             },{
                 'tabLabel':'fortnightly',
                 'icontick':false,
                 'id':'fortnightly',
                 'amount':obj._fa,
                 'disable':!obj._fl>0
             },{
                 'tabLabel':'monthly',
                 'icontick':false,
                 'id':'monthly',
                 'amount':obj._ma,
                 'disable':!obj._ml>0
             }
         ];
        },
        addDatesAndAmount:function(instalmentDates,instalmentAmounts){

                for(var i=0;i<instalmentDates.length;i++){
                  var instalment= instalmentDates[i];
                    instalment.date=moment(instalment.date).format('D MMM YYYY');
                    if(instalment.number===1){
                        instalment.amount=instalmentAmounts.firstInstalmentAmount;
                    }else{
                        instalment.amount=instalmentAmounts.instalmentAmount;
                    }
                }
        }

    }
}]);

instalmentPlanServices.factory('instalmentPlanDatePickerProceedService', ['instalmentPlanSetupService', function(instalmentPlanSetupService) {

    return {

    }
}]);

instalmentPlanServices.factory('instalmentPlanDatePickerCreateService', ['instalmentPlanStartDateService', function(instalmentPlanStartDateService) {

    return {

    }
}]);

instalmentPlanServices.factory('instalmentPlanSetupProceedService', ['instalmentPlanSetupService', function(instalmentPlanSetupService) {

    return {
        addClass:function(tabs,_class){
            angular.forEach(tabs,function(key,value){
                $('#'+key).addClass(_class);
            });
        },
        removeClass:function(tabs,_class){
            angular.forEach(tabs,function(key,value){
                $('#'+key).removeClass(_class);
            });
        }
    }
}]);

instalmentPlanServices.factory('moreTimeToPayByDateService', function() {

    return {
        getAvailablePayByDates: function (todayDate, nextBillDate) {


            //Convert inputs to moments
            var todayDateMoment = moment(todayDate, "YYYY-MM-DD");
            var nextBillDateMoment = moment(nextBillDate, "YYYY-MM-DD");

            //Last payment date is 7 days before the next Bill date (including next bill date - hence -6 days)
            var lastPayByDate = moment(nextBillDateMoment).subtract(6, 'days');

            //First potential chosen Date is tomorrow (1 day after today)
            var potentialDate = moment(todayDateMoment).add(1, 'days');

            //List of dates available for the customer to choose
            var availableDates = [];

            //From tomorrow loop through every date and add to the array until the potential date is after the last pay by date
            //Then return an array of all dates between tomorrow and last pay by date
            while (potentialDate.isBefore(lastPayByDate)) {

                availableDates[availableDates.length] = moment(potentialDate).format('YYYY-MM-DD');

                potentialDate = moment(potentialDate).add(1, 'd');
            }

            return availableDates;
        },

        getDatesInRange: function (startDate, endDate) {

            //Convert inputs to moments
            var startDateMoment = moment(startDate, "YYYY-MM-DD");
            var endDateMoment = moment(endDate, "YYYY-MM-DD");

            //List of dates available for the customer to choose
            var availableDates = [];

            var potentialDate = moment(startDateMoment);

            //From tomorrow loop through every date and add to the array until the potential date is after the last pay by date
            //Then return an array of all dates between tomorrow and last pay by date
            while (potentialDate.isBefore(endDateMoment)) {

                availableDates.push(moment(potentialDate).format('YYYY-MM-DD'));

                potentialDate = moment(potentialDate).add(1, 'd');
            }

            availableDates.push(moment(endDateMoment).format('YYYY-MM-DD'));

            return availableDates;
        }
    }
});

instalmentPlanServices.factory('calculateInstalmentAmounts', function() {

    return {

        getInstalmentAmounts: function (outstandingAmount, noOfInstalments) {

            //  Convert outstanding amount to a string
            var outstandingAmountStr = outstandingAmount.toString() + "00";

            //  Find the position of the decimal point
            var decimalPointPosition = outstandingAmountStr.indexOf(".");

            //  Does the outstanding amount contain a decimal place ?
            if (decimalPointPosition != -1) {

                // Strip the outstanding amount up to two decimal places (e.g. 126.220000001 => 126.22)
                outstandingAmountStr = outstandingAmountStr.substr(0, decimalPointPosition + 3);

                // Convert to pence by removing the decimal point (e.g. 126.22 => 12622)
                outstandingAmountStr = outstandingAmountStr.replace(".", "");
            }

            var instalmentAmount = Math.ceil(outstandingAmountStr / noOfInstalments);

            var calculatedOutstandingAmount = (instalmentAmount * noOfInstalments);

            var amountDifference = (calculatedOutstandingAmount - outstandingAmountStr);

            var firstInstalmentAmount = (instalmentAmount - amountDifference);

            firstInstalmentAmount = (firstInstalmentAmount / 100).toFixed(2);
            instalmentAmount = (instalmentAmount /100).toFixed(2);

            if (noOfInstalments == 1) {

                return {firstInstalmentAmount: firstInstalmentAmount,
                        instalmentAmount: '0.00'}
            }
            else {
                return {firstInstalmentAmount: firstInstalmentAmount,
                        instalmentAmount: instalmentAmount}
            }
        },

        getInstalmentDatesForMonthlyBill: function (endDate) {

            var number = 1;
            var endDateMoment = moment(endDate, "YYYY-MM-DD")

            var instalmentDates = [];

            instalmentDates.push({"date":moment(endDateMoment).format('YYYY-MM-DD'),"number":number});

            return instalmentDates;
        },

        getInstalmentDates: function (startDate, endDate, frequency) {

            var startDateMoment = moment(startDate, "YYYY-MM-DD");
            var endDateMoment = moment(endDate, "YYYY-MM-DD");
            var number = 1;

            var instalmentDates = [];
            instalmentDates.push({"date":moment(startDateMoment).format('YYYY-MM-DD'),"number":number});

            var nextInstalmentDate;

            // TODO: Add 1W as a constant
            if (frequency === '1W') {

                nextInstalmentDate = moment(startDateMoment).add(7, 'days');

                while ( moment(nextInstalmentDate).isBefore(moment(endDateMoment)) ) {
                          number= number+1;
                    instalmentDates.push({"date":moment(nextInstalmentDate).format('YYYY-MM-DD'),"number":number});
                    nextInstalmentDate = moment(nextInstalmentDate).add(7, 'days');
                }
            }
            else if (frequency === '2W') {

                nextInstalmentDate = moment(startDateMoment).add(14, 'days');

                while ( moment(nextInstalmentDate).isBefore(moment(endDateMoment)) ) {
                    number= number+1;
                    instalmentDates.push({"date":moment(nextInstalmentDate).format('YYYY-MM-DD'),"number":number});

                    nextInstalmentDate = moment(nextInstalmentDate).add(14, 'days');
                }
            }
            else if (frequency === '1M') {

                nextInstalmentDate = moment(startDateMoment).add(1, 'months');
                while ( moment(nextInstalmentDate).isBefore(moment(endDateMoment)) ) {
                    number= number+1;
                    instalmentDates.push({"date":moment(nextInstalmentDate).format('YYYY-MM-DD'),"number":number});

                    nextInstalmentDate = moment(nextInstalmentDate).add(1, 'months');
                }
            }
            number= number+1;
            instalmentDates.push({"date":moment(endDateMoment).format('YYYY-MM-DD'),"number":number});

            return instalmentDates;
        }
}});

instalmentPlanServices.factory('instalmentPlanSetupPlanService', ['instalmentPlanEligibilityService', function(instalmentPlanEligibilityService) {

    return {
        selectLastInstalmentDate:function(scope,_this){
             var selectedDate = null,dueDateTime=  moment(scope.paymentDueDate).toDate().getTime();
            instalmentPlanEligibilityService.selectedDatePicker =scope.selectedDatePicker = _this.datepicker;

            selectedDate= _this.datepicker.getTime();

            scope.tabPanel =constants.SET_UP_MAKE_PAYMENT;
            instalmentPlanEligibilityService.removeClass(['setupmakepayment_header'],'ng-hide');
            scope.selectedDateMoment = moment(selectedDate).format('Do MMM YYYY');
            if(selectedDate>dueDateTime){
                scope.selectedAfterDueDate = true;
                scope.selectedBeforeDueDate = false;
            }else{
                scope.selectedBeforeDueDate = true;
                scope.selectedAfterDueDate = false;

            }
        },
        removeClass:function(tabs,_class){
            angular.forEach(tabs,function(key,value){
                $('#'+key).removeClass(_class);
            });
        }
    }
}]);
instalmentPlanServices.factory('setupCreateInstalmentService', ['instalmentPlanEligibilityService', function(instalmentPlanEligibilityService) {

    return {
        createInstalment:function(routeParams,scope){
            var instalmentList=instalmentPlanEligibilityService.instalmentPreview,table=[];
            for(var i=0;i<instalmentList.length;i++){
                var obj={},amount={};
                obj.number= instalmentList[i].number;
                obj.date=moment(instalmentList[i].date).format('YYYY-MM-DD');
                amount.amount=instalmentList[i].amount;
                amount.currencyCode="GBP";
                obj.amount= amount;
                table.push(obj);
            }
            var instalmentPlan = instalmentPlanEligibilityService.getInstalmentPlan(),createInstalment =      {
                "billingAccount": routeParams.bac||scope.primaryContactBillingAccount,
                "startDate": moment(instalmentPlanEligibilityService.firstInstalmentDate).format('YYYY-MM-DD'),
                "endDate":  moment(instalmentPlanEligibilityService.lastInstalmentDatePicker).format('YYYY-MM-DD') ,
                "repaymentFrequency": instalmentPlanEligibilityService.selectedPayFormat,
                "billFrequency":instalmentPlan.billFrequency,
                "instalmentTotal": {
                    "amount": scope.balanceAmount,
                    "currencyCode": instalmentPlan.outstandingBalance.currencyCode
                },
                "minimumPayment": {
                    "amount":instalmentPlan.minimumPayment.amount,
                    "currencyCode": instalmentPlan.minimumPayment.currencyCode
                },
                "instalmentPlanEligibilityToken": instalmentPlan.instalmentPlanEligibilityToken,
                "instalments":table
            };
            return createInstalment;
        },
        showCreateInstalmentAfterSuccess:function(routeParams,scope){
                        scope.createInstalmentSuccess= true;
                        var instalment = instalmentPlanEligibilityService.getInstalmentPlan();
                        scope.instalmentPlanDetails = instalment;

                        if (routeParams.amount != undefined || routeParams.amount != null) {
                            scope.totalOutStandingAmountSuccess = +instalment.outstandingBalance.amount - (+routeParams.amount);
                        }
                        else {
                            scope.totalOutStandingAmountSuccess = +instalment.outstandingBalance.amount;
                        }
                        var displaypanel=[];
                        var instalmentList=instalmentPlanEligibilityService.instalmentPreview;
                        for(var i=0;i<instalmentList.length;i++){
                            if(i===0){
                                scope.summaryFirstInsDate=moment(instalmentList[i].date).format('DD MMM YYYY') ;
                                scope.summaryFirstInsAmount=instalmentList[i].amount;

                            }else{
                                displaypanel.push({
                                    'date':moment(instalmentList[i].date).format('DD MMM YYYY'),
                                    'amount':instalmentList[i].amount
                                })
                            }
                        }
                       return displaypanel;
        },
        createInstalmentObject:function(scope){
            var _array=[];
            var  row=
                      {"date":moment(instalmentPlanEligibilityService.lastInstalmentDatePicker).format('YYYY-MM-DD'),
                        "number":1,
                        "amount":scope.balanceAmount
                      };
             _array.push(row);
          return _array;
        }
    };
}]);
instalmentPlanServices.factory('instalmentPlanSetupMonthlyService', ['setupCreateInstalmentService', 'instalmentPlanEligibilityService', function(setupCreateInstalmentService,instalmentPlanEligibilityService) {

    return {
        createInstalment:function(routeParams,scope){
         return     setupCreateInstalmentService.createInstalment(routeParams,scope);
        },
        showCreateInstalmentAfterSuccess:function(routeParams,scope){
         return  setupCreateInstalmentService.showCreateInstalmentAfterSuccess(routeParams,scope);
        },
        upFrontAmountZeroCreateInstalment:function(routeParams,scope){
           instalmentPlanEligibilityService.selectedPayFormat=constants.BILL_MONTHLY;
             return this.createInstalment(routeParams,scope);
        }
    };
}]);

instalmentPlanServices.factory('instalmentPlanSetupQuartlyService', ['setupCreateInstalmentService', function(setupCreateInstalmentService) {

    return {
        
        upFrontAmountZeroCreateInstalment:function(routeParams,scope){
                    return this.createInstalment(routeParams,scope);
        },
         createInstalment:function(routeParams,scope){
          return  setupCreateInstalmentService.createInstalment(routeParams,scope);
        },
        showCreateInstalmentAfterSuccess:function(routeParams,scope){
           setupCreateInstalmentService.showCreateInstalmentAfterSuccess(routeParams,scope);
        }
    };
}]);

