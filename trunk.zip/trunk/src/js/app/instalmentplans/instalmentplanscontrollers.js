var instalmentPlanControllers = angular.module('instalmentPlanControllers', []);

instalmentPlanControllers.controller('InstalmentPlanEligibility', ['$scope', '$routeParams', '$location', 'urlService', 'errorLoggingService', 'instalmentPlanEligibilityService','makePaymentService','instalmentPlanViewService','instalmentPlanSetupService','instalmentPlanSetupPlanService','primaryContactService', 'utilityService', 'paymentFriendlyNameService',
    function ($scope, $routeParams, $location, urlService, errorLoggingService,  instalmentPlanEligibilityService,makePaymentService,instalmentPlanViewService,instalmentPlanSetupService,instalmentPlanSetupPlanService,primaryContactService, utilityService, paymentFriendlyNameService) {

        $scope.loading = true;

        if (connection.userType == constants.CUSTOMER && (makePaymentService.loggedOut == false || makePaymentService.loggedOut == undefined)) {

            var getPaymentFriendlyNameResponse = utilityService.getPaymentFriendlyName(paymentFriendlyNameService, primaryContactService, errorLoggingService);
            getPaymentFriendlyNameResponse.then(function (result) {

                $scope.userFriendlyName= result.userFriendlyName;
            });

            utilityService.getCustomerEmailAddress($routeParams.accKey, errorLoggingService);
        }

        $scope.repaymentPlan;
        $scope.userFriendlyName=primaryContactService.userFriendlyName;

        //  Not sure if this condition is correct as the account key on the URL is accKey (i.e. captial K)
        if ($routeParams.acckey != undefined) {
            connection.userType = 'customer';
        }
        else {

        }
           var viewLastestBill=connection.viewLatestBill;
        if(angular.isDefined(viewLastestBill)){
            $scope.viewLastestBill = viewLastestBill.replace(/%ACC_KEY/g, $routeParams.accKey);
        }
        if ($routeParams.accKey != undefined) {

            //  Get the control spend alert and globally replace %ACC_KEY with the customers account key
            var url = connection.controlSpendAlertUrl;
            $scope.getControlSpentAlertUrl = url.replace(/%ACC_KEY/g, $routeParams.accKey);

            //  Get the automated payment method URL and globally replace %ACC_KEY with the customers account key
            var automatedPaymentUrl = connection.automatedPaymentUrl;
            $scope.getAutomatedPaymentUrl = automatedPaymentUrl.replace(/%ACC_KEY/g, $routeParams.accKey);
        }

        $scope.userAgent = $scope.userType=connection.userType;
        $scope.connectionDetails = connection;

        // Get the instalment plan eligibility
        var instalmentPlanEligibilityResponse = instalmentPlanEligibilityService.getInstalmentPlanEligibility();
        instalmentPlanEligibilityResponse.then(function (result) {
                    $scope.loading = false;
                var instalmentPlan = instalmentPlanEligibilityService.instalmentPlan =result,
                    eligible=instalmentPlan.eligible==="Y"?true:false,
                    instalmentPlans= instalmentPlan.instalmentPlan;
                $scope.instalmentResult = result;
                $scope.instalmentPlanActionTabs = instalmentPlanEligibilityService.getInstalmentTabpanels(!eligible,eligible);
                var reason= instalmentPlan.reasonsForIneligibility;
                if(eligible){
                    instalmentPlanSetupService.setupInstalmentPlan($scope);
	        }else {
                     if(instalmentPlans!=null && instalmentPlans.instalments!=null && instalmentPlans.instalments.length>0){
                    instalmentPlanViewService.viewInstalmentPlan($scope);     
                     }else if(reason!=null  && reason.length>0){
                    instalmentPlanEligibilityService.warningMessage =reason;    
                    $location.path('/instalmentplannohistoryerror/');
                }
                    
                   } 
                
                
            },
            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });


        $scope.removeClass=function(){
            instalmentPlanEligibilityService.removeClass(['setupmakepayment_header'],'ng-hide');
        }
        
       $scope.yesPayNow= function(){
           instalmentPlanViewService.instalmentMakepayment(null,$scope.outstandingAmount,$scope,makePaymentService);
            $location.path('/instalmentMakepayment/');  
        };
        $scope.makePaymentJourney=function(makePayment,amount,date){
            //make payment journey
            instalmentPlanViewService.instalmentMakepayment(makePayment,amount,$scope,makePaymentService,date);
            $location.path('/instalmentMakepayment/');

        };
        $scope.onChange=function(event){//TODO need to check with Andy
            instalmentPlanSetupPlanService.selectLastInstalmentDate($scope,this);
        };

        $scope.toggleChevron = function (number) {

            var chevronId = "#chevron" + number;

            if($(chevronId).hasClass('icon-down-chevron')) {
                $(chevronId).removeClass('icon-down-chevron').addClass('icon-up-chevron');
            }
            else {
                $(chevronId).removeClass('icon-up-chevron').addClass('icon-down-chevron');
            }
        };

        $scope.payOnline=function(){
            makePaymentService.outstandingAmount= $scope.outstandingAmount;
            $location.path('/instalmentMakepayment/');
        };
        $scope.setUpCreateInstalmentPlan= function(){
            instalmentPlanSetupService.outstandingAmount= $scope.outstandingAmount;
            instalmentPlanSetupService.datepicker= $scope.datepicker;
            $location.path('/setupCreateInstalmentPlan/');
        };
        $scope.showMoreOptions=function(){
            $scope.tabPanel = 'setupautomated';
        };
        $scope.letPayNow= function(){
            $scope.tabPanel = 'setupinstalmentstarted';
        };
        $scope.onEditClick=function(tab) {
            $scope.tabPanel = tab;
            if (tab === 'setupmakepayment') {
                instalmentPlanEligibilityService.addClass([tab + '_edit',tab + '_edit_icon','setupautomated_edit','setupautomated_edit_icon','setupautomated_header','setupinstalmentstarted_header'],'ng-hide');
                $('#' + tab + '_h2').removeClass('accordion__header--complete').addClass('accordion__header--current');
                $('#setupautomated_h2').removeClass('accordion__header--complete').removeClass('accordion__header--current');
            }
            if (tab === 'setupautomated') {
                instalmentPlanEligibilityService.addClass([tab + '_edit',tab + '_edit_icon','setupautomated_edit','setupautomated_edit_icon','setupinstalmentstarted_header'],'ng-hide');
                $('#' + tab + '_h2').removeClass('accordion__header--complete').addClass('accordion__header--current');
                $('#setupinstalmentstarted_h2').removeClass('accordion__header--complete').removeClass('accordion__header--current');
            }
        };
        $scope.contactUs = function() {

            return connection.contactUs;
        };
        $scope.applyClass=function(){
            if($scope.tabPanel==="setupmakepayment"){
                $('#setupmakepayment_h2').addClass('accordion__header--current');
            }else if($scope.tabPanel==="setupautomated"){
                instalmentPlanEligibilityService.addClass(['setupmakepayment_h2'],'accordion__header--complete');
                instalmentPlanEligibilityService.addClass(['setupautomated_h2'],'accordion__header--current');
                instalmentPlanEligibilityService.removeClass(['setupautomated_header','setupmakepayment_cannot','setupmakepayment_edit','setupmakepayment_edit_icon'],'ng-hide');
            }else if($scope.tabPanel==="setupinstalmentstarted"){
                instalmentPlanEligibilityService.addClass(['setupmakepayment_h2','setupautomated_h2'],'accordion__header--complete');
                instalmentPlanEligibilityService.addClass(['setupinstalmentstarted_h2'],'accordion__header--current');
                instalmentPlanEligibilityService.removeClass(['setupinstalmentstarted_header','setupmakepayment_cannot','setupmakepayment_edit','setupmakepayment_edit_icon',
                    'setupautomated_cannot','setupautomated_edit','setupautomated_edit_icon'],'ng-hide');
            }
        };
    }]);






instalmentPlanControllers.controller('setupCreateInstalmentPlanCtrl', ['$scope', '$http', '$location','instalmentPlanEligibilityService','instalmentPlanSetupCreateService','instalmentPlanSetupService','makePaymentThistleService','errorLoggingService','$timeout','$routeParams','urlService','thistleService','calculateInstalmentAmounts','instalmentPlanSetupMonthlyService','instalmentPlanSetupQuartlyService','setupCreateInstalmentService','primaryContactService','stateService', 'utilityService',
    function ($scope, $http, $location,instalmentPlanEligibilityService,instalmentPlanSetupCreateService,instalmentPlanSetupService,makePaymentThistleService,errorLoggingService,$timeout,$routeParams,urlService,thistleService,calculateInstalmentAmounts,instalmentPlanSetupMonthlyService,instalmentPlanSetupQuartlyService,setupCreateInstalmentService,primaryContactService,stateService, utilityService) {
        $scope.connectionDetails = connection;
      var viewLastestBill=connection.viewLatestBill;
        if(angular.isDefined(viewLastestBill)){
            $scope.viewLastestBill = viewLastestBill.replace(/%ACC_KEY/g, $routeParams.accKey);
        }
           $scope.setupCreateActionTabs=instalmentPlanSetupCreateService.setupCreateActionTabs();
      
        $scope.outstandingAmount=instalmentPlanSetupCreateService.outstandingAmount=instalmentPlanSetupService.outstandingAmount ;
        $scope.datepicker=instalmentPlanSetupCreateService.datepicker=instalmentPlanSetupService.datepicker;
        $scope.paymentAmount = $routeParams.amount;
        $scope.userType=connection.userType;
        $scope.primaryContactBillingAccount= primaryContactService.primaryContactBillingAccount;
        if($routeParams.amount == null){
            $scope.paymentAmount = (($scope.outstandingAmount/100)*25).toFixed(2);
        }
        $scope.balanceAmount= ($scope.outstandingAmount-$scope.paymentAmount).toFixed(2);
        $scope.tryAgainInstalment=function(){
             $location.path('/moretimetopay/');
        };
        var instalmentPlan= instalmentPlanEligibilityService.getInstalmentPlan();
        if($location.path()==="/instalmentplanpaymentredirectsuccess"){
            $scope.tabPanel = constants.CREATE_SUMMARY;
            instalmentPlanEligibilityService.addClass(['createUpfrontAmount_h2','createChooseWhenToPay_h2','createMakePayment_h2','createSummary_h2'],'accordion__header--complete');
            instalmentPlanEligibilityService.removeClass(['createUpfrontAmount_edit_icon','createChooseWhenToPay_edit_icon','createMakePayment_edit_icon','createSummary_edit_icon'],'ng-hide');
            var repaymentPlan = $routeParams.repaymentPlan;
            $scope.withoutupfrontsuccess= false;
            angular.extend($scope,{
                paymentReference:  $routeParams.paymentReferenceId,
                paymentDateTime : $routeParams.paymentDateTime,
                accountNumber : $routeParams.bac,
                amount : $routeParams.amount,
                currency : $routeParams.currency,
                cardType : $routeParams.cardType===constants.CARD_DELTA?constants.CARD_VISA_DEBIT:$routeParams.cardType,
                nameOnCard : $routeParams.cardHolderName,
                cardNumber : $routeParams.cardNumber,
                expiryDate : $routeParams.expiryDate,
                securityCode : '***',
                emailAddress:$routeParams.email,
                postCode : $routeParams.cardHolderPostCode,
                createinstalmentplansuccess:$routeParams.createinstalmentplansuccess,
                createinstalmentplanfailure:$routeParams.createinstalmentplanfailure
            });
            if($scope.createinstalmentplansuccess==="true"){
                $scope.createinstalmentplanfailed= false;
                $scope.instalmentSummaryTable= setupCreateInstalmentService.showCreateInstalmentAfterSuccess($routeParams,$scope);
                
            }
             if($scope.createinstalmentplanfailure==="true"){
                  $scope.createinstalmentplanfailed= true;
                  instalmentPlanEligibilityService.addClass(['createSummary_h2'],'accordion__header--warning');
                  instalmentPlanEligibilityService.addClass(['createUpfrontAmount_h2','createChooseWhenToPay_h2','createMakePayment_h2'],'accordion__header--complete');
                  instalmentPlanEligibilityService.removeClass(['createUpfrontAmount_edit_icon','createChooseWhenToPay_edit_icon','createMakePayment_edit_icon','createSummary_edit_icon'],'ng-hide');
                  angular.element('#createSummary_edit_icon span').removeClass('icon-clock-white').addClass('icon-exclaimation-white');
            }

        }else if($location.path()==="/instalmentwithoutupfrontsuccess"){
            $scope.tabPanel = constants.CREATE_SUMMARY;
            $scope.withoutupfrontsuccess= true;
            instalmentPlanEligibilityService.addClass(['createUpfrontAmount_h2','createChooseWhenToPay_h2','createMakePayment_h2','createSummary_h2'],'accordion__header--complete');
            instalmentPlanEligibilityService.removeClass(['createUpfrontAmount_edit_icon','createChooseWhenToPay_edit_icon','createMakePayment_edit_icon','createSummary_edit_icon'],'ng-hide');
            $scope.instalmentSummaryTable= setupCreateInstalmentService.showCreateInstalmentAfterSuccess($routeParams,$scope);

        }else if($location.path()==="/instalmentpaymentfailed"){
            $scope.makepaymentfailed=true;
            $scope.tabPanel = 'createMakePayment';
        }else {
            $scope.tabPanel='createUpfrontAmount';
        }
        $scope.lastInstalmentDatePicker = instalmentPlanEligibilityService.selectedDatePicker;
        $scope.lastInstalmentDisplay = moment(instalmentPlanEligibilityService.selectedDatePicker).format('D MMM YYYY');
        

        $scope.applyClassForCreate=function(){
            if($scope.tabPanel==="createUpfrontAmount"){
                $('#createUpfrontAmount_h2').addClass('accordion__header--current');
            }else if($scope.tabPanel==="createChooseWhenToPay"){
                instalmentPlanEligibilityService.addClass(['createUpfrontAmount_h2'],'accordion__header--complete');
                instalmentPlanEligibilityService.addClass(['createChooseWhenToPay_h2'],'accordion__header--current');
                instalmentPlanEligibilityService.removeClass(['createChooseWhenToPay_header','createUpfrontAmount_edit','createUpfrontAmount_edit_icon'],'ng-hide');
            }else if($scope.tabPanel==="createMakePayment"){
                 if($location.path()==="/instalmentpaymentfailed"){
                     setTimeout(function(){ 
                     instalmentPlanEligibilityService.addClass(['createMakePayment_h2'],'accordion__header--warning');
                      instalmentPlanEligibilityService.addClass(['createChooseWhenToPay_h2','createUpfrontAmount_h2'],'accordion__header--complete');
 
                     instalmentPlanEligibilityService.removeClass(['createMakePayment_edit_icon','createChooseWhenToPay_edit_icon','createUpfrontAmount_edit_icon'],'ng-hide');      
                    angular.element('#createMakePayment_edit_icon span').removeClass('icon-clock-white').addClass('icon-exclaimation-white');

                     },1);
              

                 }else{
                instalmentPlanEligibilityService.addClass(['createUpfrontAmount_h2','createUpfrontAmount_h2'],'accordion__header--complete');
                instalmentPlanEligibilityService.addClass(['createMakePayment_h2'],'accordion__header--current');
                instalmentPlanEligibilityService.removeClass(['createUpfrontAmount_header','createUpfrontAmount_edit','createUpfrontAmount_edit_icon',
                    ,'createUpfrontAmount_edit','createUpfrontAmount_edit_icon'],'ng-hide');      
                 }
               
            }else if($scope.tabPanel===constants.CREATE_SUMMARY){
                if($scope.createinstalmentplanfailure==="true"){
                     setTimeout(function(){ 
                  instalmentPlanEligibilityService.addClass(['createSummary_h2'],'accordion__header--warning');
                  instalmentPlanEligibilityService.addClass(['createUpfrontAmount_h2','createChooseWhenToPay_h2','createMakePayment_h2'],'accordion__header--complete');
                  instalmentPlanEligibilityService.removeClass(['createUpfrontAmount_edit_icon','createChooseWhenToPay_edit_icon','createMakePayment_edit_icon','createSummary_edit_icon'],'ng-hide');
                  angular.element('#createSummary_edit_icon span').removeClass('icon-clock-white').addClass('icon-exclaimation-white');

                   }, 1);
                  
            }else{
                setTimeout(function(){ 
                   
                     instalmentPlanEligibilityService.addClass(['createUpfrontAmount_h2','createChooseWhenToPay_h2','createMakePayment_h2','createSummary_h2'],'accordion__header--complete');
                     instalmentPlanEligibilityService.removeClass(['createUpfrontAmount_edit_icon','createChooseWhenToPay_edit_icon','createMakePayment_edit_icon','createSummary_edit_icon'],'ng-hide');
                    
                   }, 1);
            }
                 }
        };



        $scope.onContinue = function(){
            instalmentPlanEligibilityService.removeClass(['createUpfrontAmount_edit','createChooseWhenToPay_edit','createUpfrontAmount_edit_icon','createChooseWhenToPay_edit_icon'],'ng-hide');
            instalmentPlanEligibilityService.addClass(['createUpfrontAmount_h2','createChooseWhenToPay_h2'],'accordion__header--complete');
            $scope.selectedDatePicker  = moment(instalmentPlanEligibilityService.selectedDatePicker).format('D MMM YYYY');
            
           $('#createChooseWhenToPay_frequency').removeClass('ng-hide');
            if(+$scope.amountToBePaid==0){
                var data = instalmentPlanSetupQuartlyService.upFrontAmountZeroCreateInstalment($routeParams,$scope);
                var createInstalmentPlan = instalmentPlanEligibilityService.createInstalmentPlan(data);
                createInstalmentPlan.then(function (result) {
                        $scope.createInstalmentSuccess= true;
                        $location.path('/instalmentwithoutupfrontsuccess');
                    },
                    function(errorResult) {
                        console.log(errorLoggingService.errorToString(errorResult));
                        $location.path(urlService.getErrorUrl());
                    });
            }else{
                var  thistlePaymentRequest = thistleService.getInstalmentPaymentRequestByPost($scope.amountToBePaid, "GBP",stateService.get("contactEmail"),
                    constants.OPEN_PLAN_PAYMENT_THISTLE_SUCCESS_URL,
                    constants.OPEN_PLAN_PAYMENT_THISTLE_FAILED_URL,
                    constants.OPEN_PLAN_PAYMENT_THISTLE_CANCELLED_URL,setupCreateInstalmentService.createInstalment($routeParams,$scope));

                $scope.hideframe=true;
                thistlePaymentRequest.then(function (result) {

                        //  Define the size of the Thistle iFrame
                        utilityService.defineThistleIframeHeight($scope);

                        $scope.thistleUrl = result.thistleUrl;
                        $scope.encodedXml = result.encodedXml;
                        $scope.tabPanel = 'createMakePayment';
                        $scope.loading = false;
                        postEncodedXml();
                    },
                    function(errorResult) {
                        console.log(errorLoggingService.errorToString(errorResult));
                        $location.path('/error');
                    });

                function postEncodedXml(){
                    $timeout(function(){
                        document.payform.submit();
                    },500);
                };
            }


            $scope.loaded =function(){
                $scope.loading = false;

                $scope.hideframe=false;
            }

        }

        $scope.onSetupCreateEditClick=function(tab) {
            $scope.datePickerSelected= false;
            instalmentPlanSetupCreateService.onSetupCreateEditClick(tab,$scope);

        };

        $scope.getBillFrequencyDetails= function(datepicker){
            var firstInstalment = datepicker, lastInstalmentDatePicker = $scope.lastInstalmentDatePicker,
                startDate =[datepicker.getFullYear(),(datepicker.getMonth()+1), ('0' + datepicker.getDate()).slice(-2)].join( "-"),
                endDate =[lastInstalmentDatePicker.getFullYear(),(lastInstalmentDatePicker.getMonth()+1) ,('0' + lastInstalmentDatePicker.getDate()).slice(-2)].join( "-");

            $scope.firstInstalmentDate =  moment(firstInstalment).format('D MMM YYYY');
            instalmentPlanEligibilityService.firstInstalmentDate =$scope.firstInstalmentDate;
            instalmentPlanEligibilityService.lastInstalmentDatePicker =$scope.lastInstalmentDatePicker;
            var instalmentPlan = instalmentPlanEligibilityService.instalmentPlan,billFrequency = instalmentPlan.billFrequency,instalmentPreview,
                               selectedPayFormat,_winstalmentAmounts,_finstalmentAmounts,_minstalmentAmounts;
            if(billFrequency===constants.BILL_QUARTERY){
                //creating object for weekly, fortnightly and monthly
                angular.forEach([constants.ONEWEEK,constants.TWOWEEK,constants.BILL_MONTHLY],function(key,value){
                   var _instalmentDates = calculateInstalmentAmounts.getInstalmentDates(startDate, endDate, key),
                                          instalmentAmounts=calculateInstalmentAmounts.getInstalmentAmounts($scope.balanceAmount,_instalmentDates.length);
                    instalmentPlanSetupCreateService.addDatesAndAmount(_instalmentDates,instalmentAmounts);
                if(key===constants.ONEWEEK){
                    $scope._winstalmentDates=_instalmentDates;
                    _winstalmentAmounts =instalmentAmounts.instalmentAmount;
                }else if(key===constants.TWOWEEK){
                    $scope._finstalmentDates=_instalmentDates;
                    _finstalmentAmounts =instalmentAmounts.instalmentAmount;
                }else if(key===constants.BILL_MONTHLY){
                      $scope._minstalmentDates=_instalmentDates;
                      _minstalmentAmounts =instalmentAmounts.instalmentAmount;
                }
                });
                $scope.instalmentTabs=instalmentPlanSetupCreateService.getInstalmentTabs($scope,
                                                                {
                                                                "_wa":_winstalmentAmounts,
                                                                "_wl":$scope._winstalmentDates.length,
                                                                "_fa":_finstalmentAmounts,
                                                                "_fl":$scope._finstalmentDates.length,
                                                                "_ma":_minstalmentAmounts,
                                                                "_ml":$scope._minstalmentDates.length
                });
                instalmentPreview= $scope._winstalmentDates;
                selectedPayFormat=constants.ONEWEEK;
                $scope.frequency= $scope.frequencySelectedByUser= constants.WEEKLY;
                
            }
            
            
            instalmentPlanEligibilityService.instalmentPreview= $scope.instalmentPreview= instalmentPreview;
            instalmentPlanEligibilityService.selectedPayFormat= $scope.selectedPayFormat=selectedPayFormat;
            $scope.datePickerSelected= true;

        };
        $scope.isAgent = function(){
            $scope.userType = connection.userType;

            return $scope.userType===constants.AGENT;

        };
        $scope.onAmountChange   =function() {
            var amount =  angular.element('#paymentAmount').val();
           instalmentPlanEligibilityService.amountValidation(amount,$scope);

        };
        $scope.applyClass=function(){
            instalmentPlanSetupCreateService.applyClass($scope);

        };
        $scope.chooseWhenToPay=function(){
            var amount =  angular.element('#paymentAmount').val();
           var sucessValidation= instalmentPlanEligibilityService.amountValidationForContinue(amount,$scope);
           if(!sucessValidation){
               return false;
           }
            $scope.balanceAmount= ($scope.outstandingAmount-amount).toFixed(2);
            $scope.upfrontAmount= $scope.amountToBePaid =amount;
            angular.element('#createUpfrontAmount_upfront').removeClass('ng-hide');

            if (instalmentPlanEligibilityService.getInstalmentPlan().billFrequency===constants.BILL_MONTHLY) {

                $scope.tabPanel='createMakePayment';
//                instalmentPlanEligibilityService.firstInstalmentDate=instalmentPlanEligibilityService.lastInstalmentDatePicker=$scope.firstInstalmentDate = $scope.lastInstalmentDatePicker;
                instalmentPlanEligibilityService.lastInstalmentDatePicker= $scope.lastInstalmentDatePicker;
                instalmentPlanEligibilityService.firstInstalmentDate=$scope.firstInstalmentDate = moment();
                instalmentPlanEligibilityService.instalmentPreview= $scope.instalmentPreview= setupCreateInstalmentService.createInstalmentObject($scope);
                instalmentPlanEligibilityService.selectedPayFormat= $scope.selectedPayFormat=constants.BILL_MONTHLY;

                if(+$scope.amountToBePaid==0){
                    var data= instalmentPlanSetupMonthlyService.upFrontAmountZeroCreateInstalment($routeParams,$scope);
                     var createInstalmentPlan = instalmentPlanEligibilityService.createInstalmentPlan(data);
                    createInstalmentPlan.then(function (result) {
                            $scope.createInstalmentSuccess= true;
                            $location.path('/instalmentwithoutupfrontsuccess');
                        },
                        function(errorResult) {
                            console.log(errorLoggingService.errorToString(errorResult));
                            $location.path(urlService.getErrorUrl());
                        });
                }else{
                    var  thistlePaymentRequest = thistleService.getInstalmentPaymentRequestByPost($scope.amountToBePaid, "GBP",stateService.get("contactEmail"),
                        constants.OPEN_PLAN_PAYMENT_THISTLE_SUCCESS_URL,
                        constants.OPEN_PLAN_PAYMENT_THISTLE_FAILED_URL,
                        constants.OPEN_PLAN_PAYMENT_THISTLE_CANCELLED_URL,setupCreateInstalmentService.createInstalment($routeParams,$scope));

                    $scope.hideframe=true;
                    thistlePaymentRequest.then(function (result) {

                            //  Define the size of the Thistle iFrame
                            utilityService.defineThistleIframeHeight($scope);

                            $scope.thistleUrl = result.thistleUrl;
                            $scope.encodedXml = result.encodedXml;
                            $scope.tabPanel = 'createMakePayment';
                            $scope.loading = false;
                            postEncodedXml();
                        },
                        function(errorResult) {
                            console.log(errorLoggingService.errorToString(errorResult));
                            $location.path('/error');
                        });

                    function postEncodedXml(){
                        $timeout(function(){
                            document.payform.submit();
                        },500);
                    };

                    $scope.loaded =function(){
                        $scope.loading = false;

                        $scope.hideframe=false;
                    }
                }
            }else {
                $scope.tabPanel='createChooseWhenToPay';
                $scope.instalmentBillFrequency = instalmentPlanEligibilityService.getInstalmentPlan().billFrequency === constants.BILL_QUARTERY;
            }

        };
        $scope.backFromInstalmentSetup=function(){
            $location.path('/moretimetopay');
        };
        
        $scope.tryAnotherCard=function(){
             $location.path('/moretimetopay');
        };
        $scope.onTabChange= function(tab){
            var _tab= angular.element('.next-instalment button'),len=_tab.length;
            for(var i=0;i<len;i++){
                var  item = $(_tab[i]);
                if(item.attr('id')===tab){
                    item.removeClass('btn-main-unselected').addClass('btn-main-selected');
                    var child = $(item.children()[0]);
                    child.removeClass('ng-hide');
                }else{
                    item.removeClass('btn-main-selected').addClass('btn-main-unselected');
                    var child = $(item.children()[0]);
                    child.addClass('ng-hide');
                }
            } 
          
            if(tab==="weekly"){
               instalmentPlanEligibilityService.setFrequencyData($scope._winstalmentDates,constants.ONEWEEK,constants.WEEKLY,$scope);
            }else if(tab==="monthly"){
                instalmentPlanEligibilityService.setFrequencyData($scope._minstalmentDates,constants.BILL_MONTHLY,constants.MONTHLY,$scope);
            }else if (tab==="fortnightly"){
                instalmentPlanEligibilityService.setFrequencyData($scope._finstalmentDates,constants.TWOWEEK,constants.FORTNIGHTLY,$scope);
            }
        };

    }]);

instalmentPlanControllers.controller('InstalmentPlanPreferences', ['$scope', '$http', '$location','currentBillService', 'instalmentPlanStartDateService','repaymentPlanService','instalmentPlanPreferencesService','urlService','errorLoggingService', 'instalmentPlanFrequenciesService','accessTokenService', '$routeParams',
    function ($scope, $http, $location, currentBillService, instalmentPlanStartDateService,repaymentPlanService,instalmentPlanPreferencesService,urlService,errorLoggingService,instalmentPlanFrequenciesService, accessTokenService, $routeParams) {
        $scope.loading = true;
        $scope.connectionDetails = connection;
        $scope.dates = [];

        var currentBillServiceResponse = currentBillService.getCurrentBill();
        currentBillServiceResponse.then(function (result) {

                if ($scope.connectionDetails.userType === 'agent'){
                    var repaymentPlanServiceResponse = repaymentPlanService.getRepaymentPlanHistory();
                    repaymentPlanServiceResponse.then(function (repaymentResponse) {

                            $scope.repaymentHistory = repaymentResponse;

                        },
                        function(errorResult) {
                            console.log(errorLoggingService.errorToString(errorResult));
                            $location.path(urlService.getErrorUrl());
                        })
                }
                var frequenciesResponse = instalmentPlanFrequenciesService.getFrequencies();
                frequenciesResponse.then(function (frequencies) {

                        $scope.frequencies = frequencies;


                    },
                    function(errorResult) {
                        console.log(errorLoggingService.errorToString(errorResult));
                        $location.path(urlService.getErrorUrl());
                    })
                $scope.currentBill = result;
                $scope.repaymentPlan = repaymentPlanService.getRepaymentPlan();

                if($scope.currentBill.frequency == "1M"){
                    $scope.repaymentPlan.frequency = "1M";
                }
                else{
                    $scope.repaymentPlan.frequency = "1W";
                }

                if($scope.repaymentPlan.upfront == null) {
                    $scope.repaymentPlan.upfront =
                    {
                        "amount":$scope.currentBill.repaymentPlan.minimumUpfrontPayment.amount,
                        "currencyCode":"GBP"
                    }
                }
                if($scope.repaymentPlan.instalmentTotal == null) {
                    $scope.repaymentPlan.instalmentTotal =
                    {
                        "amount":$scope.currentBill.charges.amount,
                        "currencyCode":"GBP"
                    }
                }

                $scope.recalculateDate = function () {

                    instalmentPlanPreferencesService.recalculateDate($scope);

                }

                $scope.validateAmount = function(){

                    instalmentPlanPreferencesService.validateAmount($scope);
                }

                $scope.validateAmount();

                $scope.makePaymentOrSetupPlan = function (valid) {
                    repaymentPlanService.setRepaymentPlan($scope.repaymentPlan);
                    if(valid){
                        if (connection.userType != 'agent') {
                            $location.path('/instalmentplanupfrontpayment')
                        }
                        else {
                            if (parseFloat($scope.repaymentPlan.upfront.amount) != 0.00) {
                                $location.path('/instalmentplanupfrontpayment')
                            }
                            else {
                                $scope.repaymentPlan.startDate = moment($scope.repaymentPlan.startDate, "DD-MM-YYYY");
                                var formattedStartDate = moment($scope.repaymentPlan.startDate).format('YYYY-MM-DD');
                                $scope.repaymentPlan.endDate = moment($scope.repaymentPlan.endDate, "DD-MM-YYYY");
                                var formattedEndDate = moment($scope.repaymentPlan.endDate).format('YYYY-MM-DD');
                                var accessTokenResponse = accessTokenService.getToken();
                                accessTokenResponse.then(function (result) {
                                    $location.path('/instalmentconfirmation').search({startDate : formattedStartDate,instalmentTotal: $scope.repaymentPlan.instalmentTotal.amount, amount: $scope.repaymentPlan.upfront.amount, endDate: formattedEndDate, frequency :$scope.repaymentPlan.frequency, currency : $scope.repaymentPlan.upfront.currencyCode, instalmentTotalCurrencyCode : $scope.repaymentPlan.upfront.currencyCode, tok: result.accessToken, bac: $routeParams.bac, cak: $routeParams.cak, conk: $routeParams.conk});

                                })
                            }
                        }
                    }
                };
                $scope.previewPaymentPlan = function(valid){
                    if(valid) {

                        angular.element('#instalmentPlanPreview').show();
                        var remainingBalance = ($scope.currentBill.charges.amount) - ($scope.repaymentPlan.upfront.amount);

                        if ($scope.currentBill.frequency == "1M") {
                            $scope.repaymentPlan.startDate = $scope.repaymentPlan.endDate;
                        }

                        var momentStartDate = moment($scope.repaymentPlan.startDate, 'DD/MM/YYYY');
                        var formattedStartDate = moment(momentStartDate).format('YYYY-MM-DD');

                        var momentEndDate = moment($scope.repaymentPlan.endDate, 'DD/MM/YYYY');
                        var formattedEndDate = moment(momentEndDate).format('YYYY-MM-DD');

                        var previewInstalmentPlanServiceResponse = repaymentPlanService.previewInstalmentPlan($scope.currentBill.frequency, formattedStartDate, formattedEndDate, remainingBalance, $scope.repaymentPlan.frequency, $scope.currentBill.repaymentPlan.minimumInstalment.amount, $scope.repaymentPlan.instalmentTotal.currencyCode);
                        previewInstalmentPlanServiceResponse.then(function (previewInstalmentPlanResponse) {

                                $scope.instalmentPlanPreview = previewInstalmentPlanResponse;

                            },
                            function(errorResult) {
                                console.log(errorLoggingService.errorToString(errorResult));
                                $location.path(urlService.getErrorUrl());
                            })                }
                }
                $scope.hidePreviewPaymentPlan = function(){
                    angular.element('#instalmentPlanPreview').hide();
                }
                $scope.loading = false;
            },
            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            })
    }]);

instalmentPlanControllers.controller('InstalmentPlanConfirmation', ['$scope', '$http', '$location','repaymentPlanService', 'urlService', 'errorLoggingService', '$routeParams',
    function ($scope, $http, $location, repaymentPlanService, urlService, errorLoggingService, $routeParams) {
        $scope.loading = true;

        var repaymentPlanServiceResponse = repaymentPlanService.createRepaymentPlan();
        repaymentPlanServiceResponse.then(function (result) {
                $scope.repaymentPlan = result;
                $scope.upfrontAmount = $routeParams.amount;
                $scope.todaysDate = moment().format('dddd Do MMMM');

                $scope.loading = false;

                $scope.back = function () {
                    $location.path(urlService.getHomeUrl());
                };

            },
            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            })
        // TODO THISTLE rebuild state from custom data object (cak/conk/bac, etc)
    }]);

instalmentPlanControllers.controller('InstalmentPlanOpen', ['$scope', '$http', '$location', 'urlService', 'errorLoggingService', 'repaymentPlanService',
    function ($scope, $http, $location, urlService, errorLoggingService, repaymentPlanService) {
        $scope.loading = true;
        $scope.connectionDetails = connection;

        var currentInstalmentPlanServiceResponse =  repaymentPlanService.queryRepaymentPlanBill();
        currentInstalmentPlanServiceResponse.then(function (currentInstalmentPlan) {
                $scope.repaymentPlan = currentInstalmentPlan;
                $scope.makePayment = function () {
                    $location.path('/instalmentplanopenayment')
                };
                $scope.loading = false;
            },

            $scope.back = function () {
                $location.path(urlService.getHomeUrl());
            },

            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            })
    }]);

instalmentPlanControllers.controller('InstalmentPlanOpenPayment', ['$scope', '$http', '$location', 'repaymentPlanService', 'errorLoggingService', 'thistleService', 'utilityService',
    function ($scope, $http, $location, repaymentPlanService, errorLoggingService, thistleService, utilityService) {
        $scope.loading = true;
        $scope.connectionDetails = connection;

        var currentInstalmentPlanServiceResponse =  repaymentPlanService.queryRepaymentPlanBill();
        currentInstalmentPlanServiceResponse.then(function (currentInstalmentPlan) {
                $scope.repaymentPlan = currentInstalmentPlan;

                for (var i = 0; i < $scope.repaymentPlan.instalments.length; i++) {
                    if ($scope.repaymentPlan.instalments[i].status == "Unpaid") {
                        $scope.amount =  $scope.repaymentPlan.instalments[i].amount.amount;
                        $scope.currency = $scope.repaymentPlan.instalments[i].amount.currencyCode;
                        break;}
                }

                var repaymentPlanParams = JSON.stringify($scope.repaymentPlan);

                var thistlePaymentRequest = thistleService.getInstalmentPaymentRequest($scope.amount, $scope.currency, constants.OPEN_PLAN_PAYMENT_THISTLE_SUCCESS_URL, constants.OPEN_PLAN_PAYMENT_THISTLE_FAILED_URL, constants.OPEN_PLAN_PAYMENT_THISTLE_CANCELLED_URL, repaymentPlanParams);

                thistlePaymentRequest.then(function (result) {

                        //  Define the size of the Thistle iFrame
                        utilityService.defineThistleIframeHeight($scope);

                        $scope.thistleUrl = result.thistleUrl;
                        $scope.encodedXml = result.encodedXml;
                        $scope.loading = false;
                    },
                    function(errorResult) {
                        console.log(errorLoggingService.errorToString(errorResult));
                        $location.path(urlService.getErrorUrl());
                    });
            },
            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            })

    }]);

instalmentPlanControllers.controller('InstalmentPlanFailed', ['$scope', '$http', '$location', 'errorLoggingService', 'repaymentPlanService', 'urlService',
    function ($scope, $http, $location, errorLoggingService, repaymentPlanService, urlService) {
        $scope.loading = true;
        $scope.connectionDetails = connection;

        var currentInstalmentPlanServiceResponse =  repaymentPlanService.queryRepaymentPlanBill();
        currentInstalmentPlanServiceResponse.then(function (currentInstalmentPlan) {
                $scope.repaymentPlan = currentInstalmentPlan;
                $scope.makePayment = function () {
                    $location.path('/instalmentplanfailedpayment')
                };
                $scope.loading = false;
            },

            $scope.back = function () {
                $location.path(urlService.getHomeUrl());
            },

            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            })

    }]);

instalmentPlanControllers.controller('InstalmentPlanPaymentSuccess', ['$scope', '$http', '$location', 'repaymentPlanService', 'errorLoggingService', '$routeParams', 'urlService',
    function ($scope, $http, $location, repaymentPlanService, errorLoggingService, $routeParams, urlService) {
        $scope.loading = true;
        $scope.connectionDetails = connection;

        $scope.route = $routeParams.repaymentPlan;

        $scope.repaymentPlan = JSON.parse($routeParams.repaymentPlan);

        if($scope.repaymentPlan.status == "Defaulted"){

            for (var i = 0; i < $scope.repaymentPlan.instalments.length; i++) {
                $scope.repaymentPlan.instalments[i].status = "Paid"
            }

            $scope.repaymentPlan.outstanding.amount = 0.00;

        }

        if($scope.repaymentPlan.status == "Active"){

            for (var i = 0; i < $scope.repaymentPlan.instalments.length; i++) {
                if ($scope.repaymentPlan.instalments[i].status == "Unpaid") {
                    $scope.repaymentPlan.instalments[i].status = "Paid";
                    $scope.repaymentPlan.outstanding.amount = $scope.repaymentPlan.outstanding.amount - $scope.repaymentPlan.instalments[i].amount.amount;
                    break;}
            }
        }

        $scope.back = function () {
            $location.path(urlService.getHomeUrl());
        },

            $scope.loading = false;

    }]);

instalmentPlanControllers.controller('InstalmentPlanFailedPayment', ['$scope', '$http', '$location', 'repaymentPlanService', 'thistleService', 'errorLoggingService', 'utilityService',
    function ($scope, $http, $location, repaymentPlanService, thistleService, errorLoggingService, utilityService) {
        $scope.loading = true;
        $scope.connectionDetails = connection;

        var currentInstalmentPlanServiceResponse =  repaymentPlanService.queryRepaymentPlanBill();
        currentInstalmentPlanServiceResponse.then(function (currentInstalmentPlan) {
                $scope.repaymentPlan = currentInstalmentPlan;

                $scope.amount = $scope.repaymentPlan.outstanding.amount;
                $scope.currency = $scope.repaymentPlan.outstanding.currencyCode;

                var repaymentPlanParams = JSON.stringify($scope.repaymentPlan);

                var thistlePaymentRequest = thistleService.getInstalmentPaymentRequest($scope.amount, $scope.currency, constants.FAILED_PLAN_PAYMENT_THISTLE_SUCCESS_URL, constants.FAILED_PLAN_PAYMENT_THISTLE_FAILED_URL, constants.FAILED_PLAN_PAYMENT_THISTLE_CANCELLED_URL, repaymentPlanParams);
                thistlePaymentRequest.then(function (result) {

                        //  Define the size of the Thistle iFrame
                        utilityService.defineThistleIframeHeight($scope);

                        $scope.thistleUrl = result.thistleUrl;
                        $scope.encodedXml = result.encodedXml;
                        $scope.loading = false;
                    },
                    function(errorResult) {
                        console.log(errorLoggingService.errorToString(errorResult));
                        $location.path(urlService.getErrorUrl());
                    });
            },
            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            })

    }]);

instalmentPlanControllers.controller('InstalmentPlanNotCashOrCheque', ['$scope', '$http', '$location', 'urlService',
    function ($scope, $http, $location, urlService) {
        $scope.connectionDetails = connection;

        $scope.back = function () {
            $location.path(urlService.getHomeUrl());
        }
    }]);
instalmentPlanControllers.controller('InstalmentPlanHistoryError', ['$scope', '$http', '$location', 'urlService','instalmentPlanEligibilityService','$routeParams',
    function ($scope, $http, $location, urlService,instalmentPlanEligibilityService,$routeParams) {
         var viewLastestBill=connection.viewLatestBill;
        if(angular.isDefined(viewLastestBill)){
            $scope.viewLastestBill = viewLastestBill.replace(/%ACC_KEY/g, $routeParams.accKey);
        }
        if(instalmentPlanEligibilityService.warningMessage!=null && instalmentPlanEligibilityService.warningMessage.length>0){
             $scope.warningMessage=instalmentPlanEligibilityService.warningMessage;
        }
           
    }]);
instalmentPlanControllers.controller('InstalmentPlanPaymentFailed', ['$scope', '$http', '$location',
    function ($scope, $http, $location) {
        $scope.connectionDetails = connection;
    }]);

instalmentPlanControllers.controller('InstalmentPlanUpfrontPayment', ['$scope', '$http', '$location', 'thistleService', 'errorLoggingService', 'repaymentPlanService', 'utilityService',
    function ($scope, $http, $location, thistleService, errorLoggingService, repaymentPlanService, utilityService) {
        $scope.loading = true;

        var repaymentPlan = repaymentPlanService.getRepaymentPlan();
        $scope.amount = repaymentPlan.upfront.amount;
        $scope.currency = repaymentPlan.upfront.currencyCode;
        $scope.startDate = moment(repaymentPlan.startDate, "DD-MM-YYYY");
        var formattedStartDate = moment($scope.startDate).format('YYYY-MM-DD');
        $scope.endDate = moment(repaymentPlan.endDate, "DD-MM-YYYY");
        var formattedEndDate = moment($scope.endDate).format('YYYY-MM-DD');
        $scope.frequency = repaymentPlan.frequency;
        $scope.instalmentTotal = repaymentPlan.instalmentTotal.amount;
        $scope.instalmentTotalCurrency = repaymentPlan.instalmentTotal.currencyCode;

        var thistlePaymentRequest = thistleService.getPaymentRequest($scope.amount, $scope.currency, formattedStartDate, formattedEndDate, $scope.frequency, $scope.instalmentTotal, $scope.instalmentTotalCurrency, constants.CREATE_INSTALMENT_THISTLE_SUCCESS_URL, constants.CREATE_INSTALMENT_THISTLE_FAILED_URL, constants.CREATE_INSTALMENT_THISTLE_CANCELLED_URL);

        thistlePaymentRequest.then(function (result) {

                //  Define the size of the Thistle iFrame
                utilityService.defineThistleIframeHeight($scope);

                $scope.thistleUrl = result.thistleUrl;
                $scope.encodedXml = result.encodedXml;
                $scope.loading = false;
            },
            function(errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            })
    }]);

instalmentPlanControllers.controller('InstalmentPlanDatepicker', ['$scope', 'moreTimeToPayByDateService','instalmentPlanEligibilityService',
    function ($scope, moreTimeToPayByDateService,instalmentPlanEligibilityService) {

        $scope.openDP = function($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.opened = true;
        };

        $scope.maxDate = new Date(2050, 12, 31);


        $scope.showWeeks = function () {

            return false;
        };

        $scope.showButtonBar = function () {

            return false;
        };
        $scope.onchange= function(event){
            $scope.getBillFrequencyDetails(this.datepicker);

        };
        $scope.clear = function () {
            $scope.datepicker = null;
        };

        var today =  new Date();
        var todayStr = today.getFullYear() + "-" +  (today.getMonth()+1) +  "-" + today.getDate();
        var result = instalmentPlanEligibilityService.getInstalmentPlan();
        var  nextBillDate = result.nextBillDate;
        $scope.availableDates = moreTimeToPayByDateService.getAvailablePayByDates(todayStr, nextBillDate);

        $scope.dt = today;
        // Only allow dates that are valid
        $scope.disabled = function (date, mode) {

            var validDatesArr = $scope.availableDates;

            var dateToCheck = moment([date.getFullYear(), date.getMonth(), date.getDate()]);
            var dateToCheckFormatted = moment(dateToCheck).format('dddd Do MMMM');

            //  Check whether the passed in date is in the available date list. The implementation below
            //  is an example and should be re-engineered into a more elegant solution
            var dateAvailable = true;
            for (var i = 0; i < validDatesArr.length; i++) {

                var validDate = moment(validDatesArr[i], 'YYYY-MM-DD');
                var validDateFormatted = moment(validDate).format('dddd Do MMMM');

                if (dateToCheckFormatted === validDateFormatted) {

                    dateAvailable = false;
                }
            }

            return ( dateAvailable );
        };


        $scope.open = function () {
            $timeout(function () {
                $scope.opened = true;
            });
        };

        $scope.dateOptions = {
            'year-format': "'yyyy'",
            'starting-day': 0
        };

        $scope.getDayClass = function (date, mode) {
            if (mode === 'day') {
                var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

                for (var i = 0; i < $scope.events.length; i++) {
                    var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

                    if (dayToCheck === currentDay) {
                        return $scope.events[i].status;
                    }
                }
            }

            return '';
        };
    }]);

instalmentPlanControllers.controller('InstalmentPlanDatePickerFirstPayment', ['$scope', 'moreTimeToPayByDateService', 'instalmentPlanEligibilityService',
    function ($scope, moreTimeToPayByDateService, instalmentPlanEligibilityService) {

        $scope.openDP = function($event) {
            $event.preventDefault();
            $event.stopPropagation();
            $scope.opened = true;
        };

        $scope.maxDate = new Date(2050, 12, 31);


        $scope.showWeeks = function () {

            return false;
        };

        $scope.showButtonBar = function () {

            return false;
        };
        $scope.onchange= function(event){
            $scope.getBillFrequencyDetails(this.datepicker);

        };
        $scope.clear = function () {
            $scope.datepicker = null;
        };


        if ($scope.lastInstalmentDatePicker != undefined) {

            var lastInstalmentDatePickerMoment = moment($scope.lastInstalmentDatePicker).subtract(1, 'days');
            var lastInstalmentDatePickerFormatted = moment(lastInstalmentDatePickerMoment).format("YYYY-MM-DD");

            var tomorrowFormatted = moment().add(1, 'days').format("YYYY-MM-DD");

            $scope.availableDates = moreTimeToPayByDateService.getDatesInRange(tomorrowFormatted, lastInstalmentDatePickerFormatted);
        }

        // Only allow dates that are valid
        $scope.disabled = function (date, mode) {

            var validDatesArr = $scope.availableDates;

            var dateToCheck = moment([date.getFullYear(), date.getMonth(), date.getDate()]);
            var dateToCheckFormatted = moment(dateToCheck).format('dddd Do MMMM');

            //  Check whether the passed in date is in the available date list. The implementation below
            //  is an example and should be re-engineered into a more elegant solution
            var dateAvailable = true;
            for (var i = 0; i < validDatesArr.length; i++) {

                var validDate = moment(validDatesArr[i], 'YYYY-MM-DD');
                var validDateFormatted = moment(validDate).format('dddd Do MMMM');

                if (dateToCheckFormatted === validDateFormatted) {

                    dateAvailable = false;
                }
            }

            return ( dateAvailable );
        };


        $scope.open = function () {
            $timeout(function () {
                $scope.opened = true;
            });
        };

        $scope.dateOptions = {
            'year-format': "'yyyy'",
            'starting-day': 0
        };

        $scope.getDayClass = function (date, mode) {
            if (mode === 'day') {
                var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

                for (var i = 0; i < $scope.events.length; i++) {
                    var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

                    if (dayToCheck === currentDay) {
                        return $scope.events[i].status;
                    }
                }
            }

            return '';
        };
    }]);


