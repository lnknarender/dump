var appFilters = angular.module('appFilters', []);

if ( typeof String.prototype.startsWith != 'function' ) {

    String.prototype.startsWith = function( str ) {
        return this.substring( 0, str.length ) === str;
    };
}

appFilters.filter('yesNo', function() {
    return function(input) {
        return input ? 'Yes' : 'No';
    };
});

//Only takes date in the format yyyy-MM-dd and converts to dd/MM/yyyy
appFilters.filter('reFormatDateToDDMMYYYY', function() {
    return function(input) {
        if(input){
        var stringArr = input.split("-");
        var formattedStr = stringArr[2] + "/" + stringArr[1] + "/" + stringArr[0];
        return formattedStr;
        }
        else{
            return "N/A";
        }
    };
});

//Only takes date in the format yyyy-MM-dd and converts to a string e.g. 'Friday 23rd June'
appFilters.filter('reFormatDateToString', function() {
    return function(input) {
        if(input){
            var dateToFormat = moment(input, 'yyyy-MM-DD');
            var formattedDate =  moment(dateToFormat).format('dddd Do MMMM');
            return formattedDate;
        }
        else{
            return "";
        }
    };
});

//Only takes date in the format MM/YYYY and converts to a string in format MM/YY
appFilters.filter('reFormatExpiryDate', function() {
    return function(input) {
        if(input){
            var dateToFormat = moment(input, 'MM/YYYY');
            var formattedDate =  moment(dateToFormat).format('MM/YY');
            return formattedDate;
        }
        else{
            return "";
        }
    };
});

appFilters.filter('formatSortCode', function() {
    return function(input) {
        var formattedSortCode = "";
        if(input){

                var unformattedSortCode = input.replace(/-/g, ""); // remove any hyphens

                if (unformattedSortCode.length > 0) {
                    formattedSortCode = unformattedSortCode.match(new RegExp('.{1,2}', 'g')).join("-"); //add hyphens after ever 2 digits
                }
        }

        return formattedSortCode;
    };

});

//Only takes date in the format yyyyMMdd hh:mm:ss and converts to a string e.g. '21:01 - 4th May 2015'
appFilters.filter('reFormatDateTimeToString', function() {
    return function(input) {
        if(input){
            var dateToFormat = moment(input, 'YYYYMMDD HH:mm:ss');
            var formattedDate =  moment(dateToFormat).format('D MMM YYYY  HH:mm'),splitdate= formattedDate.split(" ");
			var date,len=splitdate.length;
			for (var i=0;i<len;i++){
			  if(i==3){
			  date =[date,"at",splitdate[i]].join(" ");
			  }else{
			  date =[date,splitdate[i]].join(" ");
			  }
			}
            return date;
        }
        else{
            return "";
        }
    };
});

appFilters.filter('checkForEmptyString', function() {
    return function(input) {
        if(input){
            return input;
        }
        else{
            return "N/A";
        }
    };
});

function maskAccountNumber (str) {

    if(str) {

        var trailingMaskCharsCount = 4;

        if (str.length >= trailingMaskCharsCount) {

            var result = str.substring(0, str.length - (trailingMaskCharsCount)) + new Array(trailingMaskCharsCount + 1).join('*');

            return result;
        }
    }

    return str;
}

appFilters.filter('maskAccountNumber', function() {

    return function(str) {

        return maskAccountNumber(str);
    };
});

function maskBankAccountNumber(str) {

    if (str) {

        var maskCharsCount = 4;

        if (str.length >= maskCharsCount) {

            var result = new Array(maskCharsCount + 1).join('*') + str.substring(str.length - (maskCharsCount));

            return result;
        }
    }

    return str;
}

appFilters.filter('maskBankAccountNumber', function() {

    return function(str) {

        return maskBankAccountNumber(str);
    };
});

function toSDKStandard(str) {

    if(str) {

        if (str.startsWith('GB')) {

            var result = '02' + str.substring(2, str.length);

            return result;
        }
    }

    return str;
}

appFilters.filter('toSDKStandard', function() {

    return function(str) {

        return toSDKStandard(str);
    };
});


function toDisplayStandard(str) {

    if(str) {

        if (str.startsWith('02')) {

            var result = 'GB' + str.substring(2, str.length);

            return result;
        }
    }

    return str;
}

appFilters.filter('toDisplayStandard', function() {

    return function(str) {

        return toDisplayStandard(str);
    };
});

appFilters.filter('maskAccountNumberAndToSDKStandard', function() {

    return function(str) {

        var masked = maskAccountNumber(str);

        return toSDKStandard(masked);
    };
});

appFilters.filter('maskAccountNumberAndToDisplayStandard', function() {

    return function(str) {

        var masked = maskAccountNumber(str);

        return toDisplayStandard(masked);
    };
});
