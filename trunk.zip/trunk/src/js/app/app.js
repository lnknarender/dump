var app = angular.module('bptaAppl', ['ngRoute', 'routeStyles','appControllers', 'instalmentPlanControllers', 'makePaymentControllers','homePageControllers', 'appServices','instalmentPlanServices','makePaymentServices', 'homePageServices', 'inviteCustomerOnlineServices', 'inviteCustomerOnlineController', 'viewPaymentMethodServices', 'viewPaymentMethodController', 'setupPaymentMethodController', 'setupPaymentMethodServices', 'paymentMethodServices', 'appDirectives', 'appFilters', 'pascalprecht.translate', 'ngAnimate', 'ui.bootstrap', 'changePaymentMethodController', 'changePaymentMethodServices','cancelPaymentMethodController', 'editPaymentMethodController','editPaymentMethodServices', 'billingDashboardController', 'billingdashboardServices','reAssessmentServices']);


//Scrolls the window back to the top when a new view is loaded
angular.module('bptaAppl').run(["$rootScope", "$anchorScroll" , function ($rootScope, $anchorScroll) {
    $rootScope.$on("$locationChangeSuccess", function() {
        $anchorScroll();
    });
}]);

app.config( ['$translateProvider', function ($translateProvider) {
    $translateProvider.useStaticFilesLoader({
        prefix: 'properties/locale-',
        suffix: '.json'
    });

    $translateProvider.preferredLanguage('en');
}]);

app.config( ['$sceDelegateProvider', function ($sceDelegateProvider) {
    $sceDelegateProvider.resourceUrlWhitelist([
        'self',
        'https://btsecurepayments-test-gotham.bt.com/**',
        'https://btsecurepayments.bt.com/**'
    ]);
}]);


app.config(['$routeProvider','$locationProvider',
    function($routeProvider,$locationProvider) {

        $routeProvider.
            when('/billingdashboard', {
                templateUrl: 'templates/billingdashboard/billingdashboard.html',
                controller: 'billingDashboardCtrl',
                controllerAs: 'vm',
                title: "Billing dashboard"
            }).

            when('/viewbillprefs', {
                templateUrl: 'templates/billprefs/viewbillprefs.html',
                controller: 'ViewBillPrefsCtrl',
                title: "How I'm billed"
            }).

            when('/managebillprefs', {
                templateUrl: 'templates/billprefs/managebillprefs.html',
                controller: 'ManageBillPrefsCtrl',
                title: "How I'm billed"
            }).

            when('/successbillprefs', {
                templateUrl: 'templates/billprefs/successbillprefs.html',
                controller: 'ViewBillPrefsCtrl',
                title: "How I'm billed"
            }).

            when('/managebillprefsconf', {
                templateUrl: 'templates/billprefs/managebillprefsconfirmation.html',
                controller: 'ManageBillPrefsConfCtrl',
                title: "How I'm billed"
        }).

            when('/managebillprefssummary', {
                templateUrl: 'templates/billprefs/managebillprefssummaryagent.html',
                controller: 'ManageBillPrefsSummaryCtrl',
                title: "How I'm billed"
            }).

            when('/error', {
                templateUrl: 'templates/error.html',
                controller: 'ErrorCtrl',
                title: "Oops error occurred"
            }).

            when('/start', {
                templateUrl: 'templates/homepage/authenticationpage.html',
                controller: 'LandingCtrl',
                title: "Oops error occurred"
            }).

            when('/agentBillingHome', {
                templateUrl: 'templates/homepage/agentbillinghome.html',
                controller: 'AgentHomeCtrl',
                title: "Agent billing home"
            }).

            when('/customerBillingHome', {
                templateUrl: 'templates/homepage/customerbillinghome.html',
                controller: 'CustomerHomeCtrl',
                title: "Customer billing home"
            }).

            when('/moretimetopay', {
                templateUrl: 'templates/instalmentplans/index/instalmentplanIndex.html',
                controller: 'InstalmentPlanEligibility',
                title: "More time to pay"
            }).

            when('/instalmentMakepayment', {
                 templateUrl: 'templates/makepayment/paymentIndex.html',
                 controller: 'MakePaymentIndex',
                 title: "More time to pay"

        }).
         when('/setupCreateInstalmentPlan', {
            templateUrl: 'templates/instalmentplans/setup/create/createInstalmentIndex.html',
            controller: 'setupCreateInstalmentPlanCtrl',
            title: "More time to pay"
        }).
            when('/instalmentpreferences', {
                templateUrl: 'templates/instalmentplans/instalmentplanpreferences.html',
                controller: 'InstalmentPlanPreferences',
                title: "More time to pay"
        }).

            when('/instalmentconfirmation', {
                templateUrl: 'templates/instalmentplans/instalmentplanconfirmation.html',
                controller: 'InstalmentPlanConfirmation',
                title: "More time to pay"
        }).
            when('/instalmentplanopen', {
                            templateUrl: 'templates/instalmentplans/instalmentplanopen.html',
                            controller: 'InstalmentPlanOpen',
                        title: "More time to pay"

        }).
            when('/instalmentplanopenayment', {
                templateUrl: 'templates/instalmentplans/instalmentplanupfrontpayment.html',
                controller: 'InstalmentPlanOpenPayment',
                title: "More time to pay"
        }).
            when('/instalmentplanpaymentredirectsuccess', {
                templateUrl: 'templates/instalmentplans/setup/create/createInstalmentIndex.html',
                controller: 'setupCreateInstalmentPlanCtrl',
                title: "More time to pay"
        }).
            when('/instalmentwithoutupfrontsuccess', {
            templateUrl: 'templates/instalmentplans/setup/create/createInstalmentIndex.html',
            controller: 'setupCreateInstalmentPlanCtrl',
            title: "More time to pay"
        }).
            when('/instalmentpaymentfailed', {
            templateUrl: 'templates/instalmentplans/setup/create/createInstalmentIndex.html',
            controller: 'setupCreateInstalmentPlanCtrl',
            title: "More time to pay"
            })
            .when('/instalmentplanopenpaymentsuccess', {
                templateUrl: 'templates/instalmentplans/setup/create/instalmentPaymentResponseRedirect.html',
                title: "More time to pay"
            }).
            when('/instalmentplanopenpaymentfailed', {
                templateUrl: 'templates/instalmentplans/instalmentplanpaymentFailureResponseRedirect.html',
                title: "More time to pay"
        }).
            when('/instalmentplanfailed', {
                            templateUrl: 'templates/instalmentplans/instalmentplanfailed.html',
                            controller: 'InstalmentPlanFailed',
                            title: "More time to pay"
        }).
            when('/instalmentplanfailedpayment', {
                            templateUrl: 'templates/instalmentplans/instalmentplanupfrontpayment.html',
                            controller: 'InstalmentPlanFailedPayment',
                            title: "More time to pay"
        }).
            when('/instalmentplanfailedpaymentsuccess', {
                templateUrl: 'templates/instalmentplans/instalmentplanpaymentsuccess.html',
                controller: 'InstalmentPlanPaymentSuccess',
                title: "More time to pay"

        }).
            when('/instalmentplanfailedpaymentfailed', {
                templateUrl: 'templates/instalmentplans/instalmentplanfailedpayment.html',
                controller: 'InstalmentPlanPaymentFailed',
                title: "More time to pay"
        }).
            when('/instalmentplannotcashorcheque', {
                            templateUrl: 'templates/instalmentplans/instalmentplancustomernotoncashcheque.html',
                            controller: 'InstalmentPlanNotCashOrCheque',
                            title: "More time to pay"

            })
            .when('/instalmentplanupfrontpayment', {
                templateUrl: 'templates/instalmentplans/instalmentplanupfrontpayment.html',
                controller: 'InstalmentPlanUpfrontPayment',
                title: "More time to pay"
            })
            .when('/instalmentplanupfrontpaymentsuccess', {
                templateUrl: 'templates/instalmentplans/instalmentplanconfirmation.html',
                controller: 'InstalmentPlanConfirmation',
                title: "More time to pay"
            })
            .when('/instalmentplanupfrontpaymentfailed', {
                templateUrl: 'templates/instalmentplans/instalmentplanfailedpayment.html',
                title: "More time to pay"

            })
            .when('/customermakepaymentpaymentindex', {
                templateUrl: 'templates/makepayment/paymentIndex.html',
                controller: 'MakePaymentIndex',
                title: "Pay your BT bill"
            })

            .when('/agentmakepaymentindex', {
                templateUrl: 'templates/makepayment/paymentIndex.html',
                controller: 'MakePaymentIndex',
                title: "Pay your BT bill"
            })
             .when('/logoutmakepaymentindex', {
                templateUrl: 'templates/makepayment/paymentIndex.html',
                controller: 'MakePaymentIndex',
                title: "Pay your BT bill"
             })
            .when('/makepaymentsuccess', {
                templateUrl: 'templates/makepayment/paymentIndex.html',
                controller: 'MakePaymentIndex',
                title: "Pay your BT bill"
            })

            .when('/makepaymentfailed', {
                templateUrl: 'templates/makepayment/paymentIndex.html',
                controller: 'MakePaymentIndex',
                title: "Pay your BT bill"
            })
            .when('/makepaymentcancelled', {
                templateUrl: 'templates/makepayment/paymentIndex.html',
                controller: 'MakePaymentIndex',
                title: "Pay your BT bill"
            })
            .when('/instalmentplanCancelledRedirect', {
                 templateUrl: 'templates/instalmentplans/index/instalmentplanIndex.html',
                controller: 'InstalmentPlanEligibility',
                title: "Pay your BT bill"
            })
            .when('/makepaymentresponseredirect', {
                templateUrl: 'templates/makepayment/paymentResponseRedirect.html',
                title: "Pay your BT bill"
            })
            .when('/mobilemakepaymentresponseredirect', {
                templateUrl: 'templates/makepayment/mobilepaymentResponseRedirect.html',
                title: "Pay your BT bill"
            })


            .when('/paymentmethodupfrontpaymentsuccess', {
                templateUrl: 'templates/paymentmethod/setup/wbdd/paymentmethodResponseRedirect.html',
                title: "Pay your BT bill"

            })
            .when('/paymentmethodupfrontpaymentcancel', {
                templateUrl: 'templates/paymentmethod/setup/wbdd/paymentmenthodCancelledResponseRedirect.html',
                title: "Payment method"
            })
            .when('/paymentmethodupfrontpaymentfailed', {
                templateUrl: 'templates/paymentmethod/setup/wbdd/paymentmethodFailureResponseRedirect.html',
                title: "Payment method"
            })
            .when('/paymentmethodupfrontpaymentcancelled', {
                templateUrl: 'templates/paymentmethod/setup/wbdd/setupPaymentmethodCancelledResponseRedirect.html',
                title: "Payment method"
            })


            .when('/makepaymentfailureresponseredirect', {
                templateUrl: 'templates/makepayment/paymentFailureResponseRedirect.html',
                title: "Payment method"
            })
            .when('/makepaymentcancelledresponseredirect', {
                templateUrl: 'templates/makepayment/paymentCancelledResponseRedirect.html',
                title: "Payment method"
            })

            .when('/mobilemakepaymentfailureresponseredirect', {
                templateUrl: 'templates/makepayment/mobilepaymentFailureResponseRedirect.html',
                title: "Payment method"
            })
            .when('/mobilemakepaymentcancelledresponseredirect', {
                templateUrl: 'templates/makepayment/mobilepaymentCancelledResponseRedirect.html',
                title: "Payment method"
            })

            .when('/instalmentplanCancelled', {
                templateUrl: 'templates/instalmentplans/instalmentplanCancelledResponseRedirect.html',
                title: "Payment method"
            })
            .when('/instalmentplannohistoryerror', {
                templateUrl: 'templates/instalmentplans/instalmentplannohistoryerror.html',
                controller: 'InstalmentPlanHistoryError',
                title: "Payment method"
            })
            .when('/makePaymentthistlefailed', {
                templateUrl: 'templates/makepayment/paymentFailed.html',
                controller: 'MakePaymentThistleFailed',
                title: "Payment method"
            })
            .when('/invitecustomeronline', {
                templateUrl: 'templates/invitecustomeronline/invitecustomeronline.html',
                controller: 'inviteCustomerOnlineCtrl',
                title: "TBD"
            })
            .when('/viewPaymentMethod', {
                templateUrl: 'templates/paymentmethod/view/viewPaymentMethod.html',
                controller: 'viewPaymentMethodCtrl',
                title: "Payment method"
            })

            .when('/setupWbddPaymentMethod', {
                templateUrl: 'templates/paymentmethod/setup/wbdd/paymentMethod.html',
                controller: 'setupPaymentMethodWbddCtrl',
                title: "Payment method"
            })

            .when('/paymentMethodWbddSuccess', {
                templateUrl: 'templates/paymentmethod/setup/wbdd/paymentMethodSuccess.html',
                controller: 'setupPaymentMethodWbddSuccessCtrl',
                title: "Payment method"
            })
            .when('/paymentMethodWbddFailure', {
                templateUrl: 'templates/paymentmethod/setup/wbdd/paymentMethodSuccess.html',
                controller: 'setupPaymentMethodWbddSuccessCtrl',
                title: "Payment method"
            })
            .when('/cancelwbdd', {
                templateUrl: 'templates/paymentmethod/cancel/wbdd.html',
                controller: 'cancelPaymentMethodCtrl',
                title: "Payment method"
            })
            .when('/changepaymentmethodcashcheque', {
                templateUrl: 'templates/paymentmethod/change/changePaymentMethod.html',
                controller: 'changePaymentMethodCashChequeCtrl',
                title: "Payment method"
            })
            .when('/editPaymentMethodFrequencyWbdd', {
                templateUrl: 'templates/paymentmethod/edit/wbdd/editFrequency.html',
                controller: 'editFrequencyWbddCtrl',
                title: "Payment method"
            })
            .when('/editPaymentMethodPaymentDayWbdd', {
                templateUrl: 'templates/paymentmethod/edit/wbdd/editPaymentDay.html',
                controller: 'editPaymentDayWbddCtrl',
                title: "Payment method"
            })
            .when('/editPaymentMethodWbddSuccess', {
                templateUrl: 'templates/paymentmethod/edit/wbdd/editSuccess.html',
                controller: 'editPaymentMethodsWbddSuccessCtrl',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/editbankdetails', {
                templateUrl: 'templates/paymentmethod/edit/editBankDetails.html',
                controller: 'editBankDetailsCtrl',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/updatebankdetails', {
                templateUrl: 'templates/paymentmethod/edit/editBankDetailsSuccess.html',
                controller: 'updateBankDetailsCtrl',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/ccrasetup', {
                templateUrl: 'templates/paymentmethod/setup/ccra/setup.html',
                controller: 'setupCcraPaymentMethodController',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/ccrasetupredraw', {
                templateUrl: 'templates/paymentmethod/setup/ccra/setup.html',
                controller: 'setupCcraPaymentMethodController',
                controllerAs: 'vm',
                title: "TBD"
            })
            .when('/ccrasetuppaymentsuccess', {
                templateUrl: 'templates/paymentmethod/setup/ccra/paymentSuccessRedirect.html',
                title: "Payment method"
            })
            .when('/ccrasetuppaymentfailed', {
                templateUrl: 'templates/paymentmethod/setup/ccra/paymentFailedRedirect.html',
                title: "Payment method"
            })
            .when('/ccrasetuppaymentcancel', {
                templateUrl: 'templates/paymentmethod/setup/ccra/paymentCancelRedirect.html',
                title: "Payment method"
            })
            .when('/ccrasetupcarddetailssuccess', {
                templateUrl: 'templates/paymentmethod/setup/ccra/cardDetailsSuccessRedirect.html',
                title: "Payment method"
            })
            .when('/ccrasetupcarddetailsfailed', {
                templateUrl: 'templates/paymentmethod/setup/ccra/cardDetailsFailedRedirect.html',
                title: "Payment method"
            })
            .when('/ccrasetupcarddetailscancel', {
                templateUrl: 'templates/paymentmethod/setup/ccra/cardDetailsCancelRedirect.html',
                title: "Payment method"
            })
            .when('/ccrauseadifferentcard', {
                templateUrl: 'templates/paymentmethod/edit/ccra/useADifferentCard.html',
                controller: 'editCcraUseADifferentCardCtrl',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/ccrauseadifferentcardfailedpage', {
                templateUrl: 'templates/paymentmethod/edit/ccra/differentCardFailed.html',
                controller: 'editCcraUseADifferentCardFailedCtrl',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/ccraeditsuccess', {
                templateUrl: 'templates/paymentmethod/edit/ccra/editSuccess.html',
                controller: 'editCcraSuccessCtrl',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/ccraeditdifferentcardsuccess', {
                templateUrl: 'templates/paymentmethod/edit/ccra/differentCardSuccessRedirect.html',
                title: "Payment method"
            })
            .when('/ccraeditdifferentcardfailed', {
                templateUrl: 'templates/paymentmethod/edit/ccra/differentCardFailedRedirect.html',
                title: "Payment method"
            })
            .when('/ccraeditdifferentcardcancel', {
                templateUrl: 'templates/paymentmethod/edit/ccra/differentCardCancelRedirect.html',
                title: "Payment method"
            })
            .when('/ccracancel', {
                templateUrl: 'templates/paymentmethod/cancel/ccra.html',
                controller: 'cancelPaymentMethodCtrl',
                title: "Payment method"
            })
            .when('/setupmpp', {
                templateUrl: 'templates/paymentmethod/setup/mpp/setup.html',
                controller: 'setupMppPaymentMethodController',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/mppsetuppaymentsuccess', {
                templateUrl: 'templates/paymentmethod/setup/mpp/paymentSuccessRedirect.html',
                title: "Payment method"
            })
            .when('/mppsetuppaymentfailed', {
                templateUrl: 'templates/paymentmethod/setup/mpp/paymentFailedRedirect.html',
                title: "Payment method"
            })
            .when('/mppsetuppaymentcancel', {
                templateUrl: 'templates/paymentmethod/setup/mpp/paymentCancelRedirect.html',
                title: "Payment method"
            })
            .when('/cancelmpp', {
                templateUrl: 'templates/paymentmethod/cancel/mpp.html',
                controller: 'cancelPaymentMethodCtrl',
                title: "Payment method"
            })
            .when('/editmppamount', {
                templateUrl: 'templates/paymentmethod/edit/mpp/editPaymentAmount.html',
                controller: 'editMppPaymentAmountCtrl',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/editmpppaymentday', {
                templateUrl: 'templates/paymentmethod/edit/mpp/editPaymentDay.html',
                controller: 'editMppPaymentDayCtrl',
                controllerAs: 'vm',
                title: "Payment method"
            })            
            .when('/mppressessmentaction', {
                templateUrl: 'templates/paymentmethod/setup/mpp/ressessment/ressesmentSetup.html',
                controller: 'reAssessmentController',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/mppressessmentpaymentssuccess', {
                templateUrl: 'templates/paymentmethod/setup/mpp/ressessment/ressesmentSuccessRedirect.html',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/mppressessmentpaymentfailed', {
                templateUrl: 'templates/paymentmethod/setup/mpp/ressessment/ressesmentFailedRedirect.html',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .when('/mppressessmentpaymentcancel', {
                templateUrl: 'templates/paymentmethod/setup/mpp/ressessment/ressesmentCancelRedirect.html',
                controllerAs: 'vm',
                title: "Payment method"
            })
            .otherwise({
                redirectTo: '/start'
            });
    }]).run(['$rootScope', '$route',
    function ($rootScope, $route) {


        $rootScope.$on('$routeChangeStart', function (event, next, current) {
            $rootScope.allowstyle = !(next.disablestyle || false);

            if (connection.userType.toLowerCase() === "agent" && !$rootScope.contextupdated) {
                var api = new FrameworkNavigation(
                        function () {
                            var contextData = {
                                category: "Billing Account",
                                subCategory: "",
                                reference_value: "GenevaGB" + next.params.bac,
                                orderRevisionId: ""
                            };
                            console.log(contextData);
                            var contextUpdate = new ContextUpdate("BillingSummary", contextData);
                            api.sendMessage(contextUpdate, function () {
                                $rootScope.contextupdated = true;
                                console.info("context message sent to framework successfully");
                            }, function () {
                                console.info("context message error");
                            });
                        });

            }
        });

        //  Default the browser tab name
        $rootScope.pageTitle = 'Billing';

        //  Update the browser tab when successfully navigated to the page
        $rootScope.$on('$routeChangeSuccess', function() {

            $rootScope.pageTitle = $route.current.title;
        });
    }]);