/**
 * Created by Andrew on 23/11/2015.
 */

var viewPaymentMethodController = angular.module('viewPaymentMethodController', []);

/**
 * Controller that handles the view payment method
 */
viewPaymentMethodController.controller('viewPaymentMethodCtrl', ['$scope', '$location', 'urlService', 'errorLoggingService', 'viewPaymentMethodServices', 'viewLatestBillService', 'primaryContactService', 'utilityService', 'commonPaymentMethodServices', 'stateService', 'changePaymentMethodServices', 'editPaymentMethodWbddCommonService', '$routeParams', '$window', 'paymentFriendlyNameService',
    function ($scope, $location, urlService, errorLoggingService, viewPaymentMethodServices, viewLatestBillService, primaryContactService, utilityService, commonPaymentMethodServices, stateService, changePaymentMethodServices, editPaymentMethodWbddCommonService, $routeParams, $window, paymentFriendlyNameService) {

        $scope.loading = true;

        $scope.userType = connection.userType;
        $scope.userFriendlyName = undefined;

        if ($scope.userType === constants.CUSTOMER) {
            utilityService.getPaymentFriendlyName(paymentFriendlyNameService, primaryContactService, errorLoggingService).then(contactDetails);
        }

        // Create the view customer's latest bill link. Variable will be null for advisor
        $scope.viewLastestBill = viewLatestBillService.getLatestBillLink();

        $scope.displayHorizontalRule = true;

        var viewPaymentMethodResponse = commonPaymentMethodServices.getAllViewPaymentRequest($scope.userType);

        viewPaymentMethodResponse.then(function (result) {

                $scope.paymentMethods = result.viewPaymentMethods;

                if ($scope.userType === constants.AGENT) {
                    $scope.primaryContactDetails = commonPaymentMethodServices.primaryContactDetails = result.primaryContactDetails;
                    stateService.set(constants.STATE_SERVICE_CONTACT_EMAIL, $scope.primaryContactDetails.email);
                }
                else if ($scope.userType === constants.CUSTOMER){
                    utilityService.getCustomerEmailAddress($routeParams.accKey, errorLoggingService);
                }

                $scope.loading = false;

                //  Convert to an ordinal number (e.g 1 => 1st, 2 => 2nd, 3 => 3rd etc)
                if (result.viewPaymentMethods.paymentDay === -1) {
                    // -1 means last day of the month
                    $scope.dayOfMonth = "last day";
                } else {
                    $scope.dayOfMonth = utilityService.getOrdinalNumber(result.viewPaymentMethods.paymentDay);
                }

                // The isDefined function does not check for NULL, at least when using the version 1.2.28 of AngularJS
                if (angular.isDefined(result.cardDetails) && result.cardDetails !== null) {
                    $scope.expiryDate = utilityService.getCreditCardExpiryDate(result.cardDetails.expiryDate);
                }

                $scope.isDisplayLrPlusButton = function () {

                    return (connection.userType === constants.AGENT) && (viewPaymentMethodServices.isDirectDebit($scope.paymentMethods) || viewPaymentMethodServices.isMonthlyPaymentPlan($scope.paymentMethods)) &&
                        (viewPaymentMethodServices.isCustomerEligibleForCashAndCheque($scope.paymentMethods) || viewPaymentMethodServices.isCustomerEligibleForCcra($scope.paymentMethods));
                };

                $scope.userClosedWbddEligibleAlert = false;
                $scope.userClosedNotEligibleAlert = false;

                /**
                 *  Determine whether the customer is billed quarterly
                 *  @return Returns true when the customer is billed quarterly
                 */
                $scope.isQuarterlyBill = function () {

                    return viewPaymentMethodServices.isQuarterlyBill($scope.paymentMethods);
                };

                $scope.editPaymentMethodAction = function (paymentMethod, editAction, controller) {

                    commonPaymentMethodServices.paymentMethods = $scope.paymentMethods;

                    commonPaymentMethodServices.editPaymentMethodAction = editAction;
                    $location.path(controller);
                };
               
                if($scope.paymentMethods.mppScenario!==constants.MPP_REASSES_NONE){
                         viewPaymentMethodServices.getMppRessessmentOptions($scope.paymentMethods,$scope);
                          angular.extend(commonPaymentMethodServices,{
                                        outstandingAmount:$scope.outStandingAmount,
                                        mppScenario:$scope.mppScenario,
                                        monthlyRecommendedAmount:$scope.monthlyRecommendedAmount,
                                        oldReassessedAmount:$scope.oldReassessedAmount,
                                        newReassessedAmount:$scope.newReassessedAmount,
                                        mppReassesdate:$scope.mppReassesdate,
                                        reassesedBy:$scope.reassesedBy,
                                        refundAndPaymentHoliday:$scope.refundAndPaymentHoliday
                       });
                    }
                  $scope.mppRessessmentAction=function(action){
                      commonPaymentMethodServices.mppRessessmentAction=action;
                      commonPaymentMethodServices.paymentMethods = $scope.paymentMethods;
                      $location.path('/mppressessmentaction');
                  };
                  
                /**
                 *  Determine whether the customer is billed monthly
                 *  @return Returns true when the customer is billed monthly
                 */
                $scope.isMonthlyBill = function () {

                    return viewPaymentMethodServices.isMonthlyBill($scope.paymentMethods);
                };

                $scope.editBankeDetails = function () {
                    $scope.editPaymentMethodAction($scope.paymentMethods.paymentMethod, constants.BANKDETAILS, '/editbankdetails');

                };

                $scope.useADifferentCard = function () {
                    $scope.editPaymentMethodAction($scope.paymentMethods.paymentMethod, constants.USE_A_DIFFERENT_CARD, '/ccrauseadifferentcard');
                };

                $scope.editPaymentDays = function () {
                    if ($scope.paymentMethods.paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN) {
                        commonPaymentMethodServices.getAccountHistoryForEdit().then(function (response) {
                            if (response.paymentDateChangeOption === 'Y') {
                                $scope.editPaymentMethodAction($scope.paymentMethods.paymentMethod, constants.PAYMENT_DAY, '/editmpppaymentday');
                            } else {
                                $scope.showLinkForpaymentDay = true;
                            }
                        }, function (error) {

                        });
                    } else if ($scope.paymentMethods.paymentMethod === constants.PAYMENT_METHOD_DIRECT_DEBIT) {
                        var paymentDayResponse = editPaymentMethodWbddCommonService.getPaymentDays();
                        paymentDayResponse.then(function (paymentDayResult) {
                                if (paymentDayResult.billCycles!==null && paymentDayResult.billCycles.length > 1) {
                                    $scope.editPaymentMethodAction($scope.paymentMethods.paymentMethod, constants.PAYMENT_DAY, '/editPaymentMethodPaymentDayWbdd');
                                } else {
                                    $scope.showLinkForpaymentDay = true;
                                    return false;
                                }
                            },
                            function (errorResult) {
                                console.log(errorLoggingService.errorToString(errorResult));
                                $location.path(urlService.getErrorUrl());
                            });
                    }

                };

                $scope.closePopup = function (flag) {
                    $scope[flag] = false;
                };

                $scope.editFrequency = function () {
                    $scope.editPaymentMethodAction($scope.paymentMethods.paymentMethod, constants.FREQUENCY, '/editPaymentMethodFrequencyWbdd');

                };

                $scope.editAmount = function () {
                    $scope.editPaymentMethodAction($scope.paymentMethods.paymentMethod, constants.AMOUNT, '/editmppamount');
                };
                /**
                 *  Determine whether the customer pays their bill as cash/cheque
                 *  @return Returns true when the customer pays their bill as cash/cheque
                 */
                $scope.isDisplayCashAndCheck = function () {

                    return viewPaymentMethodServices.isCashAndCheck($scope.paymentMethods);
                };

                /**
                 *  Determine whether the customer pays their bill with direct debit
                 *  @return Returns true when the customer pays their bill with direct debit
                 */
                $scope.isDisplayDirectDebit = function () {

                    return viewPaymentMethodServices.isDirectDebit($scope.paymentMethods);
                };

                /**
                 *  Determine whether the customer pays their bill with a credit or debit card
                 *  @return Returns true when the customer pays their bill with a credit or debit card
                 */
                $scope.isDisplayCcra = function () {

                    return viewPaymentMethodServices.isCcra($scope.paymentMethods);
                };

                /**
                 *  Determine whether the customer pays their bill using a monthly payment plan
                 *  @return Returns true when the customer pays bill using a monthly payment plan
                 */
                $scope.isDisplayMonthlyPaymentPlan = function () {

                    return viewPaymentMethodServices.isMonthlyPaymentPlan($scope.paymentMethods);
                };

                /**
                 *  Determine whether to display the customer is not eligible alert (agent only)
                 *  @return Returns true when the customer has a list of ineligibilities
                 */
                $scope.isDisplayNotEligibleAlert = function () {

                    return (commonPaymentMethodServices.isInEligiblePaymentMethods($scope.paymentMethods) &&
                    ($scope.userType == constants.AGENT) &&
                    $scope.userClosedNotEligibleAlert === false);
                };

                /**
                 *  Determine whether to display the automated payments link
                 *  @return Returns true when the customer using cash/cheque and has eligible payment methods
                 */
                $scope.isDisplayAutomatedPaymentsLink = function () {

                    return viewPaymentMethodServices.isCashAndCheck($scope.paymentMethods) &&
                        viewPaymentMethodServices.isEligiblePaymentMethods($scope.paymentMethods) &&
                        viewPaymentMethodServices.isEligibleChangePaymentMethodLink($scope.paymentMethods);
                };

                $scope.isDisplayChangePaymentMethodLink = function () {

                    return (viewPaymentMethodServices.isDirectDebit($scope.paymentMethods) ||
                        viewPaymentMethodServices.isCcra($scope.paymentMethods) ||
                        viewPaymentMethodServices.isMonthlyPaymentPlan($scope.paymentMethods)) &&
                        viewPaymentMethodServices.isEligiblePaymentMethods($scope.paymentMethods) &&
                        viewPaymentMethodServices.isEligibleChangePaymentMethodLink($scope.paymentMethods);
                };

                $scope.isDisplayChangeWhenYouPayLink = function () {

                    return (viewPaymentMethodServices.isDirectDebit($scope.paymentMethods));
                };

                $scope.isDisplayChangeToMonthlyLink = function () {

                    return (viewPaymentMethodServices.isDirectDebit($scope.paymentMethods) || viewPaymentMethodServices.isCashAndCheck($scope.paymentMethods) || viewPaymentMethodServices.isCcra($scope.paymentMethods)) &&
                        viewPaymentMethodServices.isEligiblePaymentMethodWithFrequency($scope.paymentMethods) &&
                        viewPaymentMethodServices.isQuarterlyBill($scope.paymentMethods) && (viewPaymentMethodServices.isFrequencyChangeEligible($scope.paymentMethods));
                };

                $scope.isDisplayChangeToQuarterlyLink = function () {

                    return (viewPaymentMethodServices.isDirectDebit($scope.paymentMethods) || viewPaymentMethodServices.isCashAndCheck($scope.paymentMethods) || viewPaymentMethodServices.isCcra($scope.paymentMethods)) &&
                        viewPaymentMethodServices.isEligiblePaymentMethodWithFrequency($scope.paymentMethods) &&
                        viewPaymentMethodServices.isMonthlyBill($scope.paymentMethods) && (viewPaymentMethodServices.isFrequencyChangeEligible($scope.paymentMethods));
                };

                $scope.isDisplayWholeBillDDEligibleAlert = function () {

                    return viewPaymentMethodServices.isCashAndCheck($scope.paymentMethods) &&
                        viewPaymentMethodServices.isWholeBillDDEligiblePaymentMethodPresent($scope.paymentMethods) &&
                        $scope.userClosedWbddEligibleAlert === false;
                };

                $scope.isDisplayBankDetails = function () {

                    return viewPaymentMethodServices.isDirectDebit($scope.paymentMethods) || viewPaymentMethodServices.isMonthlyPaymentPlan($scope.paymentMethods);
                };
                $scope.isDisplayCreditCardDetails = function () {

                    return viewPaymentMethodServices.isCcra($scope.paymentMethods);
                };

                $scope.isDisplayReassessmentStatusAlert = function () {

                    return (viewPaymentMethodServices.isMonthlyPaymentPlan($scope.paymentMethods) && $scope.userType == constants.AGENT);
                };

                $scope.isDisplayChangeDay = function () {
                    if (viewPaymentMethodServices.isCcra($scope.paymentMethods)) {
                        return false;
                    } else {
                        return true;
                    }
                };

                /**
                 * Calculate the outstanding charges per month
                 */
                $scope.outstandingChargesPerMonths = function () {

                    return viewPaymentMethodServices.calculateOutstandingChargesPerMonths($scope.paymentMethods);
                };

                $scope.ineligibleMethods = viewPaymentMethodServices.getIneligiblePaymentMethodReasons($scope.paymentMethods);

                $scope.isDisplayIneligibleMethods = function () {

                    return ($scope.userType == constants.AGENT) && ($scope.ineligibleMethods.length > 0);
                };

                $scope.closeThis = function (thisId) {
                    utilityService.closeThis(thisId);

                };

                $scope.ineligiblePaymentMethodFrequency = viewPaymentMethodServices.getIneligiblePaymentMethodFrequencyReasons($scope.paymentMethods);

                $scope.isDisplayIneligiblePaymentMethodFrequency = function () {

                    return ($scope.userType == constants.AGENT) && ($scope.ineligiblePaymentMethodFrequency.length > 0);
                };

                $scope.clickLrPlusButton = function () {

                    if (connection.userType === constants.AGENT) {

                        //  Get the order line plus URL globally replace %BAC, %CAK, %CONK and %TEL_NO and replace with the customer's details
                        var url = connection.orderLineRentalPlus;
                        url = url.replace(/%BAC/g, $routeParams.bac);
                        url = url.replace(/%CAK/g, $routeParams.cak);
                        url = url.replace(/%CONK/g, $routeParams.conk);
                        url = url.replace(/%TEL_NO/g, $routeParams.telephone_num);

                        $window.open(url, '_blank');
                    }
                };
            },
            function (errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });

        function contactDetails(response){
            $scope.userFriendlyName = response.userFriendlyName;
        }

        /**
         * Toogles the chevron for the 'How was this calculated' link
         * @param number HTML id of the chevron
         */
        $scope.toggleChevron = function (number) {
            utilityService.toggleChevron(number, $scope);
        };

        /**
         * User clicked the close the wholesale direct debit eligible alert box
         */
        $scope.closeWbddEligibleAlert = function () {
            $scope.userClosedWbddEligibleAlert = true;
        };

        /**
         * User clicked the close the not eligible alert box
         */
        $scope.closeNotEligibleAlert = function () {
            $scope.userClosedNotEligibleAlert = true;
        };

        $scope.clickSetupAutomaticPaymentLink = function () {
            $location.path('/changepaymentmethodcashcheque');
        };
        $scope.clickSetupChangePaymentLink = function () {
            $location.path('/changepaymentmethodcashcheque');
        };
        $scope.editPaymentMethod = function (gotofun, confirm, flag) {
            $scope[gotofun]();
            // Commented below call as we are waiting for clarification from business
//                if (!confirm) {
//                    commonPaymentMethodServices.getNextBillDate().then(function (nextBillDate) {
//                        var daysdiff = 2;
//                        commonPaymentMethodServices.nextBillDate=nextBillDate;
//                        if ($scope.paymentMethods.paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN) {
//                            daysdiff = 3;
//                        }
//                        $scope[flag] = commonPaymentMethodServices.isNextBillDateDue(nextBillDate, daysdiff);
//                        if (!$scope[flag]) {
//                            $scope[gotofun]();
//                        }
//                    }, function () {
//
//                    });
//                } else {
//                    $scope[gotofun]();
//                }
        };
        
        /**
         *  Handle click change to whole bill direct debit (WBDD) button
         */
        $scope.clickChangeToWbdd = function () {
            var viewPaymentMethodResponse = commonPaymentMethodServices.getAllRequest(connection.userType);
            viewPaymentMethodResponse.then(function (result) {
                commonPaymentMethodServices.paymentMethods = result.viewPaymentMethods;

                if (connection.userType === constants.AGENT) {
                    commonPaymentMethodServices.primaryContactDetails = result.primaryContactDetails;
                    stateService.set("contactEmail", result.primaryContactDetails.email);
                }
                var eligiblePaymentMethod = changePaymentMethodServices.displayEligiblePaymentMethods(commonPaymentMethodServices.paymentMethods, {});
                commonPaymentMethodServices.newSetupPaymentMethod = eligiblePaymentMethod['wbdd'];
                commonPaymentMethodServices.newPaymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;

                $location.path('/setupWbddPaymentMethod');
            });
        };
    }
]);
