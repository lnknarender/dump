/**
 * Created by Andrew on 23/11/2015.
 */

var viewPaymentMethodServices = angular.module('viewPaymentMethodServices',[]);

viewPaymentMethodServices.factory('viewPaymentMethodServices', ['$q','ajaxServiceWithToken','commonPaymentMethodUrlService', 
    function($q,ajaxServiceWithToken,commonPaymentMethodUrlService) {

    return {

        /**
         * Determines whether the customer is billed quarterly
         * @param paymentMethod Customers payment method
         * @returns {boolean} Returns true when customer is billed quarterly
         */
        isQuarterlyBill: function(paymentMethod){

          return (paymentMethod !== undefined && paymentMethod.billFrequency === constants.BILL_QUARTERY);
        },

        /**
         * Determines whether the customer is billed monthly
         * @param paymentMethod Customers payment method
         * @returns {boolean} Returns true when customer is billed monthly
         */
        isMonthlyBill: function(paymentMethod){

            return (paymentMethod !== undefined && paymentMethod.billFrequency === constants.BILL_MONTHLY) ;
        },

        /**
         * Determines whether the customer has monthly payment plan
         * @param paymentMethod Customers payment method
         * @returns {boolean} Returns true when customer has monthly payment plan
         */
        isMonthlyPaymentPlan: function(paymentMethod){

            return (paymentMethod !== undefined && paymentMethod.paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN) ;
        },

        /**
         * Determines whether the customer pays using cash & cheque
         * @param paymentMethod Customers payment method
         * @returns {boolean} Returns true when customer using cash & cheque
         */
        isCashAndCheck: function(paymentMethod){

            return (paymentMethod !== undefined && paymentMethod.paymentMethod === constants.PAYMENT_METHOD_CHEQUE_CASH);
        },

        /**
         * Determines whether the customer pays using direct debit
         * @param paymentMethod Customers payment method
         * @returns {boolean} Returns true when customer using direct debit
         */
        isDirectDebit: function(paymentMethod){

            return (paymentMethod !== undefined && paymentMethod.paymentMethod === constants.PAYMENT_METHOD_DIRECT_DEBIT);
        },

        /**
         * Determines whether the customer pays using credit card
         * @param paymentMethod Customers payment method
         * @returns {boolean} Returns true when customer using credit card
         */
        isCcra: function(paymentMethod){

            return (paymentMethod !== undefined && paymentMethod.paymentMethod === constants.PAYMENT_METHOD_CCRA);
        },

        isEligiblePaymentMethods: function(paymentMethods){

            if (paymentMethods != undefined) {
                return (!jQuery.isEmptyObject(paymentMethods.eligiblePaymentMethods));
            }

            return false;
        },
        isEligibleChangePaymentMethodLink:function(paymentMethods){
            var paymentMethod = paymentMethods.paymentMethod;
            var eligibleToShow = 0;
            angular.forEach(paymentMethods.eligiblePaymentMethods, function(value) {
                     if(!(value.paymentMethod===paymentMethod)){
                         eligibleToShow=eligibleToShow+1;
                     }
                 });
                 return eligibleToShow>=1;
        },
         isFrequencyChangeEligible:function(paymentMethods){
             var  paymentMethod =paymentMethods.paymentMethod,billFrequency=paymentMethods.billFrequency,eligibleFrequency=0;
             if(paymentMethods!==null){
                 angular.forEach(paymentMethods.eligiblePaymentMethods, function(value) {
                     if(value.paymentMethod===paymentMethod){
                        if(!(value.frequency===billFrequency)){
                            eligibleFrequency=eligibleFrequency+1;
                          }   
                     }
                 });
             }
             return eligibleFrequency>=1;
         },
        isWholeBillDDEligiblePaymentMethodPresent: function(paymentMethods){


            return this.isEligiblePaymentMethodPresent(paymentMethods, constants.PAYMENT_METHOD_DIRECT_DEBIT);
        },

        isCustomerEligibleForCashAndCheque: function(paymentMethods){

            return this.isEligiblePaymentMethodPresent(paymentMethods, constants.PAYMENT_METHOD_CHEQUE_CASH);
        },

        isCustomerEligibleForCcra: function(paymentMethods){

            return this.isEligiblePaymentMethodPresent(paymentMethods, constants.PAYMENT_METHOD_CCRA);
        },

        isEligiblePaymentMethodPresent: function(paymentMethods, requiredPaymentMethod){

            var foundWholeBilldd = false;

            /*
             TODO: To improve efficiency it may be possible to add the result to the cache
             i.e. state service. So subsequent calls will not need to loop. Possibly consider
             adding all the looping and storing to state service at the start of the junction
             */
            if (paymentMethods != undefined && paymentMethods.eligiblePaymentMethods != undefined) {

                angular.forEach(paymentMethods.eligiblePaymentMethods, function(value) {

                    if (value.paymentMethod != undefined && value.paymentMethod == requiredPaymentMethod) {

                        foundWholeBilldd = true;
                    }
                });
            }

            return foundWholeBilldd;
        },

        isEligiblePaymentMethodWithFrequency: function(paymentMethods) {

            var frequencyFound = false;

            if (paymentMethods != undefined && paymentMethods.eligiblePaymentMethods != undefined) {

                angular.forEach(paymentMethods.eligiblePaymentMethods, function(value) {

                    if (value.paymentMethod != undefined && value.paymentMethod == paymentMethods.paymentMethod) {

                        if (value.frequency == constants.BILL_QUARTERY || value.frequency == constants.BILL_MONTHLY) {

                            frequencyFound = true;
                        }
                    }
                });
            }

            return frequencyFound;
        },

        calculateOutstandingChargesPerMonths: function(paymentMethods) {

            var numberOfMonths = 6;

            if (paymentMethods !== undefined && paymentMethods.outstanding !== undefined) {

                return paymentMethods.outstanding.amount / numberOfMonths;
            }

            return 0;
        },

        /**
         * Return an object that has non-duplicate payment method ineligibilities. Additionally those payment method ineligibilities
         * are not present within the list of payment method eligibilities
         * @param paymentMethods object that contains payment method eligibilities and payment method ineligibilities
         * @returns {Array} Returns an array of non-duplicate payment method ineligibilities
         */
        getIneligiblePaymentMethodReasons: function(paymentMethods) {

            var eligibleMethods= paymentMethods.eligiblePaymentMethods;
            var ineligibleMethods = paymentMethods.ineligiblePaymentMethods;

            //Will hold ineligible payment methods after removing payment methods that are in eligibleMethods
            var uniqueIneligibleMethods = [];

            //For each payment method in ineligibleMethods, check if the payment method is also in eligible methods, if the
            //payment method is not in eligible methods then we can add it to uniqueIneligibleMethods
            angular.forEach(ineligibleMethods, function(ineligible){

                var found = eligibleMethods.some(function (method) {
                    return method.paymentMethod === ineligible.paymentMethod;
                });

                if (!found) {
                    uniqueIneligibleMethods[uniqueIneligibleMethods.length] = (ineligible);
                }

            });

            //  If there are no ineligible entries then return an empty array
            if (uniqueIneligibleMethods === undefined || uniqueIneligibleMethods === null || uniqueIneligibleMethods.length === 0) {

                return uniqueIneligibleMethods;
            }

            //Will hold ineligible payment methods after removing methods that are in the eligible methods and unioning reasons
            var uniqueIneligibleMethodsWithReasons = [];

            //Add first payment method to uniqueIneligibleMethodsWithReasons to allow looping through the array
            uniqueIneligibleMethodsWithReasons[0] = uniqueIneligibleMethods[0];

            angular.forEach(uniqueIneligibleMethods, function(uniqueIneligibleMethod){

                //if the uniqueIneligibleMethod.paymentMethod matches one of the payment methods in uniqueIneligibleMethodsWithReasons then found
                //will return as true and we know that the payment method already exists in uniqueIneligibleMethodsWithReasons
                var found = uniqueIneligibleMethodsWithReasons.some(function (method) {
                    return method.paymentMethod === uniqueIneligibleMethod.paymentMethod;
                });

                if (!found) {
                    uniqueIneligibleMethodsWithReasons[uniqueIneligibleMethodsWithReasons.length] = uniqueIneligibleMethod;
                }
                //If the payment method is found in uniqueIneligibleMethodsWithReasons then we need to get the ineligible reasons from the
                //payment method in uniqueIneligibleMethodsWithReasons and the uniqueIneligibleMethod paymentMethod and return the union of
                //both sets of reasons. We then assign the union of the reasons to the uniqueIneligibleMethodsWithReason.reason for displaying on screen
                else{
                    angular.forEach(uniqueIneligibleMethodsWithReasons, function(uniqueIneligibleMethodsWithReason){

                        if(uniqueIneligibleMethodsWithReason.paymentMethod === uniqueIneligibleMethod.paymentMethod){

                            var reasons1 = uniqueIneligibleMethodsWithReason.reason;
                            var reasons2 = uniqueIneligibleMethod.reason;

                            var reasons = reasons1.concat(reasons2);

                            //Array to hold the union of reasons1 and reasons2
                            var uniqueReasons = [];

                            //This function will remove any duplicate reasons in the reasons array resulting in uniqueReasons array

                            //For each reason in reasons
                            angular.forEach(reasons, function(reason){

                                //if reason is in uniqueReasons then it will return the index of reason, if reason is not in uniqueReasons
                                // then it will return the index as -1 and it will be pushed to uniqueReasons.

                                if (uniqueReasons.indexOf(reason) === -1) {
                                    uniqueReasons.push(reason);
                                }
                            });

                            //Set the reason of the object to be the union of the two reason arrays
                            uniqueIneligibleMethodsWithReason.reason = uniqueReasons;
                        }

                    });
                }
            });

            return uniqueIneligibleMethodsWithReasons;

        },

        getIneligiblePaymentMethodFrequencyReasons: function(paymentMethods) {

            var currentPaymentMethod = paymentMethods.paymentMethod;
            var currentBillFrequency = paymentMethods.billFrequency;

            var paymentMethodFrequencyReasons = [];

            angular.forEach(paymentMethods.ineligiblePaymentMethods, function(ineligiblePayment){

                if (currentPaymentMethod === ineligiblePayment.paymentMethod &&
                    currentBillFrequency !== ineligiblePayment.frequency) {

                    paymentMethodFrequencyReasons[paymentMethodFrequencyReasons.length] = ineligiblePayment;
                }
            });

            return paymentMethodFrequencyReasons;
        },
        getMppRessessmentOptions:function(paymentMethods,vm){
            var outStandingAmount = angular.isObject(paymentMethods.outstanding)?paymentMethods.outstanding.amount:null,
                monthlyRecommendedAmount = angular.isObject(paymentMethods.monthlyRecommendedAmount)?paymentMethods.monthlyRecommendedAmount.amount:null,
                oldReassessedAmount = angular.isObject(paymentMethods.oldReassessedAmount)?paymentMethods.oldReassessedAmount.amount:null,
                newReassessedAmount= angular.isObject(paymentMethods.newReassessedAmount)?paymentMethods.newReassessedAmount.amount:null,
                refundAndPaymentHoliday=angular.isObject(paymentMethods.refundAndPaymentHoliday)?paymentMethods.refundAndPaymentHoliday.paymentHolidays:null;
                var scenario={
                          "REASSESS_HIGHER":constants.REASSESS_HIGHER,
                          "REASSESS_LOWER_WITH_PAYHOLIDAY":constants.REASSESS_LOWER_WITH_PAYHOLIDAY,
                          "REASSESS_LOWER_WITHOUT_PAYHOLIDAY":constants.REASSESS_LOWER_WITHOUT_PAYHOLIDAY,
                          "REASSESS_NO_CHANGE_WITH_DEBIT":constants.REASSESS_NO_CHANGE_WITH_DEBIT
                       };
            angular.extend(vm,{
                                        outstandingAmount:outStandingAmount,
                                        mppScenario:scenario[paymentMethods.mppScenario],
                                        monthlyRecommendedAmount:monthlyRecommendedAmount,
                                        oldReassessedAmount:oldReassessedAmount,
                                        newReassessedAmount:newReassessedAmount,
                                        mppReassesdate:moment(paymentMethods.mppReassesdate).format('D MMM YYYY'),
                                        reassesedBy:paymentMethods.reassesedBy,
                                        refundAndPaymentHoliday:refundAndPaymentHoliday
                       });
            
                       
                      
        }
    };
}]);

