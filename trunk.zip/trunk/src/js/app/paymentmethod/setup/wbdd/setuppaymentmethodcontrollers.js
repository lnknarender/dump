/**
 * Created by Andrew on 30/11/2015.
 */

var setupPaymentMethodController = angular.module('setupPaymentMethodController', []);


/**
 * Controller that handles the setup payment method for whole bill direct debit
 */
setupPaymentMethodController.controller('setupPaymentMethodWbddCtrl', ['$scope', '$location', '$routeParams','urlService', 'errorLoggingService', 'utilityService', 'setupPaymentMethodWbddService', 'setupPaymentMethodAccordionService', 'commonPaymentMethodServices','setupPaymentMethodUrlService','primaryContactService','makePaymentThistleService','stateService','$timeout', 'changePaymentMethodServices',
    function ($scope, $location,$routeParams, urlService, errorLoggingService, utilityService, setupPaymentMethodWbddService, setupPaymentMethodAccordionService, commonPaymentMethodServices,setupPaymentMethodUrlService,primaryContactService,makePaymentThistleService,stateService,$timeout, changePaymentMethodServices) {
        var vm = this;
        $scope.isSelected = false;

        $scope.selected = function(){
            $scope.isSelected = true
        };
        //  Retrieve the payment methods
        /**
         *  Determines whether  OPTIONAL_PAYMENT  or MANDATORY_PAYMENT or NO_PAYMENT
         *  for cash/cheque to WBDD call paymentmethods/changedetails service
         *  for MPP/CCRA to WBDD call balance service
         */
        $scope.loading = true;
        $scope.userType = connection.userType;
        setupPaymentMethodWbddService.setDefaultOption($scope);
        var existingPaymentMethod = setupPaymentMethodWbddService.existingPaymentMethod = $scope.existingPaymentMethod = commonPaymentMethodServices.paymentMethods;
        var newSetupPaymentMethod = setupPaymentMethodWbddService.newSetupPaymentMethod = $scope.newSetupPaymentMethod = commonPaymentMethodServices.newSetupPaymentMethod;


        var changeDetailsResponse = setupPaymentMethodWbddService.getPaymentMethodChangeDetails();
        changeDetailsResponse.then(function (changeSettingResult) {
            $scope.loading = false;

            setupPaymentMethodWbddService.paymentMethodChangeDetails = changeSettingResult;
            var validateSetting = setupPaymentMethodWbddService.validateChangePayment(changeSettingResult, existingPaymentMethod, newSetupPaymentMethod, existingPaymentMethod.paymentMethod);
            setupPaymentMethodWbddService.setupAccordinShow($scope, validateSetting);
            setupPaymentMethodWbddService.accordinWorkFlow = $scope.accordinWorkflow;

            $scope.paymentDay = setupPaymentMethodWbddService.paymentDay = setupPaymentMethodWbddService.calculatePaymentDay(setupPaymentMethodWbddService.existingPaymentMethod.billMedia);
            $scope.billCycle = setupPaymentMethodWbddService.billCycle = setupPaymentMethodWbddService.getBillCycle(setupPaymentMethodWbddService.paymentMethodChangeDetails.nextBillDate);
            $scope.paymentDayDisplay = utilityService.getOrdinalNumber(setupPaymentMethodWbddService.paymentDay);
            //  /  Define the status of each accordion header (i.e. "not started", "current" or "complete") and
            //  expand/collapse the whole bill direct debit accordion based on the status of the headers
            $scope.accordionStatus = setupPaymentMethodAccordionService.initialiseAccordionStatus();
            if (existingPaymentMethod.paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN) {
                $scope.existingBankDetails = $scope.termAndCondtionChecked = true;
                $scope.existingBank = setupPaymentMethodWbddService.getExistingBankDetails(existingPaymentMethod.bankDetails);

            } else {
                $scope.addBankDetails = true;
            }
        }, function (errorResult) {
            console.log(errorLoggingService.errorToString(errorResult));
            $location.path(urlService.getErrorUrl());
        });

        angular.extend($scope, {
            accountHolderName: function () {
                var element = angular.element('#inputAccountName'), regex = /^[a-zA-Z]*$/;
                $scope.validBankAccountHolderName = !regex.test(element.val());
            },
            bankAccountNumber: function () {
                var element = angular.element('#inputAccountNumber'), regex = /^\d{8}$/;
                if (element.val().length >= 8) {
                    $scope.validBankAccount = !regex.test(element.val());
                }

            },
            bankAccountSortCode: function (code) {
                var element = angular.element('#inputSort' + code);
                if (element.val().length === 2) {
                    if (code === "Code1" || code === "Code2") {
                        angular.element('#inputSort' + code).next().next().focus();
                    }

                }
            }
        });

        $scope.onAddBankDetails = function () {
            $scope.addBankDetails = $scope.showBankDetails = true;
            $scope.existingBankDetails = $scope.termAndCondtionChecked = false;

        };
        $scope.onShowBankDetails = function () {
            $scope.existingBankDetails = $scope.termAndCondtionChecked = true;
            $scope.addBankDetails = $scope.showBankDetails = false;
        };
        /**
         *  Determines whether to display the yellow outstanding balance alert
         */
        //$scope.isDisplayOutstandingChargeAlert = function () {
        //
        //    return constants.OPTIONAL_PAYMENT === $scope.accordinWorkflow || constants.MANDATORY_PAYMENT === $scope.accordinWorkflow;
        //};
        /**
         *  to show Make Payment THISTLE page
         */
        $scope.paymentMethodMakePayment = function () {
            var thistlePaymentRequest = makePaymentThistleService.getPaymentRequest($scope.upfrontAmount, "GBP", stateService.get("contactEmail"), null,
                constants.PAYMENT_METHOD_THISTLE_SUCCESS_URL,
                constants.PAYMENT_METHOD_THISTLE_FAILED_URL,
                constants.PAYMENT_METHOD_THISTLE_CANCELLED_URL, $scope.primaryContactBillingAccount);

            thistlePaymentRequest.then(function (result) {

                    //  Define the size of the Thistle iFrame
                    utilityService.defineThistleIframeHeight($scope);
                    setupPaymentMethodAccordionService.makePayment = true;
                    $scope.thistleUrl = result.thistleUrl;
                    $scope.encodedXml = result.encodedXml;
                    $scope.loading = false;
                    postEncodedXml();
                },
                function (errorResult) {
                    console.log(errorLoggingService.errorToString(errorResult));
                    $location.path('/error');
                });
            function postEncodedXml() {
                $timeout(function () {
                    document.payform.submit();
                }, 500);
            }
        };
        $scope.frequencySelected = function (frequency) {
            $scope.frequencyName = constants[frequency];
            $scope.selectedFrequency = setupPaymentMethodWbddService.frequencyOption = frequency;
            setupPaymentMethodWbddService.setFrequencyOption(frequency);
        };
        $scope.cardOrBankSelected = function (cardOrBankName, cardOrBankSelectedValue) {
            $scope.amountYouOweCardOrBankSelected = setupPaymentMethodWbddService.cardOrBankSelectedValue = cardOrBankSelectedValue;
            setupPaymentMethodWbddService.setCardOrBankSelectedOption(cardOrBankName);
        };
        $scope.onClickSoleSignatory = function (soleSignatory) {
            setupPaymentMethodWbddService.soleSignatory = soleSignatory;
            soleSignatory === 'yes' ? ($scope.signatoryYes = false, $scope.signatoryNo = true, $scope.termAndCondtionChecked = false) : ($scope.signatoryNo = false, $scope.signatoryYes = true, $scope.termAndCondtionChecked = true);

            setupPaymentMethodWbddService.setSoleSignatorySelectedOption(soleSignatory);
        };


        /**
         * Applies CSS style to colour the accordion tab
         *   ACCORDION_NOT_STARTED => gray
         *   ACCORDION_CURRENT     => blue
         *   ACCORDION_COMPLETE    => green
         *   ACCORDION_ERROR       => red
         */
        $scope.applyCSSClass = function (status) {

            return utilityService.getAccordionCSSClass(status);
        };
        $scope.noPayment = function () {
            //summary page call update account
            //setup update account Object
            if (setupPaymentMethodWbddService.soleSignatory === constants.SOLE_SIGNATORY_NOCHANGE || setupPaymentMethodWbddService.soleSignatory === constants.SOLE_SIGNATORY_NO) {
                $location.path('/paymentMethodWbddSuccess');
            } else if (setupPaymentMethodWbddService.soleSignatory === constants.SOLE_SIGNATORY_YES) {
                $scope.validateBankDetailsForNoPayment();

            }
        };

        $scope.validateBankDetailsForNoPayment = function () {
            var sortCode = $scope.bankDetails.sortCode,
                bankDetails = {
                    "bankAccountNumber": $scope.bankDetails.bankAccountNumber,
                    "sortCode": [sortCode.code1, sortCode.code2, sortCode.code3].join("")
                };
            commonPaymentMethodServices.validateBankDetails(bankDetails).then(displaySuccess, displayError);

            function displaySuccess(response) {

                var validBankDetails = response.validBankDetails;
                if (validBankDetails) {
                    setupPaymentMethodWbddService.bankDetails = $scope.bankDetails;
                    $location.path('/paymentMethodWbddSuccess');
                } else {
                    $scope.validBankAccount = true;
                }
            }

            function displayError(response) {
                $scope.validBankAccount = true;
                return false;
            }

        };
        $scope.optionalpayment = function () {
            $scope.bankDetailsInfo = [{
                "name": "creditcard.name",
                "description": "creditcard.desc",
                "value": "creditOrDebitCardDetails"
            }, {
                "name": "bankDetails.name",
                "description": "bankDetails.desc",
                "value": "bankDetails"
            }];
            //  Update the accordion status, direct debit is now complete and
            //  expand/collapse the whole bill direct debit accordion based on the status of the headers
            $scope.accordionStatus = setupPaymentMethodAccordionService.directDebitComplete($scope.accordinWorkflow);

        };
        $scope.validateBankDetails = function () {
            var sortCode = $scope.bankDetails.sortCode,
                bankDetails = {
                    "bankAccountNumber": $scope.bankDetails.bankAccountNumber,
                    "sortCode": [sortCode.code1, sortCode.code2, sortCode.code3].join("")
                };
            var validateBankDetialsResponse = commonPaymentMethodServices.validateBankDetails(bankDetails);
            validateBankDetialsResponse.then(function (response) {
                var validBankDetails = response.validBankDetails;
                if (validBankDetails) {
                    //  Update the accordion status, direct debit is now complete and
                    //  expand/collapse the whole bill direct debit accordion based on the status of the headers
                    if (setupPaymentMethodWbddService.soleSignatory === 'yes') {
                        var bankAccountNumber = $scope.bankDetails.bankAccountNumber;

                        setupPaymentMethodWbddService.bankDetails = $scope.bankDetails;
                        $scope.directDebitDisplayWbdd = [constants[setupPaymentMethodWbddService.frequencyOption], utilityService.getBankAccountNumber(bankAccountNumber)].join(",");
                    }
                    $scope.paymentMethodMakePayment();
                    $scope.accordionStatus = setupPaymentMethodAccordionService.directDebitComplete($scope.accordinWorkflow);

                } else {
                    $scope.validBankAccount = true;
                }
            }, function (errorResult) {
                $scope.validBankAccount = true;
            });
        };
        $scope.directDebitComplete = function () {

            $scope.isSelected = false;
            $scope.directDebitDisplayWbdd = "";

            if ($scope.userAgent === constants.CUSTOMER) {
                $scope.primaryContactBillingAccount = primaryContactService.primaryContactBillingAccount;
            }


            if ($scope.accordinWorkflow === constants.NO_PAYMENT) {
                $scope.noPayment();

            } else if ($scope.accordinWorkflow === constants.MANDATORY_PAYMENT) {
                //go to makepayement with calling update and account
                if (setupPaymentMethodWbddService.soleSignatory === 'yes') {
                    $scope.validateBankDetails();
                } else {
                    //  Update the accordion status, direct debit is now complete and
                    //  expand/collapse the whole bill direct debit accordion based on the status of the headers
                    $scope.paymentMethodMakePayment();
                    $scope.accordionStatus = setupPaymentMethodAccordionService.directDebitComplete($scope.accordinWorkflow);
                }

            } else if ($scope.accordinWorkflow === constants.OPTIONAL_PAYMENT) {
                //go to amount you owe

                if (setupPaymentMethodWbddService.soleSignatory === 'yes') {
                    var sortCode = $scope.bankDetails.sortCode,
                        bankDetails = {
                            "bankAccountNumber": $scope.bankDetails.bankAccountNumber,
                            "sortCode": [sortCode.code1, sortCode.code2, sortCode.code3].join("")
                        };
                    var validateBankDetialsResponse = commonPaymentMethodServices.validateBankDetails(bankDetails);
                    validateBankDetialsResponse.then(function (response) {
                        if (response.validBankDetails) {
                            setupPaymentMethodWbddService.bankDetails = $scope.bankDetails;
                            $scope.optionalpayment();
                        }
                    }, function (errorResult) {
                        $scope.validBankAccount = true;
                    });
                } else {
                    $scope.optionalpayment();
                }
            }


        };
            $scope.onEditDirectDebitClick = function () {
                //  Update the accordion status,  direct debit is now edit and
                //  expand/collapse the whole bill direct debit accordion based on the status of the headers
                $scope.accordinShow = setupPaymentMethodWbddService.accordinShow($scope.accordinWorkflow);
                $scope.accordionStatus = setupPaymentMethodAccordionService.directDebitEdit();
                setupPaymentMethodWbddService.defaultFrequencyOption(setupPaymentMethodWbddService.existingPaymentMethod.billFrequency);
                setupPaymentMethodWbddService.defaultSoleSignatorySelectedOption();
                setupPaymentMethodWbddService.defaultCardOrBankSelectedOption();
                setupPaymentMethodWbddService.setDefaultOption($scope);


            };
            $scope.amountYouOweComplete = function () {
                if ($scope.amountYouOweCardOrBankSelected === "creditOrDebitCardDetails") {
                    $scope.accordinShow.makePaymentWbdd = true;
                    $scope.paymentMethodMakePayment();
                    //  Update the accordion status, amount you owe is now complete and
                    //  expand/collapse the whole bill direct debit accordion based on the status of the headers
                    $scope.accordionStatus = setupPaymentMethodAccordionService.amountYouOweComplete($scope.accordinWorkflow);
                } else {
                    $scope.noPayment();
                }


            };
            $scope.onEditAmountYouOweClick = function () {
                $scope.isSelected = false;
                $scope.accordinShow.makePaymentWbdd = false;
                //  Update the accordion status, amount you owe is now edit and
                //  expand/collapse the whole bill direct debit accordion based on the status of the headers
                setupPaymentMethodWbddService.defaultCardOrBankSelectedOption();
                $scope.accordionStatus = setupPaymentMethodAccordionService.amountYouOweEdit();
            }
    }]);
setupPaymentMethodController.controller('setupPaymentMethodWbddSuccessCtrl', ['$scope', 'stateService', '$location', '$routeParams', 'urlService', 'errorLoggingService', 'utilityService', 'setupPaymentMethodWbddService', 'setupPaymentMethodAccordionService', 'commonPaymentMethodServices',
    function ($scope, stateService, $location, $routeParams, urlService, errorLoggingService, utilityService, setupPaymentMethodWbddService, setupPaymentMethodAccordionService, commonPaymentMethodServices) {
        $scope.accordinShow = setupPaymentMethodWbddService.accordinShow(setupPaymentMethodWbddService.accordinWorkFlow);
        angular.extend($scope, {
            applyCSSClass: function (status) {
                return utilityService.getAccordionCSSClass(status);
            },
            applyIconCSSClass: function (status) {
                return utilityService.getCssIconTick(status);
            },
            tryAnotherCard: function () {
                $location.path('/setupWbddPaymentMethod');
            }
        });
        $scope.email = stateService.get("contactEmail");
        if ($location.path().indexOf(constants.PAYMENT_METHOD_WBDD_SUCCESS) !== -1) {
            utilityService.expandOrCollapseAccordionBasedOnStatus(constants.ACCORDION_CURRENT, "summarySuccessWbddAccordionBodyId");

            var madepayment = (setupPaymentMethodWbddService.cardOrBankSelectedValue === 'creditOrDebitCardDetails'),
                withBankDetails = setupPaymentMethodWbddService.soleSignatory,
                accordinWorkFlow = setupPaymentMethodWbddService.accordinWorkFlow;
            if (accordinWorkFlow === constants.MANDATORY_PAYMENT) {
                madepayment = true;
            }
            if (accordinWorkFlow === constants.NO_PAYMENT) {
                madepayment = false;
            }
            var _scope = $scope;
            var updateAccountObject = setupPaymentMethodWbddService.createUpdateAccountObject($routeParams, withBankDetails, stateService.get("contactEmail")),
                updateAccountResponse = commonPaymentMethodServices.updateAccount(updateAccountObject);
            updateAccountResponse.then(function (result) {
                angular.extend(_scope.accordinShow,
                    setupPaymentMethodAccordionService.initialiseSummaryAccordinStatus(true)
                );
                setupPaymentMethodWbddService.showWbddSuccessPanel(withBankDetails, madepayment, $scope, $routeParams);

            }, function (errorResult) {
                setupPaymentMethodWbddService.showWbddFailurePanel(withBankDetails, madepayment, $scope, $routeParams);

            });


        } else if ($location.path().indexOf("paymentMethodWbddFailure") !== -1) {
            angular.extend($scope.accordinShow,
                setupPaymentMethodAccordionService.initialiseSummaryAccordinStatus(false)
            );

            utilityService.expandOrCollapseAccordionBasedOnStatus(constants.ACCORDION_WARNING, "makePaymentSuccessWbddAccordionBodyId");
        }
    }]);