/**
 * Created by Andrew on 23/11/2015.
 */

var setupPaymentMethodServices = angular.module('setupPaymentMethodServices', []);

setupPaymentMethodServices.factory('setupPaymentMethodUrlService', ['$routeParams', 'urlService', function ($routeParams, urlService) {

    return {

        /**
         * Get the ReST URL for payment methods/changedetails
         * @returns {string} Returns customer or agent ReST URL for payment methods/changedetails
         */
        getPaymentMethodChangeDetailsUrl: function () {
            
             if (angular.isDefined(connection.useMockData) && connection.useMockData == 'true' && connection.userType == 'agent') {

             return "http://consumer.bt.com/static/bpta/test/mockFiles/paymentMethod/paymentMethod_changeSetting_" + $routeParams.bac + ".json";
             } 
            if (connection.userType == 'agent') {
                return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/paymentmethods/changedetails';
            }

            return urlService.getSecurePath() + '/acckey/' + $routeParams.accKey + '/paymentmethods/changedetails';
        },
        getSetupMppUrl: function () {
            if (connection.userType == 'agent') {
                return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/mppsetup';
            }

            return urlService.getSecurePath() + '/acckey/' + $routeParams.accKey + '/mppsetup';
        }
    }
}]);

setupPaymentMethodServices.factory('setupPaymentMethodWbddService', ['$q', 'ajaxServiceWithToken', 'stateService', '$routeParams', 'utilityService', 'setupPaymentMethodUrlService', function ($q, ajaxServiceWithToken, stateService, $routeParams, utilityService, setupPaymentMethodUrlService) {

    return {

        /**
         * Expand/collapse the whole bill direct debit accordion based on the status of the headers (i.e. "not started", "current" or "complete")
         * @param $scope AngularJS scope
         */
        /*        expandOrCollapseAccordion: function(accordionStatus) {

         //  Update each accordion header using the header's status and HTML id
         utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.directDebitAccordionStatus, "directDebitAccordionBodyId");
         utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.summaryAccordionStatus, "summaryAccordionBodyId");
         }*/
        getPaymentMethodChangeDetails: function () {
            var deferred = $q.defer(), changeDetail = stateService.get(constants.STATE_SERVICE_PAYMENT_METHODS_CHANGE_DETAILS);

            if (changeDetail) {

                //  Already have a payment account so return it
                deferred.resolve(changeDetail);
            }
            else {
                var url = setupPaymentMethodUrlService.getPaymentMethodChangeDetailsUrl();

                var changeDetailsResponse = ajaxServiceWithToken.doGet(url, {});

                changeDetailsResponse.then(function (result) {
                        stateService.set(constants.STATE_SERVICE_PAYMENT_METHODS_CHANGE_DETAILS, result);
                        deferred.resolve(result);
                    },
                    function (errorResult) {
                        deferred.reject(errorResult);
                    });
            }

            return deferred.promise;
        },
        /**
         *
         * if payment method is cash or cheque , allowedToSetPaymentMethod is true and balance is >0 the OPTIONAL_PAYMENT
         *  else NO_PAYMENT Journey
         * if payment method is cash or cheque , allowedToSetPaymentMethod is true and balance  is <0 the   NO_PAYMENT Journey
         *if payment method is cash or cheque , allowedToSetPaymentMethod is false and balance is >0 the MANDATORY_PAYMENT Journey
         *if payment method is MMP or CCRA and balance>0 MANDATORY_PAYMENT else NO_PAYMENT Journey
         */
        getValidateSetting: function (allowedToSetPaymentMethod, balance, cashOrcheque) {

            if (cashOrcheque) {

                if (allowedToSetPaymentMethod) {
                    return +balance > 0 ? constants.OPTIONAL_PAYMENT : constants.NO_PAYMENT;
                }
                else if (+balance > 0) {
                    return  constants.MANDATORY_PAYMENT;
                }
                else {
                    return  constants.NO_PAYMENT;
                }
            }
            else {

                return +balance > 0 ? constants.MANDATORY_PAYMENT : constants.NO_PAYMENT;
            }

        },
        calculatePaymentDay: function (billMedia) {
            var date = new moment(this.paymentMethodChangeDetails.nextBillDate);
            if (billMedia === constants.PAPER) {
                return date.add(11, "days").get("date");
            } else {
                return date.add(8, "days").get("date");

            }
        },
        getBillCycle: function (date) {
            if (date !== null && date !== undefined) {
                return date.split("-")[2];
            }
        },
        setupAccordinShow: function (scope, validateSetting) {
            angular.extend(scope, validateSetting);
            scope.frequencyName = constants[validateSetting.defaultFrequency];
            scope.selectedFrequency = validateSetting.defaultFrequency;
            scope.accordinShow = this.accordinShow(scope.accordinWorkflow);
        },
        getDefaultSetting: function (allowedToSetPaymentMethod, balance, defaultFrequency, eligibleFrequency, fromCC) {
            var eligibleFrequencyList = [];
            this.frequencyOption = defaultFrequency;
            angular.forEach(eligibleFrequency.split(","), function (frequency) {
                eligibleFrequencyList.push({
                    "name": frequency,
                    "displayName": constants[frequency],
                    "selected": defaultFrequency === frequency ? "btn-main-selected" : "btn-main-unselected",
                    "iconTick": defaultFrequency === frequency ? "icon-tick" : ""
                });
            });
            //If customer is not eligible to change frequency, default it to first eligible option.
            if(eligibleFrequencyList.length === 1){
                this.frequencyOption = eligibleFrequencyList[0].name;
            }
            return  {
                "accordinWorkflow": this.getValidateSetting(allowedToSetPaymentMethod, balance, fromCC),
                "defaultFrequency": this.frequencyOption,
                "eligibleFrequency": eligibleFrequencyList,
                "upfrontAmount": balance
            };
        },
        /**
         * if payment method is cash or cheque and allowedTosetPaymentMethod is true
         * consider amount from balance other wise forma blocking Balance
         * if payment method is MPP or CCRA consider amount from balance
         * */
        validateChangePayment: function (changeSetting, oldPaymentMethod, newPaymentMethod, paymentMethod) {
            var bln = true;
            var amount = 0;
            var allowedToSetPaymentMethod;
            var balance;
            if (paymentMethod === constants.PAYMENT_METHOD_CHEQUE_CASH) {
                if (changeSetting !== null) {
                    allowedToSetPaymentMethod = changeSetting.allowedToSetPaymentMethod;
                    balance = changeSetting.balance;
                    var blockingBalance = changeSetting.blockingBalance;
                    if (allowedToSetPaymentMethod) {
                        amount = balance.amount;
                    } else {

                        if (blockingBalance != undefined &&
                            blockingBalance != null &&
                            blockingBalance.amount != undefined &&
                            blockingBalance.amount != null) {

                                amount = blockingBalance.amount;
                        }
                    }
                }
            } else if (paymentMethod === constants.PAYMENT_METHOD_CCRA || paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN) {
                if (changeSetting !== null) {
                    allowedToSetPaymentMethod = false;
                    balance = changeSetting.balance;
                    if (balance !== null) {
                        amount = balance.amount;
                    }
                    bln = false;
                }
            }
            return this.getDefaultSetting(allowedToSetPaymentMethod, amount, oldPaymentMethod.billFrequency, newPaymentMethod.frequency, bln);
        },
        getAccordinShow: function (directDebitWbdd, amountYouOweWbdd, makePaymentWbdd, summaryWbdd) {
            return{
                "directDebitWbdd": directDebitWbdd,
                "amountYouOweWbdd": amountYouOweWbdd,
                "makePaymentWbdd": makePaymentWbdd,
                "summaryWbdd": summaryWbdd
            }
        },
        accordinShow: function (workflow) {
            //Direct debit, amout You Owe, Make payment and summary
            //TODO change to names
            var DIRECT_DEBIT = true, AMOUNT_YOU_OWE = true, MAKEPAYMENT = true, SUMMARY = true;
            if (workflow === constants.OPTIONAL_PAYMENT) {
                return this.getAccordinShow(DIRECT_DEBIT, AMOUNT_YOU_OWE, !MAKEPAYMENT, SUMMARY);
            } else if (workflow === constants.NO_PAYMENT) {
                return this.getAccordinShow(DIRECT_DEBIT, !AMOUNT_YOU_OWE, !MAKEPAYMENT, SUMMARY);
            } else if (workflow === constants.MANDATORY_PAYMENT) {
                return this.getAccordinShow(DIRECT_DEBIT, !AMOUNT_YOU_OWE, MAKEPAYMENT, SUMMARY);
            }
        },
        defaultFrequencyOption: function (frequency) {
            this.setFrequencyOption(frequency);
        },
        setFrequencyOption: function (frequency) {
            var frequencyBtns = $("[id*='frequency_']");
            angular.forEach(frequencyBtns, function (_frequency) {
                var _this = $(_frequency), id = _this.attr('id');
                utilityService.onSelectionButton(_this, _this.children(), id, "frequency_" + frequency);

            })
        },
        defaultSoleSignatorySelectedOption: function () {
            var soleSignatoryBtns = $("[id*='sole_signatory_']");
            angular.forEach(soleSignatoryBtns, function (_soleSignatory) {
                var _this = $(_soleSignatory);
                utilityService.defaultSelectionButton(_this, _this.children());

            })
        },
        setSoleSignatorySelectedOption: function (soleSignatory) {
            var soleSignatoryBtns = $("[id*='sole_signatory_']");
            angular.forEach(soleSignatoryBtns, function (_soleSignatory) {
                var _this = $(_soleSignatory), id = _this.attr('id');
                utilityService.onSelectionButton(_this, _this.children(), id, "sole_signatory_" + soleSignatory);

            });
        },
        defaultCardOrBankSelectedOption: function () {
            var bankOrCardBtns = $("[id*='bankDetail_']");
            angular.forEach(bankOrCardBtns, function (_bankOrCard) {
                var _this = $(_bankOrCard), parent = _this.children('a');
                utilityService.defaultSelectionButton(parent, parent.children('span:first'));
            })
        },
        setCardOrBankSelectedOption: function (bankOrCard) {

            var bankOrCardBtns = $("[id*='bankDetail_']");
            angular.forEach(bankOrCardBtns, function (_bankOrCard) {
                var _this = $(_bankOrCard), id = _this.attr('id'), parent = _this.children('a');
                utilityService.onSelectionButton(parent, parent.children('span:first'), id, "bankDetail_" + bankOrCard);
            })
        },
        setDefaultOption: function (scope) {
            this.soleSignatory = constants.SOLE_SIGNATORY_NOCHANGE;
            angular.extend(scope, {
                termAndCondtionChecked: false,
                //bankDetails: {"sortCode": {}},
                signatoryYes: true,
                signatoryNo: true,
                validBankAccount: false

            });

        },
        createUpdateAccountObject: function (routeParams, soleSignatory, email) {
            //var paymentDay =this.calculatePaymentDay(this.existingPaymentMethod.billMedia);
            var updateAccount = {
                "billFrequency": this.frequencyOption,
                "paymentMethod": this.newSetupPaymentMethod.newPaymentMethodName,
                "paymentDay": this.paymentDay,
                "billCycle": this.billCycle,
                "email": email
            };
            if (soleSignatory === constants.SOLE_SIGNATORY_YES) {
                var sortCode = this.bankDetails.sortCode;
                updateAccount['bankDetails'] = {
                    "accountHolderName": this.bankDetails.accountHolderName,
                    "bankAccountNumber": this.bankDetails.bankAccountNumber,
                    "sortCode": [sortCode.code1, sortCode.code2, sortCode.code3].join("")
                };
            }
            else if (soleSignatory === constants.SOLE_SIGNATORY_NO) {
                updateAccount['paperMandate'] = true;
            }
            return updateAccount;

        },
        showWbddSuccessPanel: function (withBankDetails, madePayment, scope, routeParams) {

            scope.directDibetSetupFailed = false;

            scope.withBankDetails = (withBankDetails === constants.SOLE_SIGNATORY_YES);
            scope.withoutBankDetails = (withBankDetails === constants.SOLE_SIGNATORY_NO);
            scope.madePayment = madePayment;
            scope.bankDetailsNoChange = (withBankDetails === constants.SOLE_SIGNATORY_NOCHANGE);

            if (scope.withoutBankDetails) {
                utilityService.getAddressInformation(scope, this.existingPaymentMethod.address);
            }
            if (scope.madePayment) {
                utilityService.getCreditCardInformation(scope, routeParams);
            }
            if (scope.withBankDetails) {
                utilityService.getBankDetailsInformation(scope, this.calculatePaymentDay(this.existingPaymentMethod.billMedia), this.frequencyOption, this.bankDetails);
            } else if (scope.bankDetailsNoChange) {
                utilityService.getBankDetailsInformation(scope, this.calculatePaymentDay(this.existingPaymentMethod.billMedia), this.frequencyOption, this.existingPaymentMethod.bankDetails);
            }


        },
        showWbddFailurePanel: function (withBankDetails, madePayment, scope, routeParams) {
            scope.directDibetSetupFailed = true;
            scope.withBankDetails = (withBankDetails === constants.SOLE_SIGNATORY_YES);
            scope.withoutBankDetails = (withBankDetails === constants.SOLE_SIGNATORY_NO);
            scope.madePayment = madePayment;
            scope.bankDetailsNoChange = (withBankDetails === constants.SOLE_SIGNATORY_NOCHANGE);
            if (scope.madePayment) {
                utilityService.getCreditCardInformation(scope, routeParams);
            }
        },
        getExistingBankDetails: function (bankDetails) {
            return {
                holderName: bankDetails.accountHolderName,
                accountNumer: bankDetails.bankAccountNumber,
                sortCode: bankDetails.sortCode
            }
        }
    }
}]);

setupPaymentMethodServices.factory('setupPaymentMethodAccordionService', ['utilityService', function (utilityService) {

    var accordionStatus = {};

    return {

        getAccordionStatus: function () {

            return accordionStatus;

        },

        /**
         * Expand/collapse the whole bill direct debit accordion based on the status of the headers (i.e. "not started", "current" or "complete")
         * @param $scope AngularJS scope
         */
        expandOrCollapseAccordion: function (accordionStatus) {

            //  Update each accordion header using the header's status and HTML id
            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.directDebitAccordionStatus, "directDebitWbddAccordionBodyId");
            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.amountYouOweAccordionStatus, "amountYouOweWbddAccordionBodyId");
            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.makePaymentAccordionStatus, "makePaymentWbddAccordionBodyId");
            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.summaryAccordionStatus, "summaryWbddAccordionBodyId");
        },
        setAccordionStatus: function (directDebitAccordionStatus, directDebitAccordionWhiteTick, directDebitAccordionEditButton, amountYouOweAccordionStatus, amountYouOweAccordionWhiteTick, amountYouOweAccordionEditButton, makePaymentAccordionStatus, makePaymentAccordionWhiteTick, summaryAccordionStatus, summaryAccordionWhiteTick, directDebitDisplayWbdd, amountYouOweDisplayWbdd) {
            angular.extend(accordionStatus, {
                "directDebitAccordionStatus": directDebitAccordionStatus,
                "directDebitAccordionWhiteTick": directDebitAccordionWhiteTick,
                "directDebitAccordionEditButton": directDebitAccordionEditButton,
                "amountYouOweAccordionStatus": amountYouOweAccordionStatus,
                "amountYouOweAccordionWhiteTick": amountYouOweAccordionWhiteTick,
                "amountYouOweAccordionEditButton": amountYouOweAccordionEditButton,
                "makePaymentAccordionStatus": makePaymentAccordionStatus,
                "makePaymentAccordionWhiteTick": makePaymentAccordionWhiteTick,
                "summaryAccordionStatus": summaryAccordionStatus,
                "summaryAccordionWhiteTick": summaryAccordionWhiteTick,
                "directDebitDisplayWbdd": directDebitDisplayWbdd,
                "amountYouOweDisplayWbdd": amountYouOweDisplayWbdd
            });
        },
        initialiseSummaryAccordinStatus: function (success) {
            if (success) {
                this.setSummaryAccordinStatus(constants.ACCORDION_COMPLETE_ICON_TICK, constants.ACCORDION_COMPLETE_ICON_TICK,
                    constants.ACCORDION_COMPLETE, constants.ACCORDION_COMPLETE_ICON_TICK,
                    constants.ACCORDION_COMPLETE, constants.ACCORDION_COMPLETE_ICON_TICK);
            } else {
                this.setSummaryAccordinStatus(constants.ACCORDION_COMPLETE_ICON_TICK, constants.ACCORDION_COMPLETE_ICON_TICK,
                    constants.ACCORDION_WARNING, constants.ACCORDION_WARNING_ICON_TICK,
                    constants.ACCORDION_NOT_STARTED, "");
            }
            return accordionStatus;
        },
        setSummaryAccordinStatus: function (summaryDirectDebitIconTick, summaryAmountYouOweIconTick, summaryMakePaymentAccordionStatus, summaryMakePaymentIconTick, summaryAccordionStatus, summaryIconTick, amountYouOweDisplayWbdd, directDebitDisplayWbdd) {
            angular.extend(accordionStatus, {
                "summaryDirectDebitIconTick": summaryDirectDebitIconTick,
                "summaryAmountYouOweIconTick": summaryAmountYouOweIconTick,
                "summaryMakePaymentAccordionStatus": summaryMakePaymentAccordionStatus,
                "summaryMakePaymentIconTick": summaryMakePaymentIconTick,
                "summaryAccordionStatus": summaryAccordionStatus,
                "summaryIconTick": summaryIconTick,
                "amountYouOweDisplayWbdd": amountYouOweDisplayWbdd,
                "directDebitDisplayWbdd": directDebitDisplayWbdd
            });
        },
        initialiseAccordionStatus: function () {

            //  Define the status of each accordion header (i.e. "not started", "current" or "complete")
            this.setAccordionStatus(constants.ACCORDION_CURRENT, false, false, constants.ACCORDION_NOT_STARTED,
                false, false, constants.ACCORDION_NOT_STARTED, false,
                constants.ACCORDION_NOT_STARTED, false, false, false);

            //  Update each accordion header using the header's status and HTML id
            this.expandOrCollapseAccordion(accordionStatus);

            return accordionStatus;
        },

        directDebitComplete: function (workflow) {
            if (workflow === constants.MANDATORY_PAYMENT) {
                this.setAccordionStatus(constants.ACCORDION_COMPLETE, true, true, constants.ACCORDION_NOT_STARTED,
                    false, false, constants.ACCORDION_CURRENT, false,
                    constants.ACCORDION_NOT_STARTED, false, true, false);
            } else if (workflow === constants.OPTIONAL_PAYMENT) {
                this.setAccordionStatus(constants.ACCORDION_COMPLETE, true, true, constants.ACCORDION_CURRENT,
                    false, false, constants.ACCORDION_NOT_STARTED, false,
                    constants.ACCORDION_NOT_STARTED, false, true, false);
            }


            //  Update each accordion header using the header's status and HTML id
            this.expandOrCollapseAccordion(accordionStatus);

            return accordionStatus;
        },
        directDebitEdit: function () {
            return this.initialiseAccordionStatus();
        },
        amountYouOweComplete: function () {
            this.setAccordionStatus(constants.ACCORDION_COMPLETE, true, true, constants.ACCORDION_COMPLETE,
                true, true, constants.ACCORDION_CURRENT, false,
                constants.ACCORDION_NOT_STARTED, false, true, true);

            //  Update each accordion header using the header's status and HTML id
            this.expandOrCollapseAccordion(accordionStatus);

            return accordionStatus;
        },
        amountYouOweEdit: function () {
            this.setAccordionStatus(constants.ACCORDION_COMPLETE, true, true, constants.ACCORDION_CURRENT,
                false, false, constants.ACCORDION_NOT_STARTED, false,
                constants.ACCORDION_NOT_STARTED, false, true, false);

            //  Update each accordion header using the header's status and HTML id
            this.expandOrCollapseAccordion(accordionStatus);

            return accordionStatus;
        },
        completeJourney: function (success, failure) {
            if (success) {
                this.setAccordionStatus(constants.ACCORDION_COMPLETE, true, false, constants.ACCORDION_COMPLETE,
                    true, false, constants.ACCORDION_COMPLETE, true,
                    constants.ACCORDION_COMPLETE, true);
            } else if (failure) {
                this.setAccordionStatus(constants.ACCORDION_COMPLETE, true, false, constants.ACCORDION_COMPLETE,
                    true, false, constants.ACCORDION_COMPLETE, true,
                    constants.ACCORDION_WARNING, true);
            }

            //  Update each accordion header using the header's status and HTML id
            this.expandOrCollapseAccordion(accordionStatus);

            return accordionStatus;
        }

    }
}]);
