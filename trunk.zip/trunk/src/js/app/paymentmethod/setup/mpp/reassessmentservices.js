var reAssessmentServices = angular.module('reAssessmentServices',[]);

reAssessmentServices.factory('reAssessmentServices', ['utilityService',
    function(utilityService) {
     
    function tabValues(vm,active,amountYouOweCompleted,ressessmentComplete,makePaymentCompleted,makePaymentFailed,makePaymentSuccess,editAmountYouOwe){
         angular.extend(vm.tabs,{
                            active:active,
                            amountYouOweCompleted:amountYouOweCompleted,
                            ressessmentComplete:ressessmentComplete,
                            makePaymentCompleted:makePaymentCompleted,
                            makePaymentFailed:makePaymentFailed,
                            makePaymentSuccess:makePaymentSuccess,
                            editAmountYouOwe:editAmountYouOwe
                       
               });
     }
    return {
           getDefaultReAssessmentOptions:function(vm){
                angular.extend(vm,{
                        accordionStatus:{
                           amountYouOweAccordionStatus:vm.mppScenario===constants.REASSESS_HIGHER?constants.ACCORDION_CURRENT:null,
                           makePaymentAccordionStatus:vm.mppScenario===constants.REASSESS_NO_CHANGE_WITH_DEBIT?constants.ACCORDION_CURRENT:null,
                           summaryAccordionStatus:null
                       },
                       tabs:{
                            amountYouAccordinShow:vm.mppScenario===constants.REASSESS_HIGHER
                       }
               });
               tabValues(vm,vm.mppScenario===constants.REASSESS_HIGHER?"amountToPay":"makePayment",false,false,false,false,false);
           },
           reAssessmentAmountToPayDone:function(vm){
             tabValues(vm,"makePayment",true,false,false,false,false,true);
           },
           getReAssessmentSummary:function(vm){
              tabValues(vm,"summary",true,true,true,false,true);
           },
           getReAssessmentMakePaymentFailure:function(vm){
               tabValues(vm,"makePayment",true,false,true,true,false);
           },
           getSummaryPaymentData:function(vm,routeParam){
               angular.extend(vm,{
                    paymentSummary:{
                       paymentRef: routeParam.paymentReferenceId,
                       timeAndDate: routeParam.paymentDateTime,
                       accountNumber: routeParam.bac,
                       cardType: routeParam.cardType,
                       cardNumber: routeParam.cardNumber,
                       amount: routeParam.amount  
                   }
                    
               });
               
           },
           reAssessmentAction:function(vm,action,paymentMethod){
               vm.ressesment={};
               vm.ressesment.action=action;
             if(action==="mppressessmentveiwdetails"){
                      vm.scheduledPayments = this.getMontlyPaymentOverview(paymentMethod.refundAndPaymentHoliday.paymentHolidays,paymentMethod.paymentDay,vm.newReassessedAmount);
              }
           },
           defaultValues:function(vm,commonPaymentMethodServices){
               angular.extend(vm,{
                                        outstandingAmount:commonPaymentMethodServices.outStandingAmount,
                                        mppScenario:commonPaymentMethodServices.mppScenario,
                                        monthlyRecommendedAmount:commonPaymentMethodServices.monthlyRecommendedAmount,
                                        oldReassessedAmount:commonPaymentMethodServices.oldReassessedAmount,
                                        newReassessedAmount:commonPaymentMethodServices.newReassessedAmount,
                                        mppReassesdate:commonPaymentMethodServices.mppReassesdate,
                                        reassesedBy:commonPaymentMethodServices.reassesedBy,
                                        refundAndPaymentHoliday:commonPaymentMethodServices.refundAndPaymentHoliday
                       });
           },
           expandOrCollapseAccordion: function (accordionStatus) {

            //  Update each accordion header using the header's status and HTML id
            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.amountYouOweAccordionStatus, "amountYouOweMppRessessmentAccordionBodyId");
            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.makePaymentAccordionStatus, "makePaymentMppRessessmentAccordionBodyId");
            utilityService.expandOrCollapseAccordionBasedOnStatus(accordionStatus.summaryAccordionStatus, "mppRessessmentSummaryAccordionBodyId");
        },
        getMontlyPaymentOverview:function(paymentHolidays,paymentDay,amount){
            var montlyPaymentOverview=[],month=moment().month(),date =moment();
            for(var start=month;start<=month+paymentHolidays;start++){
               montlyPaymentOverview.push({
                    "date":date.set('date', paymentDay).add(1, 'months').format('D MMM YYYY'),
                    "amount":start===(month+paymentHolidays)?amount:0
                });
            }
            
            return montlyPaymentOverview;
        },
        reCalculateAmount:function(vm,result){
         var amount = (vm.defaultOutStandingAmount-vm.outStandingAmount)/6;
             return result.suggestedMppAmount.amount + amount;
        }
   };
}]);
