(function () {

    angular.module('setupPaymentMethodController').controller('setupMppPaymentMethodController', SetupMppPaymentMethodController);

    SetupMppPaymentMethodController.$inject = ['$location', '$routeParams', 'commonPaymentMethodServices', 'utilityService', 'setupMppPaymentMethodService', 'urlService', 'thistleService', 'errorLoggingService'];

    function SetupMppPaymentMethodController($location, $routeParams, commonPaymentMethodServices, utilityService, setupMppPaymentMethodService, urlService, thistleService, errorLoggingService) {

        var vm = this;
        vm.userType = connection.userType;

        // **** static information
        vm.thistleIframeHeight = constants.THISTLE_IFRAME_HEIGHT;
        vm.encodedPaymentXml = "";
        vm.encodedCardDetailsXml = "";

        vm.paymentMethods = commonPaymentMethodServices.paymentMethods;
        vm.existingBankDetails = vm.paymentMethods.bankDetails;

        // **** attaching variables to the mpp service allows us to persist
        // **** these variables when thistle calls back to us
        vm.mpp = setupMppPaymentMethodService;

        callSetupMpp()
            .then(processMppResponse)
            .then(callForCustomerEmail)
            .then(processCustomerEmail)
            .then(initialisePage, handleError);

        function callSetupMpp() {
            vm.waitingForPageToLoad = true;
            return setupMppPaymentMethodService.getSetupMppDetails();
        };

        function processMppResponse(mppResponse) {
            vm.scenario = mppResponse.type;

            vm.outstandingAmount = getAmount(mppResponse.outstandingAmount);
            vm.outstandingMonthlyAmount = getAmount(mppResponse.outstandingMPPAmount);
            vm.partialAmount = getAmount(mppResponse.partialAmount);
            vm.monthlyPaymentAmount = getAmount(mppResponse.mppAmount);
        };

        function getAmount(amountResponse) {
            if (amountResponse && amountResponse.amount) {
                return amountResponse.amount;
            }

            return 0;
        };

        function callForCustomerEmail() {
            return utilityService.getCustomerEmailAddress($routeParams.accKey);
        };

        function processCustomerEmail(emailResponse) {
            if (vm.userType === 'customer') {
                vm.email = emailResponse;
            } else {
                vm.email = commonPaymentMethodServices.primaryContactDetails.email;
            }
        };

        function initialisePage() {
            vm.waitingForPageToLoad = false;

            if ($routeParams.thistleresponse == 'paymentsuccess') {
                paymentSuccess();
            } else if ($routeParams.thistleresponse == 'paymentfailed') {
                paymentFailure();
            } else {
                setInitialValues();
            }
        };

        function setInitialValues() {
            vm.mpp.tabs = {};
            vm.mpp.tabs.active = 'monthly';
            vm.mpp.tabs.monthlyEditable = false;
            vm.mpp.tabs.monthlyComplete = false;
            vm.mpp.tabs.paymentDayEditable = false;
            vm.mpp.tabs.paymentDayComplete = false;
            vm.mpp.tabs.paymentComplete = false;

            vm.mpp.tsAndCsAccepted = false;

            vm.mpp.tabs.bankDetailsError = false;
            vm.mpp.tabs.makePaymentError = false;
            vm.mpp.tabs.summaryError = false;

            vm.mpp.paymentOption = 'payAll';

            vm.mpp.selectedDay = null;
            vm.paymentsOverview = null;

            if (vm.scenario === 'partial' || vm.scenario === 'nothing') {
                vm.mpp.paymentOption = 'payAll';
            }

            calculateAmountToPayToday();
        };

        function handleError(errorResult) {
            vm.waitingForPageToLoad = false;

            console.log(errorLoggingService.errorToString(errorResult));
            $location.path(urlService.getErrorUrl());
        };

        vm.cancel = function() {
            $location.path("/changepaymentmethodcashcheque");
        };

        vm.paymentDayFormatted = function() {
            return utilityService.getOrdinalNumber(vm.mpp.selectedDay);
        };

        vm.editMonthlyLink = function() {
            vm.mpp.tabs.active = 'monthly';
            vm.mpp.tabs.monthlyEditable = false;
            vm.mpp.tabs.monthlyComplete = false;

            calculateAmountToPayToday();
        };

        vm.editPaymentDayLink = function() {
            vm.mpp.tabs.active = 'paymentDay';
            vm.mpp.tabs.paymentDayEditable = false;
            vm.mpp.tabs.paymentDayComplete = false;

            calculateAmountToPayToday();
        };

        vm.editBankDetailsLink = function() {
            vm.mpp.tabs.active = 'bankDetails';
            vm.mpp.tabs.bankDetailsEditable = false;
            vm.mpp.tabs.bankDetailsComplete = false;

            calculateAmountToPayToday();
        };

        vm.addNewBankDetailsLink = function() {
            vm.mpp.tabs.bankDetailsShowStored = false;
            vm.mpp.tabs.bankDetailsShowAddNew = true;
        };

        vm.tsAndCsTicked = function() {
            vm.mpp.tsAndCsAccepted = !vm.mpp.tsAndCsAccepted;
        };

        vm.setSoleSignatory = function() {
            vm.mpp.soleSignatory = true;
        };

        vm.setNotSoleSignatory = function() {
            vm.mpp.soleSignatory = false;
        };

        vm.tryAnotherCardButton = function() {
            vm.mpp.tabs.makePaymentError = false;
            activateMakePaymentTab();
        };

        vm.tryAgainButton = function() {
            vm.mpp.tabs.summaryError = false;
            activateSummaryTab();
        };

        vm.backToBT = function() {
            $location.path('/viewPaymentMethod');
        };

        vm.monthlyContinueButton = function() {
            vm.mpp.tabs.monthlyComplete = true;
            vm.mpp.tabs.monthlyEditable = true;
            vm.mpp.tabs.active = 'paymentDay';

            calculateAmountToPayToday();
        };

        vm.paymentDayContinueButton = function() {
            vm.mpp.tabs.paymentDayComplete = true;
            vm.mpp.tabs.paymentDayEditable = true;

            activateBankDetailsTab();
        };

        vm.newPaymentDayClicked = function (day) {
            var paymentDayAndFuturePayments = setupMppPaymentMethodService.setPaymentDayAndGetFuturePayments(day, vm.paymentMethods.paymentDay);

            vm.mpp.selectedDay = paymentDayAndFuturePayments.paymentDay;
            vm.paymentsOverview = paymentDayAndFuturePayments.futurePayments;
        };

        vm.bankDetailsContinueButton = function() {
            vm.mpp.tabs.bankDetailsComplete = true;
            vm.mpp.tabs.bankDetailsEditable = true;
            vm.mpp.tabs.bankDetailsError = false;

            vm.mpp.newBankDetails = undefined;

            if (vm.mpp.amountToPayToday > 0) {
                activateMakePaymentTab();
            } else {
                activateSummaryTab();
            }
        };

        vm.newBankDetailsContinueButton = function() {
            var sortCode = [vm.mpp.bankDetailsFormData.sortCode1, vm.mpp.bankDetailsFormData.sortCode2, vm.mpp.bankDetailsFormData.sortCode3].join("");

            vm.mpp.newBankDetails = {
                "bankAccountNumber": vm.mpp.bankDetailsFormData.accountNumber,
                "sortCode": sortCode
            };

            vm.waitingForBankDetailsValidation = true;
            vm.mpp.tabs.bankDetailsError = false;

            var validateBankDetailsResponse = commonPaymentMethodServices.validateBankDetails(vm.mpp.newBankDetails);
            validateBankDetailsResponse.then(function (response) {
                vm.waitingForBankDetailsValidation = false;
                vm.mpp.tabs.bankDetailsError = false;

                if (response.validBankDetails) {
                    vm.mpp.newBankDetails.accountHolderName = vm.mpp.bankDetailsFormData.accountHolder;

                    vm.mpp.tabs.bankDetailsComplete = true;
                    vm.mpp.tabs.bankDetailsEditable = true;
                    vm.mpp.tabs.bankDetailsError = false;

                    if (vm.mpp.amountToPayToday > 0) {
                        activateMakePaymentTab();
                    } else {
                        activateSummaryTab();
                    }
                }

            }, function (errorResult) {
                vm.waitingForBankDetailsValidation = false;
                vm.mpp.tabs.active = 'bankDetails';
                vm.mpp.tabs.bankDetailsError = true;
            });
        };

        function activateBankDetailsTab() {
            vm.mpp.tabs.active = 'bankDetails';

            vm.mpp.soleSignatory = undefined;
            vm.mpp.newBankDetails = undefined;

            if (vm.existingBankDetails && vm.existingBankDetails.bankAccountNumber) {
                vm.mpp.tabs.bankDetailsShowStored = true;
                vm.mpp.tabs.bankDetailsShowAddNew = false;
            } else {
                vm.mpp.tabs.bankDetailsShowStored = false;
                vm.mpp.tabs.bankDetailsShowAddNew = true;
            }

            vm.mpp.tabs.bankDetailsComplete = false;
            vm.mpp.tabs.bankDetailsEditable = false;

            vm.mpp.bankDetailsFormData = {
                accountHolder: "",
                accountNumber: "",
                sortCode1: "",
                sortCode2: "",
                sortCode3: ""
            };

        };

        function activateMakePaymentTab() {
            vm.mpp.tabs.active = 'makePayment';

            if (vm.mpp.paymentOption === 'payAll') {
                paymentAmount = vm.outstandingAmount;
            }

            if (vm.mpp.paymentOption === 'payPartial') {
                paymentAmount = vm.partialAmount;
            }

            vm.encodedPaymentXml = "";
            vm.waitingForPaymentRequest = true;

            var thistlePaymentRequest = thistleService.getGenericPaymentRequest(paymentAmount, "GBP", null, constants.SETUP_MPP_PAYMENT_SUCCESS_URL, constants.SETUP_MPP_PAYMENT_FAILED_URL, constants.SETUP_MPP_PAYMENT_CANCELLED_URL);

            thistlePaymentRequest.then(function (thistleResult) {
                vm.thistleUrl = thistleResult.thistleUrl;
                vm.encodedPaymentXml = thistleResult.encodedXml;

                vm.waitingForPaymentRequest = false;
            }, function (errorResult) {
                vm.waitingForPaymentRequest = false;

                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });
        };

        function activateSummaryTab() {
            vm.mpp.tabs.active = "summary";
            vm.mpp.tabs.monthlyEditable = false;
            vm.mpp.tabs.paymentDayEditable = false;
            vm.mpp.tabs.bankDetailsEditable = false;

            vm.bankDetailsSummaryDisplayBox = null;
            vm.paperMandateRequired = false;

            var updatedAccount = {
                "billFrequency" : constants.BILL_QUARTERY,
                "paymentMethod": constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN,
                "paymentDay": vm.mpp.selectedDay,
                "email": vm.email,
                "monthlyPaymentPlanAmount": {
                    "amount": vm.mpp.amountToPayMonthly,
                    "currencyCode": "GBP"
                }
            };

            if (vm.mpp.soleSignatory === undefined) {
                vm.bankDetailsSummaryDisplayBox = vm.existingBankDetails;
            }

            if (vm.mpp.soleSignatory === true) {
                updatedAccount.bankDetails = vm.mpp.newBankDetails;
                vm.bankDetailsSummaryDisplayBox = vm.mpp.newBankDetails;
            }

            if (vm.mpp.soleSignatory === false) {
                updatedAccount.paperMandate = true;
                vm.paperMandateRequired = true;
            }

            vm.waitingForUpdateAccount = true;

            var updateAccountResponse = commonPaymentMethodServices.updateAccount(updatedAccount);

            updateAccountResponse.then(function (result) {
                vm.waitingForUpdateAccount = false;
                vm.mpp.tabs.summaryError = false;
            }, function (errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));

                vm.waitingForUpdateAccount = false;
                vm.mpp.tabs.summaryError = true;
            });

        };


        function calculateAmountToPayToday() {
            var paymentDueToday = setupMppPaymentMethodService.calculateAmountToPayToday(vm.scenario, vm.mpp.paymentOption,
                                                                                    vm.outstandingAmount, vm.outstandingMonthlyAmount,
                                                                                    vm.partialAmount, vm.monthlyPaymentAmount);

            vm.mpp.amountToPayToday = paymentDueToday.amountToPayToday;
            vm.mpp.amountToPayMonthly = paymentDueToday.amountToPayMonthly;
        };


        function paymentSuccess() {
            vm.mpp.tabs.paymentComplete = true;
            vm.mpp.tabs.makePaymentError = false;

            vm.mpp.paymentSummary = {
                paymentRef: $routeParams.paymentReferenceId,
                timeAndDate: $routeParams.paymentDateTime,
                accountNumber: $routeParams.bac,
                cardType: $routeParams.cardType,
                cardNumber: $routeParams.cardNumber,
                amount: $routeParams.amount
            };

            activateSummaryTab();
        };

        function paymentFailure() {
            vm.mpp.tabs.active = "makePayment";
            vm.mpp.tabs.makePaymentError = true;
            vm.encodedPaymentXml = "";
        };


    }

})();