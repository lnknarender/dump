angular.module('setupPaymentMethodServices').factory('setupMppPaymentMethodService',
        ['$q', 'ajaxServiceWithToken', 'stateService', '$routeParams', 'utilityService', 'setupPaymentMethodUrlService', 'commonPaymentMethodServices',
            function ($q, ajaxServiceWithToken, stateService, $routeParams, utilityService, setupPaymentMethodUrlService, commonPaymentMethodServices) {

                function moveDateAMonthAheadIfNeeded(selectedDate, existingPaymentDay) {
                    var existingPaymentDate = moment();

                    if (existingPaymentDay) {
                        existingPaymentDate = moment().date(existingPaymentDay);
                    }

                    var today = moment();
                    if (today.isAfter(existingPaymentDate.clone().subtract(3, "d"), 'day') ||
                        selectedDate.isBefore(today, 'day') ||
                        (today.isBefore(existingPaymentDate, 'day') && selectedDate.isBefore(today.add(4, "d"), 'day'))) {
                        selectedDate.add(1, "M");
                    }
                };

                return {
                    getSetupMppDetails: function () {
                        var deferred = $q.defer(), mpp = stateService.get(constants.STATE_SERVICE_SETUP_MPP);

                        //if (true) {
                        //    deferred.resolve(
                        //        {
                        //            "type": "nobalance", // partial / nothing / nobalance
                        //            "outstandingAmount": {
                        //                "amount": 99,
                        //                "currencyCode": "GBP"
                        //            },
                        //            "outstandingMPPAmount":  {
                        //                "amount": 88,
                        //                "currencyCode": "GBP"
                        //            },
                        //            "partialAmount":  {
                        //                "amount": 77,
                        //                "currencyCode": "GBP"
                        //            },
                        //            "mppAmount":  {
                        //                "amount": 66,
                        //                "currencyCode": "GBP"
                        //            }
                        //        }
                        //    );
                        //}
                        if (mpp) {
                            deferred.resolve(mpp);
                        } else {
                            var url = setupPaymentMethodUrlService.getSetupMppUrl();

                            var mppResponse = ajaxServiceWithToken.doGet(url, {});

                            mppResponse.then(function (result) {
                                stateService.set(constants.STATE_SERVICE_SETUP_MPP, result);
                                deferred.resolve(result);
                            },
                            function (errorResult) {
                                deferred.reject(errorResult);
                            });
                        }

                        return deferred.promise;
                    },


                    calculateAmountToPayToday: function(scenario, paymentOption, outstandingAmount, outstandingMonthlyAmount, partialAmount, monthlyPaymentAmount) {

                        if (scenario === 'nobalance') {
                            return {
                                "amountToPayToday": 0,
                                "amountToPayMonthly": monthlyPaymentAmount
                            }
                        }

                        if (paymentOption === 'payAll') {
                            return {
                                "amountToPayToday": outstandingAmount,
                                "amountToPayMonthly": outstandingMonthlyAmount
                            }
                        }

                        if (scenario === 'nothing' && paymentOption === 'payPartial') {
                            return {
                                "amountToPayToday": 0,
                                "amountToPayMonthly": monthlyPaymentAmount
                            }
                        }

                        if (scenario === 'partial' && paymentOption === 'payPartial') {
                            return {
                                "amountToPayToday": partialAmount,
                                "amountToPayMonthly": monthlyPaymentAmount
                            }
                        }
                    },

                    setPaymentDayAndGetFuturePayments: function (selectedDay, existingPaymentDay) {
                        var paymentDay = selectedDay;

                        if (selectedDay > 0) {
                            var selectedDate = moment().date(selectedDay);
                            paymentDay = selectedDate.date();

                            moveDateAMonthAheadIfNeeded(selectedDate, existingPaymentDay);

                            var dates = [selectedDate.clone().toDate()];
                            for (var i = 0; i < 2; i++) {
                                dates.push(selectedDate.add(1, "M").clone().toDate());
                            }
                        } else {
                            var selectedDate = moment().endOf('month');
                            paymentDay = -1;

                            moveDateAMonthAheadIfNeeded(selectedDate, existingPaymentDay);

                            var dates = [selectedDate.clone().endOf('month').toDate()];
                            for (var i = 0; i < 2; i++) {
                                dates.push(selectedDate.add(1, "M").clone().endOf('month').toDate());
                            }
                        }

                        return {
                            "paymentDay": paymentDay,
                            "futurePayments": dates
                        }
                    }



                };
            }]);