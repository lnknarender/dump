(function () {
  angular.module('setupPaymentMethodController').controller('reAssessmentController', ReAssessmentController);

    ReAssessmentController.$inject = ['$location', '$routeParams', 'commonPaymentMethodServices', 'utilityService', 'reAssessmentServices', 'errorLoggingService', 'thistleService', '$timeout', 'paymentFriendlyNameService', 'primaryContactService'];
        function ReAssessmentController($location, $routeParams, commonPaymentMethodServices, utilityService, reAssessmentServices, errorLoggingService, thistleService, $timeout, paymentFriendlyNameService, primaryContactService) {
         var vm = this,paymentMethod = commonPaymentMethodServices.paymentMethods;
         vm.userType = connection.userType;
          vm.reassess = reAssessmentServices;

              var emailResponse = utilityService.getCustomerEmailAddress($routeParams.accKey);

              emailResponse.then(function (emailResult) {
                  vm.reassess.email = emailResult;
                  if (vm.userType !== constants.CUSTOMER) {
                      vm.reassess.email = commonPaymentMethodServices.primaryContactDetails.email;
                  }

                  if (vm.userType === constants.CUSTOMER) {
                      function contactDetails(response) {
                          vm.userFriendlyName = response.userFriendlyName;
                      }
                      utilityService.getPaymentFriendlyName(paymentFriendlyNameService, primaryContactService, errorLoggingService).then(contactDetails);
                  }

                  angular.extend(vm,{
                      paymentToday :paymentMethod.paymentToday,
                      paymentDay :utilityService.getOrdinalNumber(paymentMethod.paymentDay),
                      thistleIframeHeight:constants.THISTLE_IFRAME_HEIGHT,
                      monthlyPaymentAmount: paymentMethod.monthlyPaymentAmount,
                      recalculateOutStandingAmount: paymentMethod.suggestedMppAmount.amount,
                      defaulRecalculateOutStandingAmount: paymentMethod.suggestedMppAmount.amount,
                      defaultOutStandingAmount :paymentMethod.outstanding.amount,
                      outStandingAmount:paymentMethod.outstanding.amount,
                      newReassessedAmount:commonPaymentMethodServices.newReassessedAmount,
                      reCalculateValidation: false,
                      backToPaymentMethod:function(){
                          $location.path('/viewPaymentMethod');
                      },
                      cancel:function(){
                          $location.path('/viewPaymentMethod');
                      }
                  });
              },

              function (errorResult) {
              console.log(errorLoggingService.errorToString(errorResult));
              $location.path(urlService.getErrorUrl());
              });



        
         reAssessmentServices.reAssessmentAction(vm,commonPaymentMethodServices.mppRessessmentAction,paymentMethod);
         reAssessmentServices.defaultValues(vm,commonPaymentMethodServices);
         vm.reCalculateAmountOnChange=function(){
           
                vm.makePaymentBtn= !(+vm.defaultOutStandingAmount===+vm.outStandingAmount);
                if(!vm.makePaymentBtn){
                    vm.recalculateOutStandingAmount=vm.defaulRecalculateOutStandingAmount;
                    vm.reCalculateValidation= false;
                }else { 
                    vm.recalculateOutStandingAmount;
                    vm.reCalculateValidation= false;
                }
              
         };
         vm.reCalculate= function(){
            var reCalculateResponse = commonPaymentMethodServices.getRecalculateAmount();
                reCalculateResponse.then(function (result) {
                    vm.reCalculateObject = result;
                    vm.recalculateMinimumAmount= result.minimumAmount.amount;
                    vm.recalculateMaximumAmount= result.maximumAmount.amount;
                    vm.makePaymentBtn=  vm.reCalculateValidation= false;
                    vm.recalculateOutStandingAmount= reAssessmentServices.reCalculateAmount(vm,result);
                }, function (errorResult) {

                });
         };
         
          vm.makePaymentAction=function(){
            if(!(+vm.defaultOutStandingAmount===+vm.outStandingAmount)){
               if(!((vm.reCalculateObject!==null||vm.reCalculateObject!==undefined) && +vm.outStandingAmount>=+vm.reCalculateObject.minimumAmount.amount && +vm.outStandingAmount<=+vm.reCalculateObject.maximumAmount.amount)){
                vm.reCalculateValidation= true;
                return true;
                }else{
                    vm.reCalculateValidation= false;
                } 
            }
            vm.waitingForPaymentRequest=true;
            vm.accordionStatus.makePaymentAccordionStatus=constants.ACCORDION_CURRENT;
            vm.accordionStatus.amountYouOweAccordionStatus=constants.ACCORDION_COMPLETE;
           reAssessmentServices.expandOrCollapseAccordion(vm.accordionStatus);
           reAssessmentServices.reAssessmentAmountToPayDone(vm);
           reAssessmentServices.latestRecalculateAmount=vm.recalculateOutStandingAmount;
          var thistlePaymentRequest = thistleService.getGenericPaymentRequest(vm.outStandingAmount, "GBP", null, constants.RESSESSMENT_THISITLE_SUCCESS_URL, constants.RESSESSMENT_THISITLE_FAILED_URL, constants.RESSESSMENT_THISITLE_CANCELLED_URL);

            thistlePaymentRequest.then(function (thistleResult) {
                vm.thistleUrl = thistleResult.thistleUrl;
                vm.encodedPaymentXml = thistleResult.encodedXml;
                 $timeout(function(){
                    document.payform.submit();
                    vm.waitingForPaymentRequest = false;
                  },500);
              
            }, function (errorResult) {
                vm.waitingForPaymentRequest = false;

                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });
           
         };
         if(vm.mppScenario===constants.REASSESS_HIGHER||vm.mppScenario===constants.REASSESS_NO_CHANGE_WITH_DEBIT){
             reAssessmentServices.getDefaultReAssessmentOptions(vm);
             reAssessmentServices.expandOrCollapseAccordion(vm.accordionStatus);
              if(vm.mppScenario===constants.REASSESS_NO_CHANGE_WITH_DEBIT){
                 vm.makePaymentAction();
             }
         }
         angular.extend(vm,{
           editAmountYouOwe:function(){
                    reAssessmentServices.getDefaultReAssessmentOptions(vm);
                    vm.accordionStatus.makePaymentAccordionStatus=constants.ACCORDION_NOT_STARTED;
                    vm.accordionStatus.amountYouOweAccordionStatus=constants.ACCORDION_CURRENT;
                    reAssessmentServices.expandOrCollapseAccordion(vm.accordionStatus);
           }, 
           paymentSuccess:function(){
                    reAssessmentServices.getReAssessmentSummary(vm);
                    vm.updatePaymentMethod();
           },
           paymentFailure: function(){
                     reAssessmentServices.getReAssessmentMakePaymentFailure(vm);
         }
         });
       
         vm.updatePaymentMethod=function(){
              var updateAccountResponse = commonPaymentMethodServices.updateAccount({
                "billFrequency" : paymentMethod.billFrequency,
                "paymentMethod": constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN,
                "email": vm.reassess.email,
                "monthlyPaymentPlanAmount":{
                          "amount": reAssessmentServices.latestRecalculateAmount,
                          "currencyCode": "GBP"
                      } 

            });

            vm.waitingForUpdateAccount = true;

            updateAccountResponse.then(function (result) {
              vm.accordionStatus.summaryAccordionStatus=constants.ACCORDION_CURRENT;
              vm.accordionStatus.makePaymentAccordionStatus=constants.ACCORDION_COMPLETE;
              vm.accordionStatus.amountYouOweAccordionStatus=constants.ACCORDION_COMPLETE;
              vm.tabs.editAmountYouOwe=false;
              vm.latestRecalculateAmount= reAssessmentServices.latestRecalculateAmount;
              reAssessmentServices.getSummaryPaymentData(vm,$routeParams);
              reAssessmentServices.expandOrCollapseAccordion(vm.accordionStatus);
              
            }, function (errorResult) {
               
            });  
         };
         
         
          if ($routeParams.thistleresponse === 'paymentsuccess') {
                vm.paymentSuccess();
            } else if ($routeParams.thistleresponse ==='paymentfailed') {
                vm.paymentFailure();
            }else if ($routeParams.thistleresponse ==='paymentcancel'){
                $location.path('/mppressessmentaction');
            }
        
        }
})();


