(function () {

    angular.module('setupPaymentMethodController').controller('setupCcraPaymentMethodController', SetupCcraPaymentMethodController);

    SetupCcraPaymentMethodController.$inject = ['$route', '$anchorScroll', '$location', '$routeParams', 'commonPaymentMethodServices', 'kcimEmailConfirmationService', 'utilityService', 'urlService', 'setupCcraPaymentMethodService', 'thistleService', 'errorLoggingService'];

    function SetupCcraPaymentMethodController($route, $anchorScroll, $location, $routeParams, commonPaymentMethodServices, kcimEmailConfirmationService, utilityService, urlService, setupCcraPaymentMethodService, thistleService, errorLoggingService) {

        var vm = this;
        vm.userType = connection.userType;

        // **** static information
        vm.thistleIframeHeight = constants.THISTLE_IFRAME_HEIGHT;
        vm.encodedPaymentXml = "";
        vm.encodedCardDetailsXml = "";

        vm.paymentMethods = commonPaymentMethodServices.paymentMethods;

        vm.billFrequency = vm.paymentMethods.billFrequency;

        // **** attaching variables to ccraService allows us to persist
        // **** these variables when thistle calls back to us
        vm.ccra = setupCcraPaymentMethodService;

        // *** Set up the page
        callChangeDetails()
            .then(processChangeDetailsResponse)
            .then(callForCustomerEmail)
            .then(processCustomerEmail)
            .then(initialisePage, handleError);

        function callChangeDetails() {
            vm.waitingForPageToLoad = true;

            return setupCcraPaymentMethodService.getPaymentMethodChangeDetails();
        };

        function processChangeDetailsResponse(changeDetailsResponse) {
            vm.ccra.owedMoney = changeDetailsResponse.balance.amount;
            vm.nextBillDate = changeDetailsResponse.nextBillDate;

            vm.ccraPaymentDay = utilityService.getBillCyclePlusDays(changeDetailsResponse.nextBillDate, 10);
        };

        function callForCustomerEmail() {
            return utilityService.getCustomerEmailAddress($routeParams.accKey);
        };

        function processCustomerEmail(emailResponse) {
            if (vm.userType === 'customer') {
                vm.email = emailResponse;
            } else {
                vm.email = commonPaymentMethodServices.primaryContactDetails.email;
            }
        };

        function initialisePage() {
            vm.waitingForPageToLoad = false;

            if ($location.path() == '/ccrasetup') {
                setInitialValues();
            }

            if (vm.ccra.tabs.ccraEditLinkClicked === true) {
                vm.activateCcraDetailsTab();
            } else if (vm.ccra.tabs.cardEditLinkClicked === true) {
                vm.activateCardDetailsTab();
            } else if ($routeParams.thistleresponse == 'paymentsuccess') {
                vm.paymentSuccess();
            } else if ($routeParams.thistleresponse == 'paymentfailed') {
                vm.paymentFailure();
            } else if ($routeParams.thistleresponse == 'carddetailssuccess') {
                vm.cardDetailsSuccess();
            } else if ($routeParams.thistleresponse == 'carddetailsfailed') {
                vm.cardDetailsFailure();
            } else {
                vm.ccra.error = false;
            }
        };

        function setInitialValues() {
            vm.ccra.emailSent = false;
            vm.ccra.tsAndCsAccepted = false;

            vm.ccra.tabs = {};
            vm.ccra.tabs.active = "ccradetails";

            vm.ccra.billFrequency = vm.billFrequency;
            if (vm.ccra.billFrequency == undefined || vm.ccra.billFrequency == null) {
                vm.ccra.billFrequency = "1M";
            }
        };

        function handleError(errorResult) {
            vm.waitingForPageToLoad = false;

            console.log(errorLoggingService.errorToString(errorResult));
            $location.path(urlService.getErrorUrl());
        };

        vm.tryAgainButton = function () {
            vm.ccra.tabs.active = "ccradetails";

            vm.ccra.error = false;

            vm.ccra.cardupdated = undefined;

            vm.encodedPaymentXml = "";
            vm.encodedCardDetailsXml = "";
        };

        vm.tryAgainCardDetailsButton = function() {
            vm.ccra.error = false;
            vm.activateCardDetailsTab();
        };

        vm.tryAnotherCardButton = function() {
            vm.ccra.error = false;
            vm.activateMakePaymentTab();
        };

        vm.cancel = function() {
            $location.path("/changepaymentmethodcashcheque");
        };

        vm.monthlyClicked = function() {
            vm.ccra.billFrequency = constants.BILL_MONTHLY;
        };

        vm.quarterlyClicked = function() {
            vm.ccra.billFrequency = constants.BILL_QUARTERY;
        };

        vm.paymentDayFormatted = function() {
            return utilityService.getOrdinalNumber(vm.ccraPaymentDay);
        };

        vm.tsAndCsTicked = function() {
            vm.ccra.tsAndCsAccepted = !vm.ccra.tsAndCsAccepted;
        };

        vm.backToBT = function() {
            $location.path('/viewPaymentMethod');
        };

        vm.editCcraLink = function() {
            vm.ccra.tabs.ccraEditLinkClicked = true;
            redrawPage();
        };

        vm.editCardDetailsLink = function() {
            vm.ccra.tabs.cardEditLinkClicked = true;
            redrawPage();
        };

        vm.activateCcraDetailsTab = function() {
            vm.ccra.tabs.ccraEditLinkClicked = false;

            vm.ccra.tabs.active = "ccradetails";

            vm.ccra.tabs.ccraEditable = false;
            vm.ccra.tabs.ccraComplete = false;
        };

        vm.activateCardDetailsTab = function() {
            vm.ccra.tabs.cardEditLinkClicked = false;

            vm.ccra.tabs.active = 'carddetails';

            vm.ccra.tabs.ccraEditable = true;
            vm.ccra.tabs.ccraComplete = true;
            vm.ccra.tabs.cardEditable = false;
            vm.ccra.tabs.cardComplete = false;

            vm.encodedCardDetailsXml = "";

            vm.waitingForCardDetailsRequest = true;

            var thistleCardDetailsRequest = thistleService.getValidateCardRequest({}, constants.SETUP_CCRA_CARD_DETAILS_SUCCESS_URL, constants.SETUP_CCRA_CARD_DETAILS_FAILED_URL, constants.SETUP_CCRA_CARD_DETAILS_CANCELLED_URL);

            thistleCardDetailsRequest.then(function (thistleResult) {
                vm.thistleUrl = thistleResult.thistleUrl;
                vm.encodedCardDetailsXml = thistleResult.encodedXml;

                vm.waitingForCardDetailsRequest = false;
            }, function (errorResult) {
                vm.waitingForCardDetailsRequest = false;

                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });            
        };

        vm.activateMakePaymentTab = function() {
            vm.ccra.tabs.active = 'makepayment';

            vm.ccra.tabs.ccraEditable = true;
            vm.ccra.tabs.ccraComplete = true;
            vm.ccra.tabs.cardEditable = true;
            vm.ccra.tabs.cardComplete = true;

            vm.encodedPaymentXml = "";

            vm.waitingForPaymentRequest = true;

            var thistlePaymentRequest = thistleService.getGenericPaymentRequest(vm.ccra.owedMoney, "GBP", null, constants.SETUP_CCRA_PAYMENT_SUCCESS_URL, constants.SETUP_CCRA_PAYMENT_FAILED_URL, constants.SETUP_CCRA_PAYMENT_CANCELLED_URL);

            thistlePaymentRequest.then(function (thistleResult) {
                vm.thistleUrl = thistleResult.thistleUrl;
                vm.encodedPaymentXml = thistleResult.encodedXml;

                vm.waitingForPaymentRequest = false;
            }, function (errorResult) {
                vm.waitingForPaymentRequest = false;

                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });
        };

        vm.activateSummaryTab = function() {
            vm.ccra.tabs.active = "summary";

            vm.ccra.tabs.ccraEditable = false;
            vm.ccra.tabs.ccraComplete = true;
            vm.ccra.tabs.cardEditable = false;
            vm.ccra.tabs.cardComplete = true;

            var updatedBillCycle = utilityService.getBillCycle(vm.nextBillDate);

            var updateAccountResponse = commonPaymentMethodServices.updateAccount({
                "billFrequency" : vm.ccra.billFrequency,
                "paymentMethod": constants.PAYMENT_METHOD_CCRA,
                "paymentDay": vm.ccraPaymentDay,
                "billCycle": updatedBillCycle,
                "email": vm.email,
                "paymentInstrumentReference": vm.ccra.cardupdated.paymentInstrumentRef,
                "partyCardType": vm.ccra.cardupdated.cardType,
                "paymentReferenceId": $routeParams.paymentReferenceId
            });

            vm.waitingForUpdateAccount = true;

            updateAccountResponse.then(function (result) {
                vm.ccra.error = false;
                vm.waitingForUpdateAccount = false;
            }, function (errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));

                vm.ccra.error = true;
                vm.waitingForUpdateAccount = false;
            });

        };

        vm.paymentSuccess = function() {
            vm.ccra.tabs.paymentComplete = true;

            vm.ccra.paymentSummary = {
                paymentRef: $routeParams.paymentReferenceId,
                timeAndDate: $routeParams.paymentDateTime,
                accountNumber: $routeParams.bac,
                cardType: $routeParams.cardType,
                cardNumber: $routeParams.cardNumber,
                amount: $routeParams.amount
            };

            vm.activateSummaryTab();
        };

        vm.paymentFailure = function() {
            vm.ccra.tabs.active = "makepayment";

            vm.ccra.tabs.ccraEditable = true;
            vm.ccra.tabs.ccraComplete = true;
            vm.ccra.tabs.cardEditable = true;
            vm.ccra.tabs.cardComplete = true;

            vm.ccra.error = true;
            vm.encodedPaymentXml = "";
        };

        vm.cardDetailsSuccess = function() {

            vm.ccra.cardupdated = {
                cardType: $routeParams.cardType,
                cardHolder: $routeParams.cardHolderName,
                cardNumber: $routeParams.cardNumber,
                house: $routeParams.cardHolderAddress,
                postcode: $routeParams.cardHolderPostCode,
                expiry: $routeParams.expiryDate,
                paymentInstrumentRef: $routeParams.paymentInstrumentRef
            };

            if (vm.ccra.owedMoney > 0 && vm.ccra.tabs.paymentComplete != true) {
                vm.activateMakePaymentTab();
            } else {
                vm.activateSummaryTab();
            }
        };

        vm.cardDetailsFailure = function() {
            vm.ccra.tabs.active = 'carddetails';

            vm.ccra.tabs.ccraEditable = true;
            vm.ccra.tabs.ccraComplete = true;
            vm.ccra.tabs.cardEditable = false;
            vm.ccra.tabs.cardComplete = true;

            vm.ccra.error = true;
            vm.encodedCardDetailsXml = "";
        };

        function redrawPage() {
            if ($location.path() == '/ccrasetupredraw') {
                $route.reload();
            } else {
                $location.path('/ccrasetupredraw');
            }
        }



    }
})();