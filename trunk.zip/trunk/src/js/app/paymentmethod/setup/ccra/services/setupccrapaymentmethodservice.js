/**
 * Created by Andrew on 28/01/2016.
 */

setupPaymentMethodServices.factory('setupCcraPaymentMethodService', ['$q', 'ajaxServiceWithToken', 'stateService', '$routeParams', 'utilityService', 'setupPaymentMethodUrlService', 'commonPaymentMethodServices', function ($q, ajaxServiceWithToken, stateService, $routeParams, utilityService, setupPaymentMethodUrlService, commonPaymentMethodServices) {

    return {

        getPaymentMethodChangeDetails: function () {
            var deferred = $q.defer(), changeDetail = stateService.get(constants.STATE_SERVICE_PAYMENT_METHODS_CHANGE_DETAILS);

            if (changeDetail) {
                deferred.resolve(changeDetail);
            } else {
                var url = setupPaymentMethodUrlService.getPaymentMethodChangeDetailsUrl();

                var changeDetailsResponse = ajaxServiceWithToken.doGet(url, {});

                changeDetailsResponse.then(function (result) {
                    stateService.set(constants.STATE_SERVICE_PAYMENT_METHODS_CHANGE_DETAILS, result);
                    deferred.resolve(result);
                },
                function (errorResult) {
                    deferred.reject(errorResult);
                });
            }

            return deferred.promise;
        }

    }
}]);
