angular.module('cancelPaymentMethodController', [])
        .controller('cancelPaymentMethodCtrl', ['$scope', 'stateService', '$location', '$routeParams', 'commonPaymentMethodServices',
            function ($scope, stateService, $location, $routeParams, commonPaymentMethodServices) {
                $scope.setupCancel = true;
                $scope.email = stateService.get("contactEmail");
                $scope.userType = connection.userType;
                $scope.cancelAction = function () {
                    var updateAccount = {
                        "billingAccount": $routeParams.bac,
                        "billFrequency": commonPaymentMethodServices.paymentMethods.billFrequency,
                        "paymentMethod": constants.PAYMENT_METHOD_CHEQUE_CASH,
                        "email": stateService.get("contactEmail")
                    };                    
                    commonPaymentMethodServices.updateAccount(updateAccount)
                            .then(function (result) {
                                $scope.setupCancel = false;
                                $scope.cancelPaymentMethodSuccess = true;
                                $scope.cancelPaymentMethodFailure = false;
                            }, function (errorResult) {
                                $scope.setupCancel = false;
                                $scope.cancelPaymentMethodFailure = true;
                                $scope.cancelPaymentMethodSuccess = false;
                            });
                };
                $scope.stayOn = function () {
                    $location.path('/viewPaymentMethod/');
                };

                $scope.tryAgainLater = function () {
                    $location.path('/changepaymentmethodcashcheque');
                };
                $scope.backToBT = function () {
                    $location.path('/viewPaymentMethod/');
                };
            }
        ]);