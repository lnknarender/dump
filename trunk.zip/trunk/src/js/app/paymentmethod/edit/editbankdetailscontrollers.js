/**
 * Created by Andrew on 26/01/2016.
 */
(function () {
    //  Do not create a new instance of editPaymentMethodController but bind to an existing instance
    angular.module('editPaymentMethodController')
        .controller('editBankDetailsCtrl', ['$scope', '$location', 'commonPaymentMethodServices', 'editBankDetailsService', 'urlService',
            function ($scope, $location, commonPaymentMethodServices, editBankDetailsService, urlService) {

                var vm = this;

                vm.tAndCTicked = false;
                vm.bankDetails = {"sortCode": {}};
                vm.soleSignatoryYes = false;
                vm.soleSignatoryNo = false;
                vm.validBankAccount = true;

                vm.onClickSoleSignatory = function (soleSignatory) {
                    vm.soleSignatoryYes = soleSignatory === "yes" ? true : false;
                    vm.soleSignatoryNo = soleSignatory === "no" ? true : false;
                };

                vm.saveChanges = function () {
                    $scope.loading = true;
                    if (vm.soleSignatoryNo && !vm.soleSignatoryYes) {
                        editBankDetailsService.setSoleSignatory(false);
                        $location.path('/updatebankdetails');
                    } else {
                        var accountNumber = vm.bankDetails.accountNumber,
                            sortCode = vm.bankDetails.sortCode;
                        // Form the JSON request for the bank account validation. This should be moved to a utility junction as it
                        // may be used by other functions
                        var bankDetails = {
                            "bankAccountNumber": accountNumber,
                            "sortCode": [sortCode.code1, sortCode.code2, sortCode.code3].join("")
                        };
                        //  Validate the customer bank account details. Response handled by function below
                        commonPaymentMethodServices.validateBankDetails(bankDetails).then(displaySuccess, displayError);
                    }
                };

                vm.cancelChanges = function () {
                    $location.path('/viewPaymentMethod');
                };

                /**
                 * Handle bank validation HTTP success
                 * @param response
                 */
                function displaySuccess(response) {
                    var validBankDetails = response.validBankDetails;
                    if (validBankDetails) {
                        //save the bank details in service
                        editBankDetailsService.setBankDetails(vm.bankDetails, true);
                        $location.path('/updatebankdetails');
                    } else {
                        $scope.loading = false;
                        vm.validBankAccount = false;
                    }
                }

                /**
                 * Handle bank validation HTTP error
                 * @param error
                 */
                function displayError(error) {
                    $scope.loading = false;
                    vm.validBankAccount = false;
                }
            }])
        .controller('updateBankDetailsCtrl', ['$scope', 'editBankDetailsService', '$routeParams', 'utilityService', 'paymentFriendlyNameService', 'primaryContactService', 'errorLoggingService', 'viewLatestBillService',
            function ($scope, editBankDetailsService, $routeParams, utilityService, paymentFriendlyNameService, primaryContactService, errorLoggingService, viewLatestBillService) {
                var vm = this;

                $scope.userType = connection.userType;

                if ($scope.userType === constants.CUSTOMER) {
                    utilityService.getPaymentFriendlyName(paymentFriendlyNameService, primaryContactService, errorLoggingService).then(contactDetails);
                }

                // Create the view customer's latest bill link. Variable will be null for advisor
                $scope.viewLastestBill = viewLatestBillService.getLatestBillLink();

                vm.updateChanges = function () {
                    $scope.loading = true;
                    vm.updateFailed = false;
                    editBankDetailsService.updateBankDetails($routeParams.bac).then(function (result) {
                        vm.updateSuccess = true;
                        vm.bankDetails = result.bankDetails;
                        vm.soleSignatory = result.soleSignatory;
                        vm.email = result.email;
                        vm.nextBillDateDueIn2Days = result.nextBillDateDueIn2Days;
                        vm.nextBillDateDueIn3Days = result.nextBillDateDueIn3Days;
                        //Set address in scope
                        utilityService.getAddressInformation(vm, result.address);
                        $scope.loading = false;
                    }, function (errorResult) {
                        vm.updateFailed = true;
                        $scope.loading = false;
                    });
                };

                vm.updateChanges();

                function contactDetails(response) {
                    $scope.userFriendlyName = response.userFriendlyName;
                }
            }]);
})();