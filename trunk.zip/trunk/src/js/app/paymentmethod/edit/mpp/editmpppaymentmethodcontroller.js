angular.module('editPaymentMethodController')
        .controller('editMppPaymentDayCtrl',
                ['$scope', '$routeParams', '$location', 'commonPaymentMethodServices', 'utilityService', 'editMppPaymentMethodService',
                    function ($scope, $routeParams, $location, commonPaymentMethodServices, utilityService, editMppPaymentMethodService) {
                        var vm = this;

                        vm.cancelChanges = function () {
                            $location.path('/viewPaymentMethod');
                        };

                        var paymentMethods = commonPaymentMethodServices.paymentMethods;
                        if (!paymentMethods || paymentMethods.paymentMethod !== constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN) {
                            vm.invalid = true;
                            return;
                        }

                        vm.showpaymentday = true;
                        vm.paymentMethods = paymentMethods;

                        vm.getPaymentDays = function () {
                            return [1, 2, 3, 4, 5, 6, 7,
                                8, 9, 10, 11, 12, 13, 14,
                                15, 16, 17, 18, 19, 20, 21,
                                22, 23, 24, 25, 26, 27, 28];
                        };

                        vm.selectedDay = paymentMethods.paymentDay;

                        if (paymentMethods.paymentDay === -1) {
                            // -1 means last day of the month
                            vm.formattedDay = "Last day";
                            vm.currentPaymentDay = "last day";
                        } else {
                            vm.formattedDay = vm.currentPaymentDay = utilityService.getOrdinalNumber(paymentMethods.paymentDay);
                        }

                        vm.paymentsOverview = [];
                        vm.allowUpdate = false;

                        vm.selectPaymentday = function (day) {
                            updateModel(day);
                        };

                        vm.selectLastPaymentDay = function () {
                            vm.selectPaymentday(-1);
                        };

                        function updateModel(day) {
                            if (day !== paymentMethods.paymentDay) {
                                if (day > 0) {
                                    var selectedDate = moment().date(day);
                                    vm.selectedDay = selectedDate.date();
                                    vm.formattedDay = selectedDate.format("Do");

                                    adjustPaymentDate(selectedDate);
                                    var dates = [selectedDate.clone().toDate()];
                                    for (var i = 0; i < 2; i++) {
                                        dates.push(selectedDate.add(1, "M").clone().toDate());
                                    }
                                } else {
                                    var selectedDate = moment().endOf('month');
                                    vm.selectedDay = -1;
                                    vm.formattedDay = "Last day";

                                    adjustPaymentDate(selectedDate);
                                    var dates = [selectedDate.clone().endOf('month').toDate()];
                                    for (var i = 0; i < 2; i++) {
                                        dates.push(selectedDate.add(1, "M").clone().endOf('month').toDate());
                                    }
                                }
                                vm.paymentsOverview = dates;
                                vm.allowUpdate = true;
                            }
                        }

                        function adjustPaymentDate(selectedDate) {
                            var existingPaymentDay = moment().date(paymentMethods.paymentDay);
                            var today = moment();
                            if (today.isAfter(existingPaymentDay.clone().subtract(3, "d"), 'day') ||
                                    selectedDate.isBefore(today, 'day') ||
                                    (today.isBefore(existingPaymentDay, 'day') && selectedDate.isBefore(today.add(4, "d"), 'day'))) {
                                selectedDate.add(1, "M");
                            }
                        }

                        vm.saveChanges = function () {
                            $scope.loading = true;
                            vm.showpaymentday = false;
                            vm.showpaymentdaysuccess = false;
                            vm.showpaymentdayfailure = false;

                            editMppPaymentMethodService.updatePaymentDay($routeParams.bac, vm.selectedDay)
                                    .then(function (result) {
                                        vm.email = result.email;
                                        vm.selectedDay = result.selectedDay;
                                        vm.isNextBillDateDue = result.isNextBillDateDue;

                                        vm.showpaymentdaysuccess = true;
                                        $scope.loading = false;
                                    }, function (error) {
                                        vm.showpaymentdayfailure = true;
                                        $scope.loading = false;
                                    });
                        };
                    }])
        .controller('editMppPaymentAmountCtrl',
                ['$scope', '$routeParams', '$location', 'commonPaymentMethodServices', 'utilityService', 'editMppPaymentMethodService',
                    function ($scope, $routeParams, $location, commonPaymentMethodServices, utilityService, editMppPaymentMethodService) {
                        var vm = this;

                        vm.cancelChanges = function () {
                            $location.path('/viewPaymentMethod');
                        };

                        var paymentMethods = commonPaymentMethodServices.paymentMethods;
                        if (!paymentMethods || paymentMethods.paymentMethod !== constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN) {
                            vm.invalid = true;
                            return;
                        }

                        vm.showpaymentamount = true;
                        vm.paymentMethods = paymentMethods;
                        vm.monthlyAmount = paymentMethods.monthlyRecommendedAmount.amount;

                        vm.showMinError = function () {
                            return vm.monthlyAmount && vm.monthlyAmount < paymentMethods.minimumAmount.amount;
                        };

                        vm.showMaxError = function () {
                            return vm.monthlyAmount && vm.monthlyAmount > paymentMethods.maximumAmount.amount;
                        };

                        vm.isInvalidAmount = function () {
                            return vm.monthlyAmount === "" || isNaN(vm.monthlyAmount);
                        };

                        vm.saveChanges = function () {
                            $scope.loading = true;
                            vm.showpaymentamount = false;
                            vm.showpaymentamountsuccess = false;
                            vm.showpaymentamountfailure = false;
                            if (!(vm.isInvalidAmount() || vm.showMaxError() || vm.showMinError())) {
                                editMppPaymentMethodService.updatePaymentAmount($routeParams.bac, vm.monthlyAmount)
                                        .then(function (result) {
                                            vm.email = result.email;
                                            vm.monthlyAmount = result.amount;
                                            vm.isNextBillDateDue = result.isNextBillDateDue;

                                            vm.showpaymentamountsuccess = true;
                                            $scope.loading = false;
                                        }, function (error) {
                                            vm.showpaymentamountfailure = true;
                                            $scope.loading = false;
                                        });
                            }
                        };
                    }]);
