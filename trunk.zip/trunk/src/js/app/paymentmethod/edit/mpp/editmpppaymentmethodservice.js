angular.module('editPaymentMethodServices').factory('editMppPaymentMethodService',
        ['commonPaymentMethodServices', 'stateService', 'primaryContactService', '$q',
            function (commonPaymentMethodServices, stateService, primaryContactService, $q) {

                function sendRequest(request) {
                    var requests = [];
                    requests.push(commonPaymentMethodServices.updateAccount(request));
                    // Commented below line as we are waiting for clarification from business
                    //requests.push(commonPaymentMethodServices.getNextBillDate());
                    return $q.all(requests);
                }

                return {
                    updatePaymentDay: function (bac, day) {
                        var deferred = $q.defer();
                        var existingPaymentMethod = commonPaymentMethodServices.paymentMethods;

                        var updateAccount = {
                            "billingAccount": bac || primaryContactService.primaryContactBillingAccount,
                            "paymentMethod": existingPaymentMethod.paymentMethod,
                            "email": stateService.get("contactEmail"),
                            "billFrequency": existingPaymentMethod.billFrequency,
                            "paymentDay": day
                        };

                        sendRequest(updateAccount).then(function (results) {
                            var res = {
                                email: updateAccount.email,
                                isNextBillDateDue: false,
                                selectedDay: day
                            };
                            if (results.length > 1) {
                                res.isNextBillDateDue = commonPaymentMethodServices.isNextBillDateDue(results[1], 3);
                            }
                            deferred.resolve(res);
                        },
                                function (errorResult) {
                                    deferred.reject(errorResult);
                                });

                        return deferred.promise;
                    },
                    updatePaymentAmount: function (bac, amount) {
                        var deferred = $q.defer();
                        var existingPaymentMethod = commonPaymentMethodServices.paymentMethods;

                        var updateAccount = {
                            "billingAccount": bac || primaryContactService.primaryContactBillingAccount,
                            "paymentMethod": existingPaymentMethod.paymentMethod,
                            "email": stateService.get("contactEmail"),
                            "billFrequency": existingPaymentMethod.billFrequency,
                            "monthlyPaymentPlanAmount": {
                                "amount": amount,
                                "currencyCode": "GBP"
                            }
                        };
                        
                        //updateAccount["bankDetails"] = existingPaymentMethod.bankDetails;
                        
                        sendRequest(updateAccount).then(function (results) {
                            var res = {
                                email: updateAccount.email,
                                isNextBillDateDue: false,
                                amount: amount
                            };
                            if (results.length > 1) {
                                res.isNextBillDateDue = commonPaymentMethodServices.isNextBillDateDue(results[1], 3);
                            }
                            deferred.resolve(res);
                        },
                                function (errorResult) {
                                    deferred.reject(errorResult);
                                });

                        return deferred.promise;
                    }
                };
            }]);