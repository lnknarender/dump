/**
 * Created by Andrew on 28/01/2016.
 */

(function () {

    angular.module('editPaymentMethodController').controller('editCcraEditCardDetailsCtrl', EditCcraEditCardDetailsController);

    EditCcraEditCardDetailsController.$inject = ['$route', 'thistleService', 'urlService', 'errorLoggingService'];

    function EditCcraEditCardDetailsController ($location, thistleService, urlService, errorLoggingService) {
        var vm = this;
        vm.userType = connection.userType;

        vm.thistleIframeHeight = constants.THISTLE_IFRAME_HEIGHT;

        vm.waitingForPageToLoad = true;

        vm.encodedCardDetailsXml = "";

        var thistleCardDetailsRequest = thistleService.getCardManagementRequest(constants.EDIT_CCRA_CARD_DETAILS_SUCCESS_URL, constants.EDIT_CCRA_CARD_DETAILS_FAILED_URL, constants.EDIT_CCRA_CARD_DETAILS_CANCELLED_URL);

        thistleCardDetailsRequest.then(function (thistleResult) {
            vm.thistleUrl = thistleResult.thistleUrl;
            vm.encodedCardDetailsXml = thistleResult.encodedXml;

            vm.waitingForPageToLoad = false;
        }, function (errorResult) {
            console.log(errorLoggingService.errorToString(errorResult));
            $location.path(urlService.getErrorUrl());
        });

    }

})();

(function () {

    angular.module('editPaymentMethodController').controller('editCcraEditCardDetailsFailedCtrl', EditCcraCardDetailsFailedController);

    EditCcraCardDetailsFailedController.$inject = ['$location', 'commonPaymentMethodServices'];

    function EditCcraCardDetailsFailedController ($location, commonPaymentMethodServices) {
        var vm = this;
        vm.userType = connection.userType;

        vm.tryAgainButton = function() {
            $location.path('/ccraeditcarddetails');
        }

    }

})();

(function () {

    angular.module('editPaymentMethodController').controller('editCcraUseADifferentCardCtrl', EditCcraUseADifferentCardController);

    EditCcraUseADifferentCardController.$inject = ['$location', 'thistleService', 'urlService', 'errorLoggingService'];

    function EditCcraUseADifferentCardController ($location, thistleService, urlService, errorLoggingService) {
        var vm = this;
        vm.userType = connection.userType;

        vm.thistleIframeHeight = constants.THISTLE_IFRAME_HEIGHT;

        vm.waitingForPageToLoad = true;

        vm.encodedCardDetailsXml = "";

        var thistleValidateCardRequest = thistleService.getValidateCardRequest({}, constants.EDIT_CCRA_DIFFERENT_CARD_SUCCESS_URL, constants.EDIT_CCRA_DIFFERENT_CARD_FAILED_URL, constants.EDIT_CCRA_DIFFERENT_CARD_CANCEL_URL);

        thistleValidateCardRequest.then(function (thistleResult) {
            vm.thistleUrl = thistleResult.thistleUrl;
            vm.encodedCardDetailsXml = thistleResult.encodedXml;

            vm.waitingForPageToLoad = false;
        }, function (errorResult) {
            console.log(errorLoggingService.errorToString(errorResult));
            $location.path(urlService.getErrorUrl());
        });

    }

})();

(function () {

    angular.module('editPaymentMethodController').controller('editCcraUseADifferentCardFailedCtrl', EditCcraUseADifferentFailedController);

    EditCcraUseADifferentFailedController.$inject = ['$location', 'commonPaymentMethodServices'];

    function EditCcraUseADifferentFailedController ($location, commonPaymentMethodServices) {
        var vm = this;
        vm.userType = connection.userType;

        vm.tryAgainButton = function() {
            $location.path('/ccrauseadifferentcard');
        }

    }

})();


(function () {

    angular.module('editPaymentMethodController').controller('editCcraSuccessCtrl', EditCcraSuccessController);

    EditCcraSuccessController.$inject = ['$location', '$route', '$routeParams', 'commonPaymentMethodServices', 'editCcraPaymentMethodService', 'utilityService', 'errorLoggingService'];

    function EditCcraSuccessController ($location, $route, $routeParams, commonPaymentMethodServices, editCcraPaymentMethodService, utilityService, errorLoggingService) {
        var vm = this;
        vm.userType = connection.userType;

        if (vm.userType === 'customer') {
            vm.email = utilityService.getCustomerEmailAddress($routeParams.accKey, errorLoggingService);
        } else {
            vm.email = commonPaymentMethodServices.primaryContactDetails.email;
        }

        vm.paymentMethods = commonPaymentMethodServices.paymentMethods;
        vm.billCycle = utilityService.getBillCycle(vm.paymentMethods.nextBillDate);

        vm.ccra = editCcraPaymentMethodService;

        vm.ccra.cardupdated = {
            cardType: $routeParams.cardType,
            cardHolder: $routeParams.cardHolderName,
            cardNumber: $routeParams.cardNumber,
            house: $routeParams.cardHolderAddress,
            postcode: $routeParams.cardHolderPostCode,
            expiry: $routeParams.expiryDate,
            paymentInstrumentRef: $routeParams.paymentInstrumentRef
        };

        if ($routeParams.updateaccount === 'true') {

            var updateAccountRequest = commonPaymentMethodServices.updateAccount({
                "billFrequency": vm.paymentMethods.billFrequency,
                "paymentMethod": constants.PAYMENT_METHOD_CCRA,
                "email": vm.email,
                "paymentInstrumentReference": $routeParams.paymentInstrumentRef,
                "paymentReferenceId": $routeParams.paymentReferenceId
            });

            vm.waitingForUpdateAccount = true;

            updateAccountRequest.then(function (result) {
                vm.error = false;
                vm.waitingForUpdateAccount = false;
            }, function (errorResult) {
                vm.error = true;
                vm.waitingForUpdateAccount = false;
            });

        }

        vm.tryAgain = function() {
            $route.reload();
        }

        vm.backToBT = function() {
            $location.path('/viewPaymentMethod');
        };

    }


})();

