/**
 * Created by Andrew on 28/01/2016.
 */
angular.module('editCcraPaymentMethod', []);
