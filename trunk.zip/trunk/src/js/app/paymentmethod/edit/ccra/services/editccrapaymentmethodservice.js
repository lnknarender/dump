/**
 * Created by Andrew on 28/01/2016.
 */


setupPaymentMethodServices.factory('editCcraPaymentMethodService', ['$q', 'ajaxServiceWithToken', 'stateService', '$routeParams', 'utilityService', 'setupPaymentMethodUrlService', 'commonPaymentMethodServices', function ($q, ajaxServiceWithToken, stateService, $routeParams, utilityService, setupPaymentMethodUrlService, commonPaymentMethodServices) {

    return {
    }

}]);
