/**
 * Created by Andrew on 26/01/2016.
 */

//  Do not create a new instance of editPaymentMethodController but bind to an existing instance

var editPaymentMethodController = angular.module('editPaymentMethodController');

editPaymentMethodController.controller('editPaymentDayWbddCtrl', ['$scope', '$location', '$routeParams', 'urlService', 'errorLoggingService', 'utilityService', 'commonPaymentMethodServices', 'primaryContactService', 'editPaymentMethodWbddPaymentDayService', 'stateService', '$timeout', 'editPaymentMethodWbddCommonService',
    function ($scope, $location, $routeParams, urlService, errorLoggingService, utilityService, commonPaymentMethodServices, primaryContactService, editPaymentMethodWbddPaymentDayService, stateService, $timeout, editPaymentMethodWbddCommonService) {


        $scope.loading= true;

        var paymentMethodObject = $scope.existingPaymentMethod = commonPaymentMethodServices.paymentMethods,
            paymentMethod = $scope.newSetupPaymentMethod = commonPaymentMethodServices.editPaymentMethodAction;

        editPaymentMethodWbddPaymentDayService.originalPaymentDay = {
            "paymentDay": paymentMethodObject.paymentDay,
            "billCycle": paymentMethodObject.nextBillDate !== null ? paymentMethodObject.nextBillDate.split("-")[2] : null
        };

        // This variable will hold the current payment day and hence not change on the display when
        // the user changes the payment day in date picker
        $scope.currentPaymentDay = utilityService.getOrdinalNumber(paymentMethodObject.paymentDay);

        $scope.selectedPaymentDay = utilityService.getOrdinalNumber(paymentMethodObject.paymentDay);
        editPaymentMethodWbddCommonService.frequencyOption = paymentMethodObject.billFrequency;
        var paymentDayResponse = editPaymentMethodWbddCommonService.getPaymentDays();
        paymentDayResponse.then(function (paymentDayResult) {
            editPaymentMethodWbddCommonService.setDefaultOption($scope);
            $scope.paymentDaysOption = editPaymentMethodWbddPaymentDayService.getPaymentDays(paymentDayResult, paymentMethodObject.paymentDay, paymentMethodObject.billCycle);
            $scope.editWbdd = editPaymentMethodWbddCommonService.getPanelShow(paymentMethod, $scope);
            $scope.loading = false;
        }, function (errorResult) {
            console.log(errorLoggingService.errorToString(errorResult));
            $location.path(urlService.getErrorUrl());
        });
        $scope.onPaymentDaySelect = function (paymentDay, billCycle, id, hyperlink, event) {
            if (!hyperlink) {
                event.preventDefault();
                return false;
            }
            editPaymentMethodWbddPaymentDayService.onPaymentDaySelect(paymentDay, id);
            editPaymentMethodWbddPaymentDayService.modifiedPaymentDay = {
                "paymentDay": paymentDay,
                "billCycle": billCycle
            },
                $scope.selectedPaymentDay = editPaymentMethodWbddCommonService.selectedPaymentDay = utilityService.getOrdinalNumber(paymentDay);
            $scope.editWbdd.paymentDayOption = true;
        };

        $scope.saveChanges = function () {
            editPaymentMethodWbddPaymentDayService.paymentDay = editPaymentMethodWbddPaymentDayService.modifiedPaymentDay.paymentDay;
            editPaymentMethodWbddPaymentDayService.billCycle = editPaymentMethodWbddPaymentDayService.modifiedPaymentDay.billCycle;
            $location.path('/editPaymentMethodWbddSuccess');
        };

        $scope.cancelChanges = function () {
            $location.path('/viewPaymentMethod');
        }
    }]);
