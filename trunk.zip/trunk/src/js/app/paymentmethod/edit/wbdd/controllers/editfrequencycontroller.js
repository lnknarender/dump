/**
 * Created by Andrew on 26/01/2016.
 */

//  Do not create a new instance of editPaymentMethodController but bind to an existing instance
var editPaymentMethodController = angular.module('editPaymentMethodController');
editPaymentMethodController.controller('editFrequencyWbddCtrl', ['$scope', '$location', '$routeParams','urlService', 'errorLoggingService', 'utilityService',  'commonPaymentMethodServices','primaryContactService','editPaymentMethodWbddCommonService','stateService','$timeout','editPaymentMethodWbddFrequencyService',
    function ($scope, $location,$routeParams, urlService, errorLoggingService, utilityService,  commonPaymentMethodServices,primaryContactService,editPaymentMethodWbddCommonService,stateService,$timeout,editPaymentMethodWbddFrequencyService) {

        var paymentMethodObject =$scope.existingPaymentMethod =commonPaymentMethodServices.paymentMethods,
            paymentMethod =$scope.newSetupPaymentMethod=commonPaymentMethodServices.editPaymentMethodAction;
        $scope.editWbdd= editPaymentMethodWbddCommonService.getPanelShow(paymentMethod,$scope);
        editPaymentMethodWbddCommonService.setDefaultOption($scope);
        var eligibleFrequency=editPaymentMethodWbddFrequencyService.eligibleFrequencyList(paymentMethodObject);
        angular.extend($scope,{
            "selectedFrequency":eligibleFrequency.selectedFrequency,
            "eligibleFrequency":eligibleFrequency.eligibleFrequency,
            "termAndCondtionChecked": false
        });
        $scope.frequencySelected= function(frequency){
            $scope.frequencyName= constants[frequency];

            $scope.termAndCondtionChecked = ($scope.existingPaymentMethod.billFrequency === frequency) ? false : true;

            $scope.selectedFrequency= editPaymentMethodWbddCommonService.selectedFrequency = editPaymentMethodWbddFrequencyService.modifiedFrequency = frequency;
            editPaymentMethodWbddFrequencyService.setFrequencyOption(frequency);
        };

        $scope.saveChanges=function(){
            editPaymentMethodWbddFrequencyService.frequencyOption =$scope.selectedFrequency;
            $location.path('/editPaymentMethodWbddSuccess');
        };
        $scope.cancelChanges=function(){
            $location.path('/viewPaymentMethod');
        };

    }]);