angular.module('editPaymentMethodController', []);
