var editPaymentMethodServices = angular.module('editPaymentMethodServices', []);

editPaymentMethodServices.factory('editPaymentMethodWbddCommonService', ['$q', 'ajaxServiceWithToken', 'stateService', 'utilityService', 'commonPaymentMethodUrlService', 
    function ($q, ajaxServiceWithToken, stateService, utilityService, commonPaymentMethodUrlService) {

    return {
        getPaymentDays: function () {
            var deferred = $q.defer(), paymentDays = stateService.get(constants.STATE_SERVICE_PAYMENT_DAYS);

            if (paymentDays) {
                //  Already have a payment account so return it
                deferred.resolve(paymentDays);
            }
            else {
                var url = commonPaymentMethodUrlService.getPaymentDaysUrl();

                var changeDetialsResponse = ajaxServiceWithToken.doGet(url, {});

                changeDetialsResponse.then(function (result) {
                        stateService.set(constants.STATE_SERVICE_PAYMENT_DAYS, result);
                        deferred.resolve(result);
                    },
                    function (errorResult) {
                        deferred.reject(errorResult);
                    });
            }

            return deferred.promise;
        },
        getUpdateAccountWithPaymentDay: function (updateAccount) {
            updateAccount["paymentDay"] = this.paymentDay;
            updateAccount["billCycle"] = this.billCycle;
            updateAccount["billFrequency"] = this.frequencyOption;

        },
        getUpdateAccountWithFrequency: function (updateAccount) {
            updateAccount["billFrequency"] = this.frequencyOption;
        },
        getUpdateAccount: function (updateAccount, frequency, paymentDay) {

            if (frequency) {
                this.getUpdateAccountWithFrequency(updateAccount, frequency);
            } else if (paymentDay) {
                this.getUpdateAccountWithPaymentDay(updateAccount, paymentDay);
            }

        },
        updateAccountObject: function (routeParams, email, frequency, paymentDay, paymentMethod, billCycle, paymentInstrumentId, cardType) {

            var updateAccount = {};

            if (paymentInstrumentId !== null) {
                updateAccount = {
                    "paymentMethod": paymentMethod,
                    "email": email,
                    "paymentDay": paymentDay,
                    "billCycle": billCycle,
                    "paymentInstrumentReference": paymentInstrumentId
                };
            }
            else {
                updateAccount = {
                    "paymentMethod": paymentMethod,
                    "email": email,
                    "paymentDay": paymentDay,
                    "billCycle": billCycle
                };
            }
            this.getUpdateAccount(updateAccount, frequency, paymentDay);

            return updateAccount;
        },
        showPanel: function (frequency, paymentDays, paymentDayOption, paymentDayOptionWarning, bankDetails) {
            return{
                "frequency": frequency,
                "paymentDays": paymentDays,
                "paymentDayOption": paymentDayOption,
                "paymentDayOptionWarning": paymentDayOptionWarning,
                "bankDetails": bankDetails
            };

        },
        getPanelShow: function (editPanel, scope) {
            if (editPanel === constants.PAYMENT_DAY) {
                return  this.showPanel(false, true, false, false, false);
            } else if (editPanel === constants.BANKDETAILS) {
                return  this.showPanel(false, false, false, false, true);
            } else if (editPanel === constants.FREQUENCY) {
                return  this.showPanel(true, false, false, false, false);
            }
        },
        setDefaultOption: function (scope) {
            angular.extend(scope, {
                termAndCondtionChecked: false,
                bankDetails: {"sortCode": {}},
                signatoryYes: true,
                signatoryNo: true,
                validBankAccount: false

            });

        },
        showWbddSuccessPanel: function (changePaymentMethod, scope, routeParams) {
            scope.editWbddSuccess = {};
            if (changePaymentMethod === constants.PAYMENT_DAY) {
                scope.editWbddSuccess.paymentDay = true;
                scope.selectedPaymentDay = this.selectedPaymentDay;
            } else if (changePaymentMethod === constants.BANKDETAILS) {
                var soleSignatory = this.soleSignatory === 'yes' ? true : false;
                if (soleSignatory) {
                    utilityService.getBankDetailsOnly(scope, this.bankDetails);
                    scope.editWbddSuccess.bankDetails = true;
                } else {
                    utilityService.getAddressInformation(scope, this.existingPaymentMethod.address);
                    scope.editWbddSuccess.paperMandate = true;
                }

            } else if (changePaymentMethod === constants.FREQUENCY) {
                scope.editWbddSuccess.frequency = true;
                scope.selectedFrequency = constants[this.selectedFrequency];
            }
        }
    };
}]);

editPaymentMethodServices.factory('editPaymentMethodWbddFrequencyService', ['utilityService', 'editPaymentMethodWbddCommonService', 
    function (utilityService, editPaymentMethodWbddCommonService) {

    return {
        getSelectedFrequency: function (scope, frequency) {
            this.selectedFrequency = utilityService.isEmptyObject(frequency) ? frequency : scope.selectedFrequency;
        },
        updateFrequencyDetails: function (routeParams, email, paymentMethod, paymentDay, billCycle, paymentInstrumentReference, cardType) {
            editPaymentMethodWbddCommonService.frequencyOption = this.frequencyOption;
            return  editPaymentMethodWbddCommonService.updateAccountObject(routeParams, email, true, paymentDay, paymentMethod, billCycle, paymentInstrumentReference, cardType);
        },
        eligibleFrequencyList: function (paymentMethod) {
            var displayList = {};

            //  The current payment method will not be in the eligibility list so add it here
            //  This function should be refactored as it is over complicated
            displayList[constants.PAYMENT_METHOD_DIRECT_DEBIT] =
            {
                "frequency": paymentMethod.billFrequency
            };

            angular.forEach(paymentMethod.eligiblePaymentMethods, function (eligibleFrequency) {
                if (paymentMethod.paymentMethod === constants.PAYMENT_METHOD_DIRECT_DEBIT ||
                    paymentMethod.paymentMethod === constants.PAYMENT_METHOD_CHEQUE_CASH ||
                    paymentMethod.paymentMethod === constants.PAYMENT_METHOD_CCRA) {
                    var pmObject = displayList[eligibleFrequency.paymentMethod];
                    if (pmObject === undefined) {
                        displayList[eligibleFrequency.paymentMethod] =
                        {
                            "frequency": eligibleFrequency.frequency
                        };
                    } else {
                        pmObject.frequency = [pmObject.frequency, eligibleFrequency.frequency].join(",");
                    }
                }


            });
            displayList.selectedFrequency = paymentMethod.billFrequency;
            return this.eligibleFrequency(displayList[constants.PAYMENT_METHOD_DIRECT_DEBIT].frequency, displayList.selectedFrequency);
        },
        eligibleFrequency: function (eligibleFrequency, defaultFrequency) {
            var eligibleFrequencyList = [];
            angular.forEach(eligibleFrequency.split(","), function (frequency) {
                eligibleFrequencyList.push({
                    "name": frequency,
                    "displayName": constants[frequency],
                    "selected": defaultFrequency === frequency ? "btn-main-selected" : "btn-main-unselected",
                    "iconTick": defaultFrequency === frequency ? "icon-tick" : ""
                });
            });
            return  {
                "selectedFrequency": defaultFrequency,
                "eligibleFrequency": eligibleFrequencyList
            };
        },
        setFrequencyOption: function (frequency) {
            var frequencyBtns = $("[id*='frequency_']");
            angular.forEach(frequencyBtns, function (_frequency) {
                var _this = $(_frequency), id = _this.attr('id');
                utilityService.onSelectionButton(_this, _this.children(), id, "frequency_" + frequency);

            })
        }
    };
}]);
editPaymentMethodServices.factory('editPaymentMethodWbddPaymentDayService', ['utilityService', 'editPaymentMethodWbddCommonService', 
    function (utilityService, editPaymentMethodWbddCommonService) {
    return {
        getSelectedPaymentDay: function (scope, paymentDay) {
            this.selectedpaymentDay = utilityService.isEmptyObject(paymentDay) ? paymentDay : scope.paymentDay;
        },
        pushPaymentObject: function (paymentDay, billCycle, active, id, hyperlink, paymentDayA, paymentDayLi) {
            return {
                "paymentDay": paymentDay,
                "billCycle": billCycle,
                "active": active,
                "id": id,
                "hyperlink": hyperlink,
                "paymentDayA": paymentDayA,
                "paymentDayLi": paymentDayLi
            };
        },
        getPaymentDays: function (paymentDays, paymentDay, billCycle) {
            var _paymentDays = [], _compair = [];

            _paymentDays.push(this.pushPaymentObject(paymentDay, billCycle, "active", "paymentDay" + paymentDay, false, "", paymentDay));
            _compair.push(paymentDay);
            var _this = this;
            angular.forEach(paymentDays.billCycles, function (_paymentDay) {
                _paymentDays.push(_this.pushPaymentObject(_paymentDay.paymentDay, _paymentDay.billCycle, "", "paymentDay" + _paymentDay.paymentDay, true, _paymentDay.paymentDay, ""));
                _compair.push(_paymentDay.paymentDay);
            });

            _compair.sort(function (a, b) {
                return a - b;
            });

            var min = Math.min.apply(Math, _compair), max = Math.max.apply(Math, _compair);
            for (; min < max; min++) {

                if (_compair.indexOf(min) === -1) {
                    _paymentDays.push(this.pushPaymentObject(min, min, "disabled", "paymentDay" + min, false, "", min));
                }
            }

            _paymentDays.sort(function (a, b) {
                return a.paymentDay - b.paymentDay;
            });
            return _paymentDays;
        },
        updatePaymentDayDetails: function (routeParams, email, paymentMethod) {
            editPaymentMethodWbddCommonService.paymentDay = this.paymentDay;
            editPaymentMethodWbddCommonService.billCycle = this.billCycle;
            return  editPaymentMethodWbddCommonService.updateAccountObject(routeParams, email, false, true, paymentMethod, null);
        },
        onPaymentDaySelect: function (paymentDay, id) {
            var activeElement = angular.element('.select-date-container ul li.active'),
                activeElementChild = activeElement.children('a'),
                selectedElement = angular.element('#' + id),
                selectedElementChild = selectedElement.children('a');

            activeElement.removeClass("active");
            if (activeElementChild.length === 0) {
                var addChild = angular.element('<a href="javascript:void(0)"></a>');
                addChild.text(activeElement.text() || activeElementChild.text());
                activeElement.html(addChild);
            } else {
                activeElementChild.show();
                activeElementChild.val(activeElement.text());
            }


            selectedElement.addClass("active");
            selectedElement.text(paymentDay);
            selectedElementChild.hide();
        }
    };
}]);