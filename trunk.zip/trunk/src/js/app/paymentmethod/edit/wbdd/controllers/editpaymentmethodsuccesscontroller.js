/**
 * Created by Andrew on 27/01/2016.
 */

//  Do not create a new instance of editPaymentMethodController but bind to an existing instance
var editPaymentMethodController = angular.module('editPaymentMethodController');

editPaymentMethodController.controller('editPaymentMethodsWbddSuccessCtrl', ['$scope', 'stateService', '$routeParams', 'editPaymentMethodWbddCommonService', 'commonPaymentMethodServices', 'editPaymentMethodWbddPaymentDayService', 'editPaymentMethodWbddFrequencyService', 'utilityService', '$location',
    function ($scope, stateService, $routeParams, editPaymentMethodWbddCommonService, commonPaymentMethodServices, editPaymentMethodWbddPaymentDayService, editPaymentMethodWbddFrequencyService, utilityService, $location) {

        var changePaymentMethod = commonPaymentMethodServices.editPaymentMethodAction;

        var updateAccountObject;

        var paymentMethod = commonPaymentMethodServices.paymentMethods.paymentMethod;

        var email = stateService.get("contactEmail");

        scope = $scope;

        $scope.email = email;

        $scope.backToMyBt= function(){
            return connection.backToMyBtUrl;
        };

        $scope.backToViewPaymentMethod= function(){
            $location.path('/viewPaymentMethod');
        };

        $scope.isDisplayYellowAlertBillWithinNextTwoDays = function() {

            return commonPaymentMethodServices.isNextBillDateDue(commonPaymentMethodServices.paymentMethods.nextBillDate||commonPaymentMethodServices.nextBillDate, 2);
        };

        editPaymentMethodWbddCommonService.existingPaymentMethod = commonPaymentMethodServices.paymentMethods;

        if (changePaymentMethod === constants.PAYMENT_DAY) {
            updateAccountObject = editPaymentMethodWbddPaymentDayService.updatePaymentDayDetails($routeParams, email, paymentMethod);
        }
        else if (changePaymentMethod === constants.FREQUENCY) {

            var paymentDay =  commonPaymentMethodServices.paymentMethods.paymentDay;
            var billCycle = utilityService.getBillCycle(commonPaymentMethodServices.paymentMethods.nextBillDate||commonPaymentMethodServices.nextBillDate);

            var paymentInstrumentId = null;
            var cardType = null;
            if (commonPaymentMethodServices.paymentMethods.paymentMethod === constants.PAYMENT_METHOD_CCRA) {

                paymentInstrumentId = commonPaymentMethodServices.paymentMethods.paymentInstrumentIdentifier;
                cardType = commonPaymentMethodServices.paymentMethods.cardDetails.type;
            }

            updateAccountObject = editPaymentMethodWbddFrequencyService.updateFrequencyDetails($routeParams, email, paymentMethod, paymentDay, billCycle, paymentInstrumentId, cardType);
        }

        var updateAccountResponse = commonPaymentMethodServices.updateAccount(updateAccountObject);
        updateAccountResponse.then(function (result) {
            editPaymentMethodWbddCommonService.showWbddSuccessPanel(changePaymentMethod, $scope, $routeParams);


        }, function (errorResult) {
            scope.editWbddSuccess = {};
            scope.editWbddSuccess.failed = true;
        });
    }]);