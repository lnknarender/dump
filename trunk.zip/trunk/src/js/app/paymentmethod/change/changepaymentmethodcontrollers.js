/**
 * Created by Andrew on 11/12/2015.
 */
var changePaymentMethodController = angular.module('changePaymentMethodController', []);

/**
 * Controller that handles the change payment method to cash & cheque
 */
changePaymentMethodController.controller('changePaymentMethodCashChequeCtrl', ['$scope', 'stateService', '$location', 'changePaymentMethodServices', 'commonPaymentMethodServices', 'urlService', 'errorLoggingService', '$timeout', 'setupPaymentMethodWbddService',
    function ($scope, stateService, $location, changePaymentMethodServices, commonPaymentMethodServices, urlService, errorLoggingService, $timeout, setupPaymentMethodWbddService) {

        $scope.loading = true;
        $scope.userType = connection.userType;

        var viewPaymentMethodResponse = commonPaymentMethodServices.getAllRequest($scope.userType);
        viewPaymentMethodResponse.then(function (result) {
            $scope.loading = false;

            $scope.paymentMethods = commonPaymentMethodServices.paymentMethods = result.viewPaymentMethods;
            $scope.primaryContactDetails = commonPaymentMethodServices.primaryContactDetails = result.primaryContactDetails;
            $scope.accountHistory = result.accountHistory;

            if ($scope.userType === constants.AGENT) {
                stateService.set("contactEmail", $scope.primaryContactDetails.email);
            }

            $scope.paymentMethodCount = +false;
            $scope.eligiblePaymentMethod = changePaymentMethodServices.displayEligiblePaymentMethods($scope.paymentMethods, $scope);

            $timeout(function () {
                if ($scope.paymentMethodCount === 1) {
                    changePaymentMethodServices.defaultPaymentMethodClickAction(($scope.eligiblePaymentMethod.mpp !== undefined && $scope.eligiblePaymentMethod.mpp.name) || ($scope.eligiblePaymentMethod.ccra !== undefined && $scope.eligiblePaymentMethod.ccra.name) || ($scope.eligiblePaymentMethod.wbdd !== undefined && $scope.eligiblePaymentMethod.wbdd.name));
                }
            });

            var changeDetailsResponse = setupPaymentMethodWbddService.getPaymentMethodChangeDetails();
            changeDetailsResponse.then(function (changeSettingResult) {

                var viewPaymentMethodsResponse = commonPaymentMethodServices.getAllViewPaymentRequest($scope.userType);

                viewPaymentMethodsResponse.then(function (viewPaymentMethodsResponseResult) {

                    var allowedToSetPaymentMethod = changeSettingResult.allowedToSetPaymentMethod;
                    var outstandingBalance = 0;
                    var isCashOrCheque = false;

                   if(viewPaymentMethodsResponseResult.viewPaymentMethods.paymentMethod === constants.PAYMENT_METHOD_CHEQUE_CASH){
                        outstandingBalance = changeSettingResult.blockingBalance.amount;
                        isCashOrCheque = true;
                    }
                    else{
                        outstandingBalance = changeSettingResult.balance.amount;
                    }

                    $scope.paymentStatus = setupPaymentMethodWbddService.getValidateSetting(allowedToSetPaymentMethod,outstandingBalance, isCashOrCheque);

                },
                function (errorResult) {
                    console.log(errorLoggingService.errorToString(errorResult));
                    $location.path(urlService.getErrorUrl());
                });

            }, function (errorResult) {
                console.log(errorLoggingService.errorToString(errorResult));
                $location.path(urlService.getErrorUrl());
            });


            //  Determine whether to display the change history section.
            $scope.newAccountHistory = changePaymentMethodServices.getAccountHistoryDetails($scope.accountHistory);
            $scope.displayAccountHistory = changePaymentMethodServices.isDisplayChangeHistory($scope.userType, $scope.newAccountHistory);
        }, function (errorResult) {
            $scope.loading = false;

            console.log(errorLoggingService.errorToString(errorResult));
            $location.path(urlService.getErrorUrl());
        });

        angular.extend($scope, {
            mppClick: function () {
                changePaymentMethodServices.mppClickAction();
            },
            ccraClick: function () {
                changePaymentMethodServices.ccraClickAction();
            },
            wbddClick: function () {
                changePaymentMethodServices.wbddClickAction();
            },
            monthlyPaymentPlanButtonAction: function (type, name) {
                /**
                 *  Handle click change to Monthly payment plan (MPP)button
                 */
                commonPaymentMethodServices.newSetupPaymentMethod = $scope.eligiblePaymentMethod[name];
                commonPaymentMethodServices.newPaymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
                commonPaymentMethodServices.accountHistory = $scope.accountHistory;
                if (type === constants.PAYMENT_METHOD_C_CHANGE) {
                    $location.path('/setupmpp');
                } else if (type === constants.PAYMENT_METHOD_C_CANCEL) {
                    $location.path('/cancelmpp');
                }
            },
            continuousCardRecurringButtonAction: function (type, name) {
                /**
                 *  Handle click change to continuous card recurring authority (CCRA) button
                 */
                commonPaymentMethodServices.newSetupPaymentMethod = $scope.eligiblePaymentMethod[name];
                commonPaymentMethodServices.newPaymentMethod = constants.PAYMENT_METHOD_CCRA;
                commonPaymentMethodServices.accountHistory = $scope.accountHistory;
                if (type === constants.PAYMENT_METHOD_C_CHANGE) {
                    $location.path('/ccrasetup');
                } else if (type === constants.PAYMENT_METHOD_C_CANCEL) {
                    $location.path('/ccracancel');
                }
            },
            wholeBillDirectDebitButtonAction: function (type, name) {
                /**
                 *  Handle click change to whole bill direct debit (WBDD) button
                 */
                commonPaymentMethodServices.newSetupPaymentMethod = $scope.eligiblePaymentMethod[name];
                commonPaymentMethodServices.newPaymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;
                commonPaymentMethodServices.accountHistory = $scope.accountHistory;
                if (type === constants.PAYMENT_METHOD_C_CHANGE) {
                    $location.path('/setupWbddPaymentMethod');
                } else if (type === constants.PAYMENT_METHOD_C_CANCEL) {
                    $location.path('/cancelwbdd');
                }

            },
            clickStayOnCurrentPaymentMethod: function () {
                $location.path('/viewPaymentMethod');
            },
            viewPaymentMethod: function () {
                $location.path('/viewPaymentMethod');
            }
        });
        $(window).resize(function () {
            changePaymentMethodServices.windowResize(window);

        });

    }
]);
