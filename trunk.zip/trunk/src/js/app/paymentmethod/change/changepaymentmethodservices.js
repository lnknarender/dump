/**
 * Created by Andrew on 10/12/2015.
 */

var changePaymentMethodServices = angular.module('changePaymentMethodServices',[]);

changePaymentMethodServices.factory('changePaymentMethodServices', ['stateService','utilityService','commonPaymentMethodServices',
    function(stateService,utilityService,commonPaymentMethodServices) {
        return {

            /**
             * Determine whether the customer is eligible for monthly payment plan
             * @param paymentMethods Payment methods
             * @returns {boolean} Returns true when the customer is eligible for monthly payment plan
             */
            isEligibleForMpp: function (paymentMethods) {

                if (paymentMethods != undefined && paymentMethods.eligiblePaymentMethods != undefined) {

                    var foundMpp = false;

                    angular.forEach(paymentMethods.eligiblePaymentMethods, function (value) {

                        if (value.paymentMethod != undefined && value.paymentMethod == constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN) {

                            foundMpp = true;
                        }
                    });
                }

                return foundMpp;
            },

            /**
             * Determine whether the customer is eligible for CCRA
             * @param paymentMethods Payment methods
             * @returns {boolean} Returns true when the customer is eligible for CCRA
             */
            isEligibleForCCra: function (paymentMethods) {

                if (paymentMethods != undefined && paymentMethods.eligiblePaymentMethods != undefined) {

                    var foundCcra = false;

                    angular.forEach(paymentMethods.eligiblePaymentMethods, function (value) {

                        if (value.paymentMethod != undefined && value.paymentMethod == constants.PAYMENT_METHOD_CCRA) {

                            foundCcra = true;
                        }
                    });
                }

                return foundCcra;
            },

            /**
             * Determine whether the customer is eligible for whole bill direct debit (WBDD)
             * @param paymentMethods Payment methods
             * @returns {boolean} Returns true when the customer is eligible for WBDD
             */
            isEligibleForWbdd: function (paymentMethods) {

                if (paymentMethods != undefined && paymentMethods.eligiblePaymentMethods != undefined) {

                    var foundWbdd = false;

                    angular.forEach(paymentMethods.eligiblePaymentMethods, function (value) {

                        if (value.paymentMethod != undefined && value.paymentMethod == constants.PAYMENT_METHOD_DIRECT_DEBIT) {

                            foundWbdd = true;
                        }
                    });
                }

                return foundWbdd;
            },

            /**
             * Determine whether the customer is eligible for more than one payment excluding the current payment type (i.e. cash/cheque).
             * @param paymentMethods Payment methods
             * @returns {boolean} Returns true when customer is eligible for more than one payment
             */
            isCashChequeCustomerEligibleForMoreThanOnePaymentMethod: function(paymentMethods) {

                var numOfEligible = Number(this.isEligibleForMpp(paymentMethods)) + Number(this.isEligibleForCCra(paymentMethods)) + Number(this.isEligibleForWbdd(paymentMethods));

                if (numOfEligible > 1) {

                    return true;

                }

                return false;
            },
            checkEligbilityPaymentMethods:function(paymentMethods){
                if(angular.isDefined(paymentMethods)&& angular.isDefined(paymentMethods.eligiblePaymentMethods)){
                    var currentPM=paymentMethods.paymentMethod,paymentList=[];
                    
                    angular.forEach(paymentMethods.eligiblePaymentMethods, function (eligiblePaymentMethod) {
                        if(!utilityService.isEqual(eligiblePaymentMethod.paymentMethod,currentPM)){
                            
                            if(utilityService.isEqual(constants.PAYMENT_METHOD_CHEQUE_CASH,eligiblePaymentMethod.paymentMethod)){
                                paymentList.push({
                                                'name':currentPM,
                                                'type':constants.CANCEL_PAYMENT_METHOD,
                                                "frequency":eligiblePaymentMethod.frequency
                                              });  
                            }else{
                              paymentList.push({
                                                'name':eligiblePaymentMethod.paymentMethod,
                                                'type':constants.CHANGE_PAYMENT_METHOD,
                                                "frequency":eligiblePaymentMethod.frequency
                                              });   
                            }
                        }
                      
                    });     
                  return paymentList; 
                }
            },
            /**
             *  Determine whether the customer is eligible for more than one payment
             *  excluding the current payment type (i.e. cash/cheque).
             *  if cash/cheque exists then current payment method is Cancel
             */
            displayEligiblePaymentMethods:function(paymentMethods,scope){
                var paymentList = this.checkEligbilityPaymentMethods(paymentMethods),displayList={},view=commonPaymentMethodServices.getPaymentMethodForView(),len=0;
                
                //creation of Eligible payment method to display
                angular.forEach(paymentList, function (eligiblePaymentMethod) {
                    var property =[view[eligiblePaymentMethod.type],view[eligiblePaymentMethod.name]].join(".");
                    scope.paymentMethodCount= scope.paymentMethodCount+1;
                    
                    var pmObject = displayList[view[eligiblePaymentMethod.name]];
                    
                    if(pmObject===undefined){
                          len=len+1;
                         displayList[view[eligiblePaymentMethod.name]]=
                             {
                                "name":view[eligiblePaymentMethod.name],
                                "newPaymentMethodName":eligiblePaymentMethod.name,
                                "paymentMethod":property,
                                "type":view[eligiblePaymentMethod.type],
                                "arrowClass":"change-payment-1",
                                "frequency":eligiblePaymentMethod.frequency
                            };
                    }else{
                      pmObject.frequency= [pmObject.frequency,eligiblePaymentMethod.frequency].join(",");
                    }
                   
                });
                
                angular.forEach(displayList, function (list) {
                   if(len===2 && (list.name===constants.PAYMENT_METHOD_C_CCRA ||list.name===constants.PAYMENT_METHOD_C_DD)){
                        displayList[list.name]["arrowClass"]="change-payment-2";
                    }else if(len===3){
                        if(list.name===constants.PAYMENT_METHOD_C_DD){
                             displayList[list.name]["arrowClass"]="change-payment-3";
                        }else if(list.name===constants.PAYMENT_METHOD_C_CCRA){
                            displayList[list.name]["arrowClass"]="change-payment-2"; 
                        }
                    }
                       
                   
                });
                
               return displayList;
        
    },
    defaultPaymentMethodClickAction:function(paymentMethod){
        if(paymentMethod===constants.PAYMENT_METHOD_C_MPP){
            //TODO comment back in when monthly payment plan journey is accessible
            //$('#monthly_payment_plan_button').click();
        }
        else if(paymentMethod===constants.PAYMENT_METHOD_C_CCRA){
            //TODO comment back in when ccra journey is accessible
            //$('#ccra_button').click();
        }
        else if(paymentMethod===constants.PAYMENT_METHOD_C_DD){
            $('#whole_bill_direct_debit_button').click();
        }
    },
    mppClickAction:function(){
        $('#payment_method_panel').find('.collapse.in').collapse('hide');

        if($('#ccra_popup').is(':visible')) {
            this.ccraClickAction();
        }

        if($('#whole_bill_direct_debit_popup').is(':visible') ){
            this.wbddClickAction();
        }

        var width = window.outerWidth;

        if(!$('#monthly_payment_plan_popup').is(':visible') ) {
            $("#monthly_payment_plan_button").addClass('btn-main-selected').removeClass('btn-main-unselected');
            $("#tick1").show();
            if (width >= 480 && width < 768) {
                $('#whole_bill_direct_debit_button').addClass('margin-top475');
            }
            else if (width > 768) {
                $('#payment_method_panel').addClass('largeChangePaymentButtons');
                $('#changePaymentDivider').hide();
            }
        }
        else{
            $('#whole_bill_direct_debit_button').removeClass('margin-top475');
            $('#payment_method_panel').removeClass('largeChangePaymentButtons');
            $('#changePaymentDivider').show();
            $("#monthly_payment_plan_button").removeClass('btn-main-selected').addClass('btn-main-unselected');
            $("#tick1").hide();
        }
    },
    ccraClickAction:function(){
        $('#payment_method_panel').find('.collapse.in').collapse('hide');
       if($('#monthly_payment_plan_popup').is(':visible') ){
           
            this.mppClickAction()
        }
        if($('#whole_bill_direct_debit_popup').is(':visible') ){
            
            this.wbddClickAction()
        }
        var width = window.outerWidth;

        if(!$('#ccra_popup').is(':visible') ) {
            $("#ccra_button").addClass('btn-main-selected').removeClass('btn-main-unselected');
            $("#tick2").show();
            if (width >= 480 && width < 768) {
                $('#whole_bill_direct_debit_button').addClass('margin-top30');
            }
            if (width > 768) {
                $('#payment_method_panel').addClass('largeChangePaymentButtons');
                $('#changePaymentDivider').hide();
            }
        }
        else{
            $('#payment_method_panel').removeClass('largeChangePaymentButtons');
            $('#whole_bill_direct_debit_button').removeClass('margin-top30');
            $('#changePaymentDivider').show();
            $("#ccra_button").removeClass('btn-main-selected').addClass('btn-main-unselected');
            $("#tick2").hide();
        } 
    },
    wbddClickAction:function(){
        $('#payment_method_panel').find('.collapse.in').collapse('hide');
        if($('#monthly_payment_plan_popup').is(':visible') ){

            this.mppClickAction();
        }
        if($('#ccra_popup').is(':visible') ){

            this.ccraClickAction();
        }
        if(!$('#whole_bill_direct_debit_popup').is(':visible') ) {
            $("#whole_bill_direct_debit_button").addClass('btn-main-selected').removeClass('btn-main-unselected');
            $("#tick3").show();
            $('#changePaymentDivider').hide();
        }
        else{
            $('#changePaymentDivider').show();
            $("#tick3").hide();
            $("#whole_bill_direct_debit_button").removeClass('btn-main-selected').addClass('btn-main-unselected');
        }
    },
    windowResize:function(window){
         var width = window.outerWidth;

            if(width < 480){
                if($('#monthly_payment_plan_popup').is(':visible') ) {
                    $('#whole_bill_direct_debit_button').removeClass('margin-top475');
                    $('#payment_method_panel').removeClass('largeChangePaymentButtons');
                }
                if($('#ccra_popup').is(':visible') ) {
                    $('#payment_method_panel').removeClass('largeChangePaymentButtons');
                    $('#whole_bill_direct_debit_button').removeClass('margin-top30');

                }
                
            }
            else if (width >= 480 && width < 768) {
                if($('#monthly_payment_plan_popup').is(':visible') ) {
                    $('#whole_bill_direct_debit_button').addClass('margin-top475');
                    $('#payment_method_panel').removeClass('largeChangePaymentButtons');
                }
                if($('#ccra_popup').is(':visible') ) {
                    $('#payment_method_panel').removeClass('largeChangePaymentButtons');
                    $('#whole_bill_direct_debit_button').addClass('margin-top30');

                }

            }
            else if (width >= 768) {
                if($('#monthly_payment_plan_popup').is(':visible') ) {
                    $('#whole_bill_direct_debit_button').removeClass('margin-top475');
                    $('#payment_method_panel').addClass('largeChangePaymentButtons');
                }
                if($('#ccra_popup').is(':visible') ) {
                    $('#payment_method_panel').addClass('largeChangePaymentButtons');
                    $('#whole_bill_direct_debit_button').removeClass('margin-top30');

                }
            }

    },

    isDisplayChangeHistory: function(userType, newAccountHistory) {

        // We return only if there's at least 2 entries in the new Account history
        return (userType === constants.AGENT &&
            newAccountHistory &&
            newAccountHistory.accountHistoryDetails &&
            newAccountHistory.accountHistoryDetails.length > 1);
    },

    getAccountHistoryDetails:function(accountHistory){

        var formattedAccountHistoryDetails = [];

        if (accountHistory) {

            var accountHistoryDetails = accountHistory.accountHistoryDetails;

            for (var i = 0; i < accountHistoryDetails.length - 1; i++) {

                var accountHistoryObject = {"date": "", "from": "", "to": ""};

                accountHistoryObject.date = new moment(accountHistoryDetails[i].from).format("D MMMM YYYY");
                accountHistoryObject.from = accountHistoryDetails[i + 1].paymentMethod;
                accountHistoryObject.to = accountHistoryDetails[i].paymentMethod;

                formattedAccountHistoryDetails[formattedAccountHistoryDetails.length] = (accountHistoryObject);
            }

        }

        var newAccountHistory = {'accountHistoryDetails' : ''};

        newAccountHistory.accountHistoryDetails = formattedAccountHistoryDetails;

        return newAccountHistory;


        }
        };
    }
]);