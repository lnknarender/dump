/**
 * Created by Andrew on 15/12/2015.
 */

var paymentMethodServices = angular.module('paymentMethodServices', []);

paymentMethodServices.factory('commonPaymentMethodUrlService', ['$routeParams', 'urlService', function ($routeParams, urlService) {

        return {
            /**
             * Get the ReST URL for payment methods
             * @returns {string} Returns customer or agent ReST URL for payment methods
             */
            getViewPaymentMethodUrl: function () {


              
                 if (angular.isDefined(connection.useMockData) && connection.useMockData == 'true' && connection.userType == 'agent') {
                 
                 return "http://consumer.bt.com/static/bpta/test/mockFiles/paymentMethod/paymentMethod_" + $routeParams.bac + ".json";
                 }
                 else if (angular.isDefined(connection.useMockData) && connection.useMockData == 'true' && connection.userType == 'customer') {
                 
                 return "http://consumer.bt.com/static/bpta/test/mockFiles/paymentMethod/paymentMethod_" + $routeParams.accKey + ".json";
                 }
                 
                 


                if (connection.userType == 'agent') {
                    return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/paymentmethods';
                }

                return urlService.getSecurePath() + '/acckey/' + this.getAccountKeyFromUrl() + '/paymentmethods';
            },
            getValidateBankDetailsUrl: function () {
                if (connection.userType == 'agent') {
                    return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/validate/bankdetails';
                }

                return urlService.getSecurePath() + '/acckey/' + this.getAccountKeyFromUrl() + '/validate/bankdetails';
            },
            getUpdateAccountUrl: function () {
                if (connection.userType == 'agent') {
                    return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/update/account';
                }

                return urlService.getSecurePath() + '/acckey/' + this.getAccountKeyFromUrl() + '/update/account';
            },
            getAccountHistoryUrl: function () {
                if (connection.userType == 'agent') {
                    return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/accounthistory';
                }

                return urlService.getSecurePath() + '/acckey/' + this.getAccountKeyFromUrl() + '/accounthistory';
            },
            getAccountHistoryForEditUrl: function () {
                if (connection.userType === 'agent') {
                    return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/accounthistory/edit';
                }

                return urlService.getSecurePath() + '/acckey/' + this.getAccountKeyFromUrl() + '/accounthistory/edit';
            },
            getPaymentDaysUrl: function () {

                if (connection.userType == 'agent') {
                    return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/paymentdays';
                }

                return urlService.getSecurePath() + '/acckey/' + this.getAccountKeyFromUrl() + '/paymentdays';
            },
            getNextBillDateUrl: function () {
                if (connection.userType == 'agent') {
                    return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/bill/next';
                }
                return urlService.getSecurePath() + '/acckey/' + this.getAccountKeyFromUrl() + '/bill/next';
            },
            getAccountKeyFromUrl: function() {

                if ($routeParams.accKey !== undefined) {

                    return $routeParams.accKey;
                }
                else {
                    return $routeParams.acckey;
                }
            },
            getRecalculateUrl: function () {
                if (connection.userType === 'agent') {
                    return urlService.getSecurePath() + '/cak/' + $routeParams.cak + '/conk/' + $routeParams.conk + '/bac/' + $routeParams.bac + '/recalculate';
                }
                return urlService.getSecurePath() + '/acckey/' + $routeParams.accKey + '/recalculate';
            }

        };
    }]);

paymentMethodServices.factory('commonPaymentMethodServices', ['$q', 'ajaxServiceWithToken', 'stateService', 'commonPaymentMethodUrlService', 'primaryContactService', 'utilityService',
    function ($q, ajaxServiceWithToken, stateService, commonPaymentMethodUrlService, primaryContactService, utilityService) {

        return {
            /**
             * Get the customer's payment methods. First call retrieves from server, subsequent call retrieves from
             * local storage
             * @returns {promise} Returns Customer's payment methods as a promise
             */
            getViewPaymentMethods: function () {

                var deferred = $q.defer();

                var paymentMethods = stateService.get(constants.STATE_SERVICE_PAYMENT_METHODS);

                if (paymentMethods) {

                    //  Already have a payment account so return it
                    deferred.resolve(paymentMethods);
                } else {

                    var url = commonPaymentMethodUrlService.getViewPaymentMethodUrl();

                    var viewPaymentMethodsResponse = ajaxServiceWithToken.doGet(url, {});

                    viewPaymentMethodsResponse.then(function (result) {
                        stateService.set(constants.STATE_SERVICE_PAYMENT_METHODS, result);
                        deferred.resolve(result);
                    },
                            function (errorResult) {
                                deferred.reject(errorResult);
                            });
                }

                return deferred.promise;
            },
            getAccountHistory: function () {

                var deferred = $q.defer();

                var accountHistory = stateService.get(constants.STATE_SERVICE_ACCOUNT_HISTORY_PAYMENT_METHODS);

                if (accountHistory) {

                    //  Already have a payment account so return it
                    deferred.resolve(accountHistory);
                } else {

                    var url = commonPaymentMethodUrlService.getAccountHistoryUrl();

                    var viewPaymentMethodsResponse = ajaxServiceWithToken.doGet(url, {});

                    viewPaymentMethodsResponse.then(function (result) {
                        stateService.set(constants.STATE_SERVICE_ACCOUNT_HISTORY_PAYMENT_METHODS, result);
                        deferred.resolve(result);
                    },
                            function (errorResult) {
                                deferred.reject(errorResult);
                            });
                }

                return deferred.promise;
            },
            getAccountHistoryForEdit: function () {
                var deferred = $q.defer(),
                        accountHistory = stateService.get(constants.STATE_SERVICE_ACCOUNT_HISTORY_EDIT_PAYMENT_METHODS);
                
                if (accountHistory) {
                    //  Already have a payment account so return it
                    deferred.resolve(accountHistory);
                } else {
                    var url = commonPaymentMethodUrlService.getAccountHistoryForEditUrl();
                    var viewPaymentMethodsResponse = ajaxServiceWithToken.doGet(url, {});
                    viewPaymentMethodsResponse.then(function (result) {
                        stateService.set(constants.STATE_SERVICE_ACCOUNT_HISTORY_EDIT_PAYMENT_METHODS, result);
                        deferred.resolve(result);
                    },
                            function (errorResult) {
                                deferred.reject(errorResult);
                            });
                }

                return deferred.promise;
            },
            getAllRequest: function (userType) {
                var deferred = $q.defer();
                var request = {
                    viewPaymentMethods: this.getViewPaymentMethods(),
                    accountHistory: this.getAccountHistory()
                };
                if (userType === 'agent') {
                    request.primaryContactDetails = primaryContactService.getContactDetails();
                }
                $q.all(request).then(function (results) {
                    deferred.resolve(results);
                },
                        function (errorResult) {
                            deferred.reject(errorResult);
                        });
                return deferred.promise;
            },
            getAllViewPaymentRequest: function (userType) {
                var deferred = $q.defer();
                var request = {
                    viewPaymentMethods: this.getViewPaymentMethods()
                };
                if (userType === 'agent') {
                    request.primaryContactDetails = primaryContactService.getContactDetails();
                }
                $q.all(request).then(function (results) {
                    deferred.resolve(results);
                },
                        function (errorResult) {
                            deferred.reject(errorResult);
                        });
                return deferred.promise;
            },
            isInEligiblePaymentMethods: function (paymentMethods) {

                if (paymentMethods != undefined) {
                    return (!jQuery.isEmptyObject(paymentMethods.ineligiblePaymentMethods));
                }

                return false;
            },
            isOutstandingCharges: function (paymentMethods) {

                if (paymentMethods != undefined && angular.isDefined(paymentMethods.outstanding) && paymentMethods.outstanding != null && paymentMethods.outstanding.amount > 0) {

                    return true;
                }

                return false;
            },
            getPaymentMethodForView: function () {
                return{
                    "Cheque/Cash": constants.PAYMENT_METHOD_C_CC,
                    "Direct Debit": constants.PAYMENT_METHOD_C_DD,
                    "Monthly Payment Plan": constants.PAYMENT_METHOD_C_MPP,
                    "CCRA": constants.PAYMENT_METHOD_C_CCRA,
                    "CANCEL": constants.PAYMENT_METHOD_C_CANCEL,
                    "CHANGE": constants.PAYMENT_METHOD_C_CHANGE
                };
            },
            updateAccount: function (updateAccount) {
                var url = commonPaymentMethodUrlService.getUpdateAccountUrl();
                return ajaxServiceWithToken.doPost(url, {}, updateAccount);
            },
            getNextBillDate: function () {
                var deferred = $q.defer();
                var service = this;
                if (service.nextBillDate) {
                    deferred.resolve(service.nextBillDate);
                } else if (service.paymentMethods && service.paymentMethods.nextBillDate) {
                    service.nextBillDate = service.paymentMethods.nextBillDate;
                    deferred.resolve(service.nextBillDate);
                } else {
                    var url = commonPaymentMethodUrlService.getNextBillDateUrl();
                    ajaxServiceWithToken.doGet(url, {}).then(function (result) {
                        service.nextBillDate = result.creationDate;
                        deferred.resolve(service.nextBillDate);
                    },
                            function (errorResult) {
                                deferred.reject(errorResult);
                            });
                }
                return deferred.promise;
            },
            isNextBillDateDue: function (nextBillDate, diff) {
                var today = moment().format("YYYY-MM-DD");
                return utilityService.isTwoDatesWithinDifference(today, nextBillDate, (diff || 2));
            },
            validateBankDetails: function (bankDetails) {
                var url = commonPaymentMethodUrlService.getValidateBankDetailsUrl();
                return ajaxServiceWithToken.doPost(url, {}, bankDetails);
            },
            getRecalculateAmount: function () {
               var deferred = $q.defer(), url = commonPaymentMethodUrlService.getRecalculateUrl(), 
                   viewPaymentMethodsResponse = ajaxServiceWithToken.doGet(url, {});

                    viewPaymentMethodsResponse.then(function (result) {
                        deferred.resolve(result);
                    },
                     function (errorResult) {
                         deferred.reject(errorResult);
                     });
                
                return deferred.promise;
            }
        };
    }]);

paymentMethodServices.factory('editBankDetailsService', ['commonPaymentMethodServices', 'stateService', 'primaryContactService', '$q',
    function (commonPaymentMethodServices, stateService, primaryContactService, $q) {
        var bankDetails = null, soleSignatory = null;
        return {
            updateBankDetails: function (bac) {
                var deferred = $q.defer();
                var existingPaymentMethod = commonPaymentMethodServices.paymentMethods;
                var requests = [];
                if ((existingPaymentMethod.paymentMethod === constants.PAYMENT_METHOD_DIRECT_DEBIT
                        || existingPaymentMethod.paymentMethod === constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN)
                        && (bankDetails !== null || soleSignatory !== null)) {
                    var updateAccount = {
                        "paymentMethod": existingPaymentMethod.paymentMethod,
                        "email": stateService.get("contactEmail"),
                        "billFrequency": existingPaymentMethod.billFrequency
                    };

                    if (soleSignatory === true) {
                        updateAccount['bankDetails'] = {
                            "accountHolderName": bankDetails.accountHolderName,
                            "bankAccountNumber": bankDetails.accountNumber,
                            "sortCode": [bankDetails.sortCode.code1, bankDetails.sortCode.code2, bankDetails.sortCode.code3].join("")
                        };
                    } else {
                        updateAccount['paperMandate'] = true;
                    }
                    requests.push(commonPaymentMethodServices.updateAccount(updateAccount));
                    // Commented below call as we are waiting for clarification from business
//                    if (soleSignatory) {
//                        requests.push(commonPaymentMethodServices.getNextBillDate());
//                    }

                    $q.all(requests).then(function (results) {
                        var res = {
                            bankDetails: bankDetails,
                            soleSignatory: soleSignatory,
                            email: updateAccount.email,
                            address: existingPaymentMethod.address
                        };
                        if (results.length > 1) {
                            res.nextBillDateDue = commonPaymentMethodServices.isNextBillDateDue(results[1], 2);
                        }
                        deferred.resolve(res);
                    },
                            function (errorResult) {
                                deferred.reject(errorResult);
                            });
                } else {
                    deferred.reject({
                        "errors": [{
                                "message": "Invalid Data/Customer not eligible for edit bank details",
                                "code": 0
                            }]
                    });
                }
                return deferred.promise;
            },
            setBankDetails: function (newBankDetails, soleSignatoryFlag) {
                bankDetails = newBankDetails;
                soleSignatory = soleSignatoryFlag;
            },
            setSoleSignatory: function (flag) {
                soleSignatory = flag;
            }
        };
    }]);