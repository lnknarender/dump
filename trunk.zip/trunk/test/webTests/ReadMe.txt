Test data
=========

BAC -> GB01161170 -> Next bill date -> today (always less than 2 days)

Acc Key ->  35713
BAC -> GB02535713 -> Format         -> Blue Bill
                     Language       -> English
                     Bill Media     -> Paper Free
                     Payment method -> Direct Debit
                     Next bill date -> always greater than 2 days

Acc Key ->  35714
BAC -> GB02535714->  Format         -> Blue Bill
                     Language       -> English
                     Bill Media     -> Paper Free
                     Payment method -> Cheque/Cash
                     charges        -> applicable -> true
                     barred         -> Status -> Bill Follow Up
                                              -> Installment Defaulted

Acc Key ->  35715
BAC -> GB02535715 -> Format         -> Blue Bill
                     Language       -> English
                     Bill Media     -> Paper Free
                     Payment method -> Cheque/Cash
                     charges        -> applicable -> true
                     barred         -> Status -> Bill Follow Up
                                              -> Installment Defaulted

Acc Key ->  35716
BAC -> GB02535716 -> Format         -> Blue Bill
                     Language       -> English
                     Bill Media     -> Paper
                     Payment method -> Cheque/Cash
                     charges        -> applicable -> true
                     barred         -> Status -> String
                                              -> String

Acc Key ->  35717
BAC -> GB02535717 -> Format         -> Braille
                     Language       -> English
                     Bill Media     -> Dual
                     Payment method -> Cheque/Cash


Acc Key ->  35718
BAC -> GB02535718 -> Format         -> Blue Bill
                     Language       -> English
                     Bill Media     -> Paper
                     Payment method -> Cheque/Cash
                     Status 	 -> Closed
                     subStatus 	 -> Pending Termination


Acc Key ->  35719
BAC -> GB02535719 -> Format         -> Braille
                     Language       -> English
                     Bill Media     -> Paper
                     Payment method -> Cheque/Cash


Acc Key ->  42511
BAC -> GB02533877 -> Format     -> Blue Bill
                     Language   -> English
                     Bill Media -> Paper Free
                     Active     -> Billing account not active


BAC -> GB02536943 -> Format     -> Blue Bill
                     Language   -> English
                     Bill Media -> Dual


Acc Key ->  42360
BAC -> GB02534856 -> Format     -> Braille Bill
                     Language   -> English
                     Bill Media -> Dual