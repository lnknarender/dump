/**
* Created by Andrew on 14/05/2015.
*/

var PaymentSuccessfulPage = (function () {

    function PaymentSuccessfulPage() {
        this.subTitle = element(By.id("paymentSuccess"));
        this.successMessage = element(By.id("paymentSuccess"));
        this.paymentReference = element(By.id("paymentReference"));
        this.paymentDateTime = element(By.id("paymentDateTime"));
        this.accountNumber = element(By.id("accountNumber"));
        this.amount = element(By.id("amountPaid"));
        this.cardType = element(By.id("cardType"));
        this.nameOnCard = element(By.id("nameOnCard"));
        this.cardNumber = element(By.id("cardNumber"));
        this.startDate = element(By.id("startDate"));
        this.expiryDate = element(By.id("expiryDate"));
        this.securityCode = element(By.id("securityCode"));
        this.postCode = element(By.id("postCode"));
        this.emailSuccessful = element(By.id("emailSuccessful"));
        this.emailLoggedout = element(By.id("loggedoutemail"));


        this.emailBtn = element(By.id("customer_email"));
        this.customerEmailBtn = element(By.id("completeBtn"));
        this.printBtn = element(By.id("printBtn"))
        this.sendEmailBtn = element(By.id("agent_email"));
    };

    PaymentSuccessfulPage.prototype.getSubTitle = function () {
        return this.subTitle.getText();
    };

    PaymentSuccessfulPage.prototype.getSuccessMessage = function () {
        return this.successMessage.getText();
    };

    PaymentSuccessfulPage.prototype.getPaymentReference = function () {
        return this.paymentReference.getText();
    };

    PaymentSuccessfulPage.prototype.getAccountNumber = function () {
        return this.accountNumber.getText();
    };

    PaymentSuccessfulPage.prototype.getAmount = function () {
        return this.amount.getText();
    };

    PaymentSuccessfulPage.prototype.getCardType = function () {
        return this.cardType.getText();
    };

    PaymentSuccessfulPage.prototype.getNameOnCard = function () {
        return this.nameOnCard.getText();
    };

    PaymentSuccessfulPage.prototype.getCardNumber = function () {
        return this.cardNumber.getText();
    };

    PaymentSuccessfulPage.prototype.getSecurityCode = function () {
        return this.securityCode.getText();
    };

    PaymentSuccessfulPage.prototype.getExpiryDate = function () {
        return this.expiryDate.getText();
    };

    PaymentSuccessfulPage.prototype.getPostCode = function () {
        return this.postCode.getText();
    };

    PaymentSuccessfulPage.prototype.clickEmailButton = function () {
        return this.emailBtn.click();
    };

    PaymentSuccessfulPage.prototype.clickCustomerEmailButton = function () {
        return this.customerEmailBtn.click();
    };

    PaymentSuccessfulPage.prototype.clickPrintButton = function () {
        return this.printBtn.click();
    };

    PaymentSuccessfulPage.prototype.sendEmailButton = function () {
        return this.sendEmailBtn.click();
    };

    PaymentSuccessfulPage.prototype.assertEmailButtonIsEnabled = function () {

        expect(this.sendEmailBtn.isEnabled().toBe(false));
    };

    PaymentSuccessfulPage.prototype.getEmailSuccessful = function () {
        return this.emailSuccessful.getText();
    };

    PaymentSuccessfulPage.prototype.enterEmailAddress = function (emailAddress) {

        this.emailLoggedout.clear();
        this.emailLoggedout.sendKeys(emailAddress);
    };


    return PaymentSuccessfulPage;
})();

module.exports = PaymentSuccessfulPage;