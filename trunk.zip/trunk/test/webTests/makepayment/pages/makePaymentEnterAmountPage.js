/**
 * Created by Neil Pullen on 5/8/15.
 */
var MakePaymentEnterAmountPage = (function () {

    function MakePaymentEnterAmountPage() {
        this.title = element(By.id("title"));

        this.accountNumber = element(By.id("accountNumber"));
        this.accountFriendlyName = element(By.id("accountFriendlyName"));
        this.outstandingBalance = element(By.id("outstandingBalance"));
        this.paymentDueDateLabel =element(By.id("paymentDueDateLabel"));
        this.accountCreditedBy =element(By.id("accountCreditedBy"));
        this.dontNeedToPay =element(By.id("dontNeedToPay"));
        this.paymentDueDate = element(By.id("paymentDueDate"));
        this.minWarning = element(By.id("minWarning"));

        this.amountField = element(By.id("amount"));
        this.amountError = element(By.id("amountValidationTypeError"));
        this.minimumAmountError = element(By.id("reenterBacError"));
        this.outstandingBalanceWarning = element(By.id("warningMessage"));

        this.emailField = element(By.id("email"));
        this.emailError = element(By.id("emailError"));

        this.phoneNumberField = element(By.id("phoneNumber"));
        this.phoneNumberError = element(By.id("phoneNumberError"));

        this.submit = element(By.id("submitButton"));
        this.cancel = element(By.id("cancelButton"));
    }

    MakePaymentEnterAmountPage.prototype.getTitle = function () {
        return this.title.getText();
    };

    MakePaymentEnterAmountPage.prototype.getAccountNumber = function () {
        return this.accountNumber.getText();
    };

    MakePaymentEnterAmountPage.prototype.getAccountFriendlyName = function () {
        return this.accountFriendlyName.getText();
    };

    MakePaymentEnterAmountPage.prototype.getOutstandingBalance = function () {
        return this.outstandingBalance.getText();
    };

    MakePaymentEnterAmountPage.prototype.getOutstandingBalanceWarning = function () {
        return this.outstandingBalanceWarning.getText();
    };

    MakePaymentEnterAmountPage.prototype.getPaymentDueDate = function () {
        return this.paymentDueDate.getText();
    };

    MakePaymentEnterAmountPage.prototype.getMinWarning = function () {
        return this.minWarning.getText();
    };

    MakePaymentEnterAmountPage.prototype.clickSubmitButton = function () {
        return this.submit.click();
    };

    MakePaymentEnterAmountPage.prototype.clickCancelButton = function () {
        return this.cancel.click();
    };

    MakePaymentEnterAmountPage.prototype.enterEmail = function (email) {
        this.emailField.clear();
        this.emailField.sendKeys(email);
    };

    MakePaymentEnterAmountPage.prototype.getEmailError = function () {
        return this.emailError.getText();
    };

    MakePaymentEnterAmountPage.prototype.enterAmount = function (amount) {
        this.amountField.clear();
        this.amountField.sendKeys(amount);
    };

    MakePaymentEnterAmountPage.prototype.getAmountError = function () {
        return this.amountError.getText();
    };

    MakePaymentEnterAmountPage.prototype.getMinimumAmountError = function () {
        return this.minimumAmountError.getText();
    };

    MakePaymentEnterAmountPage.prototype.enterPhoneNumber = function (number) {
        this.phoneNumberField.clear();
        this.phoneNumberField.sendKeys(number);
    };

    MakePaymentEnterAmountPage.prototype.getPhoneNumberError = function () {
        return this.phoneNumberError.getText();
    };

    return MakePaymentEnterAmountPage

})();

module.exports = MakePaymentEnterAmountPage;
