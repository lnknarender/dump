var MakePaymentEnterBacPage = (function () {

    function MakePaymentEnterBacPage() {
        this.title = element(By.id("title"));
        this.bacLabel = element(By.id("bacLabel"));
        this.reenterBacLabel = element(By.id("reenterBacLabel"));

        this.bacField = element(By.id("bac"));
        this.reenterBacField = element(By.id("reenterBac"));

        this.bacError = element(By.id("bacError"));
        this.unknownBacError = element(By.id("unknownBacError"));
        this.reenterBacError = element(By.id("reenterBacError"));

        this.continue = element(By.id("continueBtn"));
    }

    MakePaymentEnterBacPage.prototype.getTitle = function () {
        return this.title.getText();
    };

    MakePaymentEnterBacPage.prototype.getBacLabel = function () {
        return this.bacLabel.getText();
    };

    MakePaymentEnterBacPage.prototype.getReenterBacLabel = function () {
        return this.reenterBacLabel.getText();
    };

    MakePaymentEnterBacPage.prototype.getBacError = function () {
        return this.bacError.getText();
    };

    MakePaymentEnterBacPage.prototype.getUnknownBacError = function () {
        return this.unknownBacError.getText();
    };

    MakePaymentEnterBacPage.prototype.getReenterBacError = function () {
        return this.reenterBacError.getText();
    };

    MakePaymentEnterBacPage.prototype.enterBac = function (bac) {
        this.bacField.clear();
        this.bacField.sendKeys(bac);
    };

    MakePaymentEnterBacPage.prototype.enterReenterBac = function (bac) {
        this.reenterBacField.clear();
        this.reenterBacField.sendKeys(bac);
    };

    MakePaymentEnterBacPage.prototype.clickContinueButton = function () {
        return this.continue.click();
    };

    return MakePaymentEnterBacPage

})();

module.exports = MakePaymentEnterBacPage;
