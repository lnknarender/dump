/**
 * Created by Andrew on 14/05/2015.
 */

var PaymentFailedPage = (function () {

    function PaymentFailedPage() {
        this.title = element(By.id("title"));
        this.errorMessage1 = element(By.id("errorMessage1"));
        this.errorMessage2 = element(By.id("errorMessage2"));

        this.backBtn = element(By.id("backBtn"));
    };

    PaymentFailedPage.prototype.getTitle = function () {
        return this.title.getText();
    };

    PaymentFailedPage.prototype.getErrorMessage1 = function () {
        return this.errorMessage1.getText();
    };

    PaymentFailedPage.prototype.getErrorMessage2 = function () {
        return this.errorMessage2.getText();
    };

    PaymentFailedPage.prototype.clickBackButton = function () {
        return this.backBtn.click();
    };

    return PaymentFailedPage;
})();

module.exports = PaymentFailedPage;

