/**
* Created by Andrew on 14/05/2015.
*/

var PaymentFailurePage = (function () {

    function PaymentFailurePage() {
        this.title = element(By.id("errorMessage1"));
        this.subTitle = element(By.id("errorMessage2"));
    };

    PaymentFailurePage.prototype.getTitle = function () {
        return this.title.getText();
    };

    PaymentFailurePage.prototype.getSubTitle = function () {
        return this.subTitle.getText();
    };

    return PaymentFailurePage;
})();

module.exports = PaymentFailurePage;