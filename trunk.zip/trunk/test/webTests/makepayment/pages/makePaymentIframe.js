/**
 * Created by Neil Pullen on 5/8/15.
 */
var MakePaymentIframePage = (function () {

    function MakePaymentIframePage() {
        this.accountNumber = element(By.id("accountNumber"));
        this.amount = element(By.id("amount"));
    };

    MakePaymentIframePage.prototype.getAccountNumber = function () {
        return this.accountNumber.getText();
    };

    MakePaymentIframePage.prototype.getAmount = function () {
        return this.amount.getText();
    };

    return MakePaymentIframePage

})();

module.exports = MakePaymentIframePage;
