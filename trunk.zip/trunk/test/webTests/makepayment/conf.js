var helper = require('../../helper.js');

exports.config={
    seleniumAddress:'http://127.0.0.1:4444/wd/hub',
    capabilities: {
        'browserName': 'firefox',
        proxy: {
            proxyType: 'manual',
            httpProxy: 'http://proxy.intra.bt.com:8080',
            sslProxy: 'http://proxy.intra.bt.com:8080'
        }
    },
    seleniumArgs: [
        "-Dwebdriver.firefox.profile=bdnt4eer.default"
    ],

    getMultiCapabilities: helper.getFirefoxProfile,

    specs: ['./tests/agent*Test.js'],

    jasmineNodeOpts: {
        onComplete: null,
        isVerbose: false,
        showColors: true,
        defaultTimeoutInterval: 60000, // 60 seconds as thistle can be slow
        includeStackTrace: false
    }
}