var LandingPage = require("../../../landingPage.js");
var CustomerHomePage = require("../../../customerHomePage.js");
var MakePaymentEnterAmountPage = require("../pages/makePaymentEnterAmountPage.js");
var ThistlePageTester = require("./../../../common/thistlePageTester.js");
var PaymentSuccessfulPage = require("../pages/paymentSuccessfulPage.js");
var PaymentFailurePage = require("../pages/paymentFailurePage.js");

describe("MAKE PAYMENT - LOGGED IN CUSTOMER", function () {

    it('Successful payment', function () {

        var makePaymentEnterAmountPage = new MakePaymentEnterAmountPage();

        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterAcckey("42497");
        landingPage.clickCustomerButton();

        var customerHomePage = new CustomerHomePage();
        customerHomePage.clickCustomerMakePayment();

        var AMOUNT = "11.99";
        makePaymentEnterAmountPage.enterAmount(AMOUNT);
        expect(makePaymentEnterAmountPage.getPaymentDueDate()).toContain("27/12/2014");
        expect(makePaymentEnterAmountPage.getOutstandingBalance()).toContain("�10.00");

        makePaymentEnterAmountPage.clickSubmitButton().then(function () {

            //  Enter card details into Thistle
            var thistlePageTester = new ThistlePageTester();
            thistlePageTester.useValidCard();

            var paymentSuccessfulPage = new PaymentSuccessfulPage();

            expect(paymentSuccessfulPage.getSuccessMessage()).toContain("Thank you for your payment");

            var CARD_TYPE = "VISA";
            var ACCOUNT_NUMBER = "Account Number GB0253****";

            expect(paymentSuccessfulPage.getAccountNumber()).toContain(ACCOUNT_NUMBER);
            expect(paymentSuccessfulPage.getAmount()).toContain(AMOUNT);
            expect(paymentSuccessfulPage.getCardType()).toContain(CARD_TYPE);
            expect(paymentSuccessfulPage.getCardNumber()).toContain("************0800");

            paymentSuccessfulPage.clickCustomerEmailButton();
            paymentSuccessfulPage.enterEmailAddress("andrew.hoard@bt.com");
            paymentSuccessfulPage.sendEmailButton();

            expect(paymentSuccessfulPage.getEmailSuccessful()).toContain("Thank you, confirmation email sent");
        });
    }),
    it('Failed payment - failed page should be displayed', function () {

        var AMOUNT = '50.00';

        var makePaymentEnterAmountPage = new MakePaymentEnterAmountPage();

        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.clickCustomerButton();

        var customerHomePage = new CustomerHomePage();
        customerHomePage.clickCustomerMakePayment();

        makePaymentEnterAmountPage.enterAmount(AMOUNT);

        makePaymentEnterAmountPage.clickSubmitButton().then(function () {

            //  Enter card details into Thistle
            var thistlePageTester = new ThistlePageTester();
            thistlePageTester.useInvalidCard();
            thistlePageTester.enterSecurityCode();
            thistlePageTester.enterSecurityCode();
            thistlePageTester.enterSecurityCode();
            thistlePageTester.enterSecurityCode();
            thistlePageTester.enterSecurityCode();

            var paymentFailurePage = new PaymentFailurePage();

            expect(paymentFailurePage.getTitle()).toContain("Your payment has failed too many times");
            expect(paymentFailurePage.getSubTitle()).toContain("For security reasons we cannot allow you to retry the payment");
        });
    })
});
