var LandingPage = require("../../../landingPage.js");
var MakePaymentEnterBacPage = require("../pages/makePaymentEnterBac.js");
var MakePaymentEnterAmountPage = require("../pages/makePaymentEnterAmountPage.js");
var MakePaymentIframePage = require("../pages/makePaymentIframe.js");
var ThistlePageTester = require("./../../../common/thistlePageTester.js");
var PaymentSuccessfulPage = require("../pages/paymentSuccessfulPage.js");

describe("MAKE PAYMENT - NOT LOGGED IN", function() {


     it('The Billing Account field must be valid',function() {

     var makePaymentEnterBacPage = new MakePaymentEnterBacPage();

     var landingPage = new LandingPage();
     landingPage.visitPage();
     landingPage.clickLoggedOutMakePaymentButton ();

     // Enter number into BAC
     // Valid is:
     //  * two letters followed by 8 numbers
     //  * no spaces
     //  * alphanumeric only
     //  * BAC and re-entered BAC should be the same

     makePaymentEnterBacPage.enterBac('ksd09238');
     expect(makePaymentEnterBacPage.getBacError()).toContain('The billing account number should be two letters followed by eight numbers.');

     makePaymentEnterBacPage.enterBac('as123 45678');
     expect(makePaymentEnterBacPage.getBacError()).toContain('The billing account number should be two letters followed by eight numbers.');

     makePaymentEnterBacPage.enterBac('as1234567*');
     expect(makePaymentEnterBacPage.getBacError()).toContain('The billing account number should be two letters followed by eight numbers.');

     makePaymentEnterBacPage.enterBac('as12345678');
     makePaymentEnterBacPage.enterReenterBac('as12345679');
     expect(makePaymentEnterBacPage.getReenterBacError()).toContain('Please enter a valid account number');

     }),


    it('The Billing Account must exist',function() {

         var ACCOUNT_NUMBER = "GB02535713";

         var makePaymentEnterBacPage = new MakePaymentEnterBacPage();

         var landingPage = new LandingPage();
         landingPage.visitPage();
         landingPage.clickLoggedOutMakePaymentButton ();

         makePaymentEnterBacPage.enterBac(ACCOUNT_NUMBER);
         makePaymentEnterBacPage.enterReenterBac(ACCOUNT_NUMBER);

         makePaymentEnterBacPage.clickContinueButton().then(function () {
         //TODO: This test returns a HTTP 404. This is an issue with way Java is handling the stub data. Further invesigation required.
         //            expect(makePaymentEnterBacPage.getUnknownBacError()).toContain('The billing account number is unrecognised.');
         });
     }),

   it('A valid email address must be entered',function() {

     var ACCOUNT_NUMBER = 'GB02533877';

     var makePaymentEnterBacPage = new MakePaymentEnterBacPage();
     var makePaymentEnterAmountPage = new MakePaymentEnterAmountPage();

     var landingPage = new LandingPage();
     landingPage.visitPage();
     landingPage.clickLoggedOutMakePaymentButton ();

     makePaymentEnterBacPage.enterBac(ACCOUNT_NUMBER);
     makePaymentEnterBacPage.enterReenterBac(ACCOUNT_NUMBER);

     makePaymentEnterBacPage.clickContinueButton().then(function () {

         var AMOUNT = "12.99";
         makePaymentEnterAmountPage.enterAmount(AMOUNT);

         makePaymentEnterAmountPage.clickSubmitButton().then(function() {

             //  Enter card details into Thistle
             var thistlePageTester = new ThistlePageTester();
             thistlePageTester.useValidCard();

             var paymentSuccessfulPage = new PaymentSuccessfulPage();

             browser.sleep(3000);

             expect(paymentSuccessfulPage.getSuccessMessage()).toContain("Thank you for your payment");

             var CARD_TYPE = "VISA";
             var ACCOUNT_NUMBER = "Account Number GB0253****";

             expect(paymentSuccessfulPage.getAccountNumber()).toContain(ACCOUNT_NUMBER);
             expect(paymentSuccessfulPage.getAmount()).toContain(AMOUNT);
             expect(paymentSuccessfulPage.getCardType()).toContain(CARD_TYPE);
             expect(paymentSuccessfulPage.getCardNumber()).toContain("************0800");

             paymentSuccessfulPage.clickCustomerEmailButton();
             paymentSuccessfulPage.enterEmailAddress("andrew.hoard@bt.com");
             paymentSuccessfulPage.sendEmailButton();

             expect(paymentSuccessfulPage.getEmailSuccessful()).toContain("Thank you, confirmation email sent");
         });
     });

     }),

    it('A invalid email address must be entered', function () {

        var ACCOUNT_NUMBER = 'GB02533877';

        var makePaymentEnterBacPage = new MakePaymentEnterBacPage();
        var makePaymentEnterAmountPage = new MakePaymentEnterAmountPage();

        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.clickLoggedOutMakePaymentButton();

        makePaymentEnterBacPage.enterBac(ACCOUNT_NUMBER);
        makePaymentEnterBacPage.enterReenterBac(ACCOUNT_NUMBER);

        makePaymentEnterBacPage.clickContinueButton().then(function () {

            var AMOUNT = "12.99";
            makePaymentEnterAmountPage.enterAmount(AMOUNT);

            makePaymentEnterAmountPage.clickSubmitButton().then(function () {

                //  Enter card details into Thistle
                var thistlePageTester = new ThistlePageTester();
                thistlePageTester.useValidCard();

                var paymentSuccessfulPage = new PaymentSuccessfulPage();

                browser.sleep(3000);

                expect(paymentSuccessfulPage.getSuccessMessage()).toContain("Thank you for your payment");

                var CARD_TYPE = "VISA";
                var ACCOUNT_NUMBER = "Account Number GB0253****";

                expect(paymentSuccessfulPage.getAccountNumber()).toContain(ACCOUNT_NUMBER);
                expect(paymentSuccessfulPage.getAmount()).toContain(AMOUNT);
                expect(paymentSuccessfulPage.getCardType()).toContain(CARD_TYPE);
                expect(paymentSuccessfulPage.getCardNumber()).toContain("************0800");

                paymentSuccessfulPage.clickCustomerEmailButton();
                paymentSuccessfulPage.enterEmailAddress("andrew.hoard.bt.com");

                // TODO: Fix error - TypeError: Object [object Object] has no method 'toBe'
                //paymentSuccessfulPage.assertEmailButtonIsEnabled();
            });
        });
    })
});
