var LandingPage = require("../../../landingPage.js");
var AgentHomePage = require("../../../agentHomePage.js");
var MakePaymentEnterAmountPage = require("../pages/makePaymentEnterAmountPage.js");
var ThistlePageTester = require("./../../../common/thistlePageTester.js");
var PaymentSuccessfulPage = require("../pages/paymentSuccessfulPage.js");
var PaymentFailurePage = require("../pages/paymentFailurePage.js");

describe("MAKE PAYMENT - AGENT", function() {

    it('A minimum amount must be enforced if there is no final bill received and there should be a warning if amount is less than outstanding balance',function() {

        var makePaymentEnterAmountPage = new MakePaymentEnterAmountPage();

        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535714");
        landingPage.clickAgentButton();

        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentMakePayment();

        // Validate the minimum amount entered
        // * Syntax error (assuming this means non number)
        // * Amount lower than minimum
        makePaymentEnterAmountPage.enterAmount("asdf");
        expect(makePaymentEnterAmountPage.getAmountError()).toContain("The amount must be a currency value, with pounds and pence separated by a decimal point.");

        makePaymentEnterAmountPage.enterAmount("0.99");
        expect(makePaymentEnterAmountPage.getMinimumAmountError()).toContain("Please enter an amount higher than £1.00");

        makePaymentEnterAmountPage.enterAmount("1.00");
        expect(makePaymentEnterAmountPage.getOutstandingBalanceWarning()).toContain("Please note, by reducing the amount you will not be paying off your outstanding balance");


        makePaymentEnterAmountPage.enterAmount("3.14");
        expect(makePaymentEnterAmountPage.getOutstandingBalanceWarning()).toContain("");
    }),

    it('Should go to the thistle pay page if all details entered are correct',function() {

        var AMOUNT = '50.00';

        var makePaymentEnterAmountPage = new MakePaymentEnterAmountPage();

        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535714");
        landingPage.enterAgentDN("1234567890");
        landingPage.enterAgentEIN("123456789");
        landingPage.clickAgentButton();

        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentMakePayment();

        makePaymentEnterAmountPage.enterAmount(AMOUNT);

        makePaymentEnterAmountPage.clickSubmitButton().then(function() {

            //  Enter card details into Thistle
            var thistlePageTester = new ThistlePageTester();
            thistlePageTester.useValidCard();

            var paymentSuccessfulPage = new PaymentSuccessfulPage();

            expect(paymentSuccessfulPage.getSuccessMessage()).toContain("Thank you for your payment");

            var CARD_TYPE = "VISA";
            var ACCOUNT_NUMBER = "Account Number GB0253****";

            expect(paymentSuccessfulPage.getAccountNumber()).toContain(ACCOUNT_NUMBER);
            expect(paymentSuccessfulPage.getAmount()).toContain(AMOUNT);
            expect(paymentSuccessfulPage.getCardType()).toContain(CARD_TYPE);
            expect(paymentSuccessfulPage.getCardNumber()).toContain("************0800");

            paymentSuccessfulPage.clickEmailButton();
        });
    }),

    it('Payment failed page should be displayed',function() {

        var AMOUNT = '50.00';

        var makePaymentEnterAmountPage = new MakePaymentEnterAmountPage();

        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535714");
        landingPage.enterAgentDN("1234567890");
        landingPage.enterAgentEIN("123456789");
        landingPage.clickAgentButton();

        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentMakePayment();

        makePaymentEnterAmountPage.enterAmount(AMOUNT);

        makePaymentEnterAmountPage.clickSubmitButton().then(function() {

            //  Enter card details into Thistle
            var thistlePageTester = new ThistlePageTester();
            thistlePageTester.useInvalidCard();
            thistlePageTester.enterSecurityCode();
            thistlePageTester.enterSecurityCode();
            thistlePageTester.enterSecurityCode();
            thistlePageTester.enterSecurityCode();
            thistlePageTester.enterSecurityCode();

            var paymentFailurePage = new PaymentFailurePage();

            expect(paymentFailurePage.getTitle()).toContain("Your payment has failed too many times");
            expect(paymentFailurePage.getSubTitle()).toContain("For security reasons we cannot allow you to retry the payment");
        });
    })
});
