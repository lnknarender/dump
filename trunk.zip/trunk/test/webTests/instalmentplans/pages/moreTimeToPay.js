var MoreTimeToPayPage = (function () {

    function MoreTimeToPayPage() {
        this.title = element(By.id("title"));
        this.setupDDButton = element(By.id("setupDD"));
        this.setupMPButton = element(By.id("setupMP"));
        this.setupCCRAButton = element(By.id("setupCCRA"));
        this.spreadYourPaymentsButton = element(By.id("spreadpaymentbuttonagent"));
        this.backButton = element(By.id("backBtn"));
        this.datepicker = element(By.id("datepicker"));
        this.instalmentPlanHistoryTable = element(By.id("instalmentPlanHistoryTable"));
    }

    MoreTimeToPayPage.prototype.getTitle = function () {
        return this.title.getText();
    };

    MoreTimeToPayPage.prototype.clickSetupDDButton = function () {
        return this.setupDDButton.click();
    };

    MoreTimeToPayPage.prototype.clickSetupMPButton = function () {
        return this.setupMPButton.click();
    };

    MoreTimeToPayPage.prototype.clickSetupCCRAButton = function () {
        return this.setupCCRAButton.click();
    };

    MoreTimeToPayPage.prototype.clickSpreadYourPaymentsButton = function () {
        return this.spreadYourPaymentsButton.click();
    };

    MoreTimeToPayPage.prototype.clickBackButton = function () {
        return this.backButton.click();
    };

    MoreTimeToPayPage.prototype.clickDatePicker = function () {
        return this.datepicker.click();
    };

    MoreTimeToPayPage.prototype.visitPage = function () {
        browser.get("http://consumer.bt.com/static/bpta/index.html#/moretimetopay?bac=GB02535713&cak=ACC_002&conk=002");

     }

    /*
    parameter month:
     0 - current month
     1 - next month
     2 - in 2 months from current month
     3 - in 3 months from current month
     */
    MoreTimeToPayPage.prototype.selectDateWithParameter = function (dateofTheMonth, month) {

        this.datepicker.click();

        for (month; month > 0; month--) {
            this.calendarXpath = element(By.xpath(".//*[@id='ui-datepicker-div']/div/a[2]/span")).click();
        }

       this.calendarXpath = element(By.xpath("//td[not(contains(@class,'ui-datepicker-other-month'))]/a[text()='" + dateofTheMonth + "']"));
       this.calendarXpath.click();
    }

    MoreTimeToPayPage.prototype.getNumberOfRowsInRepaymentHistoryTable = function () {

        var rows = element.all(by.repeater('repaymentHistory in repaymentHistory'));

        // print the number of rows
        console.log(rows.count().then(function(inputValue) { console.log(inputValue); }));
        return rows.count();
    }


    MoreTimeToPayPage.prototype.getValueFromTable = function (columnName, rowNumber) {

        // print actual value
        element(By.id(columnName + '_' + rowNumber)).getText().then(function(inputValue){console.log(inputValue);});

        return element(By.id(columnName +"_" + rowNumber)).getText();

    }

    return MoreTimeToPayPage;

})();

module.exports = MoreTimeToPayPage;


