var InstalmentPlanFailedPage = (function () {
    function InstalmentPlanFailedPage() {
        this.title = element(By.id("title"));
        this.outstandingAmount = element(By.id("outstandingAmount"));
        this.status = element(By.id("status"));
        this.backButton = element(By.id("backBtn"));
        this.makePaymentButton = element(By.id("makePaymentBtn"));
    }

    InstalmentPlanFailedPage.prototype.getTitle = function () {
        return this.title.getText();
    };

    InstalmentPlanFailedPage.prototype.getOutstandingAmount = function () {
        return this.outstandingAmount.getText();
    };

    InstalmentPlanFailedPage.prototype.getStatus = function () {
        return this.status.getText();
    };

    InstalmentPlanFailedPage.prototype.clickMakePaymentButton = function () {
        return this.makePaymentButton.click();
    };

    InstalmentPlanFailedPage.prototype.clickBackButton = function () {
        return this.backButton.click();
    };

    return InstalmentPlanFailedPage

})();

module.exports = InstalmentPlanFailedPage;
