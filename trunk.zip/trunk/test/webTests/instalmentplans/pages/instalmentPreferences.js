var instalmentPlanPreferencesPage = (function () {

    function instalmentPlanPreferencesPage() {
        this.amountToPayTextBox = element(By.id("amountToPay"));
        this.frequencyOfPaymentDropdown = element(By.id("frequencyOfPayment"));
        this.dateToPayCalendar = element(By.id("dateToPay"));
        this.viewInstalmentPlanButton = element(By.id("previewPlan"));
        this.nextButton = element(By.id("next"));
        this.payframe = element(By.name("payframe"));

    }

    instalmentPlanPreferencesPage.prototype.clickAmountToPayTextBox = function () {
        return this.amountToPayTextBox.click();
    };

    instalmentPlanPreferencesPage.prototype.clickFrequencyOfPaymentDropdown = function () {
        return this.frequencyOfPaymentDropdown.click();
    };

    instalmentPlanPreferencesPage.prototype.clickDateToPayCalendar = function () {
        return this.dateToPayCalendar.click();
    };

    instalmentPlanPreferencesPage.prototype.clickInstalmentPlanButton = function () {
        return this.viewInstalmentPlanButton.click();
    };

    instalmentPlanPreferencesPage.prototype.clickNextButton = function () {
        return this.nextButton.click();
    };

    instalmentPlanPreferencesPage.prototype.selectDateWithParameter = function (dateofTheMonth) {
        this.datepicker.click();
        this.calendarXpath = element(By.xpath("//td[not(contains(@class,'ui-datepicker-other-month'))]/a[text()='" + dateofTheMonth + "']"));
        this.calendarXpath.click();
    }



    instalmentPlanPreferencesPage.prototype.selectStartDateWithParameter = function (dateofTheMonth, month) {

        this.dateToPayCalendar.click();

        for (month; month > 0; month--) {
            this.calendarXpath = element(By.xpath(".//*[@id='ui-datepicker-div']/div/a[2]/span")).click();
        }

        this.calendarXpath = element(By.xpath("//td[not(contains(@class,'ui-datepicker-other-month'))]/a[text()='" + dateofTheMonth + "']"));
        this.calendarXpath.click();
    }



    return instalmentPlanPreferencesPage


})();

module.exports = instalmentPlanPreferencesPage;

