var InstalmentPlanOpenPage = (function () {
    function InstalmentPlanOpenPage() {
        this.title = element(By.id("title"));
        this.outstandingAmount = element(By.id("outstandingAmount"));
        this.status = element(By.id("status"));
        this.backButton = element(By.id("backBtn"));
        this.makePaymentButton = element(By.id("makePaymentBtn"));
    }

    InstalmentPlanOpenPage.prototype.getTitle = function () {
        return this.title.getText();
    };

    InstalmentPlanOpenPage.prototype.getOutstandingAmount = function () {
        return this.outstandingAmount.getText();
    };

    InstalmentPlanOpenPage.prototype.getStatus = function () {
        return this.status.getText();
    };

    InstalmentPlanOpenPage.prototype.clickMakePaymentButton = function () {
        return this.makePaymentButton.click();
    };

    InstalmentPlanOpenPage.prototype.clickBackButton = function () {
        return this.backButton.click();
    };

    return InstalmentPlanOpenPage

})();

module.exports = InstalmentPlanOpenPage;
