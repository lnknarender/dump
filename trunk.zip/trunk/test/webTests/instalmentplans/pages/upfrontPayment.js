/**
 * Created by Yo on 4/20/15.
 */
var UpfrontPaymentPage = (function () {

    function UpfrontPaymentPage() {
        this.paymentAmountStr = element(By.id("paymentAmountStr"));

    }

    UpfrontPaymentPage.prototype.getPaymentAmountStr = function() {
        return this.paymentAmountStr.getText();
    };


    return UpfrontPaymentPage


})();

module.exports = UpfrontPaymentPage;

