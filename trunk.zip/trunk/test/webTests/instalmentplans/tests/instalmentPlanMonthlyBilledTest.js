/**
 * Created by dev on 4/14/15.
 */

var LandingPage = require("../../../landingPage.js");
var AgentHomePage = require("../../../agentHomePage.js");
var MoreTimeToPay = require("./../pages/moreTimeToPay.js");

describe("Instalment Plan monthly billed Test", function() {

    it('Scenario: Check instalment plan for monthly billed customer',function() {

        console.log("Scenario: Check values in instalment plan history table for one entity");

        //  Landing page
        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535725");
        landingPage.clickAgentButton();

        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentInstalmentPlan();

        //  Select a date
        var moreTimeToPay = new MoreTimeToPay();
        moreTimeToPay.clickDatePicker();

        browser.sleep(6000);
    })
});