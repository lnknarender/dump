/**
 * Created by dev on 4/14/15.
 */

var LandingPage = require("../../../landingPage.js");
var AgentHomePage = require("../../../agentHomePage.js");
var MoreTimeToPay = require("./../pages/moreTimeToPay.js");


describe("Instalment Plan History Test", function() {
    it('Scenario: Check values in instalment plan history table for one entity',function(){

        console.log("Scenario: Check values in instalment plan history table for one entity");

        var moreTimeToPay = new MoreTimeToPay();

        //  Landing page
        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535722");
        landingPage.clickAgentButton();
        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentInstalmentPlan();

        browser.sleep(600);

        console.log("WHEN I select 20th date of the next month");
        moreTimeToPay.selectDateWithParameter(21, 1);

        browser.sleep(600);

        console.log("WHEN I proceed with 'Spread your payment' option");
        moreTimeToPay.clickSpreadYourPaymentsButton();

        browser.sleep(1000);

        expect(moreTimeToPay.getNumberOfRowsInRepaymentHistoryTable()).toEqual(1);

        console.log("Then compare the Instalment Plan History");

        /*The values for current cak, conk and back should be:
         Date Requested: 09/02/2015
         Value of Bill: £74.23
         Number of Instalments: 1
         All Payments Made?: No
         Date Completed: 09/02/2015
         Post Instalment Plan Follow-up Actions?: [""]
        */

        browser.sleep(600);

        expect(moreTimeToPay.getValueFromTable('requestedDate', 0)).toEqual('09/02/2015');
        expect(moreTimeToPay.getValueFromTable('amount', 0)).toEqual('£74.23');
        expect(moreTimeToPay.getValueFromTable('instalments', 0)).toEqual('1');
        expect(moreTimeToPay.getValueFromTable('allPaymentsMade', 0)).toEqual('No');
        expect(moreTimeToPay.getValueFromTable('completedDate', 0)).toEqual('09/02/2015');

    });
    it('Scenario: Check values in instalment plan history table for 2 entities',function(){

        console.log("Scenario: Check values in instalment plan history table for two entities");

        var moreTimeToPay = new MoreTimeToPay();

        //  Landing page
        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535721");
        landingPage.clickAgentButton();
        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentInstalmentPlan();

        browser.sleep(600);

        console.log("WHEN I select 20th date in 2 months");
        moreTimeToPay.selectDateWithParameter(11, 1);

        browser.sleep(600);


        console.log("WHEN I proceed with 'Spread your payment' option");
        moreTimeToPay.clickSpreadYourPaymentsButton();

        browser.sleep(1000);

        expect(moreTimeToPay.getNumberOfRowsInRepaymentHistoryTable()).toEqual(2);

        console.log("Then compare the Instalment Plan History");

        /*The values for current cak, conk and back should be:
         1st instalment:
            Date Requested: 09/02/2015
            Value of Bill: £74.23
            Number of Instalments: 1
            All Payments Made?: No
            Date Completed: 09/02/2015

          2nd instalment:
            Date Requested: 09/02/2015
            Value of Bill: £74.23
            Number of Instalments: 1
            All Payments Made?: No
            Date Completed: 09/02/2015

         */

        browser.sleep(600);

        expect(moreTimeToPay.getValueFromTable('requestedDate', 0)).toEqual('09/02/2015');
        expect(moreTimeToPay.getValueFromTable('amount', 0)).toEqual('£74.23');
        expect(moreTimeToPay.getValueFromTable('instalments', 0)).toEqual('1');
        expect(moreTimeToPay.getValueFromTable('allPaymentsMade', 0)).toEqual('No');
        expect(moreTimeToPay.getValueFromTable('completedDate', 0)).toEqual('09/02/2015');

        expect(moreTimeToPay.getValueFromTable('requestedDate', 1)).toEqual('09/02/2014');
        expect(moreTimeToPay.getValueFromTable('amount', 1)).toEqual('£100.23');
        expect(moreTimeToPay.getValueFromTable('instalments', 1)).toEqual('2');
        expect(moreTimeToPay.getValueFromTable('allPaymentsMade', 1)).toEqual('No');
        expect(moreTimeToPay.getValueFromTable('completedDate', 1)).toEqual('09/02/2015');

    });
});

