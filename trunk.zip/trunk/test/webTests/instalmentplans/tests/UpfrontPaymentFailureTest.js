/**
 * Created by Yo on 4/20/15.
 */


var LandingPage = require("../../../landingPage.js");
var AgentHomePage = require("../../../agentHomePage.js");
var MoreTimeToPay = require("./../pages/moreTimeToPay.js");
var InstalmentPlanPreferencesPage = require("./../pages/instalmentPreferences.js")
var UpfrontPaymentPage = require("./../pages/upfrontPayment.js");
var ThistlePageTester = require("./../../../common/thistlePageTester.js")


describe("As a Customer/Advisor I want to make an upfront payment", function() {
//    var ptor, driver;
//    ptor = protractor.getInstance();
//    driver = ptor.driver;


    it('Scenario: 1  Customer failed making payment for three times',function(){

        console.log("Scenario: 1  Customer failed making payment for three times");
        var moreTimeToPay = new MoreTimeToPay();
        var instalmentPreferencesPage = new InstalmentPlanPreferencesPage();
        var upfrontPaymentPage = new UpfrontPaymentPage();
        var thistlePageTester = new ThistlePageTester();

        //  Landing page
        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535722");
        landingPage.clickAgentButton();
        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentInstalmentPlan();

        browser.sleep(600);

        console.log("WHEN I select 30th date of the current month");
        moreTimeToPay.selectDateWithParameter(30,0);

        browser.sleep(600);

        console.log("WHEN I proceed with 'Spread your payment' option");
        moreTimeToPay.clickSpreadYourPaymentsButton();

        browser.sleep(1000);

        console.log("WHEN I select 23rd date of the current month");
        instalmentPreferencesPage.selectStartDateWithParameter(23,0);

        console.log("WHEN I click view instalment plan and next");
        instalmentPreferencesPage.clickInstalmentPlanButton();
        instalmentPreferencesPage.clickNextButton();


        browser.sleep(5000);
        expect(upfrontPaymentPage.getPaymentAmountStr()).toContain('Amount:£55.13');


        expect(element(by.id("payform")).isDisplayed()).toBe(true);
        expect(element(by.id("payframe")).isDisplayed()).toBe(true);

        browser.switchTo().frame("payframe");

        thistlePageTester.testThistlePage("userName", "VISA", "4912340400304111", "12", "2025", "111", "Ty Cynnal", "CF11 0SW");

        browser.driver.findElement(protractor.By.id('submitBtn')).click();

        thistlePageTester.testThistlePage("userName", "VISA", "4912340400304111", "12", "2025", "111", "Ty Cynnal", "CF11 0SW");

        browser.driver.findElement(protractor.By.id('submitBtn')).click();

        thistlePageTester.testThistlePage("userName", "VISA", "4912340400304111", "12", "2025", "111", "Ty Cynnal", "CF11 0SW");

        browser.driver.findElement(protractor.By.id('submitBtn')).click();

        browser.switchTo().defaultContent();

        browser.waitForAngular();


    })
});