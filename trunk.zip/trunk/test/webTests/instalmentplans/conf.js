var helper = require('../../helper.js');

exports.config={
    seleniumAddress:'http://127.0.0.1:4444/wd/hub',
    capabilities: {
        'browserName': 'firefox',
        proxy: {
            proxyType: 'manual',
            httpProxy: 'http://proxy.intra.bt.com:8080',
            sslProxy: 'http://proxy.intra.bt.com:8080'
        }
    },
    seleniumArgs: [
        "-Dwebdriver.firefox.profile=bdnt4eer.default"
    ],


    specs: [//'./tests/InstalmentPlanHistoryTest.js',
            './tests/UpfrontPaymentFailureTest.js'],

    getMultiCapabilities: helper.getFirefoxProfile,

 //   specs: ['./tests/TrySanityTest.js'],

    jasmineNodeOpts: {
        onComplete: null,
        isVerbose: false,
        showColors: true,
        includeStackTrace: false
    }
}

console.log("BAC -> GB02535713 -> Format     -> Blue Bill");
console.log("                     Language   -> English");
console.log("                     Bill Media -> Paper Free");
console.log("");
console.log("BAC -> GB02535715 -> Format                -> Blue Bill");
console.log("                     Language              -> English");
console.log("                     Bill Media            -> Paper Free");
console.log("                     InstalmentPlan Status -> Defaulted");
console.log("");
console.log("BAC -> GB02535721 -> Format                -> Blue Bill");
console.log("                     Language              -> English");
console.log("                     Bill Media            -> Paper Free");
console.log("                     InstalmentPlan Status -> Complete");
console.log("                     Bill Frequency -> Monthly");
console.log("");
console.log("BAC -> GB02535722 -> Format     -> Blue Bill");
console.log("                     Language   -> English");
console.log("                     Bill Media -> Paper Free");
console.log("                     InstalmentPlan Status -> Complete");
console.log("                     Bill Frequency -> Quarterly");
console.log("");
console.log("BAC -> GB02533877 -> Format     -> Blue Bill");
console.log("                     Language   -> English");
console.log("                     Bill Media -> Paper Free");
console.log("");
console.log("BAC -> GB02536943 -> Format     -> Blue Bill");
console.log("                     Language   -> English");
console.log("                     Bill Media -> Dual");
console.log("");
console.log("BAC -> GB02534856 -> Format     -> Braille Bill");
console.log("                     Language   -> English");
console.log("                     Bill Media -> Dual");

