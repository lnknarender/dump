var ManageBillPrefsConfirmationPage = (function () {
    function ManageBillPrefsConfirmationPage() {

        this.heading1 = element(By.id("heading_1"));
        this.addressLine1 = element(By.id("addressLine1"));
        this.postTown = element(By.id("postTown"));
        this.country = element(By.id("country"));
        this.postCode = element(By.id("postCode"));

        this.impairmentWarning = element(By.id("heading_impairment"));

        this.finishButton = element(By.id("finishBtn"));
    }

    ManageBillPrefsConfirmationPage.prototype.getHeading1 = function () {
        return this.heading1.getText();
    };

    ManageBillPrefsConfirmationPage.prototype.getAddressLine1 = function () {
        return this.addressLine1.getText();
    };

    ManageBillPrefsConfirmationPage.prototype.getPostTown = function () {
        return this.postTown.getText();
    };

    ManageBillPrefsConfirmationPage.prototype.getCountry = function () {
        return this.country.getText();
    };

    ManageBillPrefsConfirmationPage.prototype.getPostCode = function () {
        return this.postCode.getText();
    };

    ManageBillPrefsConfirmationPage.prototype.getImpairmentWarning = function () {
        return this.impairmentWarning.getText();
    };



    ManageBillPrefsConfirmationPage.prototype.isImpairmentHeadingPresent = function () {
        return this.impairmentWarning.isElementPresent()
    };


    //ManageBillPrefsConfirmationPage.prototype.isHeadingTwoDayWarningVisible = function () {
    //    return element(By.id("heading_twoDayWarning")).isPresent();
    //};

    ManageBillPrefsConfirmationPage.prototype.clickFinishButton = function () {
        return this.finishButton.click();
    };

    return ManageBillPrefsConfirmationPage;

})();

module.exports = ManageBillPrefsConfirmationPage;



