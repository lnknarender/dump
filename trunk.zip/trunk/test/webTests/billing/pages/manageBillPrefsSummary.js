var ManageBillPrefsSummaryPage = (function () {
    function ManageBillPrefsSummaryPage() {

        this.billMedia = element(By.id("billMedia"));
        this.billFormat = element(By.id("billFormat"));
        this.language = element(By.id("language"));
        this.newBillMedia = element(By.id("newBillMedia"));
        this.allChargesText = element(By.id("chargeAcceptBoxLabel"));

        this.previousButton = element(By.id("previousManagePrefsBtn"));
        this.cancelButton= element(By.id("cancelManagePrefsBtn"));
        this.submitButton = element(By.id("submitManagePrefsBtn"));
    }

    ManageBillPrefsSummaryPage.prototype.getSubHeading_1 = function () {
        return this.subHeading_1.getText();
    };

    ManageBillPrefsSummaryPage.prototype.getPreviousFormat = function () {
        return this.previousFormat.getText();
    };

    ManageBillPrefsSummaryPage.prototype.getPreviousBillMedia = function () {
        return this.previousBillMedia.getText();
    };

    ManageBillPrefsSummaryPage.prototype.getNewFormat = function () {
        return this.newFormat.getText();
    };

    ManageBillPrefsSummaryPage.prototype.getNewBillMedia = function () {
        return this.newBillMedia.getText();
    };

    ManageBillPrefsSummaryPage.prototype.getAllCharges = function () {
        return this.allChargesText.getText();
    };

    ManageBillPrefsSummaryPage.prototype.clickReceiveBillsOnline = function () {
        this.receiveBillsOnline.click();
    };

    ManageBillPrefsSummaryPage.prototype.clickCancelButton = function () {
        return this.cancelButton.click();
    };

    ManageBillPrefsSummaryPage.prototype.isPresentCancelButton = function () {
        return this.cancelButton.isPresent();
    };

    ManageBillPrefsSummaryPage.prototype.clickPreviousButton = function () {
        this.previousButton.click();
    };

    ManageBillPrefsSummaryPage.prototype.clickSubmitButton = function () {
        return this.submitButton.click();
    };

    ManageBillPrefsSummaryPage.prototype.isPresentSubmitButton = function () {
        return this.submitButton.isPresent();
    };

    return ManageBillPrefsSummaryPage;

})();

module.exports = ManageBillPrefsSummaryPage;


