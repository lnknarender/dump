var ViewBillPrefsPage = (function () {
    function ViewBillPrefsPage() {

        this.title = element(By.id("title"));
        this.mediaSprite = element(By.id("mediaSprite"));
        this.formatSprite = element(By.id("formatSprite"));
        this.billMedia = element(By.id("billMedia"));
        this.billFormat = element(By.id("billFormat"));
        this.language = element(By.id("language"));
        this.changeBillPrefsButton = element(By.id("changePrefsBtn"));
        this.sucessConditionData = element(By.id("condition-date"));
    }

    ViewBillPrefsPage.prototype.getSucessConditionData = function () {
        return this.sucessConditionData.getText();
    };

    ViewBillPrefsPage.prototype.getTitle = function () {
        return this.title.getText();
    };

    ViewBillPrefsPage.prototype.getMediaSprite = function () {
        return this.mediaSprite;
    };

    ViewBillPrefsPage.prototype.getFormatSprite = function () {
        return this.formatSprite;
    };

    ViewBillPrefsPage.prototype.getBillMedia = function () {
        return this.billMedia.getText();
    };

    ViewBillPrefsPage.prototype.getBillFormat = function () {
        return this.billFormat.getText();
    };

    ViewBillPrefsPage.prototype.getLanguage = function () {
        return this.language.getText();
    };

    ViewBillPrefsPage.prototype.clickChangeBillPrefsButton = function () {
        return this.changeBillPrefsButton.click();
    };

    ViewBillPrefsPage.prototype.isPostChargesDisplayed = function () {
        return expect(this.charges.getText()).toContain('You can have your bills sent by post, however you might be charged a £1.50 fee to cover costs such as printing and postage.');
    };

    ViewBillPrefsPage.prototype.getExpectedMediaOnlineAndPostText = function () {
        return "Online and by Post";
    };

    ViewBillPrefsPage.prototype.getExpectedMediaOnlineText = function () {
        return "Online";
    };

    ViewBillPrefsPage.prototype.getExpectedMediaInThePostText = function () {
        return "Paper";
    };
    ViewBillPrefsPage.prototype.getExpectedFormatStandardText = function () {
        return "Standard";
    };
    ViewBillPrefsPage.prototype.getExpectedFormatLargePrintText = function () {
        return "Large-Print";
    };

    ViewBillPrefsPage.prototype.getExpectedFormatBrailleBillText = function () {
        return "Braille Bill";
    };
    ViewBillPrefsPage.prototype.getExpectedFormatAudioCDText = function () {
        return "Audio CD";
    };

    ViewBillPrefsPage.prototype.getExpectedLanguageEnglishText = function () {
        return "English";
    };
    ViewBillPrefsPage.prototype.getExpectedLanguageWelshText = function () {
        return "Welsh";
    };
    return ViewBillPrefsPage

})();

module.exports = ViewBillPrefsPage;
