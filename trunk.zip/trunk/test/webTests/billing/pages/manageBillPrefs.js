var ManageBillPrefsPage = (function () {

    function ManageBillPrefsPage() {
        //  Radio buttons
        this.post = element(By.id("postRadio"));
        this.online = element(By.id("onlineRadio"));
        this.onlineAndPost = element(By.id("onlineAndPostRadio"));
        this.blueBill =element(By.id("Blue Bill"));
        this.largePrint =element(By.id("Large-Print"));
        this.brailleBill =element(By.id("Braille Bill"));
        this.audioCD =element(By.id("Audio CD"));
        this.english =element(By.id("english"));
        this.welsh =element(By.id("welsh"));


        //  Buttons
        this.backButton= element(By.id("back"));
        this.continueButton = element(By.id("continue"));


        this.billMedia = element('input[ng-model="modifyBillAccountDetails.media"]');
        this.billFormat = element('input[ng-model="modifyBillAccountDetails.format"]');
        this.language = element('input[ng-model="modifyBillAccountDetails.language"]');
    }
    /*
     Narender code start
     */

    ManageBillPrefsPage.prototype.isBillMediaChecked = function () {
        return this.billMedia.prop("checked")=="checked"?true:false;
    };
    ManageBillPrefsPage.prototype.isBillFormatChecked = function () {
        return this.billFormat.prop("checked")=="checked"?true:false;
    };
    ManageBillPrefsPage.prototype.isLanguageChecked = function () {
        return this.language.prop("checked")=="checked"?true:false;
    };
    ManageBillPrefsPage.prototype.isEnabledPost = function () {
        return this.post.isEnabled();
    };

    ManageBillPrefsPage.prototype.clickPost = function () {
        return this.post.click();
    };
    ManageBillPrefsPage.prototype.isSelectedPost = function () {
        return this.post.prop("checked")=="checked"?true:false;
    };
    ManageBillPrefsPage.prototype.getPost = function () {
        return this.post;
    };
    ManageBillPrefsPage.prototype.isEnabledOnline = function () {
        return this.online.isEnabled();
    };

    ManageBillPrefsPage.prototype.clickOnline = function () {
        return this.online.click();
    };
    ManageBillPrefsPage.prototype.isSelectedOnline = function () {
        return this.online.prop("checked")=="checked"?true:false;
    };
    ManageBillPrefsPage.prototype.getOnline = function () {
        return this.online;
    };
    ManageBillPrefsPage.prototype.isEnabledOnlineAndPost = function () {
        return this.onlineAndPost.isEnabled();
    };

    ManageBillPrefsPage.prototype.clickOnlineAndPost = function () {
        return this.onlineAndPost.click();
    };
    ManageBillPrefsPage.prototype.isSelectedOnlineAndPost = function () {
        return this.onlineAndPost.is;
    };
    ManageBillPrefsPage.prototype.getOnlineAndPost = function () {
        return this.onlineAndPost;
    };
    ManageBillPrefsPage.prototype.isEnabledBlueBill = function () {
        return this.blueBill.isEnabled();
    };

    ManageBillPrefsPage.prototype.clickBlueBill = function () {
        return this.blueBill.click();
    };
    ManageBillPrefsPage.prototype.isSelectedBlueBill = function () {
        return this.blueBill.prop("checked")=="checked"?true:false;
    };
    ManageBillPrefsPage.prototype.getBlueBill = function () {
        return this.blueBill;
    };
    ManageBillPrefsPage.prototype.isEnabledLargePrint = function () {
        return this.largePrint.isEnabled();
    };

    ManageBillPrefsPage.prototype.clickLargePrint = function () {
        return this.largePrint.click();
    };
    ManageBillPrefsPage.prototype.isSelectedLargePrint  = function () {
        return this.largePrint.prop("checked")=="checked"?true:false;
    };
    ManageBillPrefsPage.prototype.getLargePrint  = function () {
        return this.largePrint;
    };
    ManageBillPrefsPage.prototype.isEnabledBrailleBill = function () {
        return this.brailleBill.isEnabled();
    };

    ManageBillPrefsPage.prototype.clickBrailleBill = function () {
        return this.brailleBill.click();
    };
    ManageBillPrefsPage.prototype.isSelectedBrailleBill  = function () {
        return this.brailleBill.prop("checked")=="checked"?true:false;
    };
    ManageBillPrefsPage.prototype.getBrailleBill  = function () {
        return this.brailleBill;
    };
    ManageBillPrefsPage.prototype.isEnabledAudioCD = function () {
        return this.audioCD.isEnabled();
    };

    ManageBillPrefsPage.prototype.clickAudioCD = function () {
        return this.audioCD.click();
    };
    ManageBillPrefsPage.prototype.isSelectedAudioCD  = function () {
        return this.audioCD.prop("checked")=="checked"?true:false;
    };
    ManageBillPrefsPage.prototype.getAudioCD  = function () {
        return this.audioCD;
    };
    ManageBillPrefsPage.prototype.isEnabledEnglish = function () {
        return this.english.isEnabled();
    };

    ManageBillPrefsPage.prototype.clickEnglish = function () {
        return this.english.click();
    };
    ManageBillPrefsPage.prototype.isSelectedEnglish = function () {
        return this.english.isSelected();
    };
    ManageBillPrefsPage.prototype.getEnglish  = function () {
        return this.english;
    };
    ManageBillPrefsPage.prototype.isEnabledWelsh = function () {
        return this.welsh.isEnabled();
    };

    ManageBillPrefsPage.prototype.clickWelsh= function () {
        return this.welsh.click();
    };
    ManageBillPrefsPage.prototype.isSelectedWelsh = function () {
        return this.welsh.prop("checked")=="checked"?true:false;
    };
    ManageBillPrefsPage.prototype.getWelsh  = function () {
        return this.welsh;
    };
    /*
     Narender code end
     */
    ManageBillPrefsPage.prototype.clickBackButton = function () {
        return this.backButton.click();
    };

    ManageBillPrefsPage.prototype.clickContinueButton = function () {
        return this.continueButton.click();
    };

    ManageBillPrefsPage.prototype.getContinueButton = function () {
        return this.continueButton;
    };

    ManageBillPrefsPage.prototype.isEnabledContinueButton = function () {
        return this.continueButton.isEnabled();
    }

    return ManageBillPrefsPage;

})();

module.exports = ManageBillPrefsPage;

