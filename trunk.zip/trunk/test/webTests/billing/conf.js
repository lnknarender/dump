exports.config={
    seleniumAddress:'http://127.0.0.1:4444/wd/hub',
    capabilities: {
        'browserName': 'firefox',
        proxy: {
            proxyType: 'manual',
            httpProxy: 'http://proxy.intra.bt.com:8080',
            sslProxy: 'http://proxy.intra.bt.com:8080'
        }
    },
    seleniumArgs: [
        "-Dwebdriver.firefox.profile=bdnt4eer.default"
    ],

    specs: ['./tests/*Test.js'],

    jasmineNodeOpts: {
        onComplete: null,
        isVerbose: false,
        showColors: true,
        includeStackTrace: false
    }
}


console.log("BAC -> GB01161170 -> Next bill date -> today (always less than 2 days)");
console.log("");

console.log("Acc Key ->  35713");
console.log("BAC -> GB02535713 -> Format         -> Blue Bill");
console.log("                     Language       -> English");
console.log("                     Bill Media     -> Paper Free");
console.log("                     Payment method -> Direct Debit");
console.log("                     Next bill date -> always greater than 2 days");
console.log("");

console.log("Acc Key ->  35714");
console.log("BAC -> GB02535714->  Format         -> Blue Bill");
console.log("                     Language       -> English");
console.log("                     Bill Media     -> Paper Free");
console.log("                     Payment method -> Cheque/Cash");
console.log("                     charges        -> applicable -> true");
console.log("                     barred         -> Status -> Bill Follow Up");
console.log("                                              -> Installment Defaulted");
console.log("");

console.log("Acc Key ->  35715");
console.log("BAC -> GB02535715 -> Format         -> Blue Bill");
console.log("                     Language       -> English");
console.log("                     Bill Media     -> Paper Free");
console.log("                     Payment method -> Cheque/Cash");
console.log("                     charges        -> applicable -> true");
console.log("                     barred         -> Status -> Bill Follow Up");
console.log("                                              -> Installment Defaulted");
console.log("");

console.log("Acc Key ->  35716");
console.log("BAC -> GB02535716 -> Format         -> Blue Bill");
console.log("                     Language       -> English");
console.log("                     Bill Media     -> Paper");
console.log("                     Payment method -> Cheque/Cash");
console.log("                     charges        -> applicable -> true");
console.log("                     barred         -> Status -> String");
console.log("                                              -> String");
console.log("");

console.log("Acc Key ->  35717");
console.log("BAC -> GB02535717 -> Format         -> Braille");
console.log("                     Language       -> English");
console.log("                     Bill Media     -> Dual");
console.log("                     Payment method -> Cheque/Cash");
console.log("");

console.log("Acc Key ->  35718");
console.log("BAC -> GB02535718 -> Format         -> Blue Bill");
console.log("                     Language       -> English");
console.log("                     Bill Media     -> Paper");
console.log("                     Payment method -> Cheque/Cash");
console.log("                     Status 	 -> Closed");
console.log("                     subStatus 	 -> Pending Termination");
console.log("");

console.log("Acc Key ->  35719");
console.log("BAC -> GB02535719 -> Format         -> Braille");
console.log("                     Language       -> English");
console.log("                     Bill Media     -> Paper");
console.log("                     Payment method -> Cheque/Cash");
console.log("");

console.log("Acc Key ->  42511");
console.log("BAC -> GB02533877 -> Format     -> Blue Bill");
console.log("                     Language   -> English");
console.log("                     Bill Media -> Paper Free");
console.log("                     Active     -> Billing account not active");

console.log("");
console.log("BAC -> GB02536943 -> Format     -> Blue Bill");
console.log("                     Language   -> English");
console.log("                     Bill Media -> Dual");
console.log("");

console.log("Acc Key ->  42360");
console.log("BAC -> GB02534856 -> Format     -> Braille Bill");
console.log("                     Language   -> English");
console.log("                     Bill Media -> Dual");
