var LandingPage = require("../../../landingPage.js");
var CustomerHomePage = require("../../../customerHomePage.js");
var ViewBillPrefsPage = require("./../pages/viewBillPrefs.js");
var ManageBillPrefsPage = require("./../pages/manageBillPrefs.js");
var ManageBillPrefsSummaryPage = require("./../pages/manageBillPrefsSummary.js");

describe("As a Customer I want to change my bill media from Dual to paper-free", function() {

    it('BPTA-63 Scenario: 1 Can the customer change their bill media from paper to dual billing?',function(){

        var viewBillPrefsPage = new ViewBillPrefsPage();
        var manageBillPrefsPage = new ManageBillPrefsPage();
        var manageBillPrefsSummaryPage = new ManageBillPrefsSummaryPage();

        var landingPage = new LandingPage();
        var customerHomePage = new CustomerHomePage();
        landingPage.visitPage();
        landingPage.enterAcckey("35716");
        landingPage.clickCustomerButton();
        customerHomePage.clickCustomerBillPrefs();

        console.log("GIVEN that I am currently on paper billing");
        expect(viewBillPrefsPage.getBillMedia()).toContain(viewBillPrefsPage.getExpectedMediaInThePostText());
        expect(viewBillPrefsPage.getBillFormat()).toContain(viewBillPrefsPage.getExpectedFormatStandardText());
        expect(viewBillPrefsPage.getLanguage()).toContain(viewBillPrefsPage.getExpectedLanguageEnglishText());

        viewBillPrefsPage.clickChangeBillPrefsButton().then(function () {

            console.log("WHEN I select to change my bill media to dual billing");
            manageBillPrefsPage.clickReceiveDual();

            manageBillPrefsPage.clickContinueButton().then(function() {
                console.log("THEN I am shown a summary of the changes ");
                expect(manageBillPrefsSummaryPage.getPreviousBillMedia()).toContain('By post');
                expect(manageBillPrefsSummaryPage.getNewBillMedia()).toContain('Online and by post');

                console.log("AND I can click to confirm ");
                expect(manageBillPrefsSummaryPage.isPresentSubmitButton()).toBe(true);

                console.log("AND I can click to cancel ");
                expect(manageBillPrefsSummaryPage.isPresentCancelButton()).toBe(true);
            })
        });
    }),
    it('BPTA-63 Scenario: 1 Is the customer told that they cannot change their bill media?',function(){

         var viewBillPrefsPage = new ViewBillPrefsPage();
         var manageBillPrefsPage = new ManageBillPrefsPage();
         var manageBillPrefsSummaryPage = new ManageBillPrefsSummaryPage();

         var landingPage = new LandingPage();
         var customerHomePage = new CustomerHomePage();
         landingPage.visitPage();
         landingPage.enterAcckey("35718");
         landingPage.clickCustomerButton();
         customerHomePage.clickCustomerBillPrefs();

         console.log("GIVEN that I am currently on paper billing");
         expect(viewBillPrefsPage.getBillMedia()).toContain(viewBillPrefsPage.getExpectedMediaInThePostText());
         expect(viewBillPrefsPage.getBillFormat()).toContain(viewBillPrefsPage.getExpectedFormatStandardText());
         expect(viewBillPrefsPage.getLanguage()).toContain(viewBillPrefsPage.getExpectedLanguageEnglishText());

         console.log(" WHEN I select to edit my bill preferences ");
         console.log(" AND I am ineligible to change my bill media (this test uses a closed account) ");
         viewBillPrefsPage.clickChangeBillPrefsButton().then(function () {

             console.log("THEN I am told that I cannot change my bill media ");
             expect(manageBillPrefsPage.getBarredAccount()).toContain('It seems your billing account is not active, hence you are not allowed to proceed with bill media changes.');

             console.log("AND I can still make changes to my other bill preferences");
             manageBillPrefsPage.clickStandardWelsh();

             manageBillPrefsPage.clickContinueButton().then(function() {
             expect(manageBillPrefsSummaryPage.getPreviousBillMedia()).toContain('By post');
             expect(manageBillPrefsSummaryPage.getNewBillMedia()).toContain('By post');
             expect(manageBillPrefsSummaryPage.getPreviousFormat()).toContain('Standard Bill - In English');
             expect(manageBillPrefsSummaryPage.getNewFormat()).toContain('Standard Bill - In Welsh');
         })
     });
  })
});

