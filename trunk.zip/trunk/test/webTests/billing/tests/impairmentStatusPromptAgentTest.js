var LandingPage = require("../../../landingPage.js");
var AgentHomePage = require("../../../agentHomePage.js");
var ViewBillPrefsPage = require("./../pages/viewBillPrefs.js");
var ManageBillPrefsPage = require("./../pages/manageBillPrefs.js");
var ManageBillPrefsSummaryPage = require("./../pages/manageBillPrefsSummary.js");
var ManageBillPrefsConfirmationPage = require("./../pages/manageBillPrefsConfirmation.js");

describe("As an Advisor I want to be prompted to update a customer's impairment status if they change their bill media", function() {
    it('BPTA-81 Scenario: 1a Is the advisor prompted to capture an impairment flag? - braille',function(){

        console.log("Scenario: 1a Is the advisor prompted to capture an impairment flag? - switch to braille");

        // Billing preferences page
        var viewBillPrefsPage = new ViewBillPrefsPage();
        var manageBillPrefsPage = new ManageBillPrefsPage();


        //  Landing page
        var landingPage = new LandingPage();
        var agentHomePage = new AgentHomePage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_003");
        landingPage.enterConk("003");
        landingPage.enterBac("0202535713");
        landingPage.clickAgentButton();
        agentHomePage.clickAgentBillPrefs();

        //expect(viewBillPrefsPage.getBillMedia()).toContain(viewBillPrefsPage.getExpectedMediaOnlineText());
        expect(viewBillPrefsPage.getBillFormat()).toContain(viewBillPrefsPage.getExpectedFormatStandardText());
        expect(viewBillPrefsPage.getLanguage()).toContain(viewBillPrefsPage.getExpectedLanguageEnglishText());

        viewBillPrefsPage.clickChangeBillPrefsButton().then(function () {

            expect(manageBillPrefsPage.isSelectedStandardEnglish()).toBeTruthy();

            expect(manageBillPrefsPage.isSelectedStandardWelsh()).toBeFalsy();
            expect(manageBillPrefsPage.isSelectedLargePrint()).toBeFalsy();
            expect(manageBillPrefsPage.isSelectedBrailleEnglish()).toBeFalsy();
            expect(manageBillPrefsPage.isSelectedAudioEnglish()).toBeFalsy();

            console.log("GIVEN I have changed my bill format from Standard to Large Print/Audio CD/Braille");
            manageBillPrefsPage.clickOnlineAndPost();
            manageBillPrefsPage.clickBrailleEnglish();

            console.log("WHEN I save the changes");
            manageBillPrefsPage.clickContinueButton().then(function() {

                var manageBillPrefsSummaryPage = new ManageBillPrefsSummaryPage();

                console.log("AND I am shown a confirmation message of my change");
                expect(manageBillPrefsSummaryPage.getPreviousBillMedia()).toContain('Online');
                expect(manageBillPrefsSummaryPage.getNewBillMedia()).toContain('Online and by post');
                expect(manageBillPrefsSummaryPage.getPreviousFormat()).toContain('Standard Bill - In English');
                expect(manageBillPrefsSummaryPage.getNewFormat()).toContain('Braille - In English');

                console.log("THEN the changes are submitted");
                manageBillPrefsSummaryPage.clickSubmitButton().then(function() {

                    var manageBillPrefsConfirmationPage = new ManageBillPrefsConfirmationPage();
                    expect(manageBillPrefsConfirmationPage.getImpairmentWarning()).toContain('You should update the impairment status of this customer as they have moved to a non-standard bill format.');
                });
            });
        });
    })
});
