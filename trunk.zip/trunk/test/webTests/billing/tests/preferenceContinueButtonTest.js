/**
 * Created by Yo on 4/23/15.
 */
var LandingPage = require("../../../landingPage.js");
var AgentHomePage = require("../../../agentHomePage.js");
var ViewBillPrefsPage = require("./../pages/viewBillPrefs.js");
var ManageBillPrefsPage = require("./../pages/manageBillPrefs.js");
var ManageBillPrefsSummaryPage = require("./../pages/manageBillPrefsSummary.js");

describe("As a Customer/Advisor I am unable to continue to edit my bill preferences unless I have made a change to my bill preferences", function() {
    it('Scenario: 1 Can the customer not continue to change bill preferences unless a change has been made?',function(){

        console.log("Scenario: 1 Can the customer not continue to change bill preferences unless a change has been made?");

        // Billing preferences page
        var viewBillPrefsPage = new ViewBillPrefsPage();
        var manageBillPrefsPage = new ManageBillPrefsPage();

        //  Landing page
        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535714");
        landingPage.enterAgentDN("01173021234");
        landingPage.enterAgentEIN("123456789");
        landingPage.clickAgentButton();
        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentBillPrefs();

        console.log("GIVEN I am viewing my current bill preferences");
        console.log("AND I have clicked to edit my bill preferences");
        console.log("WHEN I have not made any changes to my current bill preferences");
        viewBillPrefsPage.clickChangeBillPrefsButton().then(function () {
            expect(manageBillPrefsPage.isEnabledContinueButton()).toBe(false);
        });
    })
});
