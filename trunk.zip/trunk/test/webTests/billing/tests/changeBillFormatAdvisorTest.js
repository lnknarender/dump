var LandingPage = require("../../../landingPage.js");
var AgentHomePage = require("../../../agentHomePage.js");
var ViewBillPrefsPage = require("./../pages/viewBillPrefs.js");
var ManageBillPrefsPage = require("./../pages/manageBillPrefs.js");
var ManageBillPrefsSummaryPage = require("./../pages/manageBillPrefsSummary.js");
var ManageBillPrefsConfirmationPage = require("./../pages/manageBillPrefsConfirmation.js");

describe("As a Customer/Advisor I can change my bill format", function() {


    it('BPTA-33 Scenario: 2a Is the user prompted to accept charges if they will be charged a paper-bill fee when changing to Standard billing? ',function(){

        console.log("Scenario: 2a Is the user prompted to accept charges if they will be charged a paper-bill fee when changing to Standard billing?");

        // Billing preferences page
        var viewBillPrefsPage = new ViewBillPrefsPage();
        var manageBillPrefsPage = new ManageBillPrefsPage();

        //  Landing page
        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535717");
        landingPage.clickAgentButton();
        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentBillPrefs();

        console.log("GIVEN I am viewing my current bill preferences");

        expect(viewBillPrefsPage.getBillMedia()).toContain(viewBillPrefsPage.getExpectedMediaOnlineAndPostText());
        expect(viewBillPrefsPage.getBillFormat()).toContain(viewBillPrefsPage.getExpectedFormatBrailleText());
        expect(viewBillPrefsPage.getLanguage()).toContain(viewBillPrefsPage.getExpectedLanguageEnglishText());

        console.log("WHEN I proceed with this change");
        viewBillPrefsPage.clickChangeBillPrefsButton().then(function () {

            expect(manageBillPrefsPage.isSelectedBrailleEnglish()).toBeTruthy();

            expect(manageBillPrefsPage.isSelectedStandardEnglish()).toBeFalsy();
            expect(manageBillPrefsPage.isSelectedStandardWelsh()).toBeFalsy();
            expect(manageBillPrefsPage.isSelectedLargePrint()).toBeFalsy();
            expect(manageBillPrefsPage.isSelectedAudioEnglish()).toBeFalsy();

            manageBillPrefsPage.clickStandardEnglish();
            manageBillPrefsPage.clickContinueButton().then(function () {

                var manageBillPrefsSummaryPage = new ManageBillPrefsSummaryPage();

                expect(manageBillPrefsSummaryPage.getPreviousFormat()).toContain("Braille - In English");
                expect(manageBillPrefsSummaryPage.getNewFormat()).toContain("Standard Bill - In English");

                expect(manageBillPrefsSummaryPage.getPreviousBillMedia()).toContain("Online and by post");
                expect(manageBillPrefsSummaryPage.getNewBillMedia()).toContain("Online and by post");
                expect(manageBillPrefsSummaryPage.getAllCharges()).toContain('You will be charged a paper-bill fee of £1.50 for each bill issued. Please tick to confirm you accept these charges');

                expect(manageBillPrefsSummaryPage.isPresentSubmitButton()).toBeTruthy();
                expect(manageBillPrefsSummaryPage.isPresentCancelButton()).toBeTruthy();
            });
        });
    }),
    it('BPTA-33 Scenario: 3 Can the user save their change to Standard format, if they are not charged a paper-bill fee',function(){

        console.log("Scenario: 3 Can the user save their change to Standard format, if they are not charged a paper-bill fee");

        // Billing preferences page
        var viewBillPrefsPage = new ViewBillPrefsPage();
        var manageBillPrefsPage = new ManageBillPrefsPage();

        //  Landing page
        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535714");
        landingPage.clickAgentButton();
        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentBillPrefs();

        console.log("GIVEN I am viewing my current bill preferences");

        expect(viewBillPrefsPage.getBillMedia()).toContain(viewBillPrefsPage.getExpectedMediaOnlineText());
        expect(viewBillPrefsPage.getBillFormat()).toContain(viewBillPrefsPage.getExpectedFormatStandardText());
        expect(viewBillPrefsPage.getLanguage()).toContain(viewBillPrefsPage.getExpectedLanguageEnglishText());

        console.log("WHEN I proceed with this change");
        viewBillPrefsPage.clickChangeBillPrefsButton().then(function () {

            manageBillPrefsPage.clickStandardWelsh();
            manageBillPrefsPage.clickContinueButton().then(function () {

                var manageBillPrefsSummaryPage = new ManageBillPrefsSummaryPage();

                expect(manageBillPrefsSummaryPage.getPreviousFormat()).toContain("Standard Bill - In English");
                expect(manageBillPrefsSummaryPage.getNewFormat()).toContain("Standard Bill - In Welsh");

                expect(manageBillPrefsSummaryPage.getPreviousBillMedia()).toContain("Online");
                expect(manageBillPrefsSummaryPage.getNewBillMedia()).toContain("Online");

                manageBillPrefsSummaryPage.clickSubmitButton().then(function () {

                    var manageBillPrefsConfirmationPage = new ManageBillPrefsConfirmationPage();

                    expect(manageBillPrefsConfirmationPage.getHeading1()).toContain("Your Billing Preferences have been successfully updated");

                    var manageBillPrefsConfirmationPage = new ManageBillPrefsConfirmationPage();
                    manageBillPrefsConfirmationPage.clickFinishButton();
                });
            });
        });
    }),
    it('BPTA-33 Scenario: 4 Is the customer shown an error if they try to move away from a standard format and they have a paper-free bill media ?',function(){

        console.log("Scenario: 4 Is the customer shown an error if they try to move away from a standard format and they have a paper-free bill media ?");

        // Billing preferences page
        var viewBillPrefsPage = new ViewBillPrefsPage();
        var manageBillPrefsPage = new ManageBillPrefsPage();

        //  Landing page
        var landingPage = new LandingPage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202535714");
        landingPage.clickAgentButton();
        var agentHomePage = new AgentHomePage();
        agentHomePage.clickAgentBillPrefs();

        console.log("GIVEN I am viewing my current bill preferences");

        expect(viewBillPrefsPage.getBillMedia()).toContain(viewBillPrefsPage.getExpectedMediaOnlineText());
        expect(viewBillPrefsPage.getBillFormat()).toContain(viewBillPrefsPage.getExpectedFormatStandardText());
        expect(viewBillPrefsPage.getLanguage()).toContain(viewBillPrefsPage.getExpectedLanguageEnglishText());

        console.log("WHEN I proceed with this change");
        viewBillPrefsPage.clickChangeBillPrefsButton().then(function () {

            expect(manageBillPrefsPage.isEnabledStandardEnglish()).toBeTruthy();
            expect(manageBillPrefsPage.isEnabledStandardWelsh()).toBeTruthy();

            expect(manageBillPrefsPage.isEnabledLargePrint()).toBeFalsy();
            expect(manageBillPrefsPage.isEnabledBrailleEnglish()).toBeFalsy();
            expect(manageBillPrefsPage.isEnabledAudioEnglish()).toBeFalsy();

            manageBillPrefsPage.clickStandardWelsh();
        });
    })
});
