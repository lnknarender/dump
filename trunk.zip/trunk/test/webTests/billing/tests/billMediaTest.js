var LandingPage = require("../../../landingPage.js");
var AgentHomePage = require("../../../agentHomePage.js");
var ViewBillPrefsPage = require("./../pages/viewBillPrefs.js");
var ManageBillPrefsPage = require("./../pages/manageBillPrefs.js");
var ManageBillPrefsSummaryPage = require("./../pages/manageBillPrefsSummary.js");
var ManageBillPrefsConfirmationPage = require("./../pages/manageBillPrefsConfirmation.js");

describe("As a Customer I want to change my bill media from Dual to paper-free", function() {

    it('BPTA-29 Scenario: 1 Can the customer change from Dual to paper-free billing and be shown they will no longer be a paper-bill fee - CONTINUE',function(){

        console.log("BPTA-29 Scenario: 1 Can the customer change from Dual to paper-free billing and be shown they will no longer be a paper-bill fee - CONTINUE");

        // Billing preferences page
        var viewBillPrefsPage = new ViewBillPrefsPage();
        var manageBillPrefsPage = new ManageBillPrefsPage();

        //  Landing page
        var landingPage = new LandingPage();
        var agentHomePage = new AgentHomePage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202536943");
        landingPage.clickAgentButton();
        agentHomePage.clickAgentBillPrefs();

        console.log("GIVEN that I am changing from Dual to paper-free");
        expect(viewBillPrefsPage.getBillMedia()).toContain(viewBillPrefsPage.getExpectedMediaOnlineAndPostText());
        expect(viewBillPrefsPage.getBillFormat()).toContain(viewBillPrefsPage.getExpectedFormatStandardText());
        expect(viewBillPrefsPage.getLanguage()).toContain(viewBillPrefsPage.getExpectedLanguageEnglishText());


        viewBillPrefsPage.clickChangeBillPrefsButton().then(function () {

            console.log("WHEN I proceed with this change");
            manageBillPrefsPage.clickReceiveBillsOnline();

            console.log("THEN I am shown a summary of the changes");
            manageBillPrefsPage.clickContinueButton().then(function () {

                console.log("AND I can click to continue");
                var manageBillPrefsSummaryPage = new ManageBillPrefsSummaryPage();
                expect(manageBillPrefsSummaryPage.getPreviousBillMedia()).toContain('Online and by post');
                expect(manageBillPrefsSummaryPage.getPreviousFormat()).toContain('Standard Bill - In English');

                expect(manageBillPrefsSummaryPage.getNewBillMedia()).toContain('Online');
                expect(manageBillPrefsSummaryPage.getNewFormat()).toContain('Standard Bill - In English');

                manageBillPrefsSummaryPage.clickSubmitButton().then(function () {

                    var manageBillPrefsConfirmationPage = new ManageBillPrefsConfirmationPage();

                    //expect(manageBillPrefsConfirmationPage.getHeading1()).toContain('Your Billing Preferences have been successfully updated');
                    manageBillPrefsConfirmationPage.clickFinishButton();
                });

            });
        });
    }),
    it('BPTA-29 Scenario: 3 Is the customer shown an error if they try to move from Dual to paper-free and they have a non-standard bill format?',function(){

        console.log("BPTA-29 Scenario: 3 Is the customer shown an error if they try to move from Dual to paper-free and they have a non-standard bill format?");

        // Billing preferences page
        var viewBillPrefsPage = new ViewBillPrefsPage();
        var manageBillPrefsPage = new ManageBillPrefsPage();

        //  Landing page
        var landingPage = new LandingPage();
        var agentHomePage = new AgentHomePage();
        landingPage.visitPage();
        landingPage.enterCak("ACC_002");
        landingPage.enterConk("002");
        landingPage.enterBac("0202534856");
        landingPage.clickAgentButton();
        agentHomePage.clickAgentBillPrefs();

        console.log("GIVEN that I am changing from Dual to paper-free");
        expect(viewBillPrefsPage.getBillMedia()).toContain(viewBillPrefsPage.getExpectedMediaOnlineAndPostText());
        expect(viewBillPrefsPage.getBillFormat()).toContain(viewBillPrefsPage.getExpectedFormatBrailleText());
        expect(viewBillPrefsPage.getLanguage()).toContain(viewBillPrefsPage.getExpectedLanguageEnglishText());


        viewBillPrefsPage.clickChangeBillPrefsButton().then(function () {

            console.log("WHEN I proceed with this change");
            manageBillPrefsPage.clickReceiveBillsOnline();

            console.log("THEN I am told that I cannot have a non-standard bill format if I want paper-free bills ");
            expect(manageBillPrefsPage.getError1()).toContain('In order to have paper-free bills, you have to have a');
        });
    })
});

