var LandingPage = require("./landingPage.js");
var ViewBillPrefsPage = require("./pages/viewBillPrefs.js");
var ManageBillPrefsSummaryPage = require("./pages/manageBillPrefs.js");

require('./jasmine-given.min.js');

describe("As a Customer/Advisor I want to change my bill media from Dual to paper-free", function() {

    describe("Scenario: 1 Can the customer change from Dual to paper-free billing and be shown they will no longer be a paper-bill fee", function() {

        // Billing preferences page
        var viewBillPrefsPage = new ViewBillPrefsPage();
        var manageBillPrefsSummaryPage = new ManageBillPrefsSummaryPage();

        Given(function() {

            //  Landing page
            var landingPage = new LandingPage();
            landingPage.visitPage();
            landingPage.enterCak("ACC_002");
            landingPage.enterConk("002");
            landingPage.enterBac("GB02536943");
            landingPage.clickAgentButton();

        });
        describe("AND I can click to cancel", function() {
            Given(function() {

                expect(viewBillPrefsPage.getBillFormat()).toContain('Online and by post');
                expect(viewBillPrefsPage.getCharges()).toContain('Stopping your paper bills you‘ll join millions of other BT customers already saving enough paper to stretch 7,500 miles from London to Tokyo every year. You could also save a £1.50 paper fee per bill.');
            });
            When(function() {
                buttonClick = viewBillPrefsPage.clickChangeBillPrefsButton();

            });
            Then(function() {

                manageBillPrefsSummaryPage.clickReceiveBillsOnline();

                browser.waitForAngular();
            })
        });
    });
});
