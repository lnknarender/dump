// Karma configuration
// Generated on Tue May 27 2014 13:32:47 GMT+0100 (GMT Daylight Time)
module.exports = function (config) {
    config.set({
        // base path, that will be used to resolve files and exclude
        basePath: '..',
        // frameworks to use
        frameworks: ['jasmine'],
        // list of files / patterns to load in the browser. Note is the controller is not being created
        // but is attached to an existing controller then the instantiated controller must be listed
        // before src/js/app/**/*.js (i.e. editpaymentmethodcontroller)
        files: ['properties/constants.js',
            'properties/omniture.js',
            'test/library/angular.js',
            'js/lib/angular/angular-mocks.js',
            'js/lib/angular/angular-route.min.js',
            'js/lib/angular/angular-cookies.min.js',
            'js/lib/angular/angular-translate.min.js',
            'js/lib/moment/moment.min.js',
            'js/lib/angular/angular-translate-loader-static-files.min.js',
            'js/lib/angular/angular-animate.min.js',
            'js/lib/ui-bootstrap-tpls-0.10.0.min.js',
            'js/lib/jquery/jquery-1.11.2.min.js',
            'js/lib/jquery/jquery.cookie.js',
            'src/js/app/paymentmethod/setup/wbdd/setuppaymentmethodservices.js',
            'src/js/app/paymentmethod/setup/wbdd/setuppaymentmethodcontrollers.js',
            'src/js/app/paymentmethod/edit/wbdd/services/editpaymentmethodservices.js',
            'src/js/app/paymentmethod/edit/wbdd/controllers/editpaymentmethodmodule.js',
            'src/js/app/paymentmethod/edit/ccra/controllers/editccrapaymentmethodmodule.js',
            'src/js/app/paymentmethod/setup/ccra/controllers/setupccrapaymentmethodcontroller.js',
            'src/js/app/billingdashboard/controllers/billingdashboardmodule.js',
            'src/js/app/billingdashboard/services/billingdashboardservicemodule.js',
            'src/js/app/**/*.js',
            'src/js/app/common/urlService.js',
            'src/js/app/*.js',
            'js/lib/iframehelper.js',
            'test/unit/**/*Test.js',
            'test/unit/**/*TestData.js'
                    //allfiles in index,html &  test files,
        ],
        // list of files to exclude
        exclude: ['Vendor/angular-1.0.6/angular-scenario.js'],
        // test results reporter to use
        // possible values: 'dots', 'progress', 'junit', 'growl', 'coverage'
        reporters: ['progress', 'junit', 'coverage'],
        coverageReporter: {
            dir: 'test/out/',
            reporters: [
                // reporters not supporting the `file` property
                {type: 'html', subdir: 'coverage'},
                // output them in the `dir` directory
                {type: 'text'}
            ]
        },
        junitReporter: {
            // will be resolved to basePath (in the same way as files/exclude patterns)
            outputDir: 'test/out/',
            outputFile: 'unit-test-results.xml',
            suite: "bpta"
        },
        // web server port
        port: 9876,
        // enable / disable colors in the output (reporters and logs)
        colors: true,
        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_INFO,
        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,
        // Start these browsers, currently available:
        // - Chrome
        // - ChromeCanary
        // - Firefox
        // - Opera (has to be installed with `npm install karma-opera-launcher`)
        // - Safari (only Mac; has to be installed with `npm install karma-safari-launcher`)
        // - PhantomJS
        // - IE (only Windows; has to be installed with `npm install karma-ie-launcher`)
        browsers: ['PhantomJS'],
        // If browser does not capture in given timeout [ms], kill it
        captureTimeout: 60000,
        // Continuous Integration mode
        // if true, it capture browsers, run tests and exit
        singleRun: false,
        preprocessors: {
            '**/src/js/app/**/*.js': 'coverage'
        }
    });
};
