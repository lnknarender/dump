var cards = {};
cards["american express"] = "id('cardType')/option[2]";
cards["maestro"] = "id('cardType')/option[3]";
cards["mastercard"] = "id('cardType')/option[4]";
cards["visa"] = "id('cardType')/option[5]";
cards["visa debit/delta"] = "id('cardType')/option[6]";
cards["electron"] = "id('cardType')/option[7]";

var months = {};
months["01"] = "id('expiryMonth')/option[2]";
months["02"] = "id('expiryMonth')/option[3]";
months["03"] = "id('expiryMonth')/option[4]";
months["04"] = "id('expiryMonth')/option[5]";
months["05"] = "id('expiryMonth')/option[6]";
months["06"] = "id('expiryMonth')/option[7]";
months["07"] = "id('expiryMonth')/option[8]";
months["08"] = "id('expiryMonth')/option[9]";
months["09"] = "id('expiryMonth')/option[10]";
months["10"] = "id('expiryMonth')/option[11]";
months["11"] = "id('expiryMonth')/option[12]";
months["12"] = "id('expiryMonth')/option[13]";

var years = {};
years["2015"] = "id('expiryYear')/option[2]";
years["2016"] = "id('expiryYear')/option[3]";
years["2017"] = "id('expiryYear')/option[4]";
years["2018"] = "id('expiryYear')/option[5]";
years["2019"] = "id('expiryYear')/option[6]";
years["2020"] = "id('expiryYear')/option[7]";
years["2021"] = "id('expiryYear')/option[8]";
years["2022"] = "id('expiryYear')/option[9]";
years["2023"] = "id('expiryYear')/option[10]";
years["2024"] = "id('expiryYear')/option[11]";
years["2025"] = "id('expiryYear')/option[12]";


var TestThistlePage = (function () {

    function TestThistlePage() {

    }

    TestThistlePage.prototype.testThistlePage = function(username, cardType, cardNumber, expiryMonth, expiryYear, securityCode, buildingName, postcode) {

        browser.driver.findElement(protractor.By.id('cardHolder')).sendKeys(username);

        cardType = cardType.toLowerCase();
        var card = cards[cardType];
        var month = months[expiryMonth];
        var year = years[expiryYear]

        browser.driver.findElement(protractor.By.xpath(card)).click();
        browser.driver.findElement(protractor.By.id('cardNumber')).sendKeys(cardNumber);
        browser.driver.findElement(protractor.By.xpath(month)).click();
        browser.driver.findElement(protractor.By.xpath(year)).click();
        browser.driver.findElement(protractor.By.id('securityCode')).sendKeys(securityCode);
        browser.driver.findElement(protractor.By.id('buildingName')).sendKeys(buildingName);
        browser.driver.findElement(protractor.By.id('postcode')).sendKeys(postcode);
    };

    TestThistlePage.prototype.useValidCard = function() {

        var NAME_ON_CARD = "BPTA";
        var CARD_TYPE = "VISA";
        var CARD_NUMBER = "4421620000000800";
        var EXPIRY_MONTH = "12";
        var EXPIRY_YEAR = "2025";
        var SECURITY_CODE = "123";
        var BUILDING_NAME = "Ty Cynnal";
        var POST_CODE = "CF11 0SW";

        browser.sleep(6000);

        expect(element(by.id("payform")).isDisplayed()).toBe(true);
        expect(element(by.id("payframe")).isDisplayed()).toBe(true);
        browser.switchTo().frame("payframe");

        this.testThistlePage(NAME_ON_CARD, CARD_TYPE, CARD_NUMBER, EXPIRY_MONTH, EXPIRY_YEAR, SECURITY_CODE, BUILDING_NAME, POST_CODE);

        browser.driver.findElement(protractor.By.id('submitBtn')).click();
        browser.switchTo().defaultContent();
        browser.waitForAngular();
    };

    TestThistlePage.prototype.useInvalidCard = function() {

        var NAME_ON_CARD = "BPTA";
        var CARD_TYPE = "VISA";
        var CARD_NUMBER = "1234567890123456";
        var EXPIRY_MONTH = "12";
        var EXPIRY_YEAR = "2025";
        var SECURITY_CODE = "123";
        var BUILDING_NAME = "Ty Cynnal";
        var POST_CODE = "CF11 0SW";

        browser.sleep(1000);

        expect(element(by.id("payform")).isDisplayed()).toBe(true);
        expect(element(by.id("payframe")).isDisplayed()).toBe(true);
        browser.switchTo().frame("payframe");

        this.testThistlePage(NAME_ON_CARD, CARD_TYPE, CARD_NUMBER, EXPIRY_MONTH, EXPIRY_YEAR, SECURITY_CODE, BUILDING_NAME, POST_CODE);

        browser.driver.findElement(protractor.By.id('submitBtn')).click();
        browser.switchTo().defaultContent();
        browser.waitForAngular();
    };

    TestThistlePage.prototype.enterSecurityCode = function() {

        var SECURITY_CODE = "123";

        expect(element(by.id("payform")).isDisplayed()).toBe(true);
        expect(element(by.id("payframe")).isDisplayed()).toBe(true);
        browser.switchTo().frame("payframe");

        browser.driver.findElement(protractor.By.id('securityCode')).sendKeys(SECURITY_CODE);

        browser.driver.findElement(protractor.By.id('submitBtn')).click();
        browser.switchTo().defaultContent();
        browser.waitForAngular();
    };

    return TestThistlePage

})();

module.exports = TestThistlePage;