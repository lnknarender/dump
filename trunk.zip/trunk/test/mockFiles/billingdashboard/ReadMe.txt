BAC         Payment Method  Bill status    Debit/Credit
==========  ==============  ===========    ============
0202534856  Cash/Cheque     Final bill     Zero balance
0202535713  Direct Debit    Standard bill  In credit
0202535714  CCRA            Standard bill  In debit
0202535715  Cash/Cheque     Standard bill  In debit
0202535716  Cash/Cheque     Standard bill  In credit
0202535721  MPP             Final bill     In debit