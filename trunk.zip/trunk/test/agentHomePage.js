var jasmineConnection = require("./properties/jasmineConnection.json");

var AgentHomePage = (function () {
    function AgentHomePage() {
        this.agentMakePayment = element(By.id("agentMakePayment"));
        this.agentBillPrefs = element(By.id("agentBillPrefs"));
        this.agentInstalmentPlan = element(By.id("agentInstalmentPlan"));
        this.agentsignoutbutton = element(By.id("agentsignoutbutton"));
        this.agentInviteCustomerOnline = element(By.id("agentInviteCustomerOnline"));
    }

    AgentHomePage.prototype.visitPage = function () {
        browser.get(jasmineConnection.host);
    };

    AgentHomePage.prototype.clickAgentMakePayment = function () {
        this.agentMakePayment.click();
    };

    AgentHomePage.prototype.clickAgentBillPrefs = function () {
        this.agentBillPrefs.click();
    };

    AgentHomePage.prototype.clickAgentInstalmentPlan = function () {
        this.agentInstalmentPlan.click();
    };

    AgentHomePage.prototype.clickAgentsignoutbutton = function () {
        this.agentsignoutbutton.click();
    };

    AgentHomePage.prototype.clickAgentInviteCustomerOnline = function () {
        this.agentInviteCustomerOnline.click();
    };

    return AgentHomePage

})();

module.exports = AgentHomePage;