/**
 * Created by Andrew on 03/03/2016.
 */
describe('Controller: Billing dashboard - billingDashboardCtrl', function () {

    var scope, createController;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
    }));

    beforeEach(inject(function ($q, $rootScope, $location, $controller, utilityService, errorLoggingService, accessTokenService, billingdashboardServices, stateService, commonPaymentMethodServices, changePaymentMethodServices) {

        scope = $rootScope.$new();

        //  Create the billingDashboardCtrl and pass the mock objects
        createController = function() {
            var ctrl = $controller('billingDashboardCtrl',
                   {$location: $location,
                    accessTokenService: accessTokenService,
                    billingdashboardServices: billingdashboardServices,
                    errorLoggingService: errorLoggingService,
                    utilityService: utilityService,
                    stateService: stateService,
                    commonPaymentMethodServices: commonPaymentMethodServices,
                    changePaymentMethodServices: changePaymentMethodServices
                });

            scope.$digest();
            return ctrl;
        };
    }));


    //  Mock the billing account service (getAccount) and access token service (getToken)
    beforeEach(angular.mock.inject(function (_billingdashboardServices_, _accessTokenService_, _$q_, _$rootScope_, _httpErrorInterceptor_) {

//        scope = _$rootScope_.$new();
        var deferred = _$q_.defer();

        /**
         *  Mock the billing dashboard srevice
         */
        spyOn(_billingdashboardServices_, 'getBillingDashboard').and.callFake(function () {

            return {

                then: function(callback) { return callback(billingDashboard); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        /**
         *  Mock the access token service.
         */
        spyOn(_accessTokenService_, 'getToken').and.callFake(function () {

            return {

                then: function(callback) { return callback(accessTokenMockData);  },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        deferred.resolve(billingDashboard);
        scope.$digest();
    }));

    it('Testing billingDashboardCtrl', function() {

        console.log("Testing billingDashboardCtrl");
        expect(createController().amountOwed.pounds).toEqual('52');
        expect(createController().amountOwed.pence).toEqual('90');
        expect(createController().paymentDay).toEqual('17th');
        expect(createController().isPaymentQuarterly).toBeFalsy();
        expect(createController().invoiceAmount.pounds).toEqual('3');
        expect(createController().invoiceAmount.pence).toEqual('14');

        expect(createController().paymentMethodTitleSuffix).toEqual('non.mpp.credit');
        expect(createController().showAccountBalance).toBeTruthy();
        expect(createController().isCashAndCheque).toBeFalsy();
        expect(createController().headlineNotification.key).toEqual(constants.HEADING_NOTIFICATION_CREDIT_FIRST_STANDARD_BILL);
        expect(createController().headlineNotification.alertType).toEqual(constants.AMBER_WARNING_ALERT);
        expect(createController().headlineNotification.ctaMakePayment).toBeFalsy();

    });
});