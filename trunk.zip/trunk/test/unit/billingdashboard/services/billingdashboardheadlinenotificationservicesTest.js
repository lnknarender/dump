describe('Service: billingdashboardHeadlineNotificationServices', function () {

    var stateService, $q, $httpBackend, scope, service, mockAjaxServiceWithToken;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    function setupTest (mockData) {
        (inject(function (_$q_, _$httpBackend_, _$rootScope_, _ajaxServiceWithToken_, _stateService_, _billingdashboardHeadlineNotificationServices_) {

            scope = _$rootScope_.$new();
            $httpBackend = _$httpBackend_;

            stateService = _stateService_;

            mockAjaxServiceWithToken = _ajaxServiceWithToken_;
            service = _billingdashboardHeadlineNotificationServices_;

            spyOn(mockAjaxServiceWithToken, 'doGet').and.callFake(function () {

                return {

                    then: function (callback) {
                        return callback(mockData);
                    },

                    catch: function (callback) {
                        return null;
                    },

                    finally: function (callback) {
                        return null;
                    }
                };
            });
        }));
    }

    it('Test billingdashboardServices - getPaymentMethodTitleSuffix - non MPP credit', (function () {

        setupTest(billingDashboard);

        service.init(billingDashboard);

        var languageKey = service.getLanguageBundleKey();
        var alertType = service.getAlertType();
        var isCtaPayment = service.isMakePaymentCta();

        expect(languageKey).toEqual("credit.1");
        expect(alertType).toEqual("amberWarningAlert");
        expect(isCtaPayment).toBeFalsy();
    }));
});
