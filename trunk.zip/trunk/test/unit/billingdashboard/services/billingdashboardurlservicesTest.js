describe('Service: billingdashboardUrlServices', function () {

    var billingdashboardUrlServices;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    beforeEach
        (inject(function (_billingdashboardUrlServices_) {

            billingdashboardUrlServices = _billingdashboardUrlServices_;
    }));

    it('Test billingdashboardServices - getBillingDashboard', (function () {

        var url = billingdashboardUrlServices.getBillingDashboardUrl();

        //  Assert that the get method has been called
        expect(url).toEqual("undefined/protected/v1/cak/ACC_002/conk/002/bac/0202535714/billingdashboard");
    }));
});