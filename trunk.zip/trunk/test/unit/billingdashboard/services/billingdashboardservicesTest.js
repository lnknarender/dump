describe('Service: billingdashboardServices', function () {

    var stateService, $q, $httpBackend, scope, billingdashboardServices, mockAjaxServiceWithToken;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    function setupTest (mockData) {
        (inject(function (_$q_, _$httpBackend_, _$rootScope_, _ajaxServiceWithToken_, _stateService_, _billingdashboardServices_) {

            scope = _$rootScope_.$new();
            $httpBackend = _$httpBackend_;

            stateService = _stateService_;

            mockAjaxServiceWithToken = _ajaxServiceWithToken_;
            billingdashboardServices = _billingdashboardServices_;

            spyOn(mockAjaxServiceWithToken, 'doGet').and.callFake(function () {

                return {

                    then: function (callback) {
                        return callback(mockData);
                    },

                    catch: function (callback) {
                        return null;
                    },

                    finally: function (callback) {
                        return null;
                    }
                };
            });
        }));
    }

    it('Test billingdashboardServices - getPaymentMethodTitleSuffix - non MPP credit', (function () {

        setupTest(billingDashboard);

        var suffix = billingdashboardServices.getPaymentMethodTitleSuffix(billingDashboard);

        //  Assert that the correct suffix is returned
        expect(suffix).toEqual("non.mpp.credit");
    }));

    it('Test billingdashboardServices - getPaymentMethodTitleSuffix - non MPP zero pound', (function () {

        billingDashboard.owe.balance.amount = 0;

        setupTest(billingDashboard);

        var suffix = billingdashboardServices.getPaymentMethodTitleSuffix(billingDashboard);

        //  Assert that the correct suffix is returned
        expect(suffix).toEqual("non.mpp.zero.pound");
    }));

    it('Test billingdashboardServices - getPaymentMethodTitleSuffix - non MPP debit', (function () {

        billingDashboard.owe.balance.amount = -10;

        setupTest(billingDashboard);

        var suffix = billingdashboardServices.getPaymentMethodTitleSuffix(billingDashboard);

        //  Assert that the correct suffix is returned
        expect(suffix).toEqual("non.mpp.debit");
    }));

    it('Test billingdashboardServices - getPaymentMethodTitleSuffix - MPP debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.owe.balance.amount = 100;

        setupTest(billingDashboard);

        var suffix = billingdashboardServices.getPaymentMethodTitleSuffix(billingDashboard);

        //  Assert that the correct suffix is returned
        expect(suffix).toEqual("mpp.credit");
    }));

    it('Test billingdashboardServices - getPaymentMethodTitleSuffix - MPP zero pound', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.owe.balance.amount = 0;

        setupTest(billingDashboard);

        var suffix = billingdashboardServices.getPaymentMethodTitleSuffix(billingDashboard);

        //  Assert that the correct suffix is returned
        expect(suffix).toEqual("mpp.zero.pound");
    }));

    it('Test billingdashboardServices - getPaymentMethodTitleSuffix - MPP debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.owe.balance.amount = -100;

        setupTest(billingDashboard);

        var suffix = billingdashboardServices.getPaymentMethodTitleSuffix(billingDashboard);

        //  Assert that the correct suffix is returned
        expect(suffix).toEqual("mpp.debit");
    }));

    it('Test billingdashboardServices - isQuarterlyBill - monthly', (function () {

        billingDashboard.billFrequency = "1M";
        setupTest(billingDashboard);

        var quarterly = billingdashboardServices.isQuarterlyBill(billingDashboard);

        //  Assert that the correct suffix is returned
        expect(quarterly).toEqual(false);
    }));

    it('Test billingdashboardServices - isQuarterlyBill - quarterly', (function () {

        billingDashboard.billFrequency = constants.BILL_QUARTERY;

        setupTest(billingDashboard);

        var quarterly = billingdashboardServices.isQuarterlyBill(billingDashboard);

        //  Assert that the correct suffix is returned
        expect(quarterly).toEqual(true);
    }));

    it('Test billingdashboardServices - isShowAccountBalance - cash/cheque - before first bill', (function () {

        billingDashboard.billType = constants.BEFORE_FIRST_BILL;
        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CHEQUE_CASH;

        setupTest(billingDashboard);

        var showBalance = billingdashboardServices.isShowAccountBalance(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(showBalance).toEqual(false);
    }));

    it('Test billingdashboardServices - isShowAccountBalance - direct debit - before first bill', (function () {

        billingDashboard.billType = constants.BEFORE_FIRST_BILL;
        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;

        setupTest(billingDashboard);

        var showBalance = billingdashboardServices.isShowAccountBalance(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(showBalance).toEqual(false);
    }));

    it('Test billingdashboardServices - isShowAccountBalance - MPP - before first bill', (function () {

        billingDashboard.billType = constants.BEFORE_FIRST_BILL;
        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;

        setupTest(billingDashboard);

        var showBalance = billingdashboardServices.isShowAccountBalance(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(showBalance).toEqual(false);
    }));

    it('Test billingdashboardServices - isShowAccountBalance - CCRA - before first bill', (function () {

        billingDashboard.billType = constants.BEFORE_FIRST_BILL;
        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CCRA;

        setupTest(billingDashboard);

        var showBalance = billingdashboardServices.isShowAccountBalance(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(showBalance).toEqual(false);
    }));

    it('Test billingdashboardServices - isShowAccountBalance - cash/cheque', (function () {

        billingDashboard.billType = constants.STANDARD_BILL;
        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CHEQUE_CASH;

        setupTest(billingDashboard);

        var showBalance = billingdashboardServices.isShowAccountBalance(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(showBalance).toEqual(true);
    }));

    it('Test billingdashboardServices - isShowAccountBalance - direct debit', (function () {

        billingDashboard.paymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;

        setupTest(billingDashboard);

        var showBalance = billingdashboardServices.isShowAccountBalance(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(showBalance).toEqual(true);
    }));

    it('Test billingdashboardServices - isShowAccountBalance - CCRA', (function () {

        billingDashboard.paymentMethod = constants.PAYMENT_METHOD_CCRA;

        setupTest(billingDashboard);

        var showBalance = billingdashboardServices.isShowAccountBalance(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(showBalance).toEqual(true);
    }));

    it('Test billingdashboardServices - isShowAccountBalance - CCRA - final bill', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CCRA;
        billingDashboard.billType = constants.FINAL_BILL;

        setupTest(billingDashboard);

        var showBalance = billingdashboardServices.isShowAccountBalance(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(showBalance).toEqual(false);
    }));

    it('Test billingdashboardServices - isShowAccountBalance - MPP', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.billType = constants.STANDARD_BILL;
        billingDashboard.nextBillDate = "2016-04-01";

        setupTest(billingDashboard);

        var showBalance = billingdashboardServices.isShowAccountBalance(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(showBalance).toEqual(true);
    }));

    it('Test billingdashboardServices - isShowAccountBalance - MPP - final bill', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.billType = constants.FINAL_BILL;

        setupTest(billingDashboard);

        var showBalance = billingdashboardServices.isShowAccountBalance(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(showBalance).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - cash/cheque - before first bill', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CHEQUE_CASH;
        billingDashboard.billType = constants.BEFORE_FIRST_BILL;
        billingDashboard.owe.balance.amount = 0;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toBeFalsy();
        expect(customKeyMessage.displayMakePaymentLink).toBeFalsy();
        expect(customKeyMessage.displayDontNeedToDoAnything).toBeFalsy();
        expect(customKeyMessage.displayLastPaymentText).toBeFalsy();
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toBeFalsy();
        expect(customKeyMessage.displayBeforeFirstBillText).toBeTruthy();
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - cash/cheque - first bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CHEQUE_CASH;
        billingDashboard.billType = constants.FIRST_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(true);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - cash/cheque - standard bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CHEQUE_CASH;
        billingDashboard.nextBillDate = "2016-03-01";
        billingDashboard.billType = constants.STANDARD_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(true);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - cash/cheque - final bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CHEQUE_CASH;
        billingDashboard.billType = constants.FINAL_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(true);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - cash/cheque - first bill - credit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CHEQUE_CASH;
        billingDashboard.billType = constants.FIRST_BILL;
        billingDashboard.owe.balance.amount = 100.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(true);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - cash/cheque - standard bill - credit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CHEQUE_CASH;
        billingDashboard.billType = constants.STANDARD_BILL;
        billingDashboard.owe.balance.amount = 100.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(true);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - cash/cheque - final bill - credit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CHEQUE_CASH;
        billingDashboard.billType = constants.FINAL_BILL;
        billingDashboard.owe.balance.amount = 10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - direct debit - first bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;
        billingDashboard.billType = constants.FIRST_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(true);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - direct debit - standard bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;
        billingDashboard.billType = constants.STANDARD_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);


        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(true);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - direct debit - final bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;
        billingDashboard.billType = constants.FINAL_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(true);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - direct debit - first bill - credit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;
        billingDashboard.billType = constants.FIRST_BILL;
        billingDashboard.owe.balance.amount = 100.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(true);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - direct debit - standard bill - credit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;
        billingDashboard.billType = constants.STANDARD_BILL;
        billingDashboard.owe.balance.amount = 100.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(true);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - direct debit - final bill - credit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_DIRECT_DEBIT;
        billingDashboard.billType = constants.FINAL_BILL;
        billingDashboard.owe.balance.amount = 10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(true);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - MPP - first bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.billType = constants.FIRST_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(true);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - MPP - standard bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.billType = constants.STANDARD_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);


        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(true);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - MPP - final bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.billType = constants.FINAL_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(true);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - MPP - first bill - credit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.billType = constants.FIRST_BILL;
        billingDashboard.owe.balance.amount = 100.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(true);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - MPP - standard bill - credit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.billType = constants.STANDARD_BILL;
        billingDashboard.owe.balance.amount = 100.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(true);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - MPP - final bill - credit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN;
        billingDashboard.billType = constants.FINAL_BILL;
        billingDashboard.owe.balance.amount = 10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(true);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(false);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - CCRA - first bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CCRA;
        billingDashboard.billType = constants.FIRST_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);

        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toEqual(false);
        expect(customKeyMessage.displayMakePaymentLink).toEqual(false);
        expect(customKeyMessage.displayDontNeedToDoAnything).toEqual(false);
        expect(customKeyMessage.displayLastPaymentText).toEqual(false);
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toEqual(true);
    }));

    it('Test billingdashboardServices - getCustomKeyMessage - CCRA - standard bill - debit', (function () {

        billingDashboard.owe.paymentMethod = constants.PAYMENT_METHOD_CCRA;
        billingDashboard.billType = constants.STANDARD_BILL;
        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var customKeyMessage = billingdashboardServices.getCustomKeyMessage(billingDashboard);


        //  Assert that the show balance should be displayed or not
        expect(customKeyMessage.displayMakePaymentButton).toBeFalsy();
        expect(customKeyMessage.displayMakePaymentLink).toBeFalsy();
        expect(customKeyMessage.displayDontNeedToDoAnything).toBeFalsy();
        expect(customKeyMessage.displayLastPaymentText).toBeFalsy();
        expect(customKeyMessage.displayDontNeedToUsingDebitCreditCard).toBeTruthy();
    }));

    it('Test billingdashboardServices - isAccountInCredit - in debit', (function () {

        billingDashboard.owe.balance.amount = -10.50;

        setupTest(billingDashboard);

        var accountCredit = billingdashboardServices.isAccountInCredit(billingDashboard);

        //  Assert that the account is in debit
        expect(accountCredit).toBeFalsy();
    }));

    it('Test billingdashboardServices - isAccountInCredit - in credit', (function () {

        billingDashboard.owe.balance.amount = 10.50;

        setupTest(billingDashboard);

        var accountCredit = billingdashboardServices.isAccountInCredit(billingDashboard);

        //  Assert that the account is in credit
        expect(accountCredit).toBeTruthy();
    }));

    it('Test billingdashboardServices - getHeadlineNotification - in credit', (function () {

        billingDashboard.owe.balance.amount = 10.50;

        setupTest(billingDashboard);

        var headlineNotification = billingdashboardServices.getHeadlineNotification(billingDashboard);

        //  Assert the headlineNotification object
        expect(headlineNotification.key).toEqual(constants.HEADING_NOTIFICATION_CREDIT_FIRST_STANDARD_BILL);
        expect(headlineNotification.alertType).toEqual(constants.AMBER_WARNING_ALERT);
        expect(headlineNotification.ctaMakePayment).toBeFalsy();
    }));

});