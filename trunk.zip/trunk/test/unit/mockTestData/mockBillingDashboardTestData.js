var billingDashboard = {
    "billType":"STANDARD_BILL",
    "owe":{
        "balance":{
            "amount":52.9,
            "currencyCode":"GBP"
        },
        "paymentMethod":"Direct Debit",
        "billFrequency":"1M",
        "paymentDueDate":"2016-03-17",
        "subStatus":"String",
        "debtActionName":null,
        "debtActionDate":null,
        "restrictionDate":null,
        "paymentDay":17
    },
    "billing":{
        "invoiceAmount":{
            "amount":3.14,
            "currencyCode":"GBP"
        },
        "issuedDate":"1967-09-13",
        "nextBillDate":"1967-08-13",
        "billMedia":"Dual",
        "billFormat":"Braille Bill",
        "language":"ENG",
        "itemisationOption":"2- Custom Itemisation",
        "itemisationThreshold":{
            "amount":10.0,
            "currencyCode":"GBP"
        },
        "address":{
            "organization":null,
            "thoroughfareName":"Park Street",
            "dependentLocality":"locality",
            "subBuildingName":"subBuilding",
            "county":"Cardiff",
            "postCode":"CF10 1NT",
            "buildingNumber":"1",
            "dependentThoroughfare":null,
            "buildingName":"Stadium House",
            "postTown":"Cardiff",
            "poBox":null,
            "doubleDependentLocality":null,
            "country":"UK"
        },
        "invoiceURL":null,
        "invoiceNumber":"IV02533877"
    }
};