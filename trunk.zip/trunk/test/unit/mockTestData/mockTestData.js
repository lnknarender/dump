//  Define the mock access token responses
var accessTokenMockData = {'timeoutSeconds': '1200', 'accessToken': 'b2297kr5v5sledqf6su0qpda9fc0v0ug2do7br'};

//  Define the mock bill account responses
var billAccountMockData = {"media":"Dual",
                           "format":"Braille Bill",
                           "language":"ENG",
                           "itemisationOption":"10",
                           "itemisationThreshold": {
                                "amount": 10.0,
                                "currencyCode": "GBP"
                            },
                           "paymentMethod":"DirectDebit",
                           "charges":{"amount":1.59,
                                      "currencyCode":"GBP",
                                      "applicable":false},
                           "address":{"organization":"BT",
                                      "thoroughfareName":"Park Street",
                                      "dependentLocality":"locality",
                                      "subBuildingName":"subBuilding",
                                      "county":"Cardiff",
                                      "postCode":"CF10 1NT",
                                      "buildingNumber":"1",
                                      "dependentThoroughfare":"dependentThoroughfare",
                                      "buildingName":"Stadium House",
                                      "postTown":"Cardiff",
                                      "poBox":"99",
                                      "doubleDependentLocality":"doubleDependentLocality",
                                      "country":"UK"},
                           "barred":{"status":"String",
                                     "substatus":"String"}};

var  getJourneyMockData ={"daysUntilNextBill":1,
                          "charges":{"applicable": true,"amount":2,"currencyCode": ""},
                          "billAccountDetails":{"media":"Dual",
                                                "format":"Braille Bill",
                                                "language":"ENG",
                                                "itemisationOption":"10",
                                                "paymentMethod":"DirectDebit",
                                                "charges":{"amount":1.59,
                                                           "currencyCode":"GBP",
                                                           "applicable":false},
                                                "address":{"organization":"BT",
                                                           "thoroughfareName":"Park Street",
                                                           "dependentLocality":"locality",
                                                           "subBuildingName":"subBuilding",
                                                           "county":"Cardiff",
                                                           "postCode":"CF10 1NT",
                                                           "buildingNumber":"1",
                                                           "dependentThoroughfare":"dependentThoroughfare",
                                                           "buildingName":"Stadium House",
                                                           "postTown":"Cardiff",
                                                           "poBox":"99", "doubleDependentLocality":"doubleDependentLocality",
                                                           "country":"UK"},
                                                "barred":{"status":"String",
                                                          "substatus":"String"}},
                          "impairment":{"impairmentFlag":false}
};

var instalmentPlanEligibility_ineligible_final_bill_MockData =
                                            {"eligible": "N",
                                             "reasonsForIneligibility": ["Final bill has been sent"],
                                             "paymentDueDate": "2014-12-27",
                                             "minimumPayment": {"amount": 10.0,
                                                                "currencyCode": "GBP"},
                                             "outstandingBalance": {"amount": 10.0,
                                                                    "currencyCode": "GBP"},
                                             "credit": "N",
                                             "accountStatus": null,
                                             "billFrequency": null,
                                             "nextBillDate": null,
                                             "instalmentHistory": [{"requestedDate": "2015-02-09",
                                                                    "completedDate": "2015-02-09",
                                                                    "amount": {"amount": 74.23,
                                                                    "currencyCode": "GBP"},
                                                                    "instalments": 1,
                                                                    "allPaymentsMade": false},
                                                                   {"requestedDate": "2014-02-09",
                                                                    "completedDate": "2015-02-09",
                                                                    "amount": {"amount": 100.23,
                                                                               "currencyCode": "GBP"},
                                                                    "instalments": 2,
                                                                    "allPaymentsMade": false}],
                                             "instalmentPlan": {"status": "Defaulted",
                                                                "outstanding": {"amount": 63.92,
                                                                                "currencyCode": "GBP"},
                                                                "instalments": [{"number": "1",
                                                                                 "date": "2015-01-20",
                                                                                 "amount": {"amount": 23.92,
                                                                                            "currencyCode": "GBP"},
                                                                                 "status": "Defaulted"},
                                                                                {"number": "2",
                                                                                 "date": "2015-01-21",
                                                                                 "amount": {"amount": 15.0,
                                                                                            "currencyCode": "GBP"},
                                                                                 "status": "Defaulted"},
                                                                                {"number": "3",
                                                                                 "date": "2015-01-22",
                                                                                 "amount": {"amount": 13.0,
                                                                                            "currencyCode": "GBP"},
                                                                                 "status": "Defaulted"},
                                                                                {"number": "4",
                                                                                 "date": "2015-01-23",
                                                                                 "amount": {"amount": 12.0,
                                                                                            "currencyCode": "GBP"},
                                                                                 "status": "Defaulted"}
                                                                               ]
                                                                }
                                             };

var instalmentPlanEligibility_ineligible_MockData =
                                                  {"eligible": "N",
                                                   "reasonsForIneligibility": ["Charges is less than minimum payment"],
                                                   "paymentDueDate": "2014-12-27",
                                                   "minimumPayment": {"amount": 10.0,
                                                                      "currencyCode": "GBP"},
                                                   "outstandingBalance": {"amount": 9.0,
                                                                          "currencyCode": "GBP"},
                                                   "credit": "N",
                                                   "accountStatus": null,
                                                   "billFrequency": null,
                                                   "nextBillDate": null,
                                                   "instalmentHistory": null,
                                                   "instalmentPlan": null
                                                  };

var instalmentPlanEligibility_eligible_MockData =
                                                {
                                                 "eligible": "Y",
                                                 "reasonsForIneligibility": null,
                                                 "paymentDueDate": "2015-04-18",
                                                 "minimumPayment": {"amount": 10.0,
                                                                    "currencyCode": "GBP"
                                                 },
                                                 "outstandingBalance": {"amount": 10.0,
                                                                        "currencyCode": "GBP"
                                                 },
                                                 "credit": "N",
                                                 "accountStatus": "ACTIVE",
                                                 "billFrequency": "1M",
                                                 "nextBillDate": "2015-05-13",
                                                 "instalmentHistory": [{"requestedDate": "2015-02-09",
                                                                        "completedDate": "2015-02-09",
                                                                        "amount": {"amount": 74.23,
                                                                                   "currencyCode": "GBP"},
                                                                        "instalments": 1,
                                                                        "allPaymentsMade": false}
                                                                      ],
                                                 "instalmentPlan": null
                                                };

var linkedAccounts = {
                       "emailLinkedAccounts": [{"email" : "email1@bt.com",
                                               "linkedAccounts": [{"btId": "btid1.1",
                                                                  "emailTemplate": "emailTemplate1.1",
                                                                  "emailToken": "emailToken1.1",
                                                                  "status": "status1.1"},
                                                                  {"btId": "btid1.2",
                                                                   "emailTemplate": "emailTemplate1.2",
                                                                   "emailToken": "emailToken1.2",
                                                                   "status": "status1.2"}]},
                                               {"email" : "email2@bt.com",
                                                "linkedAccounts": [{"btId": "btid2.1",
                                                                    "emailTemplate": "emailTemplate2.1",
                                                                    "emailToken": "emailToken2.1",
                                                                    "status": "status2.1"},
                                                                   {"btId": "btid2.2",
                                                                    "emailTemplate": "emailTemplate2.2",
                                                                    "emailToken": "emailToken2.2",
                                                                    "status": "status2.2"}]}],
                       "otherEmails": [{"emailAddress": "otherEmail1@bt.com",
                                        "isPrimary": "Y"},
                                       {"emailAddress": "otherEmail2@bt.com",
                                        "isPrimary": "N"}],
                       "linkedAccountsToken": "1234567890ABCDEFG"
                     };

var linkedAccountsEmail = {
                            "btId": "btid1",
                            "emailTemplate": "emailTemplate1",
                            "emailToken": "emailToken1",
                            "status": "status1",
                            "pendingAccounts": ["pendingAccounts1", "pendingAccounts2", "pendingAccounts3"],
                            "profileAccounts": ["profileAccounts1", "profileAccounts2", "profileAccounts3"]
};

var paymentMethods =
    {
        "paymentMethod": "Cheque/Cash",
        "billFrequency": "3M",
        "paymentDay": "0",
        "billMedia": "Dual",
        "bankDetails": {
        "accountHolderName": "Account holder",
            "bankAccountNumber": "******7890",
            "sortCode": "******11"
    },
        "cardDetails": {
        "cardHolderName": "Bruce Wayne",
            "cardNumber": "************5678",
            "expiryDate": "2015-11-18"
    },
        "address": {
        "organization": null,
            "thoroughfareName": null,
            "dependentLocality": null,
            "subBuildingName": null,
            "county": null,
            "postCode": null,
            "buildingNumber": null,
            "dependentThoroughfare": null,
            "buildingName": null,
            "postTown": null,
            "poBox": null,
            "doubleDependentLocality": null,
            "country": null
    },
    "monthlyRecommendedAmount": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "usage": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "rental": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "outstanding": {
        "amount": 63.92,
        "currencyCode": "GBP"
},
    "eligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "1M"
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "3M"
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "1M"
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M"
        }
    ],
        "ineligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "3M",
        "reason": ["CPO"]
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "6M",
            "reason": ["CPO","LRPlus"]
        }
    ]
};

var noEligiblePaymentMethods =
{
    "paymentMethod": "Cheque/Cash",
    "billFrequency": "3M",
    "paymentDay": "0",
    "billMedia": "Dual",
    "bankDetails": {
        "accountHolderName": "Account holder",
        "bankAccountNumber": "******7890",
        "sortCode": "******11"
    },
    "cardDetails": {
        "cardHolderName": "Bruce Wayne",
        "cardNumber": "************5678",
        "expiryDate": "2015-11-18"
    },
    "address": {
        "organization": null,
        "thoroughfareName": null,
        "dependentLocality": null,
        "subBuildingName": null,
        "county": null,
        "postCode": null,
        "buildingNumber": null,
        "dependentThoroughfare": null,
        "buildingName": null,
        "postTown": null,
        "poBox": null,
        "doubleDependentLocality": null,
        "country": null
    },

    "outstanding": null,
    "eligiblePaymentMethods": [],
    "ineligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "3M",
        "reason": ["CPO"]
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        }
    ]
};

var paymentMethodsNoWbdd =
{
    "paymentMethod": "Cheque/Cash",
    "billFrequency": "3M",
    "paymentDay": "0",
    "billMedia": "Dual",
    "bankDetails": {
        "accountHolderName": "Account holder",
        "bankAccountNumber": "******7890",
        "sortCode": "******11"
    },
    "cardDetails": {
        "cardHolderName": "Bruce Wayne",
        "cardNumber": "************5678",
        "expiryDate": "2015-11-18"
    },
    "address": {
        "organization": null,
        "thoroughfareName": null,
        "dependentLocality": null,
        "subBuildingName": null,
        "county": null,
        "postCode": null,
        "buildingNumber": null,
        "dependentThoroughfare": null,
        "buildingName": null,
        "postTown": null,
        "poBox": null,
        "doubleDependentLocality": null,
        "country": null
    },
    "eligiblePaymentMethods": [
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "3M"
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "1M"
        }
    ],
    "ineligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "3M",
        "reason": ["CPO"]
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        }
    ]
};

var paymentMethodCcra =
{
    "paymentMethod": "CCRA",
    "billFrequency": "3M",
    "paymentDay": "0",
    "billMedia": "Dual",
    "bankDetails": {
        "accountHolderName": "Account holder",
        "bankAccountNumber": "******7890",
        "sortCode": "******11"
    },
    "cardDetails": {
        "cardHolderName": "Bruce Wayne",
        "cardNumber": "************5678",
        "expiryDate": "2015-11-18"
    },
    "address": {
        "organization": null,
        "thoroughfareName": null,
        "dependentLocality": null,
        "subBuildingName": null,
        "county": null,
        "postCode": null,
        "buildingNumber": null,
        "dependentThoroughfare": null,
        "buildingName": null,
        "postTown": null,
        "poBox": null,
        "doubleDependentLocality": null,
        "country": null
    },
    "eligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "1M"
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "3M"
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "1M"
        }
    ],
    "ineligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "3M",
        "reason": ["CPO"]
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        }
    ]
};

var paymentMethodDirectDebit =
{
    "paymentMethod": "Direct Debit",
    "billFrequency": "3M",
    "paymentDay": "0",
    "billMedia": "Dual",
    "bankDetails": {
        "accountHolderName": "Account holder",
        "bankAccountNumber": "******7890",
        "sortCode": "******11"
    },
    "cardDetails": {
        "cardHolderName": "Bruce Wayne",
        "cardNumber": "************5678",
        "expiryDate": "2015-11-18"
    },
    "address": {
        "organization": null,
        "thoroughfareName": null,
        "dependentLocality": null,
        "subBuildingName": null,
        "county": null,
        "postCode": null,
        "buildingNumber": null,
        "dependentThoroughfare": null,
        "buildingName": null,
        "postTown": null,
        "poBox": null,
        "doubleDependentLocality": null,
        "country": null
    },
    "eligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "1M"
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "3M"
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "1M"
        }
    ],
    "ineligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "3M",
        "reason": ["CPO"]
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        }
    ]
};

var paymentMethodMpp =
{
    "paymentMethod": "Monthly Payment Plan",
    "mppScenario": "REASSESS_HIGHER",
    "billFrequency": "3M",
    "paymentDay": 22,
    "billMedia": "Paper-free",
    "nextBillDate": null,
    "bankDetails": {
        "accountHolderName": "egsr",
        "bankAccountNumber": "****5672",
        "sortCode": "000003"
    },
    "cardDetails": null,
    "address": {
        "organization": null,
        "thoroughfareName": "Hoop Lane",
        "dependentLocality": "Mansion",
        "subBuildingName": "Main",
        "county": "ESSEX",
        "postCode": "CH49 6PN",
        "buildingNumber": "5",
        "dependentThoroughfare": null,
        "buildingName": "Odeon",
        "postTown": "LONDON",
        "poBox": null,
        "doubleDependentLocality": null,
        "country": "United Kingdom"
    },
    "monthlyRecommendedAmount": {
        "amount": 25.5,
        "currencyCode": "GBP"
    },
    "usage": {
        "amount": 4.5,
        "currencyCode": "GBP"
    },
    "rental": {
        "amount": 15.77,
        "currencyCode": "GBP"
    },
    "oneOff": {
        "amount": 0.0,
        "currencyCode": "GBP"
    },
    "outstanding": {
        "amount": 30.0,
        "currencyCode": "GBP"
    },
    "minimumAmount": {
        "amount": 10.0,
        "currencyCode": "GBP"
    },
    "maximumAmount": {
        "amount": 50.0,
        "currencyCode": "GBP"
    },
    "eligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "1M"
    }],
    "ineligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "3M",
        "reason": ["CPO", "LRS"]
    },
    {
        "paymentMethod": "Monthly Payment Plan",
        "frequency": "1M",
        "reason": ["CPO", "LRS"]
    },
    {
        "paymentMethod": "Monthly Payment Plan",
        "frequency": "3M",
        "reason": ["CPO", "LRS"]
    },
    {
        "paymentMethod": "CCRA",
        "frequency": "1M",
        "reason": ["LRS"]
    },
    {
        "paymentMethod": "CCRA",
        "frequency": "3M",
        "reason": ["CPO", "LRS"]
    },
    {
        "paymentMethod": "Cheque/Cash",
        "frequency": "1M",
        "reason": ["CPO", "LRS"]
    },
    {
        "paymentMethod": "Cheque/Cash",
        "frequency": "3M",
        "reason": ["CPO", "LRS"]
    }]
};

var paymentMethodsNoIneligibleCashFrequency =
{
    "paymentMethod": "Cheque/Cash",
    "billFrequency": "3M",
    "paymentDay": "0",
    "billMedia": "Dual",
    "bankDetails": {
        "accountHolderName": "Account holder",
        "bankAccountNumber": "******7890",
        "sortCode": "******11"
    },
    "cardDetails": {
        "cardHolderName": "Bruce Wayne",
        "cardNumber": "************5678",
        "expiryDate": "2015-11-18"
    },
    "address": {
        "organization": null,
        "thoroughfareName": null,
        "dependentLocality": null,
        "subBuildingName": null,
        "county": null,
        "postCode": null,
        "buildingNumber": null,
        "dependentThoroughfare": null,
        "buildingName": null,
        "postTown": null,
        "poBox": null,
        "doubleDependentLocality": null,
        "country": null
    },
    "eligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "1M"
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "3M"
        },
        {
            "paymentMethod": "Cheque/Cash"
        }
    ],
    "ineligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "3M",
        "reason": ["CPO"]
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        }
    ]
};

var noEligibleMpp =
{
    "paymentMethod": "Cheque/Cash",
    "billFrequency": "3M",
    "paymentDay": "0",
    "billMedia": "Dual",
    "bankDetails": {
        "accountHolderName": "Account holder",
        "bankAccountNumber": "******7890",
        "sortCode": "******11"
    },
    "cardDetails": {
        "cardHolderName": "Bruce Wayne",
        "cardNumber": "************5678",
        "expiryDate": "2015-11-18"
    },
    "address": {
        "organization": null,
        "thoroughfareName": null,
        "dependentLocality": null,
        "subBuildingName": null,
        "county": null,
        "postCode": null,
        "buildingNumber": null,
        "dependentThoroughfare": null,
        "buildingName": null,
        "postTown": null,
        "poBox": null,
        "doubleDependentLocality": null,
        "country": null
    },
    "monthlyRecommendedAmount": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "usage": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "rental": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "eligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "1M"
    },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "1M"
        }
    ],
    "ineligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "3M",
        "reason": ["CPO"]
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        }
    ]
};

var paymentMethodsNoInEligibility =
{
    "paymentMethod": "Cheque/Cash",
    "billFrequency": "3M",
    "paymentDay": "0",
    "billMedia": "Dual",
    "bankDetails": {
        "accountHolderName": "Account holder",
        "bankAccountNumber": "******7890",
        "sortCode": "******11"
    },
    "cardDetails": {
        "cardHolderName": "Bruce Wayne",
        "cardNumber": "************5678",
        "expiryDate": "2015-11-18"
    },
    "address": {
        "organization": null,
        "thoroughfareName": null,
        "dependentLocality": null,
        "subBuildingName": null,
        "county": null,
        "postCode": null,
        "buildingNumber": null,
        "dependentThoroughfare": null,
        "buildingName": null,
        "postTown": null,
        "poBox": null,
        "doubleDependentLocality": null,
        "country": null
    },
    "monthlyRecommendedAmount": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "usage": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "rental": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "outstanding": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "eligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "1M"
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "3M"
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "1M"
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M"
        }
    ],
    "ineligiblePaymentMethods": []
};


var existingPaymentMethod={
    "allowedToSetPaymentMethod": true,
        "blockingBalance": {
        "amount": 23.3,
            "currencyCode": "GBP"
    },
    "balance": {
        "amount": 23.3,
            "currencyCode": "GBP"
    }
};

var currentPaymentMethodNotInEligibleList =
{
    "paymentMethod": "Cheque/Cash",
    "billFrequency": "3M",
    "paymentDay": "0",
    "billMedia": "Dual",
    "bankDetails": {
        "accountHolderName": "Account holder",
        "bankAccountNumber": "******7890",
        "sortCode": "******11"
    },
    "cardDetails": {
        "cardHolderName": "Bruce Wayne",
        "cardNumber": "************5678",
        "expiryDate": "2015-11-18"
    },
    "address": {
        "organization": null,
        "thoroughfareName": null,
        "dependentLocality": null,
        "subBuildingName": null,
        "county": null,
        "postCode": null,
        "buildingNumber": null,
        "dependentThoroughfare": null,
        "buildingName": null,
        "postTown": null,
        "poBox": null,
        "doubleDependentLocality": null,
        "country": null
    },
    "monthlyRecommendedAmount": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "usage": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "rental": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "outstanding": {
        "amount": 63.92,
        "currencyCode": "GBP"
    },
    "eligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "1M"
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "3M"
        },
        {
            "paymentMethod": "Cheque/Cash",
            "frequency": "1M"
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M"
        }
    ],
    "ineligiblePaymentMethods": [{
        "paymentMethod": "Direct Debit",
        "frequency": "3M",
        "reason": ["CPO"]
    },
        {
            "paymentMethod": "Monthly Payment Plan",
            "frequency": "1M",
            "reason": ["CPO"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "3M",
            "reason": ["CPO","LRPlus"]
        },
        {
            "paymentMethod": "CCRA",
            "frequency": "1M",
            "reason": ["CPO"]
        }
    ]
};