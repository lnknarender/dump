/* global paymentMethodMpp, spyOn, expect, constants, moment */
describe('Factory: Payment method - editMppPaymentMethodService', function () {

    var editMppPaymentMethodService, scope, mockCommonPaymentMethodServices;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(inject(function (_commonPaymentMethodServices_, _editMppPaymentMethodService_, _$routeParams_, _stateService_, _$rootScope_) {
        editMppPaymentMethodService = _editMppPaymentMethodService_;

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202896169";
        _$routeParams_.telephone_num = "0202535714";
        _$routeParams_.agentEin = "0202535714";

        // Setup mock data
        _commonPaymentMethodServices_.paymentMethods = paymentMethodMpp;
        _commonPaymentMethodServices_.primaryContactDetails = {"email": "raj@gmail.com", "mobilePhoneNumber": "01543627219"};
        _stateService_.set("contactEmail", "raj@gmail.com");

        mockCommonPaymentMethodServices = _commonPaymentMethodServices_;
        spyOn(mockCommonPaymentMethodServices, 'updateAccount').and.callFake(function (args) {
            return {
                then: function (success, error) {
                    if (args.paymentDay > 0 || (args.monthlyPaymentPlanAmount && args.monthlyPaymentPlanAmount.amount !== 0)) {
                        success({});
                    } else {
                        error({});
                    }
                }
            };
        });
        scope = _$rootScope_.$new();
    }));

    it('Testing editMppPaymentMethodService - updatePaymentDay', function () {
        var result = null, error = null;
        editMppPaymentMethodService.updatePaymentDay("0202896169", 22).then(function (res) {
            result = res;
        }, function (res) {
            error = res;
        });
        scope.$digest();
        expect(result).not.toBeNull();
        expect(mockCommonPaymentMethodServices.updateAccount).toHaveBeenCalledWith({
            "billingAccount": '0202896169',
            "paymentMethod": "Monthly Payment Plan",
            "email": "raj@gmail.com",
            "billFrequency": "3M",
            "paymentDay": 22
        });
        expect(result.selectedDay).toBe(22);
        expect(result.email).toBe("raj@gmail.com");
    });
    
    it('Testing editMppPaymentMethodService - updatePaymentDay error', function () {
        var result = null, error = null;
        editMppPaymentMethodService.updatePaymentDay("0202896169", 0).then(function (res) {
            result = res;
        }, function (res) {
            error = res;
        });
        scope.$digest();
        expect(result).toBeNull();
        expect(error).not.toBeNull();
    });
    
    it('Testing editMppPaymentMethodService - updatePaymentAmount', function () {
        var result = null, error = null;
        editMppPaymentMethodService.updatePaymentAmount("0202896169", 30.00).then(function (res) {
            result = res;
        }, function (res) {
            error = res;
        });
        scope.$digest();
        expect(result).not.toBeNull();
        expect(mockCommonPaymentMethodServices.updateAccount).toHaveBeenCalledWith({
            "billingAccount": '0202896169',
            "paymentMethod": "Monthly Payment Plan",
            "email": "raj@gmail.com",
            "billFrequency": "3M",
            "monthlyPaymentPlanAmount": {
                "amount": 30.00,
                "currencyCode": "GBP"
            }
        });
        expect(result.amount).toBe(30.00);
        expect(result.email).toBe("raj@gmail.com");
    });
    
    it('Testing editMppPaymentMethodService - updatePaymentAmount error', function () {
        var result = null, error = null;
        editMppPaymentMethodService.updatePaymentAmount("0202896169", 0).then(function (res) {
            result = res;
        }, function (res) {
            error = res;
        });
        scope.$digest();
        expect(result).toBeNull();
        expect(error).not.toBeNull();
    });
});
