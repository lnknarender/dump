/* global paymentMethodMpp, spyOn, expect, constants, moment */
describe('Controller: Payment method - editMpp', function () {

    var $rootScope, $controller, editMppPaymentMethodService;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(inject(function (_$rootScope_, _$controller_, _commonPaymentMethodServices_, _editMppPaymentMethodService_) {
        $controller = _$controller_;
        $rootScope = _$rootScope_;
        editMppPaymentMethodService = _editMppPaymentMethodService_;

        // Setup mock data
        _commonPaymentMethodServices_.paymentMethods = paymentMethodMpp;
        _commonPaymentMethodServices_.primaryContactDetails = {"email": "raj@gmail.com", "mobilePhoneNumber": "01543627219"};
    }));
    describe("editMppPaymentDayCtrl", function () {
        var scope, vm;
        beforeEach(function () {
            scope = $rootScope.$new();
            vm = $controller('editMppPaymentDayCtrl',
                    {$scope: scope,
                        $routeParams: {
                            cak: "ACC_002",
                            conk: "002",
                            bac: "0202896169"
                        }});
            scope.$digest();

            spyOn(editMppPaymentMethodService, 'updatePaymentDay').and.callFake(function (bac, day) {
                return {
                    then: function (success, error) {
                        if (day !== 1) {
                            success({
                                email: "raj@gmail.com",
                                selectedDay: day
                            });
                        } else {
                            error({});
                        }
                    }
                };
            });
        });
        it('Testing editMppPaymentDayCtrl', function () {
            expect(vm.paymentMethods).not.toBeNull();
            expect(vm.paymentMethods.paymentMethod).toBe(constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN);
            expect(vm.getPaymentDays()).toEqual([1, 2, 3, 4, 5, 6, 7,
                8, 9, 10, 11, 12, 13, 14,
                15, 16, 17, 18, 19, 20, 21,
                22, 23, 24, 25, 26, 27, 28]);

            expect(vm.selectedDay).toBe(22);
            expect(vm.formattedDay).toBe(moment().date(22).format("Do"));
            expect(vm.currentPaymentDay).toBe(moment().date(22).format("Do"));

            expect(vm.paymentsOverview).toEqual([]);
            expect(vm.showpaymentday).toBe(true);
            expect(vm.allowUpdate).toBe(false);

            //Select a same day as current date. continue button should be disabled
            vm.selectPaymentday(22);
            expect(vm.paymentsOverview).toEqual([]);
            expect(vm.allowUpdate).toBe(false);

            //Select a same day as current date. continue button should be disabled
            vm.selectPaymentday(25);
            expect(vm.paymentsOverview.length).toEqual(3);
            expect(vm.allowUpdate).toBe(true);

            //Save the changes and verify the output
            vm.saveChanges();
            expect(vm.email).toBe("raj@gmail.com");
            expect(vm.selectedDay).toBe(25);
            expect(vm.showpaymentday).toBe(false);
            expect(vm.showpaymentdaysuccess).toBe(true);
        });

        it('Testing editMppPaymentDayCtrl - last payment day', function () {
            expect(vm.paymentMethods).not.toBeNull();
            expect(vm.paymentMethods.paymentMethod).toBe(constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN);
            expect(vm.getPaymentDays()).toEqual([1, 2, 3, 4, 5, 6, 7,
                8, 9, 10, 11, 12, 13, 14,
                15, 16, 17, 18, 19, 20, 21,
                22, 23, 24, 25, 26, 27, 28]);

            //Select a same day as current date. continue button should be disabled
            vm.selectLastPaymentDay();
            expect(vm.paymentsOverview.length).toEqual(3);
            expect(vm.allowUpdate).toBe(true);

            //Save the changes and verify the output
            vm.saveChanges();
            expect(vm.email).toBe("raj@gmail.com");
            expect(vm.selectedDay).toBe(-1);
            expect(vm.showpaymentdaysuccess).toBe(true);
            expect(vm.showpaymentday).toBe(false);
        });

        it('Testing editMppPaymentDayCtrl - error', function () {
            expect(vm.paymentMethods).not.toBeNull();
            expect(vm.paymentMethods.paymentMethod).toBe(constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN);
            expect(vm.getPaymentDays()).toEqual([1, 2, 3, 4, 5, 6, 7,
                8, 9, 10, 11, 12, 13, 14,
                15, 16, 17, 18, 19, 20, 21,
                22, 23, 24, 25, 26, 27, 28]);

            //Select a same day as current date. continue button should be disabled
            vm.selectPaymentday(1);
            expect(vm.paymentsOverview.length).toEqual(3);
            expect(vm.allowUpdate).toBe(true);

            //Save the changes and verify the output
            vm.saveChanges();
            expect(vm.showpaymentdayfailure).toBe(true);
            expect(vm.showpaymentdaysuccess).toBe(false);
            expect(vm.showpaymentday).toBe(false);
        });
    });

    describe("editMppPaymentAmountCtrl", function () {
        var scope, vm;
        beforeEach(function () {
            scope = $rootScope.$new();
            vm = $controller('editMppPaymentAmountCtrl',
                    {$scope: scope,
                        $routeParams: {
                            cak: "ACC_002",
                            conk: "002",
                            bac: "0202896169"
                        }});
            scope.$digest();

            spyOn(editMppPaymentMethodService, 'updatePaymentAmount').and.callFake(function (bac, amount) {
                return {
                    then: function (success, error) {
                        if (amount !== 25.5) {
                            success({
                                email: "raj@gmail.com",
                                amount: amount
                            });
                        } else {
                            error({});
                        }
                    }
                };
            });
        });
        it('Testing editMppPaymentAmountCtrl', function () {
            expect(vm.paymentMethods).not.toBeNull();
            expect(vm.paymentMethods.paymentMethod).toBe(constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN);
            expect(vm.monthlyAmount).toBe(25.5);
            expect(vm.showpaymentamount).toBe(true);

            //Save the changes and verify the output
            vm.monthlyAmount = 40;
            vm.saveChanges();
            expect(vm.email).toBe("raj@gmail.com");
            expect(vm.monthlyAmount).toBe(40);
            expect(vm.showpaymentamountsuccess).toBe(true);
            expect(vm.showpaymentamount).toBe(false);
        });

        it('Testing editMppPaymentAmountCtrl - validations', function () {
            expect(vm.paymentMethods).not.toBeNull();
            expect(vm.paymentMethods.paymentMethod).toBe(constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN);
            expect(vm.monthlyAmount).toBe(25.5);
            expect(vm.showpaymentamount).toBe(true);

            //Save the changes and verify the output
            vm.monthlyAmount = "";
            expect(vm.isInvalidAmount()).toBe(true);

            vm.monthlyAmount = 5;
            expect(vm.isInvalidAmount()).toBe(false);
            expect(vm.showMinError()).toBe(true);

            vm.monthlyAmount = 51;
            expect(vm.isInvalidAmount()).toBe(false);
            expect(vm.showMaxError()).toBe(true);
        });

        it('Testing editMppPaymentAmountCtrl - update failed', function () {
            expect(vm.paymentMethods).not.toBeNull();
            expect(vm.paymentMethods.paymentMethod).toBe(constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN);
            expect(vm.monthlyAmount).toBe(25.5);
            expect(vm.showpaymentamount).toBe(true);

            vm.saveChanges();
            expect(vm.showpaymentamountsuccess).toBe(false);
            expect(vm.showpaymentamountfailure).toBe(true);
            expect(vm.showpaymentamount).toBe(false);
        });
    });
});
