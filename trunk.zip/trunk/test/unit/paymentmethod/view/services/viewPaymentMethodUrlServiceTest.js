/**
 * Created by dev on 9/16/15.
 */

describe ('Service: viewPaymentMethodUrlService',function(){

    var service, scope;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    beforeEach(inject(function(_$rootScope_, _commonPaymentMethodUrlService_) {

        scope = _$rootScope_.$new();

        service = _commonPaymentMethodUrlService_;
    }));

    it('Testing view payment method Url Service - agent', inject(function () {

        connection.userType = "agent";

        //  Call the service under test
        var url = service.getViewPaymentMethodUrl();

        //  Assert that the service under test returns the expected values
       expect(url).toEqual("undefined/protected/v1/cak/ACC_002/conk/002/bac/0202535714/paymentmethods");
    }));

    it('Testing view payment method Url Service - customer', inject(function () {

        connection.userType = "customer";

        //  Call the service under test
        var url = service.getViewPaymentMethodUrl();

        //  Assert that the service under test returns the expected values
        expect(url).toEqual("undefined/protected/v1/acckey/1234/paymentmethods");
    }));
});