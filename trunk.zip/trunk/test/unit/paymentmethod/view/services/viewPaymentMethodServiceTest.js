describe('Service: viewPaymentMethodService', function () {

    var stateService, $q, $httpBackend, scope, paymentMethodService, mockAjaxServiceWithToken, paymentMethodUrlService, urlService, viewPaymentMethodServices, paymentMethodServices;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    function setupTest (mockData) {
        (inject(function (_$rootScope_, _accessTokenService_, ajaxServiceWithToken, _viewPaymentMethodServices_, _urlService_, _commonPaymentMethodUrlService_, _$q_, _$httpBackend_, _stateService_, _commonPaymentMethodServices_) {

            scope = _$rootScope_.$new();
            //$q = _$q_;
            $httpBackend = _$httpBackend_;

            stateService = _stateService_;

            mockAjaxServiceWithToken = ajaxServiceWithToken;
            paymentMethodUrlService = _commonPaymentMethodUrlService_;
            viewPaymentMethodServices = _viewPaymentMethodServices_;
            urlService = _urlService_;
            paymentMethodServices = _commonPaymentMethodServices_;

            spyOn(mockAjaxServiceWithToken, 'doGet').and.callFake(function () {

                return {

                    then: function (callback) {
                        return callback(mockData);
                    },

                    catch: function (callback) {
                        return null;
                    },

                    finally: function (callback) {
                        return null;
                    }
                };
            });

            //var deferred = _$q_.defer();
            //deferred.resolve();
            //scope.$digest();
        }));
    }

    beforeEach(angular.mock.inject(function (_urlService_) {

        urlService = _urlService_;
    }));

    it('Test viewPaymentMethodService - getViewPaymentMethods via ReST', (function () {

        setupTest(paymentMethods);

        paymentMethodServices.getViewPaymentMethods();
        var paymentMethods = stateService.get(constants.STATE_SERVICE_PAYMENT_METHODS);

        //  Assert that the PUT method has been called
        expect(paymentMethods).toEqual(paymentMethods);


        paymentMethods = stateService.set(constants.STATE_SERVICE_PAYMENT_METHODS, 'Testing');

        //  Assert that the URL service has not been called
        var url = paymentMethodUrlService.getViewPaymentMethodUrl();
        expect(mockAjaxServiceWithToken.doGet).toHaveBeenCalledWith(url, { });
    }));

    it('Test viewPaymentMethodService - getViewPaymentMethods from state service', (function () {

        setupTest(paymentMethods);

        // Test that if state service already has payment methods if it does not try retrieve they using a ReST call
        var paymentMethods = stateService.set(constants.STATE_SERVICE_PAYMENT_METHODS, 'Already got data');

        paymentMethodServices.getViewPaymentMethods();
        paymentMethods = stateService.get(constants.STATE_SERVICE_PAYMENT_METHODS);

        //  Assert that the PUT method has been called
        expect(paymentMethods).toEqual('Already got data');

        //  Assert that the URL service has not been called
        var url = paymentMethodUrlService.getViewPaymentMethodUrl();
        expect(mockAjaxServiceWithToken.doGet).not.toHaveBeenCalledWith(url, { });
    }));

    it('Test viewPaymentMethodService - isQuarterlyBill', (function () {

        setupTest(paymentMethods);

        var isQuarterly = viewPaymentMethodServices.isQuarterlyBill(paymentMethods);

        //  Assert the quarterly bill service returns the correct value
        expect(isQuarterly).toEqual(true);

        paymentMethods.billFrequency = constants.BILL_MONTHLY;
        isQuarterly = viewPaymentMethodServices.isQuarterlyBill(paymentMethods);

        //  Assert the quarterly bill service returns the correct value
        expect(isQuarterly).toEqual(false);


        //  Assert the quarterly bill service handles undefined
        isQuarterly = viewPaymentMethodServices.isQuarterlyBill(undefined);
        expect(isQuarterly).toEqual(false);
    }));

    it('Test viewPaymentMethodService - isCashAndCheck', (function () {

        setupTest(paymentMethods);

        var isCashCheque = viewPaymentMethodServices.isCashAndCheck(paymentMethods);

        //  Assert the cash/cheque service returns the correct value
        expect(isCashCheque).toEqual(true);
    }));

    it('Test viewPaymentMethodService - isEligiblePaymentMethods (true)', (function () {

        var isEligible = viewPaymentMethodServices.isEligiblePaymentMethods(paymentMethods);

        //  Assert the eligible payment methods
        expect(isEligible).toEqual(true);
    }));

    it('Test viewPaymentMethodService - isEligiblePaymentMethods (false)', (function () {

        var isEligible = viewPaymentMethodServices.isEligiblePaymentMethods(noEligiblePaymentMethods);

        //  Assert the eligible payment methods
        expect(isEligible).toEqual(false);
    }));

    it('Test viewPaymentMethodService - isEligiblePaymentMethods (false)', (function () {

        var found = viewPaymentMethodServices.isWholeBillDDEligiblePaymentMethodPresent(paymentMethods);

        //  Assert the eligible payment methods
        expect(found).toEqual(true);
    }));

    it('Test viewPaymentMethodService - isWholeBillDDEligiblePaymentMethodPresent (true)', (function () {

        var found = viewPaymentMethodServices.isWholeBillDDEligiblePaymentMethodPresent(paymentMethods);

        //  Assert the whole bill direct debit
        expect(found).toEqual(true);
    }));

    it('Test viewPaymentMethodService - isWholeBillDDEligiblePaymentMethodPresent (false)', (function () {

        var found = viewPaymentMethodServices.isWholeBillDDEligiblePaymentMethodPresent(paymentMethodsNoWbdd);

        //  Assert the whole bill direct debit
        expect(found).toEqual(false);
    }));

    it('Test viewPaymentMethodService - isCustomerEligibleForCashAndCheque (true)', (function () {

        var found = viewPaymentMethodServices.isCustomerEligibleForCashAndCheque(paymentMethodsNoWbdd);

        //  Assert the cash & cheque
        expect(found).toEqual(true);
    }));

    it('Test viewPaymentMethodService - isCustomerEligibleForCcra (false)', (function () {

        var found = viewPaymentMethodServices.isCustomerEligibleForCcra(paymentMethodsNoWbdd);

        //  Assert the cash & cheque
        expect(found).toEqual(false);
    }));

    it('Test viewPaymentMethodService - isCustomerEligibleForCcra (true)', (function () {

        var found = viewPaymentMethodServices.isCustomerEligibleForCcra(paymentMethods);

        //  Assert the cash & cheque
        expect(found).toEqual(true);
    }));

    it('Test viewPaymentMethodService - isEligiblePaymentMethodWithFrequency (Cheque/Cash)', (function () {

        var found = viewPaymentMethodServices.isEligiblePaymentMethodWithFrequency(paymentMethods);

        //  Assert Cheque/Cash
        expect(found).toEqual(true);
    }));

    it('Test viewPaymentMethodService - isEligiblePaymentMethodWithFrequency (Cheque/Cash - no frequency)', (function () {

        var found = viewPaymentMethodServices.isEligiblePaymentMethodWithFrequency(paymentMethodsNoIneligibleCashFrequency);

        //  Assert Cheque/Cash
        expect(found).toEqual(false);
    }));

    it('Test viewPaymentMethodService - calculateOutstandingChargesPerMonths ', (function () {

        var perMonth = viewPaymentMethodServices.calculateOutstandingChargesPerMonths(paymentMethods);

        //  Assert amount per month
        // 63.92/6
        expect(Math.round(perMonth * 100) / 100).toEqual(10.65);
    }));

    it('Test viewPaymentMethodService - getIneligiblePaymentMethodReasons', (function () {

        var uniqueIneligibles = viewPaymentMethodServices.getIneligiblePaymentMethodReasons(paymentMethodsNoWbdd);

        expect(uniqueIneligibles.length).toEqual(2);

        expect(uniqueIneligibles[0].paymentMethod).toEqual("Direct Debit");
        expect(uniqueIneligibles[0].frequency).toEqual("3M");
        expect(uniqueIneligibles[0].reason).toEqual(["CPO"]);

        expect(uniqueIneligibles[1].paymentMethod).toEqual("CCRA");
        expect(uniqueIneligibles[1].frequency).toEqual("3M");
        expect(uniqueIneligibles[1].reason).toEqual(["CPO", "LRPlus"]);
    }));

    it('Test viewPaymentMethodService - getIneligiblePaymentMethodReasons - add an extra CCRA reason', (function () {

        var paymentMethods = paymentMethodsNoWbdd;

        paymentMethods.ineligiblePaymentMethods[3].reason.push("XYZ");

        var uniqueIneligibles = viewPaymentMethodServices.getIneligiblePaymentMethodReasons(paymentMethods);

        expect(uniqueIneligibles.length).toEqual(2);

        expect(uniqueIneligibles[0].paymentMethod).toEqual("Direct Debit");
        expect(uniqueIneligibles[0].frequency).toEqual("3M");
        expect(uniqueIneligibles[0].reason).toEqual(["CPO"]);

        expect(uniqueIneligibles[1].paymentMethod).toEqual("CCRA");
        expect(uniqueIneligibles[1].frequency).toEqual("3M");
        expect(uniqueIneligibles[1].reason).toEqual(["CPO", "LRPlus", "XYZ"]);
    }));

    it('Test viewPaymentMethodService - getIneligiblePaymentMethodReasons - all payment methods present as eligible and ineligible', (function () {

        var uniqueIneligibles = viewPaymentMethodServices.getIneligiblePaymentMethodReasons(paymentMethods);

        expect(uniqueIneligibles.length).toEqual(0);
    }));

    it('Test viewPaymentMethodService - getIneligiblePaymentMethodReasons - empty ineligibility', (function () {

        var uniqueIneligibles = viewPaymentMethodServices.getIneligiblePaymentMethodReasons(paymentMethodsNoInEligibility);

        expect(uniqueIneligibles.length).toEqual(0);
    }));

    it('Test viewPaymentMethodService - getIneligiblePaymentMethodReasons - empty eligibility', (function () {

        var uniqueIneligibles = viewPaymentMethodServices.getIneligiblePaymentMethodReasons(noEligiblePaymentMethods);

        expect(uniqueIneligibles.length).toEqual(4);

        expect(uniqueIneligibles[0].paymentMethod).toEqual("Direct Debit");
        expect(uniqueIneligibles[0].frequency).toEqual("3M");
        expect(uniqueIneligibles[0].reason).toEqual(["CPO"]);

        expect(uniqueIneligibles[1].paymentMethod).toEqual("Monthly Payment Plan");
        expect(uniqueIneligibles[1].frequency).toEqual("1M");
        expect(uniqueIneligibles[1].reason).toEqual(["CPO"]);

        expect(uniqueIneligibles[2].paymentMethod).toEqual("CCRA");
        expect(uniqueIneligibles[2].frequency).toEqual("3M");
        expect(uniqueIneligibles[2].reason).toEqual(["CPO","LRPlus"]);

        expect(uniqueIneligibles[3].paymentMethod).toEqual("Cheque/Cash");
        expect(uniqueIneligibles[3].frequency).toEqual("3M");
        expect(uniqueIneligibles[3].reason).toEqual(["CPO","LRPlus"]);
    }));

    it('Test viewPaymentMethodService - getIneligiblePaymentMethodFrequencyReasons ', (function () {

        var ineligibleFrequencies = viewPaymentMethodServices.getIneligiblePaymentMethodFrequencyReasons(paymentMethods);

        expect(ineligibleFrequencies.length).toEqual(2);

        expect(ineligibleFrequencies[0].paymentMethod).toEqual("Cheque/Cash");
        expect(ineligibleFrequencies[0].frequency).toEqual("3M");
        expect(ineligibleFrequencies[0].reason).toEqual(["CPO","LRPlus"]);

        expect(ineligibleFrequencies[1].paymentMethod).toEqual("Cheque/Cash");
        expect(ineligibleFrequencies[1].frequency).toEqual("6M");
        expect(ineligibleFrequencies[1].reason).toEqual(["CPO","LRPlus"]);
    }));

    it('Test viewPaymentMethodService - getIneligiblePaymentMethodFrequencyReasons - no eligible payment methods', (function () {

        var ineligibleFrequencies = viewPaymentMethodServices.getIneligiblePaymentMethodFrequencyReasons(noEligiblePaymentMethods);

        expect(ineligibleFrequencies.length).toEqual(0);
    }));

    it('Test viewPaymentMethodService - getIneligiblePaymentMethodFrequencyReasons - current payment method not in ineligible list', (function () {

        var ineligibleFrequencies = viewPaymentMethodServices.getIneligiblePaymentMethodFrequencyReasons(currentPaymentMethodNotInEligibleList);

        expect(ineligibleFrequencies.length).toEqual(0);
    }));
});