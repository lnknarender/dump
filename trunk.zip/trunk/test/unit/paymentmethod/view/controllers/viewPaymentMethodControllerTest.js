/**
 * Created by Andrew on 25/11/2015.
 */
describe('Controller: Payment method - viewPaymentMethodCtrl', function () {

    var scope, location, createController;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
    }));

    beforeEach(inject(function ($rootScope, $controller, _$location_, _urlService_, _errorLoggingService_, _viewPaymentMethodServices_, _viewLatestBillService_, _primaryContactService_, _utilityService_, _commonPaymentMethodServices_) {

        location = _$location_;       
        scope = $rootScope.$new();
        //$scope, $location, urlService, errorLoggingService, viewPaymentMethodService, viewLatestBillService, primaryContactService, utilityService, paymentMethodServices
        //  Create the viewPaymentMethodCtrl and pass the mock objects
        createController = function() {
            var ctrl = $controller('viewPaymentMethodCtrl',
                                {$scope: scope,
                                 $location: location,
                                 urlService: _urlService_,
                                 errorLoggingService: _errorLoggingService_,
                                 viewPaymentMethodServices: _viewPaymentMethodServices_,
                                 viewLatestBillService: _viewLatestBillService_,
                                 primaryContactService: _primaryContactService_,
                                 utilityService: _utilityService_,
                                 paymentMethodServices: _commonPaymentMethodServices_
            });
            scope.$digest();
            return ctrl;
        };
    }));

    //  Mock the payment method service (getAccount) and access token service (getToken)
    function setupTest (mockData) {
        (angular.mock.inject(function (_commonPaymentMethodServices_, _primaryContactService_) {

            spyOn(_commonPaymentMethodServices_, 'getViewPaymentMethods').and.callFake(function () {

                return {

                    then: function (callback) {
                        return callback(mockData);
                    },

                    catch: function (callback) {
                        return null;
                    },

                    finally: function (callback) {
                        return null;
                    }
                };
            });
            
            spyOn(_primaryContactService_, 'getContactDetails').and.callFake(function () {

                return {

                    then: function (callback) {
                        return callback({"email":"raj@gmail.com","mobilePhoneNumber":"01543627219"});
                    },

                    catch: function (callback) {
                        return null;
                    },

                    finally: function (callback) {
                        return null;
                    }
                };
            });

        }));
    }

    it('Testing viewPaymentMethodCtrl', function() {

        setupTest(paymentMethods);
        scope.paymentMethods=paymentMethods;
        //  Create the controller
        createController();

       /* expect(scope.isDisplayAutomatedPaymentsLink()).toBeTruthy();
        expect(scope.isDisplayWholeBillDDEligibleAlert()).toBeTruthy();

        expect(scope.isDisplayChangePaymentMethodLink()).toBeFalsy();
        expect(scope.isDisplayBankDetails()).toBeFalsy();
        expect(scope.isDisplayCreditCardDetails()).toBeFalsy();*/
    });

    it('Testing viewPaymentMethodCtrl - no eligible payments', function() {

        setupTest(noEligiblePaymentMethods);
        scope.paymentMethods=paymentMethods;
        //  Create the controller
        createController();

      /*  expect(scope.isDisplayAutomatedPaymentsLink()).toBeFalsy();
        expect(scope.isDisplayWholeBillDDEligibleAlert()).toBeFalsy();
        expect(scope.isDisplayChangePaymentMethodLink()).toBeFalsy();
        expect(scope.isDisplayBankDetails()).toBeFalsy();
        expect(scope.isDisplayCreditCardDetails()).toBeFalsy();*/
    });

    it('Testing viewPaymentMethodCtrl - no whole bill direct debit', function() {

        setupTest(paymentMethodsNoWbdd);

        //  Create the controller
        createController();
        scope.paymentMethods=paymentMethods;
       // expect(scope.isDisplayAutomatedPaymentsLink()).toBeTruthy();

       /* expect(scope.isDisplayWholeBillDDEligibleAlert()).toBeFalsy();
        expect(scope.isDisplayChangePaymentMethodLink()).toBeFalsy();
        expect(scope.isDisplayBankDetails()).toBeFalsy();
        expect(scope.isDisplayCreditCardDetails()).toBeFalsy();*/
    });

    it('Testing viewPaymentMethodCtrl - CCRA', function() {

        setupTest(paymentMethodCcra);

        //  Create the controller
        createController();
        scope.paymentMethods=paymentMethods;
      /* expect(scope.isDisplayCreditCardDetails()).toBeTruthy();
        expect(scope.isDisplayChangePaymentMethodLink()).toBeTruthy();

        expect(scope.isDisplayAutomatedPaymentsLink()).toBeFalsy();
        expect(scope.isDisplayWholeBillDDEligibleAlert()).toBeFalsy();
        expect(scope.isDisplayBankDetails()).toBeFalsy();*/
    });

    it('Testing viewPaymentMethodCtrl - Direct Debit', function() {

        setupTest(paymentMethodDirectDebit);

        //  Create the controller
        createController();
        scope.paymentMethods=paymentMethods;
        //expect(scope.isDisplayChangePaymentMethodLink()).toBeTruthy();
       /* expect(scope.isDisplayBankDetails()).toBeTruthy();

        expect(scope.isDisplayCreditCardDetails()).toBeFalsy();
        expect(scope.isDisplayAutomatedPaymentsLink()).toBeFalsy();
        expect(scope.isDisplayWholeBillDDEligibleAlert()).toBeFalsy();*/
    });

    it('Testing viewPaymentMethodCtrl - Monthly Payment Plan', function () {

        setupTest(paymentMethodMpp);
        //  Create the controller
        createController();
        
        expect(scope.paymentMethods).not.toBeNull();
        expect(scope.paymentMethods.paymentMethod).toBe(constants.PAYMENT_METHOD_MONTHLY_PAYMENT_PLAN);
        expect(scope.paymentMethods.paymentDay).toBe(22);
        expect(scope.isDisplayBankDetails()).toBeTruthy();

        expect(scope.isDisplayChangePaymentMethodLink()).toBeTruthy();
        expect(scope.isDisplayMonthlyPaymentPlan()).toBeTruthy();
        expect(scope.isDisplayChangeDay()).toBeTruthy();
        expect(scope.isDisplayCreditCardDetails()).toBeFalsy();
        expect(scope.isDisplayAutomatedPaymentsLink()).toBeFalsy();
        expect(scope.isDisplayWholeBillDDEligibleAlert()).toBeFalsy();
    });
});
