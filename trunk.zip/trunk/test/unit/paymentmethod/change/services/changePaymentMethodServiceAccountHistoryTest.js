describe('Service: changePaymentMethodService', function () {

    var stateService, changePaymentMethodServices;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(inject(function (_changePaymentMethodServices_) {

        changePaymentMethodServices = _changePaymentMethodServices_;
    }));


    it('Test getAccountHistoryDetails - returns correct account History', (function () {

        var accountHistory = {"accountHistoryDetails" :[{
         "paymentMethod": "Cheque/Cash",  "from":"2008-07-17T12:54:25.000",  "to" :null},
        { "paymentMethod" : "CCRA",  "from":"2008-06-15T14:25:34.000",  "to":"2008-07-17T12:54:25.000"},
        { "paymentMethod":"Monthly Payment Plan",  "from":"2008-05-14T14:25:34.000",  "to":"2008-06-15T14:25:34.000"},
        { "paymentMethod":"Cheque/Cash",  "from":"2008-05-10T14:25:34.000",  "to":"2008-05-14T14:25:34.000"}]};

        var newAccountHistory = changePaymentMethodServices.getAccountHistoryDetails(accountHistory);

        //  Assert that the new history is correct
        expect(newAccountHistory.accountHistoryDetails.length).toEqual(3);

        expect(newAccountHistory.accountHistoryDetails[0].date).toEqual('17 July 2008');
        expect(newAccountHistory.accountHistoryDetails[0].from).toEqual('CCRA');
        expect(newAccountHistory.accountHistoryDetails[0].to).toEqual('Cheque/Cash');

        expect(newAccountHistory.accountHistoryDetails[1].date).toEqual('15 June 2008');
        expect(newAccountHistory.accountHistoryDetails[1].from).toEqual('Monthly Payment Plan');
        expect(newAccountHistory.accountHistoryDetails[1].to).toEqual('CCRA');

        expect(newAccountHistory.accountHistoryDetails[2].date).toEqual('14 May 2008');
        expect(newAccountHistory.accountHistoryDetails[2].from).toEqual('Cheque/Cash');
        expect(newAccountHistory.accountHistoryDetails[2].to).toEqual('Monthly Payment Plan');
    }));

    it('Test getAccountHistoryDetails - returns correct account History', (function () {

        var accountHistory = {"accountHistoryDetails" :[{
            "paymentMethod": "Cheque/Cash",  "from":"2015-11-11T12:54:25.000",  "to" :null},
            { "paymentMethod" : "CCRA",  "from":"2014-07-05T14:25:34.000",  "to":"2015-11-11T12:54:25.000"},
            { "paymentMethod":"Cheque/Cash",  "from":"2012-12-25T14:25:34.000",  "to":"2014-07-05T14:25:34.000"},
            { "paymentMethod":"Monthly Payment Plan",  "from":"2012-01-01T14:25:34.000",  "to":"2012-12-25T14:25:34.000"},
            { "paymentMethod":"CCRA",  "from":"2011-05-10T14:25:34.000",  "to":"2012-01-01T14:25:34.000"},
            { "paymentMethod":"Direct Debit",  "from":"2011-05-10T14:25:34.000",  "to":"2011-05-14T14:25:34.000"}]};

        var newAccountHistory = changePaymentMethodServices.getAccountHistoryDetails(accountHistory);

        //  Assert that the new history is correct
        expect(newAccountHistory.accountHistoryDetails.length).toEqual(5);

        expect(newAccountHistory.accountHistoryDetails[0].date).toEqual('11 November 2015');
        expect(newAccountHistory.accountHistoryDetails[0].from).toEqual('CCRA');
        expect(newAccountHistory.accountHistoryDetails[0].to).toEqual('Cheque/Cash');

        expect(newAccountHistory.accountHistoryDetails[1].date).toEqual('5 July 2014');
        expect(newAccountHistory.accountHistoryDetails[1].from).toEqual('Cheque/Cash');
        expect(newAccountHistory.accountHistoryDetails[1].to).toEqual('CCRA');

        expect(newAccountHistory.accountHistoryDetails[2].date).toEqual('25 December 2012');
        expect(newAccountHistory.accountHistoryDetails[2].from).toEqual('Monthly Payment Plan');
        expect(newAccountHistory.accountHistoryDetails[2].to).toEqual('Cheque/Cash');

        expect(newAccountHistory.accountHistoryDetails[3].date).toEqual('1 January 2012');
        expect(newAccountHistory.accountHistoryDetails[3].from).toEqual('CCRA');
        expect(newAccountHistory.accountHistoryDetails[3].to).toEqual('Monthly Payment Plan');

        expect(newAccountHistory.accountHistoryDetails[4].date).toEqual('10 May 2011');
        expect(newAccountHistory.accountHistoryDetails[4].from).toEqual('Direct Debit');
        expect(newAccountHistory.accountHistoryDetails[4].to).toEqual('CCRA');
    }));

    it('Test getAccountHistoryDetails - noHistory', (function () {

        var accountHistory = {"accountHistoryDetails" :[{
            "paymentMethod": "Cheque/Cash",  "from":"2015-11-11T12:54:25.000",  "to" :null}]};

        var newAccountHistory = changePaymentMethodServices.getAccountHistoryDetails(accountHistory);

        //  Assert that the new history is correct
        expect(newAccountHistory.accountHistoryDetails.length).toEqual(0);

    }));

    it('Test getAccountHistoryDetails - one History', (function () {

        var accountHistory = {"accountHistoryDetails" :[{
            "paymentMethod": "Cheque/Cash",  "from":"2015-11-11T12:54:25.000",  "to" :null},
            {"paymentMethod": "Direct Debit",  "from":"2014-11-11T12:54:25.000",  "to" :"2015-11-11T12:54:25.000"}]};

        var newAccountHistory = changePaymentMethodServices.getAccountHistoryDetails(accountHistory);

        //  Assert that the new history is correct
        expect(newAccountHistory.accountHistoryDetails.length).toEqual(1);

        expect(newAccountHistory.accountHistoryDetails[0].date).toEqual('11 November 2015');
        expect(newAccountHistory.accountHistoryDetails[0].from).toEqual('Direct Debit');
        expect(newAccountHistory.accountHistoryDetails[0].to).toEqual('Cheque/Cash');

    }));

});