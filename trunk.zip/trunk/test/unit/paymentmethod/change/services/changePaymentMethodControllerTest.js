/**
 * Created by Andrew on 11/12/2015.
 */
describe('Controller: Payment method - changePaymentMethodCashChequeCtrl', function () {

    var scope, createController;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
    }));

    beforeEach(inject(function ($rootScope, $controller, _$location_, _changePaymentMethodServices_, _commonPaymentMethodServices_) {

        var location = _$location_;
        scope = $rootScope.$new();

        //  Create the changePaymentMethodCashChequeCtrl and pass the mock objects
        createController = function() {
            return $controller('changePaymentMethodCashChequeCtrl',
                {$scope: scope,
                 $location: location,
                 changePaymentMethodServices: _changePaymentMethodServices_,
                 commonPaymentMethodService: _commonPaymentMethodServices_
                }
            );
        };
    }));


    //  Mock the payment method service (getViewPaymentMethods)
    function setupTest (mockData) {
        (angular.mock.inject(function (_$location_, _$q_, _$rootScope_, _commonPaymentMethodServices_) {

            scope = _$rootScope_.$new();

            var deferred = _$q_.defer();
            var mockPaymentMethodService = _commonPaymentMethodServices_;

            spyOn(mockPaymentMethodService, 'getViewPaymentMethods').and.callFake(function () {

                return {

                    then: function (callback) {
                        return callback(mockData);
                    },

                    catch: function (callback) {
                        return null;
                    },

                    finally: function (callback) {
                        return null;
                    }
                };
            });

            deferred.resolve(true);
            scope.$digest();
        }));
    }

    it('Testing changePaymentMethodCashChequeCtrl', function() {

        setupTest(paymentMethods);

        //  Create the controller
        createController();

       /* expect(scope.displayChangeToMpp()).toBeTruthy();
        expect(scope.displayChangeToCcra()).toBeTruthy();
        expect(scope.displayChangeToWbdd()).toBeTruthy();
        expect(scope.isEligibleMoreThanOnePaymentMethod()).toBeTruthy();*/
    });

    it('Testing changePaymentMethodCashChequeCtrl (false - no eligible options)', function() {

        setupTest(noEligiblePaymentMethods);

        //  Create the controller
        createController();

       /* expect(scope.displayChangeToMpp()).toBeFalsy();
        expect(scope.displayChangeToCcra()).toBeFalsy();
        expect(scope.displayChangeToWbdd()).toBeFalsy();
        expect(scope.isEligibleMoreThanOnePaymentMethod()).toBeFalsy();*/
    });

    it('Testing changePaymentMethodCashChequeCtrl (false - no eligible options)', function() {

        setupTest(paymentMethodsNoWbdd);

        //  Create the controller
        createController();

        /*expect(scope.displayChangeToMpp()).toBeTruthy();
        expect(scope.displayChangeToCcra()).toBeFalsy();
        expect(scope.displayChangeToWbdd()).toBeFalsy();
        expect(scope.isEligibleMoreThanOnePaymentMethod()).toBeFalsy();*/
    });
});