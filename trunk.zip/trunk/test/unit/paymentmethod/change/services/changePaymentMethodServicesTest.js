describe('Service: changePaymentMethodService', function () {

    var stateService, changePaymentMethodServices;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "12345";
    }));

    beforeEach(inject(function (_stateService_, _changePaymentMethodServices_) {

        stateService = _stateService_;

        changePaymentMethodServices = _changePaymentMethodServices_;
    }));

    it('Test changePaymentMethodServices - isEligibleForMpp (true)', (function () {

        var eligible = changePaymentMethodServices.isEligibleForMpp(paymentMethods);

        //  Assert that MPP is eligible option
        expect(eligible).toEqual(true);
    }));

    it('Test changePaymentMethodServices - isEligibleForMpp (false - no eligible options)', (function () {

        var eligible = changePaymentMethodServices.isEligibleForMpp(noEligiblePaymentMethods);

        //  Assert that MPP is not eligible option
        expect(eligible).toEqual(false);
    }));

    it('Test changePaymentMethodServices - isEligibleForMpp (false - no MPP option)', (function () {

        var eligible = changePaymentMethodServices.isEligibleForMpp(noEligibleMpp);

        //  Assert that MPP is not eligible option
        expect(eligible).toEqual(false);
    }));

    it('Test changePaymentMethodServices - isEligibleForCCra (true)', (function () {

        var eligible = changePaymentMethodServices.isEligibleForCCra(paymentMethods);

        //  Assert that CCRA is eligible option
        expect(eligible).toEqual(true);
    }));

    it('Test changePaymentMethodServices - isEligibleForCCra (false - no eligible options)', (function () {

        var eligible = changePaymentMethodServices.isEligibleForCCra(noEligiblePaymentMethods);

        //  Assert that CCRA is not eligible option
        expect(eligible).toEqual(false);
    }));

    it('Test changePaymentMethodServices - isEligibleForWbdd (true)', (function () {

        var eligible = changePaymentMethodServices.isEligibleForWbdd(paymentMethods);

        //  Assert that WBDD is eligible option
        expect(eligible).toEqual(true);
    }));

    it('Test changePaymentMethodServices - isEligibleForWbdd (false - no eligible options)', (function () {

        var eligible = changePaymentMethodServices.isEligibleForWbdd(noEligiblePaymentMethods);

        //  Assert that WBDD is not eligible option
        expect(eligible).toEqual(false);
    }));

    it('Test changePaymentMethodServices - isCashChequeCustomerEligibleForMoreThanOnePaymentMethod', (function () {

        var eligible = changePaymentMethodServices.isCashChequeCustomerEligibleForMoreThanOnePaymentMethod(paymentMethods);

        //  Assert that cash/cheque customer is not eligible for more than one payment option
        expect(eligible).toEqual(true);
    }));

    it('Test changePaymentMethodServices - isCashChequeCustomerEligibleForMoreThanOnePaymentMethod (false - no eligible options)', (function () {

        var eligible = changePaymentMethodServices.isCashChequeCustomerEligibleForMoreThanOnePaymentMethod(noEligiblePaymentMethods);

        //  Assert that cash/cheque customer is not eligible for more than one payment option
        expect(eligible).toEqual(false);
    }));

    it('Test changePaymentMethodServices - isCashChequeCustomerEligibleForMoreThanOnePaymentMethod (false - no WBDD)', (function () {

        var eligible = changePaymentMethodServices.isCashChequeCustomerEligibleForMoreThanOnePaymentMethod(paymentMethodsNoWbdd);

        //  Assert that cash/cheque customer is not eligible for more than one payment option
        expect(eligible).toEqual(false);
    }));

    it('Testing setupPaymentMethodAccordionService - isDisplayChangeHistory - agent - multiple change history entries', inject(function () {

        var accountHistory = {"accountHistoryDetails": [{"paymentMethod": "Cheque/Cash",
            "from": "2008-07-19T12:54:25.000",
            "to": null
        },
            {"paymentMethod": "Monthly Payment Plan",
                "from": "2008-06-17T14:25:34.000",
                "to": "2008-07-19T12:54:25.000"
            },
            {"paymentMethod": "Direct Debit",
                "from": "2008-06-15T14:25:34.000",
                "to": "2008-07-17T12:54:25.000"
            }
        ]};

        //  Call the service under test
        var displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(constants.AGENT, accountHistory);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeTruthy();

        //  Call the service under test
        displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(null, accountHistory);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeFalsy();

    }));

    it('Testing setupPaymentMethodAccordionService - isDisplayChangeHistory - customer - multiple change history entries', inject(function () {

        var accountHistory = {"accountHistoryDetails": [{"paymentMethod": "Cheque/Cash",
            "from": "2008-07-19T12:54:25.000",
            "to": null
        },
            {"paymentMethod": "Monthly Payment Plan",
                "from": "2008-06-17T14:25:34.000",
                "to": "2008-07-19T12:54:25.000"
            },
            {"paymentMethod": "Direct Debit",
                "from": "2008-06-15T14:25:34.000",
                "to": "2008-07-17T12:54:25.000"
            }
        ]};

        //  Call the service under test
        var displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(constants.CUSTOMER, accountHistory);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeFalsy();
    }));

    it('Testing setupPaymentMethodAccordionService - isDisplayChangeHistory - agent - one change history entry', inject(function () {

        var accountHistory = {"accountHistoryDetails": [{"paymentMethod": "Cheque/Cash",
            "from": "2008-07-19T12:54:25.000",
            "to": null
        }
        ]};

        //  Call the service under test
        var displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(constants.AGENT, accountHistory);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeFalsy();
    }));

    it('Testing setupPaymentMethodAccordionService - isDisplayChangeHistory - customer - one change history entry', inject(function () {

        var accountHistory = {"accountHistoryDetails": [{"paymentMethod": "Cheque/Cash",
            "from": "2008-07-19T12:54:25.000",
            "to": null
        }
        ]};

        //  Call the service under test
        var displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(constants.CUSTOMER, accountHistory);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeFalsy();
    }));

    it('Testing setupPaymentMethodAccordionService - isDisplayChangeHistory - null - one change history entry', inject(function () {

        var accountHistory = {"accountHistoryDetails": [{"paymentMethod": "Cheque/Cash",
            "from": "2008-07-19T12:54:25.000",
            "to": null
        }
        ]};

        //  Call the service under test
        var displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(null, accountHistory);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeFalsy();
    }));

    it('Testing setupPaymentMethodAccordionService - isDisplayChangeHistory - null - multiple change history entries', inject(function () {

        var accountHistory = {"accountHistoryDetails": [{"paymentMethod": "Cheque/Cash",
            "from": "2008-07-19T12:54:25.000",
            "to": null
        },
            {"paymentMethod": "Monthly Payment Plan",
                "from": "2008-06-17T14:25:34.000",
                "to": "2008-07-19T12:54:25.000"
            },
            {"paymentMethod": "Direct Debit",
                "from": "2008-06-15T14:25:34.000",
                "to": "2008-07-17T12:54:25.000"
            }
        ]};

        //  Call the service under test
        var displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(null, accountHistory);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeFalsy();
    }));

    it('Testing setupPaymentMethodAccordionService - isDisplayChangeHistory - agent - null change history', inject(function () {

        //  Call the service under test
        var displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(constants.AGENT, null);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeFalsy();
    }));

    it('Testing setupPaymentMethodAccordionService - isDisplayChangeHistory - customer - null change history', inject(function () {

        //  Call the service under test
        var displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(constants.CUSTOMER, null);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeFalsy();
    }));

    it('Testing setupPaymentMethodAccordionService - isDisplayChangeHistory - null - null change history', inject(function () {

        //  Call the service under test
        var displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(null, null);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeFalsy();
    }));

    it('Testing setupPaymentMethodAccordionService - isDisplayChangeHistory - agent - null change history', inject(function () {

        var accountHistory = {};

        //  Call the service under test
        var displayChangeHistory = changePaymentMethodServices.isDisplayChangeHistory(constants.AGENT, accountHistory);

        //  Assert that the service under test returns the expected values
        expect(displayChangeHistory).toBeFalsy();
    }));
});