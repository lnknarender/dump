/**
 * Created by Andrew on 15/12/2015.
 */

describe('Service: paymentMethodService', function () {

    var stateService, $q, $httpBackend, scope, paymentMethodServices, urlService;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    function setupTest (mockData) {
        (inject(function (_$rootScope_, _commonPaymentMethodServices_, _urlService_, _$q_, _$httpBackend_, _stateService_) {

            scope = _$rootScope_.$new();

            $q = _$q_;

            $httpBackend = _$httpBackend_;

            stateService = _stateService_;

            urlService = _urlService_;
            paymentMethodServices = _commonPaymentMethodServices_;

            var deferred = _$q_.defer();
            deferred.resolve();
            scope.$digest();
        }));
    }

    beforeEach(angular.mock.inject(function (_urlService_) {

        urlService = _urlService_;
    }));

    it('Test paymentMethodServices - isInEligiblePaymentMethods', (function () {

        setupTest(paymentMethods);

        //  Assert that the whether there are ineligibility's
        var isEligible = paymentMethodServices.isInEligiblePaymentMethods();
        expect(isEligible).toBeFalsy();

        setupTest(noEligibleMpp);

        //  Assert that the whether there are ineligibility's
        isEligible = paymentMethodServices.isInEligiblePaymentMethods();
        expect(isEligible).toBeFalsy();
    }));

    it('Test paymentMethodServices - isOutstandingCharges', (function () {

        //  Assert that whether there is an outstanding charge
        var isOutstanding = paymentMethodServices.isOutstandingCharges(paymentMethods);
        expect(isOutstanding).toBeTruthy();

        //  Assert that whether there is an outstanding charge
        var inEligible = paymentMethodServices.isOutstandingCharges(noEligibleMpp);
        expect(inEligible).toBeFalsy();

        //  Assert that whether there is an outstanding charge (outstanding amount is NULL)
        inEligible = paymentMethodServices.isOutstandingCharges(noEligiblePaymentMethods);
        expect(inEligible).toBeFalsy();
    }));

    it('Test paymentMethodServices - isBillDueNextTwoDays', (function () {

        var nextBillDate = new Date() + 2;

        //  Assert that whether there is an outstanding charge
        var isOutstanding = paymentMethodServices.isNextBillDateDue(nextBillDate, 2);
        expect(isOutstanding).toBeTruthy();
    }));
});