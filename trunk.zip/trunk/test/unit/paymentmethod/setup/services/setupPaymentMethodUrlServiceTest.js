/**
 * Created by Andrew on 04/12/2015.
 */

describe ('Service: setupPaymentMethodUrlService', function(){

    var service, scope;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    beforeEach(inject(function(_$rootScope_, _setupPaymentMethodUrlService_) {

        scope = _$rootScope_.$new();

        service = _setupPaymentMethodUrlService_;
    }));
    
    afterEach(function() {
        connection.userType = "agent";
    });

    it('Testing view payment method Url Service - agent', inject(function () {

        connection.userType = "agent";

        //  Call the service under test
        var url = service.getPaymentMethodChangeDetailsUrl();

        //  Assert that the service under test returns the expected values
       expect(url).toEqual("undefined/protected/v1/cak/ACC_002/conk/002/bac/0202535714/paymentmethods/changedetails");
    }));

    it('Testing view payment method Url Service - customer', inject(function () {

        connection.userType = "customer";

        //  Call the service under test
        var url = service.getPaymentMethodChangeDetailsUrl();

        //  Assert that the service under test returns the expected values
        expect(url).toEqual("undefined/protected/v1/acckey/1234/paymentmethods/changedetails");
    }));

    it('Testing view payment method Url Service mpp - agent', inject(function () {

        connection.userType = "agent";

        //  Call the service under test
        var url = service.getSetupMppUrl();

        //  Assert that the service under test returns the expected values
       expect(url).toEqual("undefined/protected/v1/cak/ACC_002/conk/002/bac/0202535714/mppsetup");
    }));

    it('Testing view payment method Url Service - customer', inject(function () {

        connection.userType = "customer";

        //  Call the service under test
        var url = service.getSetupMppUrl();

        //  Assert that the service under test returns the expected values
        expect(url).toEqual("undefined/protected/v1/acckey/1234/mppsetup");
    }));
});