/**
 * Created by Andrew on 04/12/2015.
 */

describe ('Service: setupMppPaymentMethodService', function(){

    var service, scope;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    beforeEach(inject(function(_$rootScope_, _ajaxServiceWithToken_, _setupMppPaymentMethodService_) {

        mockAjaxServiceWithToken = _ajaxServiceWithToken_;
        
        spyOn(mockAjaxServiceWithToken, 'doGet').and.callFake(function (args) {
            return {
                then: function (success, error) {
                    success({
                        "type": "nobalance",
                        "outstandingAmount": {
                            "amount": 99,
                            "currencyCode": "GBP"
                        },
                        "outstandingMPPAmount":  {
                            "amount": 88,
                            "currencyCode": "GBP"
                        },
                        "partialAmount":  {
                            "amount": 77,
                            "currencyCode": "GBP"
                        },
                        "mppAmount":  {
                            "amount": 66,
                            "currencyCode": "GBP"
                        }
        
                    });
                }
            };
        });
        scope = _$rootScope_.$new();

        service = _setupMppPaymentMethodService_;
    }));

    it('Testing mpp service get setup MPP data - agent', inject(function () {
        //Test the service
        service.getSetupMppDetails().then(function (res) {
            result = res;
        }, function (res) {
            error = res;
        });

        scope.$digest();
        expect(result).not.toBeNull();

        expect(result.type).toBe("nobalance");
        expect(result.outstandingAmount.amount).toBe(99);
        expect(result.outstandingMPPAmount.amount).toBe(88);
        expect(result.partialAmount.amount).toBe(77);
        expect(result.mppAmount.amount).toBe(66);
    }));


    it('Testing mpp service calculate amount to pay today', inject(function () {
        var outstandingAmount = 5;
        var outstandingMPPAmount = 4;
        var partialAmount = 3;
        var mppAmount = 2;

        result = service.calculateAmountToPayToday('nobalance', '', outstandingAmount, outstandingMPPAmount, partialAmount, mppAmount);

        expect(result.amountToPayToday).toBe(0);
        expect(result.amountToPayMonthly).toBe(mppAmount);

        result = service.calculateAmountToPayToday('nothing', 'payAll', outstandingAmount, outstandingMPPAmount, partialAmount, mppAmount);

        expect(result.amountToPayToday).toBe(outstandingAmount);
        expect(result.amountToPayMonthly).toBe(outstandingMPPAmount);

        result = service.calculateAmountToPayToday('nothing', 'payPartial', outstandingAmount, outstandingMPPAmount, partialAmount, mppAmount);

        expect(result.amountToPayToday).toBe(0);
        expect(result.amountToPayMonthly).toBe(mppAmount);

        result = service.calculateAmountToPayToday('partial', 'payPartial', outstandingAmount, outstandingMPPAmount, partialAmount, mppAmount);

        expect(result.amountToPayToday).toBe(partialAmount);
        expect(result.amountToPayMonthly).toBe(mppAmount);

    }));

    it('Testing mpp service select day and get future payment dates', inject(function () {
        var selectedDay = 6;
        var existingPaymentDay = 4;

        result = service.setPaymentDayAndGetFuturePayments(selectedDay, existingPaymentDay);
        var selectedDate = moment().date(selectedDay);

        expect(result.paymentDay).toBe(6);

        expect(result.futurePayments[0].getDate()).toBe(selectedDate.clone().add(1, "M").toDate().getDate());
        expect(result.futurePayments[0].getMonth()).toBe(selectedDate.clone().add(1, "M").toDate().getMonth());
        expect(result.futurePayments[0].getFullYear()).toBe(selectedDate.clone().add(1, "M").toDate().getFullYear());

        expect(result.futurePayments[1].getDate()).toBe(selectedDate.clone().add(2, "M").toDate().getDate());
        expect(result.futurePayments[1].getMonth()).toBe(selectedDate.clone().add(2, "M").toDate().getMonth());
        expect(result.futurePayments[1].getFullYear()).toBe(selectedDate.clone().add(2, "M").toDate().getFullYear());

        expect(result.futurePayments[2].getDate()).toBe(selectedDate.clone().add(3, "M").toDate().getDate());
        expect(result.futurePayments[2].getMonth()).toBe(selectedDate.clone().add(3, "M").toDate().getMonth());
        expect(result.futurePayments[2].getFullYear()).toBe(selectedDate.clone().add(3, "M").toDate().getFullYear());

    }));


});