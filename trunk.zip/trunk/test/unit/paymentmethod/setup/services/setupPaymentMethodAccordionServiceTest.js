/**
* Created by Andrew on 16/12/2015.
*/

describe ('Service: setupPaymentMethodAccordionService', function(){

    var service, scope;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(inject(function(_$rootScope_, _setupPaymentMethodAccordionService_, _utilityService_) {

        scope = _$rootScope_.$new();

        service = _setupPaymentMethodAccordionService_;
        var mockUtilityService = _utilityService_;

        // Mock the "expandOrCollapseAccordionBasedOnStatus" function as it performs a jQuery show/hide command
        spyOn(mockUtilityService, "expandOrCollapseAccordionBasedOnStatus").and.callFake(function () {

            return {

                then: function () {
                    return null;
                }
            };
        });
    }));

    it('Testing setupPaymentMethodAccordionService - initialiseAccordionStatus', inject(function () {

        //  Call the service under test
        var accordionStatus = service.initialiseAccordionStatus();

        //  Assert that the service under test returns the expected values
        expect(accordionStatus.directDebitAccordionStatus).toEqual(constants.ACCORDION_CURRENT);
        expect(accordionStatus.summaryAccordionStatus).toEqual(constants.ACCORDION_NOT_STARTED);
        expect(accordionStatus.directDebitAccordionWhiteTick).toBeFalsy();
        expect(accordionStatus.summaryAccordionWhiteTick).toBeFalsy();
    }));

    it('Testing setupPaymentMethodAccordionService - directDebitComplete', inject(function () {

        // Initialise the test case
        var accordionStatus = service.initialiseAccordionStatus();

        //  Call the service under test
        accordionStatus = service.directDebitComplete('mandatory_payment');

        //  Assert that the service under test returns the expected values
        expect(accordionStatus.directDebitAccordionStatus).toEqual(constants.ACCORDION_COMPLETE);
        expect(accordionStatus.summaryAccordionStatus).toEqual(constants.ACCORDION_NOT_STARTED);
        expect(accordionStatus.directDebitAccordionWhiteTick).toBeTruthy();
        expect(accordionStatus.summaryAccordionWhiteTick).toBeFalsy();
    }));

    it('Testing setupPaymentMethodAccordionService - directDebitEdit', inject(function () {

        // Initialise the test case
        var accordionStatus = service.directDebitEdit();

        //  Call the service under test


        //  Assert that the service under test returns the expected values
        expect(accordionStatus.directDebitAccordionStatus).toEqual(constants.ACCORDION_CURRENT);
        expect(accordionStatus.directDebitAccordionWhiteTick).toBeFalsy();
        expect(accordionStatus.directDebitAccordionEditButton).toBeFalsy();
        expect(accordionStatus.amountYouOweAccordionStatus).toEqual(constants.ACCORDION_NOT_STARTED);
    }));
    it('Testing setupPaymentMethodAccordionService - amountYouOweComplete', inject(function () {

        // Initialise the test case
        var accordionStatus = service.amountYouOweComplete();

        //  Call the service under test


        //  Assert that the service under test returns the expected values
        expect(accordionStatus.directDebitAccordionStatus).toEqual(constants.ACCORDION_COMPLETE);
        expect(accordionStatus.directDebitAccordionWhiteTick).toBeTruthy();
        expect(accordionStatus.directDebitAccordionEditButton).toBeTruthy();
        expect(accordionStatus.amountYouOweAccordionStatus).toEqual(constants.ACCORDION_COMPLETE);
    }));
    it('Testing setupPaymentMethodAccordionService - amountYouOweEdit', inject(function () {

        // Initialise the test case
        var accordionStatus = service.amountYouOweEdit();

        //  Call the service under test


        //  Assert that the service under test returns the expected values
        expect(accordionStatus.directDebitAccordionStatus).toEqual(constants.ACCORDION_COMPLETE);
        expect(accordionStatus.directDebitAccordionWhiteTick).toBeTruthy();
        expect(accordionStatus.directDebitAccordionEditButton).toBeTruthy();
        expect(accordionStatus.amountYouOweAccordionStatus).toEqual(constants.ACCORDION_CURRENT);
    }));
    it('Testing setupPaymentMethodAccordionService - initialiseSummaryAccordinStatus', inject(function () {

        // Initialise the test case
        var accordionStatus = service.initialiseSummaryAccordinStatus(true);

        //  Call the service under test


        //  Assert that the service under test returns the expected values
        expect(accordionStatus.summaryDirectDebitIconTick).toEqual(constants.ACCORDION_COMPLETE_ICON_TICK);
        expect(accordionStatus.summaryAmountYouOweIconTick).toEqual(constants.ACCORDION_COMPLETE_ICON_TICK);
        expect(accordionStatus.summaryMakePaymentAccordionStatus).toEqual(constants.ACCORDION_COMPLETE);
        expect(accordionStatus.summaryAccordionStatus).toEqual(constants.ACCORDION_COMPLETE);
    }));
    it('Testing setupPaymentMethodAccordionService - initialiseSummaryAccordinStatus', inject(function () {

        // Initialise the test case
        var accordionStatus = service.initialiseSummaryAccordinStatus(false);

        //  Call the service under test


        //  Assert that the service under test returns the expected values
        expect(accordionStatus.summaryDirectDebitIconTick).toEqual(constants.ACCORDION_COMPLETE_ICON_TICK);
        expect(accordionStatus.summaryAmountYouOweIconTick).toEqual(constants.ACCORDION_COMPLETE_ICON_TICK);
        expect(accordionStatus.summaryMakePaymentAccordionStatus).toEqual(constants.ACCORDION_WARNING);
        expect(accordionStatus.summaryAccordionStatus).toEqual(constants.ACCORDION_NOT_STARTED);
    }));
});