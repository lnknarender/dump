/**
 * Created by Andrew on 15/12/2015.
 */
describe('Controller: Payment method - setupPaymentMethodWbddCtrl', function () {

    var scope, location, createController;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
    }));

    beforeEach(inject(function ($rootScope, $controller, _$location_, _urlService_, _errorLoggingService_, _utilityService_, _setupPaymentMethodWbddService_,commonPaymentMethodServices) {

        location = _$location_;
        scope = $rootScope.$new();

        //  Create the setupPaymentMethodWbddCtrl and pass the mock objects
        createController = function() {
            return $controller('setupPaymentMethodWbddCtrl',
                {$scope: scope,
                 $location: location,
                 urlService: _urlService_,
                 errorLoggingService: _errorLoggingService_,
                 utilityService: _utilityService_,
                 setupPaymentMethodWbddService: _setupPaymentMethodWbddService_,
                 commonPaymentMethodServices:commonPaymentMethodServices
                });
        };
    }));

    //  Mock the payment method service (getAccount) and access token service (getToken)
    function setupTest (mockData) {
        (angular.mock.inject(function (_commonPaymentMethodServices_, _accessTokenService_, _$q_, _$rootScope_, _utilityService_) {

            scope = _$rootScope_.$new();
            var deferred = _$q_.defer();

            var mockPaymentMethodServices = _commonPaymentMethodServices_;

            spyOn(mockPaymentMethodServices, 'getViewPaymentMethods').and.callFake(function () {

                return {

                    then: function (callback) {
                        return callback(mockData);
                    },

                    catch: function (callback) {
                        return null;
                    },

                    finally: function (callback) {
                        return null;
                    }
                };
            });

            var mockUtilityService = _utilityService_;

            // Mock the "expandOrCollapseAccordionBasedOnStatus" function as it performs a jQuery show/hide command
            spyOn(mockUtilityService, "expandOrCollapseAccordionBasedOnStatus").and.callFake(function () {

                return {

                    then: function () {
                        return null;
                    }
                };
            });

            deferred.resolve(true);
            scope.$digest();
        }));
    }

    it('Testing setupPaymentMethodWbddCtrl - applyCSSClass', function() {

        setupTest(paymentMethods);

        //  Create the controller
        createController();

        //  Assert that the correct CSS class is returned given the accordion status
        expect(scope.applyCSSClass(constants.ACCORDION_NOT_STARTED)).toEqual(constants.ACCORDION_CSS_NOT_STARTED);
        expect(scope.applyCSSClass(constants.ACCORDION_CURRENT)).toEqual(constants.ACCORDION_CSS_CURRENT);
        expect(scope.applyCSSClass(constants.ACCORDION_COMPLETE)).toEqual(constants.ACCORDION_CSS_COMPLETE);
        expect(scope.applyCSSClass(constants.ACCORDION_WARNING)).toEqual(constants.ACCORDION_CSS_WARNING);
    });

    it('Testing setupPaymentMethodWbddCtrl - isHideWhiteTick', function() {

        setupTest(paymentMethods);

        //  Create the controller
        createController();

        //  Assert that the white tick is shown/hidden
    /*    expect(scope.isHideWhiteTick(true)).toBeFalsy();
        expect(scope.isHideWhiteTick(false)).toBeTruthy();*/
    });
});