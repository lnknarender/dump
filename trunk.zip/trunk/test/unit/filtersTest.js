/**
 * Created by Andrew on 01-06-2015.
 */

describe('The mask account filter', function () {
    'use strict';

    var $filter;

    beforeEach(function () {
        module('appFilters');

        inject(function (_$filter_) {
            $filter = _$filter_;
        });
    });

    it('should mask account number', function () {

        var accountNumber = 'GB12345678', result;
        result = $filter('maskAccountNumber')(accountNumber);

        expect(result).toEqual('GB1234****');
    });

    it('should mask account number with 5 characters', function () {

        var accountNumber = 'GB123', result;
        result = $filter('maskAccountNumber')(accountNumber);

        expect(result).toEqual('G****');
    });

    it('should mask account number with 4 characters', function () {

        var accountNumber = 'GB12', result;
        result = $filter('maskAccountNumber')(accountNumber);

        expect(result).toEqual('****');
    });

    it('should mask account number with 2 characters', function () {

        var accountNumber = 'G1', result;
        result = $filter('maskAccountNumber')(accountNumber);

        expect(result).toEqual('G1');
    });

    it('should mask account number with only 1 characters', function () {

        var accountNumber = 'G', result;
        result = $filter('maskAccountNumber')(accountNumber);

        expect(result).toEqual('G');
    });

    it('mask empty account number should return empty string', function () {

        var accountNumber = '', result;
        result = $filter('maskAccountNumber')(accountNumber);

        expect(result).toEqual('');
    });

    it('GB account number should changed to start with 02', function () {

        var accountNumber = 'GB12345678', result;

        result = $filter('toSDKStandard')(accountNumber);
        expect(result).toEqual('0212345678');

        accountNumber = 'GB1234****';
        result = $filter('toSDKStandard')(accountNumber);
        expect(result).toEqual('021234****');
    });

    it('02 account number should changed to start with GB', function () {

        var accountNumber = '0212345678', result;

        result = $filter('toDisplayStandard')(accountNumber);
        expect(result).toEqual('GB12345678');

        accountNumber = '021234****';
        result = $filter('toDisplayStandard')(accountNumber);
        expect(result).toEqual('GB1234****');
    });

    it('Non GB account number should not changed', function () {

        var accountNumber = 'CP12345678', result;

        result = $filter('toSDKStandard')(accountNumber);
        expect(result).toEqual('CP12345678');

        accountNumber = 'CP1234****';
        result = $filter('toSDKStandard')(accountNumber);
        expect(result).toEqual('CP1234****');
    });

    it('Non 02 account number should not changed', function () {

        var accountNumber = '0312345678', result;

        result = $filter('toDisplayStandard')(accountNumber);
        expect(result).toEqual('0312345678');

        accountNumber = '121234****';
        result = $filter('toDisplayStandard')(accountNumber);
        expect(result).toEqual('121234****');
    });

    it('Null account number should not changed', function () {

        var accountNumber = '', result;

        result = $filter('toSDKStandard')(accountNumber);
        expect(result).toEqual('');
        result = $filter('toDisplayStandard')(accountNumber);
        expect(result).toEqual('');

        accountNumber = null;
        result = $filter('toSDKStandard')(accountNumber);
        expect(result).toEqual(null);
        result = $filter('toDisplayStandard')(accountNumber);
        expect(result).toEqual(null);
    });

    it('02 account number should be masked changed to start with GB', function () {

        var accountNumber = 'GB12345678', result;

        result = $filter('maskAccountNumberAndToSDKStandard')(accountNumber);
        expect(result).toEqual('021234****');

        accountNumber = 'GB1234****';
        result = $filter('maskAccountNumberAndToSDKStandard')(accountNumber);
        expect(result).toEqual('021234****');
    });

    it('GB account number should be masked changed to start with 02', function () {

        var accountNumber = '0212345678', result;

        result = $filter('maskAccountNumberAndToDisplayStandard')(accountNumber);
        expect(result).toEqual('GB1234****');

        accountNumber = '021234****';
        result = $filter('maskAccountNumberAndToDisplayStandard')(accountNumber);
        expect(result).toEqual('GB1234****');
    });

    it('sort code should be formatted correctly', function () {

        var sortCode = '123456';
        var result;

        result = $filter('formatSortCode')(sortCode);
        expect(result).toEqual('12-34-56');

        sortCode = '98-76-54';
        result = $filter('formatSortCode')(sortCode);
        expect(result).toEqual('98-76-54');

        sortCode = '123456789';
        result = $filter('formatSortCode')(sortCode);
        expect(result).toEqual('12-34-56-78-9');

        sortCode = '';
        result = $filter('formatSortCode')(sortCode);
        expect(result).toEqual('');

        sortCode = 'niaIsAwesome';
        result = $filter('formatSortCode')(sortCode);
        expect(result).toEqual('ni-aI-sA-we-so-me');
    });
});