describe('Service: inviteCustomerOnlineServices - inviteOnlineUrlService', function () {

    var stateService, $q, $httpBackend, scope, inviteOnlineUrlService;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    beforeEach(inject(function(_$rootScope_, _inviteOnlineUrlService_) {

        scope = _$rootScope_.$new();

        inviteOnlineUrlService = _inviteOnlineUrlService_;
    }));

    it('Test inviteOnlineUrlService - linkedAccountsUrlService', (function () {

        connection.userType = "agent";
        var url = inviteOnlineUrlService.getLinkedAccountsUrl();
        expect(url).toEqual('/cak/ACC_002/conk/002/bac/0202535714/linkedaccounts');
    }));

    it('Test inviteOnlineUrlService - getLinkedAccountsEmailUrl', function () {

        connection.userType = "agent";
        var url = inviteOnlineUrlService.getLinkedAccountsEmailUrl();
        expect(url).toEqual('/cak/ACC_002/conk/002/bac/0202535714/linkedaccounts/email');
    });

    it('Test inviteOnlineUrlService - getForgottenPasswordUrl', function () {

        connection.userType = "agent";
        var url = inviteOnlineUrlService.getForgottenPasswordUrl();
        expect(url).toEqual('/cak/ACC_002/conk/002/bac/0202535714/passwordrecovery');
    });

    it('Test inviteOnlineUrlService - inviteCustomerOnlineUrl', function () {

        connection.userType = "agent";
        var url = inviteOnlineUrlService.getInviteCustomerOnlineUrl();
        expect(url).toEqual('/cak/ACC_002/conk/002/bac/0202535714/invitetoebilling');
    });
});