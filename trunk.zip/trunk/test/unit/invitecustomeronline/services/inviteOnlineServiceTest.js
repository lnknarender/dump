describe('Service: inviteCustomerOnlineServices', function () {

    var stateService, $q, $httpBackend, scope, inviteOnlineService, mockAjaxServiceWithToken, inviteOnlineUrlService, urlService;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    beforeEach(inject(function(_$rootScope_,  _accessTokenService_, ajaxServiceWithToken, _inviteOnlineService_, _urlService_, _inviteOnlineUrlService_, _$q_, _$httpBackend_, _stateService_) {

        scope = _$rootScope_.$new();

        $q = _$q_;

        $httpBackend = _$httpBackend_;

        stateService = _stateService_;

        mockAjaxServiceWithToken = ajaxServiceWithToken;
        inviteOnlineService = _inviteOnlineService_;
        inviteOnlineUrlService = _inviteOnlineUrlService_;
        urlService = _urlService_;

        spyOn(mockAjaxServiceWithToken, 'doPost').and.callFake(function () {

            return {

                then: function(callback) {

                  return callback();
                }
            };
        });

        var deferred = _$q_.defer();
        deferred.resolve();
        scope.$digest();
    }));

    it('Test inviteOnlineService - inviteCustomerOnline', (function () {

        var inviteCustomer = {"emailToken": "emailToken1",
                              "linkedAccountsRequestIO": {"conk": "conk1",
                                                          "email": "email1",
                                                          "linkedAccountsToken": "token1"}};

        var url = urlService.getSecurePath() + inviteOnlineUrlService.getInviteCustomerOnlineUrl();

        inviteOnlineService.inviteCustomerOnline(inviteCustomer);

        //  Assert that the PUT method has been called
        expect(mockAjaxServiceWithToken.doPost).toHaveBeenCalledWith(url, { }, inviteCustomer);
    }));
});