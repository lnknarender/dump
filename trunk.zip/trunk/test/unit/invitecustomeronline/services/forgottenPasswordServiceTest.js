describe('Service: inviteCustomerOnlineServices - forgotten password', function () {

    var forgottenPasswordService, stateService, $q, $httpBackend, scope;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    beforeEach(inject(function(_$rootScope_,  _accessTokenService_, ajaxServiceWithToken, _forgottenPasswordService_, _$q_, _$httpBackend_, _stateService_) {

        scope = _$rootScope_.$new();

        $q = _$q_;

        $httpBackend = _$httpBackend_;

        stateService = _stateService_;

        var mockAjaxServiceWithToken = ajaxServiceWithToken;

        forgottenPasswordService = _forgottenPasswordService_;

        spyOn(mockAjaxServiceWithToken, 'doPost').and.callFake(function () {

            return {

                then: function(callback) {

                    return callback("200");
                }
            };
        });

        var deferred = _$q_.defer();
        deferred.resolve();
        scope.$digest();
    }));

    it('Test forgottenPasswordService - getForgottenPassword', (function () {

        connection.userType = "agent";
        var forgottenPassword = {"email": "email1@bt.com", "emailToken": "emailToken1"};

        // Make the mock ReST request
        forgottenPasswordService.forgottenPassword(forgottenPassword);
    }));
});