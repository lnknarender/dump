describe('Service: linkedAccountsService', function () {

    var linkedAccountsService, stateService, $q, $httpBackend, scope;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    beforeEach(inject(function(_$rootScope_,  _accessTokenService_, ajaxServiceWithToken, _linkedAccountsService_, _$q_, _$httpBackend_, _stateService_) {

        scope = _$rootScope_.$new();

        $q = _$q_;

        $httpBackend = _$httpBackend_;

        stateService = _stateService_;

        var mockAjaxServiceWithToken = ajaxServiceWithToken;

        linkedAccountsService = _linkedAccountsService_;

        spyOn(mockAjaxServiceWithToken, 'doGet').and.callFake(function () {

            return {

                then: function(callback) {

                    return callback(linkedAccounts);
                }
            };
        });

        var deferred = _$q_.defer();
        deferred.resolve();
        scope.$digest();
    }));

    it('Test linkedAccountsService - getLinkedAccount', (function () {

        connection.userType = "agent";

        // Make the mock ReST request
        linkedAccountsService.getLinkedAccount();
        var linkedAccounts = stateService.get(constants.STATE_SERVICE_LINKED_ACCOUNT);

        /*
         Assert will be done against the state service as the promise for the getLinkedAccount
         will not return within a Karma unit test
         */
        expect(linkedAccounts.emailLinkedAccounts[0].email).toBe("email1@bt.com");
        expect(linkedAccounts.emailLinkedAccounts[0].linkedAccounts[0].btId).toBe("btid1.1");
        expect(linkedAccounts.emailLinkedAccounts[0].linkedAccounts[0].emailTemplate).toBe("emailTemplate1.1");
        expect(linkedAccounts.emailLinkedAccounts[0].linkedAccounts[0].emailToken).toBe("emailToken1.1");
        expect(linkedAccounts.emailLinkedAccounts[0].linkedAccounts[0].status).toBe("status1.1");

        expect(linkedAccounts.emailLinkedAccounts[0].linkedAccounts[1].btId).toBe("btid1.2");
        expect(linkedAccounts.emailLinkedAccounts[0].linkedAccounts[1].emailTemplate).toBe("emailTemplate1.2");
        expect(linkedAccounts.emailLinkedAccounts[0].linkedAccounts[1].emailToken).toBe("emailToken1.2");
        expect(linkedAccounts.emailLinkedAccounts[0].linkedAccounts[1].status).toBe("status1.2");

        expect(linkedAccounts.emailLinkedAccounts[1].linkedAccounts[0].btId).toBe("btid2.1");
        expect(linkedAccounts.emailLinkedAccounts[1].linkedAccounts[0].emailTemplate).toBe("emailTemplate2.1");
        expect(linkedAccounts.emailLinkedAccounts[1].linkedAccounts[0].emailToken).toBe("emailToken2.1");
        expect(linkedAccounts.emailLinkedAccounts[1].linkedAccounts[0].status).toBe("status2.1");

        expect(linkedAccounts.emailLinkedAccounts[1].linkedAccounts[1].btId).toBe("btid2.2");
        expect(linkedAccounts.emailLinkedAccounts[1].linkedAccounts[1].emailTemplate).toBe("emailTemplate2.2");
        expect(linkedAccounts.emailLinkedAccounts[1].linkedAccounts[1].emailToken).toBe("emailToken2.2");
        expect(linkedAccounts.emailLinkedAccounts[1].linkedAccounts[1].status).toBe("status2.2");

        expect(linkedAccounts.otherEmails[0].emailAddress).toBe("otherEmail1@bt.com");
        expect(linkedAccounts.otherEmails[0].isPrimary).toBe("Y");

        expect(linkedAccounts.otherEmails[1].emailAddress).toBe("otherEmail2@bt.com");
        expect(linkedAccounts.otherEmails[1].isPrimary).toBe("N");

        expect(linkedAccounts.linkedAccountsToken).toBe("1234567890ABCDEFG");
    }));

    it('Test linkedAccountsService - resetLinkedAccount', (function () {

        // Make the mock ReST request
        linkedAccountsService.getLinkedAccount();
        var linkedAccounts = stateService.get(constants.STATE_SERVICE_LINKED_ACCOUNT);

        expect(linkedAccounts.emailLinkedAccounts[0].email).toBe("email1@bt.com");

        //  Remove the forgotten password from the state service and assert it has been removed
        linkedAccountsService.resetLinkedAccount();
        linkedAccounts = stateService.get(constants.STATE_SERVICE_LINKED_ACCOUNT);

        expect(linkedAccounts).toBe(undefined);
    }));
});