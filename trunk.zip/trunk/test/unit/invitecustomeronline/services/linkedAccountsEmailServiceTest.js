describe('Service: inviteCustomerOnlineServices', function () {

    var stateService, $q, $httpBackend, scope, linkedAccountsEmailService;

    //  Define the mock responses
    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.telephone_num = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    beforeEach(inject(function(_$rootScope_,  _accessTokenService_, ajaxServiceWithToken, _linkedAccountsEmailService_, _$q_, _$httpBackend_, _stateService_) {

        scope = _$rootScope_.$new();

        $q = _$q_;

        $httpBackend = _$httpBackend_;

        stateService = _stateService_;

        var mockAjaxServiceWithToken = ajaxServiceWithToken;

        spyOn(mockAjaxServiceWithToken, 'doPost').and.callFake(function (params) {

            return {

                then: function(callback) {

                    if(params.indexOf("/linkedaccounts/email")>-1) {

                        return callback(linkedAccountsEmail);
                    }

                    return callback(linkedAccounts);
                }
            };
        });

        linkedAccountsEmailService = _linkedAccountsEmailService_;

        var deferred = _$q_.defer();
        deferred.resolve();
        scope.$digest();
    }));

    it('Test linkedAccountsEmailService - getLinkedAccountEmail', (function () {

        // Make the mock ReST request
        linkedAccountsEmailService.getLinkedAccountEmail();
        var linkedAccountsEmail = stateService.get(constants.STATE_SERVICE_LINKED_ACCOUNT_EMAIL);

        /*
         Assert will be done against the state service as the promise for the getLinkedAccountEmail
         will not return within a Karma unit test
         */
        expect(linkedAccountsEmail.btId).toBe("btid1");
        expect(linkedAccountsEmail.emailTemplate).toBe("emailTemplate1");
        expect(linkedAccountsEmail.emailToken).toBe("emailToken1");
        expect(linkedAccountsEmail.status).toBe("status1");

        expect(linkedAccountsEmail.pendingAccounts[0]).toBe("pendingAccounts1");
        expect(linkedAccountsEmail.pendingAccounts[1]).toBe("pendingAccounts2");
        expect(linkedAccountsEmail.pendingAccounts[2]).toBe("pendingAccounts3");

        expect(linkedAccountsEmail.profileAccounts[0]).toBe("profileAccounts1");
        expect(linkedAccountsEmail.profileAccounts[1]).toBe("profileAccounts2");
        expect(linkedAccountsEmail.profileAccounts[2]).toBe("profileAccounts3");
    }));

    it('Test linkedAccountsEmailService - resetLinkedAccountEmail', (function () {

        // Make the mock ReST request
        linkedAccountsEmailService.getLinkedAccountEmail();
        var linkedAccountsEmail = stateService.get(constants.STATE_SERVICE_LINKED_ACCOUNT_EMAIL);

        expect(linkedAccountsEmail.btId).toBe("btid1");

        //  Remove the forgotten password from the state service and assert it has been removed
        linkedAccountsEmailService.resetLinkedAccountEmail();
        linkedAccountsEmail = stateService.get(constants.STATE_SERVICE_LINKED_ACCOUNT_EMAIL);

        expect(linkedAccountsEmail).toBe(undefined);
    }));
});