/**
 * Created by Andrew on 10/23/15.
 */
describe('Controller: Invite customer online controller - inviteCustomerOnlineCtrl', function () {

    var scope, location, createController;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
    }));

    beforeEach(inject(function ($rootScope, $controller, _$location_, _urlService_, _errorLoggingService_, _linkedAccountsService_) {

        location = _$location_;
        scope = $rootScope.$new();

        //  Create the MakePaymentIndex and pass the mock objects
        createController = function() {
            return $controller('inviteCustomerOnlineCtrl', {$scope: scope,
                $location: location,
                errorLoggingService: _errorLoggingService_,
                urlService: _urlService_,
                linkedAccountsService: _linkedAccountsService_
            });
        };
    }));

    //  Mock the billing account service (getAccount) and access token service (getToken)
    beforeEach(angular.mock.inject(function (_linkedAccountsService_, _accessTokenService_, _$q_, _$rootScope_) {

        scope = _$rootScope_.$new();

        var deferred = _$q_.defer();
        var mockLinkedAccountsService = _linkedAccountsService_;

        spyOn(mockLinkedAccountsService, 'getLinkedAccount').and.callFake(function () {

            return {

                then: function(callback) { return callback(linkedAccounts); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        deferred.resolve(getJourneyMockData);
        scope.$digest();
    }));

    it('Testing inviteCustomerOnlineCtrl - inviteCustomerOnlineCtrl', function() {

        //  Create the controller
        createController();

        expect(scope.emailLinkedAccounts[0].email).toBe("email1@bt.com");

        expect(scope.emailLinkedAccounts[0].linkedAccounts[0].btId).toBe("btid1.1");
        expect(scope.emailLinkedAccounts[0].linkedAccounts[0].emailTemplate).toBe("emailTemplate1.1");
        expect(scope.emailLinkedAccounts[0].linkedAccounts[0].emailToken).toBe("emailToken1.1");
        expect(scope.emailLinkedAccounts[0].linkedAccounts[0].status).toBe("status1.1");

        expect(scope.emailLinkedAccounts[0].linkedAccounts[1].btId).toBe("btid1.2");
        expect(scope.emailLinkedAccounts[0].linkedAccounts[1].emailTemplate).toBe("emailTemplate1.2");
        expect(scope.emailLinkedAccounts[0].linkedAccounts[1].emailToken).toBe("emailToken1.2");
        expect(scope.emailLinkedAccounts[0].linkedAccounts[1].status).toBe("status1.2");

        expect(scope.emailLinkedAccounts[1].linkedAccounts[0].btId).toBe("btid2.1");
        expect(scope.emailLinkedAccounts[1].linkedAccounts[0].emailTemplate).toBe("emailTemplate2.1");
        expect(scope.emailLinkedAccounts[1].linkedAccounts[0].emailToken).toBe("emailToken2.1");
        expect(scope.emailLinkedAccounts[1].linkedAccounts[0].status).toBe("status2.1");

        expect(scope.emailLinkedAccounts[1].linkedAccounts[1].btId).toBe("btid2.2");
        expect(scope.emailLinkedAccounts[1].linkedAccounts[1].emailTemplate).toBe("emailTemplate2.2");
        expect(scope.emailLinkedAccounts[1].linkedAccounts[1].emailToken).toBe("emailToken2.2");
        expect(scope.emailLinkedAccounts[1].linkedAccounts[1].status).toBe("status2.2");

        expect(scope.otherEmails[0].emailAddress).toBe("otherEmail1@bt.com");
        expect(scope.otherEmails[0].isPrimary).toBe("Y");

        expect(scope.otherEmails[1].emailAddress).toBe("otherEmail2@bt.com");
        expect(scope.otherEmails[1].isPrimary).toBe("N");

        expect(scope.linkedAccountsToken).toBe("1234567890ABCDEFG");
    });
});