//Sample test suite
describe('controllers', function () {

    //Sample test for a controller
    describe('controller', function () {            
            it('should return seven different statuses', function () {
            	expect("Sample test").toBe("Sample test");
            });
    });
});