//Unit tests for Thistle service

describe('Service: thistleService', function () {

    var service, stateService;
    var amount, currency, startDate, endDate, frequency, instalmentTotal, instalmentTotalCurrency, successUrl, failureUrl, cancelUrl;

    //  Define the mock responses
    var thistleMockData = {'thistleUrl': 'http://thistle.bt.com', 'encodedXml': '<result>The results</result>'};

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle

        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');

    }));

    beforeEach(inject(function(_thistleService_, _ajaxServiceWithToken_) {

        //  Service under test
        service = _thistleService_;

        //  Mock the ajax service. This service is called by the service under test
        var mockAjaxService = _ajaxServiceWithToken_;
        spyOn(mockAjaxService, 'doGet').and.callFake(function () {

            return {

                then: function(callback) { return callback(thistleMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });
    }));

    beforeEach(angular.mock.inject(function (_stateService_) {

        stateService = _stateService_;
    }));

    beforeEach(angular.mock.inject(function () {

        amount = 99.99;
        currency = "GBP";
        startDate = "2015-07-71";
        endDate = "2019-07-24";
        frequency = "Monthly";
        instalmentTotal = "48.88";
        instalmentTotalCurrency = "24.50";
        successUrl = "/success.html";
        failureUrl = "/failure.html";
        cancelUrl = "/cancel.html";
    }));

    it('Test thistleService getPaymentRequest', (function () {

        service.getPaymentRequest(amount, currency, startDate, endDate, frequency, instalmentTotal, instalmentTotalCurrency, successUrl, failureUrl, cancelUrl);
        var thistle = stateService.get("thistle");

        //  Perform the assert against the state service rather than the return promise. The promise returned by the service under
        //  test a 'real' promise rather than a mock. So this test will not 'see' and act on the returned promise. Further investigation
        //  required in order to test a non-mocked promise.
        expect(thistle.thistleUrl).toBe(thistleMockData.thistleUrl);
        expect(thistle.encodedXml).toBe(thistleMockData.encodedXml);
    }));

    it('Test thistleService getInstalmentPaymentRequest', (function () {

        service.getInstalmentPaymentRequest(amount, currency, startDate, endDate, frequency, instalmentTotal, instalmentTotalCurrency, successUrl, failureUrl, cancelUrl);
        var thistle = stateService.get("thistle");

        //  Perform the assert against the state service rather than the return promise. The promise returned by the service under
        //  test a 'real' promise rather than a mock. So this test will not 'see' and act on the returned promise. Further investigation
        //  required in order to test a non-mocked promise.
        expect(thistle.thistleUrl).toBe(thistleMockData.thistleUrl);
        expect(thistle.encodedXml).toBe(thistleMockData.encodedXml);
    }));
});