//Unit tests for State service

describe('Service: URL service', function () {

    var urlService;

    connection = {
        "userType": "agent",
        "host": "http://consumner.bt.com/appsbills",
        "version": "/v1",
        "protectedTypeUri": "/protected",
        "publicTypeUri": "/public"
    };

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
        _$routeParams_.agentDN = "12345678901";
        _$routeParams_.agentEin = "123456789";

        _$routeParams_.accKey = "1234";
    }));

    beforeEach(angular.mock.inject(function (_urlService_) {

        urlService = _urlService_;
    }));

    it('Test billing account URL', function () {

        var url = urlService.getBillAccountUrl();
        expect(url).toEqual('/cak/ACC_002/conk/002/bac/0202535714');
    });

    it('Test days until next bill URL', function () {

        var url = urlService.getDaysUntilNextBillUrl();
        expect(url).toEqual('/cak/ACC_002/conk/002/bac/0202535714/bill/next');
    });

    it('Test make payment URL - agent', function () {

        var url = urlService.getMakePaymentRequestUrl("99.99", "GBP", "justin.time@bt.com", "01173024567", "success", "failure", "cancel");
        expect(url).toEqual('/cak/ACC_002/conk/002/bac/0202535714/payment/99.99/GBP?telephone_num=12345678901&ein=123456789&email=justin.time@bt.com&phoneNumber=01173024567&successUrl=success&failureUrl=failure&cancelUrl=cancel');

        connection.userType = "customer";
        url = urlService.getMakePaymentRequestUrl("99.99", "GBP", "justin.time@bt.com", "01173024567", "success", "failure", "cancel");
        expect(url).toEqual('/acckey/1234/payment/99.99/GBP?email=justin.time@bt.com&phoneNumber=01173024567&successUrl=success&failureUrl=failure&cancelUrl=cancel');
    });

    it('Test make payment URL - customer', function () {

        var url = urlService.getMakeInsecurePaymentRequestUrl("0202535713", "99.99", "GBP", "justin.time@bt.com", "01173024567", "success", "failure", "cancel");
        expect(url).toEqual('/bac/0202535713/payment/99.99/GBP?email=justin.time@bt.com&phoneNumber=01173024567&successUrl=success&failureUrl=failure&cancelUrl=cancel');
    });

    it('Test instalment plan eligibility URL - agent', function () {

        connection.userType = "agent";
        var url = urlService.getInstalmentPlanEligibilityUrl();
        expect(url).toEqual('/cak/ACC_002/conk/002/bac/0202535714/eligible/instalmentplan');
    });

    it('Test instalment plan eligibility URL - customer', function () {

        connection.userType = "customer";
        var url = urlService.getInstalmentPlanEligibilityUrl();
        expect(url).toEqual('/acckey/1234/eligible/instalmentplan');
    });
});