//Unit tests for AJAX service

describe('Service: myService', function () {

    var ajaxService;

    //  Define the mock responses
    var accessTokenMockData = {'timeoutSeconds': '1200', 'accessToken': 'b2297kr5v5sledqf6su0qpda9fc0v0ug2do7br'};

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle

        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_ajaxService_, _$q_, _$rootScope_) {

        var scope = _$rootScope_.$new();

        var deferred = _$q_.defer();
        ajaxService = _ajaxService_;

        spyOn(ajaxService, 'doGet').and.callFake(function (params) {
            return {

                then: function(callback) {return callback(accessTokenMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        //spyOn(ajaxServiceWithoutToken, "getProtectedRequest").and.returnValue(deferred.promise);
        //spyOn(ajaxServiceWithoutToken, 'getProtectedRequest').and.callThrough();

        deferred.resolve(accessTokenMockData);
        scope.$digest();
    }));

    it('Test for ajaxService doGet', (function () {

        //  This test case is rather pointless as the service under test has been mocked. So the test is testing a mock service
        //  rather than the 'real' service. The test is here is an example of mocking a a service. When returning a mock promise
        //  the promise blocks below execute.
        var response = ajaxService.doGet("url");

        expect(ajaxService.doGet).toHaveBeenCalled();

        response.then(function (result) {

            //  This assert will execute as the service under test returns a mock promise. When a service returns a 'real' promise
            //  this block of code would not execute.
            expect(result.accessToken).toBe(accessTokenMockData.accessToken);
            expect(result.timeoutSeconds).toBe(accessTokenMockData.timeoutSeconds);
        });
    }));
});
