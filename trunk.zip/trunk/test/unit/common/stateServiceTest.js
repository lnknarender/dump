//Sample test suite
describe('controllers', function () {

    //Sample test for a controller
    describe('controller', function () {
        it('should return seven different statuses', function () {
            expect("Sample test").toBe("Sample test");
        });
    });
});

//Unit tests for State service
describe('appService Module', function () {
    beforeEach(module('appServices'));

    //Unit tests for State service
    describe('state service', function () {
        it('Test setter and getters', inject(function (stateService) {
            stateService.set("key", "value");
            expect(stateService.get("key")).toBe("value");
            stateService.reset();
            expect(stateService.get("key")).toBe(undefined);

        }));

        it('Test setter and getters with json data', inject(function (stateService) {
            stateService.set("objkey", {"key1": "value1", "key2": "value2"});
            expect(stateService.get("objkey").key1).toBe("value1");
            expect(stateService.get("objkey").key2).toBe("value2");

            stateService.set("arrkey", [{"key": "value1"}, {"key": "value2"}]);
            expect(stateService.get("arrkey")[0].key).toBe("value1");
            expect(stateService.get("arrkey")[1].key).toBe("value2");

        }));
    });
});