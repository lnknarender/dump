/**
 * Created by Andrew on 26/11/2015.
 */

describe('Service: Utility service', function () {

    var scope, utilityService;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$rootScope_, _utilityService_) {

        scope = _$rootScope_.$new();

        utilityService = _utilityService_;
    }));



    it('Test getOrdinalNumber', function () {

        var ordinal = utilityService.getOrdinalNumber(1);
        expect(ordinal).toEqual('1st');

        ordinal = utilityService.getOrdinalNumber(2);
        expect(ordinal).toEqual('2nd');

        ordinal = utilityService.getOrdinalNumber(3);
        expect(ordinal).toEqual('3rd');

        ordinal = utilityService.getOrdinalNumber(4);
        expect(ordinal).toEqual('4th');

        ordinal = utilityService.getOrdinalNumber(5);
        expect(ordinal).toEqual('5th');

        ordinal = utilityService.getOrdinalNumber(6);
        expect(ordinal).toEqual('6th');

        ordinal = utilityService.getOrdinalNumber(7);
        expect(ordinal).toEqual('7th');

        ordinal = utilityService.getOrdinalNumber(8);
        expect(ordinal).toEqual('8th');

        ordinal = utilityService.getOrdinalNumber(9);
        expect(ordinal).toEqual('9th');

        ordinal = utilityService.getOrdinalNumber(10);
        expect(ordinal).toEqual('10th');

        ordinal = utilityService.getOrdinalNumber(11);
        expect(ordinal).toEqual('11th');

        ordinal = utilityService.getOrdinalNumber(12);
        expect(ordinal).toEqual('12th');

        ordinal = utilityService.getOrdinalNumber(13);
        expect(ordinal).toEqual('13th');

        ordinal = utilityService.getOrdinalNumber(14);
        expect(ordinal).toEqual('14th');

        ordinal = utilityService.getOrdinalNumber(15);
        expect(ordinal).toEqual('15th');

        ordinal = utilityService.getOrdinalNumber(16);
        expect(ordinal).toEqual('16th');

        ordinal = utilityService.getOrdinalNumber(17);
        expect(ordinal).toEqual('17th');

        ordinal = utilityService.getOrdinalNumber(18);
        expect(ordinal).toEqual('18th');

        ordinal = utilityService.getOrdinalNumber(19);
        expect(ordinal).toEqual('19th');

        ordinal = utilityService.getOrdinalNumber(20);
        expect(ordinal).toEqual('20th');

        ordinal = utilityService.getOrdinalNumber(21);
        expect(ordinal).toEqual('21st');

        ordinal = utilityService.getOrdinalNumber(22);
        expect(ordinal).toEqual('22nd');

        ordinal = utilityService.getOrdinalNumber(23);
        expect(ordinal).toEqual('23rd');

        ordinal = utilityService.getOrdinalNumber(24);
        expect(ordinal).toEqual('24th');

        ordinal = utilityService.getOrdinalNumber(25);
        expect(ordinal).toEqual('25th');

        ordinal = utilityService.getOrdinalNumber(26);
        expect(ordinal).toEqual('26th');

        ordinal = utilityService.getOrdinalNumber(27);
        expect(ordinal).toEqual('27th');

        ordinal = utilityService.getOrdinalNumber(28);
        expect(ordinal).toEqual('28th');

        ordinal = utilityService.getOrdinalNumber(29);
        expect(ordinal).toEqual('29th');

        ordinal = utilityService.getOrdinalNumber(30);
        expect(ordinal).toEqual('30th');

        ordinal = utilityService.getOrdinalNumber(31);
        expect(ordinal).toEqual('31st');
    });

    it('Test getOrdinalNumber passing undefined', function () {

        var ordinal = utilityService.getOrdinalNumber(undefined);
        expect(ordinal).toEqual('');
    });

    it('Test getOrdinalNumber passing null', function () {

        var ordinal = utilityService.getOrdinalNumber(null);
        expect(ordinal).toEqual('');
    });

    it('Test getCreditCardExpiryDate ', function () {

        var ordinal = utilityService.getCreditCardExpiryDate('2015-10-13');
        expect(ordinal).toEqual('10/15');
    });

    it('Test getCreditCardExpiryDate passing undefined', function () {

        var ordinal = utilityService.getCreditCardExpiryDate(undefined);
        expect(ordinal).toEqual(undefined);
    });

    it('Test getCreditCardExpiryDate passing null', function () {

        var ordinal = utilityService.getCreditCardExpiryDate(null);
        expect(ordinal).toEqual(undefined);
    });

    it('Test getAccordionCSSClass passing ACCORDION_NOT_STARTED', function () {

        var ordinal = utilityService.getAccordionCSSClass(constants.ACCORDION_NOT_STARTED);
        expect(ordinal).toEqual(constants.ACCORDION_CSS_NOT_STARTED);
    });

    it('Test getAccordionCSSClass passing ACCORDION_CURRENT', function () {

        var ordinal = utilityService.getAccordionCSSClass(constants.ACCORDION_CURRENT);
        expect(ordinal).toEqual(constants.ACCORDION_CSS_CURRENT);
    });

    it('Test getAccordionCSSClass passing ACCORDION_COMPLETE', function () {

        var ordinal = utilityService.getAccordionCSSClass(constants.ACCORDION_COMPLETE);
        expect(ordinal).toEqual(constants.ACCORDION_CSS_COMPLETE);
    });

    it('Test defineThistleIframeHeight - CUSTOMER LOGIN', function () {

        scope.userType = "customer";
        scope.loggedOut = false;

        utilityService.defineThistleIframeHeight(scope);
        expect(scope.thistleIFrameHeight).toEqual(constants.THISTLE_IFRAME_HEIGHT_LOGIN_CUSTOMER);
    });

    it('Test defineThistleIframeHeight - AGENT LOGIN', function () {

        scope.userType = "agent";
        scope.loggedOut = false;

        utilityService.defineThistleIframeHeight(scope);
        expect(scope.thistleIFrameHeight).toEqual(constants.THISTLE_IFRAME_HEIGHT);
    });

    it('Test defineThistleIframeHeight - CUSTOMER LOGOUT', function () {

        scope.userType = "customer";
        scope.loggedOut = true;

        utilityService.defineThistleIframeHeight(scope);
        expect(scope.thistleIFrameHeight).toEqual(constants.THISTLE_IFRAME_HEIGHT);
    });

    it('Test getBillCycle', function () {

        var billCycle = utilityService.getBillCycle("2015-10-20");
        expect(billCycle).toEqual(20);

        billCycle = utilityService.getBillCycle("15-10-20");
        expect(billCycle).toEqual(null);
    });

    it('Test getBillCyclePlusDays', function () {

        var billCycle = utilityService.getBillCyclePlusDays("2015-11-20", 2);
        expect(billCycle).toEqual(22);

        billCycle = utilityService.getBillCyclePlusDays("2015-11-20", 12);
        expect(billCycle).toEqual(2);

        billCycle = utilityService.getBillCycle("15-10-20");
        expect(billCycle).toEqual(null);
    });

    it('Test isTwoDatesWithinDifference - same month', function () {

        var dateDifference = utilityService.isTwoDatesWithinDifference("2016-02-05", "2016-02-09", 2);
        expect(dateDifference).toEqual(false);

        dateDifference = utilityService.isTwoDatesWithinDifference("2016-02-05", "2016-02-08", 2);
        expect(dateDifference).toEqual(false);

        dateDifference = utilityService.isTwoDatesWithinDifference("2016-02-05", "2016-02-07", 2);
        expect(dateDifference).toEqual(true);

        dateDifference = utilityService.isTwoDatesWithinDifference("2016-02-05", "2016-02-06", 2);
        expect(dateDifference).toEqual(true);

        dateDifference = utilityService.isTwoDatesWithinDifference("2016-02-05", "2016-02-05", 2);
        expect(dateDifference).toEqual(true);
    });

    it('Test isTwoDatesWithinDifference - different month', function () {

        var dateDifference = utilityService.isTwoDatesWithinDifference("2016-02-05", "2016-03-05", 2);
        expect(dateDifference).toEqual(false);
    });

    it('Test isTwoDatesWithinDifference - first date in the past', function () {

        var dateDifference = utilityService.isTwoDatesWithinDifference("2015-12-25", "2016-03-05", 2);
        expect(dateDifference).toEqual(false);
    });

    it('Test getBankAccountNumber - 8 digit bank account number', function () {

        var bankAccountNumber = utilityService.getBankAccountNumber("12345678");
        expect(bankAccountNumber).toEqual("****5678");
    });

    it('Test getBankAccountNumber - 10 digit bank account number', function () {

        var bankAccountNumber = utilityService.getBankAccountNumber("1234567890");
        expect(bankAccountNumber).toEqual("****567890");
    });

    it('Test getBankAccountNumber - 0 digit bank account number', function () {

        var bankAccountNumber = utilityService.getBankAccountNumber("");
        expect(bankAccountNumber).toEqual("****");
    });

    it('Test getOmnitureError - valid error key', function () {

        var omnitureError = utilityService.getOmnitureError("makePayment.validation.invalidAmount");

        expect(omnitureError[0].errorType).toEqual("SE");
        expect(omnitureError[0].errorPrefix).toEqual("Amount less than 1 pound");

        // As the language bundle has been mocked the key is returned rather than the actual value
        expect(omnitureError[0].errorMessage).toEqual("makePayment.validation.invalidAmount");
    });

    it('Test getOmnitureError - invalid error key', function () {

        var omnitureError = utilityService.getOmnitureError("this.key.does.not.exist");

        expect(omnitureError[0].errorType).toEqual(undefined);
        expect(omnitureError[0].errorPrefix).toEqual(undefined);

        // As the language bundle has been mocked the key is returned rather than the actual value
        expect(omnitureError[0].errorMessage).toEqual("this.key.does.not.exist");
    });

    it('Test getOmnitureError - missing error key', function () {

        var omnitureError = utilityService.getOmnitureError();

        expect(omnitureError[0].errorType).toEqual(undefined);
        expect(omnitureError[0].errorPrefix).toEqual(undefined);
        expect(omnitureError[0].errorMessage).toEqual(undefined);
    });

    it('Test getOmnitureError - empty string for error key', function () {

        var omnitureError = utilityService.getOmnitureError("");

        expect(omnitureError[0].errorType).toEqual(undefined);
        expect(omnitureError[0].errorPrefix).toEqual(undefined);
        expect(omnitureError[0].errorMessage).toEqual('');
    });

    it('Test isObjectUndefinedOrNull - undefined', function () {

        var testObj;
        var isDefined = utilityService.isObjectUndefinedOrNull(testObj);

        expect(isDefined).toEqual(true);
    });

    it('Test isObjectUndefinedOrNull - defined', function () {

        var testObj = {'testValue': 1};
        var isDefined = utilityService.isObjectUndefinedOrNull(testObj);

        expect(isDefined).toEqual(false);
    });

    it('Test isObjectUndefinedOrNull - null', function () {

        var testObj = null;
        var isDefined = utilityService.isObjectUndefinedOrNull(testObj);

        expect(isDefined).toEqual(true);
    });

    it('Test isObjectUndefinedOrNull - not null', function () {

        var testObj = 1;
        var isDefined = utilityService.isObjectUndefinedOrNull(testObj);

        expect(isDefined).toEqual(false);
    });

    it('Test isObjectNotUndefinedOrNotNull - undefined', function () {

        var testObj;
        var isDefined = utilityService.isObjectNotUndefinedOrNotNull(testObj);

        expect(isDefined).toEqual(false);
    });

    it('Test isObjectNotUndefinedOrNotNull - defined', function () {

        var testObj = {'testValue': 1};
        var isDefined = utilityService.isObjectNotUndefinedOrNotNull(testObj);

        expect(isDefined).toEqual(true);
    });

    it('Test splitMoneyPoundsAndPence', function () {

        var amount = "10.99";
        var money = utilityService.splitMoneyPoundsAndPence(amount);

        expect(money.pounds).toEqual("10");
        expect(money.pence).toEqual("99");

        amount = "1.99";
        money = utilityService.splitMoneyPoundsAndPence(amount);

        expect(money.pounds).toEqual("1");
        expect(money.pence).toEqual("99");

        amount = "10.1";
        money = utilityService.splitMoneyPoundsAndPence(amount);

        expect(money.pounds).toEqual("10");
        expect(money.pence).toEqual("10");

        amount = "10";
        money = utilityService.splitMoneyPoundsAndPence(amount);

        expect(money.pounds).toEqual("10");
        expect(money.pence).toEqual("00");

        amount = "-10.13";
        money = utilityService.splitMoneyPoundsAndPence(amount);

        expect(money.pounds).toEqual("10");
        expect(money.pence).toEqual("13");
    });
});