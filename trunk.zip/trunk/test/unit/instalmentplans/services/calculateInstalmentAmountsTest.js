describe('Service: calculateInstalmentAmounts', function () {

    var service, scope;

    //  Define the mock responses

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(inject(function(_$rootScope_, _calculateInstalmentAmounts_) {

        scope = _$rootScope_.$new();


        service = _calculateInstalmentAmounts_;
    }));


    it('Test calculateInstalmentAmounts - getInstalmentAmounts', (function () {

        var outstandingAmount = 100;
        var noOfInstalments = 4;

        var expectedResults = {firstInstalmentAmount: '25.00', instalmentAmount: '25.00'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);

    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts', (function () {

        var outstandingAmount = 75;
        var noOfInstalments = 4;

        var expectedResults = {firstInstalmentAmount: '18.75', instalmentAmount: '18.75'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - no decimal point', (function () {

        var outstandingAmount = 75;
        var noOfInstalments = 1;

        var expectedResults = {firstInstalmentAmount: '75.00', instalmentAmount: '0.00'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - no decimal point, more than one instalment', (function () {

        var outstandingAmount = 75;
        var noOfInstalments = 7;

        var expectedResults = {firstInstalmentAmount: '10.68', instalmentAmount: '10.72'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - one decimal point value', (function () {

        var outstandingAmount = 75.0;
        var noOfInstalments = 1;

        var expectedResults = {firstInstalmentAmount: '75.00', instalmentAmount: '0.00'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - one instalment', (function () {

        var outstandingAmount = 75.00;
        var noOfInstalments = 1;

        var expectedResults = {firstInstalmentAmount: '75.00', instalmentAmount: '0.00'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - trailing decimal place', (function () {

        var outstandingAmount = 75.; // jshint ignore:line

        var noOfInstalments = 1;

        var expectedResults = {firstInstalmentAmount: '75.00', instalmentAmount: '0.00'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - nine instalments', (function () {

        var outstandingAmount = 150.26;
        var noOfInstalments = 9;

        var expectedResults = {firstInstalmentAmount: '16.66', instalmentAmount: '16.70'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - twelve instalments', (function () {

        var outstandingAmount = 7.50;
        var noOfInstalments = 12;

        var expectedResults = {firstInstalmentAmount: '0.57', instalmentAmount: '0.63'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - thirteen instalments', (function () {

        var outstandingAmount = 63.73;
        var noOfInstalments = 13;

        var expectedResults = {firstInstalmentAmount: '4.81', instalmentAmount: '4.91'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - less than one pound, nine instalments', (function () {

        var outstandingAmount = 0.75;
        var noOfInstalments = 9;

        var expectedResults = {firstInstalmentAmount: '0.03', instalmentAmount: '0.09'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - missing decimal point, three instalments', (function () {

        var outstandingAmount = 48;
        var noOfInstalments = 3;

        var expectedResults = {firstInstalmentAmount: '16.00', instalmentAmount: '16.00'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts', (function () {

        var outstandingAmount = 103.80;
        var noOfInstalments = 2;

        var expectedResults = {firstInstalmentAmount: '51.90', instalmentAmount: '51.90'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts - live issue', (function () {

        var outstandingAmount = 103.80000000000001;
        var noOfInstalments = 2;

        var expectedResults = {firstInstalmentAmount: '51.90', instalmentAmount: '51.90'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts', (function () {

        var outstandingAmount = 103.80000000000001;
        var noOfInstalments = 3;

        var expectedResults = {firstInstalmentAmount: '34.60', instalmentAmount: '34.60'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));


    it('Test calculateInstalmentAmounts - getInstalmentAmounts', (function () {

        var outstandingAmount = 103.80000000000001;
        var noOfInstalments = 7;

        var expectedResults = {firstInstalmentAmount: '14.82', instalmentAmount: '14.83'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts', (function () {

        var outstandingAmount = 103.8009999999999999;

        var noOfInstalments = 2;

        var expectedResults = {firstInstalmentAmount: '51.90', instalmentAmount: '51.90'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));


    it('Test calculateInstalmentAmounts - getInstalmentAmounts', (function () {

        var outstandingAmount = 135.20;

        var noOfInstalments = 2;

        var expectedResults = {firstInstalmentAmount: '67.60', instalmentAmount: '67.60'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));

    it('Test calculateInstalmentAmounts - getInstalmentAmounts', (function () {

        var outstandingAmount = 135.29;

        var noOfInstalments = 2;

        var expectedResults = {firstInstalmentAmount: '67.64', instalmentAmount: '67.65'};

        var instalmentAmounts = service.getInstalmentAmounts(outstandingAmount, noOfInstalments);

        expect(instalmentAmounts.firstInstalmentAmount).toBe(expectedResults.firstInstalmentAmount);
        expect(instalmentAmounts.instalmentAmount).toBe(expectedResults.instalmentAmount);
    }));
});