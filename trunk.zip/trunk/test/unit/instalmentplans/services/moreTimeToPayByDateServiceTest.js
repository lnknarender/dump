describe('Service: more Time To Pay Date Service', function () {

    var service, scope;

    //  Define the mock responses

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(inject(function(_$rootScope_, _moreTimeToPayByDateService_) {

        scope = _$rootScope_.$new();


        service = _moreTimeToPayByDateService_;
    }));


    it('Test moreTimeToPayByDateService - getAvailablePayByDatesWithinMonth', (function () {

        var todayDateMoment = ("2015-10-01");
        var nextBillDateMoment = ("2015-10-31");

        var availableDates = service.getAvailablePayByDates(todayDateMoment, nextBillDateMoment);

        expect(availableDates.length).toBe(23);
        expect(availableDates[0]).toBe('2015-10-02');
        expect(availableDates[1]).toBe('2015-10-03');
        expect(availableDates[2]).toBe('2015-10-04');
        expect(availableDates[3]).toBe('2015-10-05');
        expect(availableDates[4]).toBe('2015-10-06');
        expect(availableDates[5]).toBe('2015-10-07');
        expect(availableDates[6]).toBe('2015-10-08');
        expect(availableDates[7]).toBe('2015-10-09');
        expect(availableDates[8]).toBe('2015-10-10');
        expect(availableDates[9]).toBe('2015-10-11');
        expect(availableDates[10]).toBe('2015-10-12');
        expect(availableDates[11]).toBe('2015-10-13');
        expect(availableDates[12]).toBe('2015-10-14');
        expect(availableDates[13]).toBe('2015-10-15');
        expect(availableDates[14]).toBe('2015-10-16');
        expect(availableDates[15]).toBe('2015-10-17');
        expect(availableDates[16]).toBe('2015-10-18');
        expect(availableDates[17]).toBe('2015-10-19');
        expect(availableDates[18]).toBe('2015-10-20');
        expect(availableDates[19]).toBe('2015-10-21');
        expect(availableDates[20]).toBe('2015-10-22');
        expect(availableDates[21]).toBe('2015-10-23');
        expect(availableDates[22]).toBe('2015-10-24');


    }));

    it('Test moreTimeToPayByDateService - getAvailablePayByDatesSpanMonth', (function () {

        var todayDateMoment = ("2016-01-24");
        var nextBillDateMoment = ("2016-02-10");

        var availableDates = service.getAvailablePayByDates(todayDateMoment, nextBillDateMoment);

        expect(availableDates.length).toBe(10);
        expect(availableDates[0]).toBe('2016-01-25');
        expect(availableDates[1]).toBe('2016-01-26');
        expect(availableDates[2]).toBe('2016-01-27');
        expect(availableDates[3]).toBe('2016-01-28');
        expect(availableDates[4]).toBe('2016-01-29');
        expect(availableDates[5]).toBe('2016-01-30');
        expect(availableDates[6]).toBe('2016-01-31');
        expect(availableDates[7]).toBe('2016-02-01');
        expect(availableDates[8]).toBe('2016-02-02');
        expect(availableDates[9]).toBe('2016-02-03');

    }));

    it('Test moreTimeToPayByDateService - getAvailablePayByDatesSpanLeapYear', (function () {

        var todayDateMoment = ("2016-02-24");
        var nextBillDateMoment = ("2016-03-27");

        var availableDates = service.getAvailablePayByDates(todayDateMoment, nextBillDateMoment);

        expect(availableDates.length).toBe(25);
        expect(availableDates[0]).toBe('2016-02-25');
        expect(availableDates[1]).toBe('2016-02-26');
        expect(availableDates[2]).toBe('2016-02-27');
        expect(availableDates[3]).toBe('2016-02-28');
        expect(availableDates[4]).toBe('2016-02-29');
        expect(availableDates[5]).toBe('2016-03-01');
        expect(availableDates[6]).toBe('2016-03-02');
        expect(availableDates[7]).toBe('2016-03-03');
        expect(availableDates[8]).toBe('2016-03-04');
        expect(availableDates[9]).toBe('2016-03-05');
        expect(availableDates[10]).toBe('2016-03-06');
        expect(availableDates[11]).toBe('2016-03-07');
        expect(availableDates[12]).toBe('2016-03-08');
        expect(availableDates[13]).toBe('2016-03-09');
        expect(availableDates[14]).toBe('2016-03-10');
        expect(availableDates[15]).toBe('2016-03-11');
        expect(availableDates[16]).toBe('2016-03-12');
        expect(availableDates[17]).toBe('2016-03-13');
        expect(availableDates[18]).toBe('2016-03-14');
        expect(availableDates[19]).toBe('2016-03-15');
        expect(availableDates[20]).toBe('2016-03-16');
        expect(availableDates[21]).toBe('2016-03-17');
        expect(availableDates[22]).toBe('2016-03-18');
        expect(availableDates[23]).toBe('2016-03-19');
        expect(availableDates[24]).toBe('2016-03-20');

    }));

    it('Test moreTimeToPayByDateService - getAvailablePayByDatesNextBillDateBeforeTomorrow', (function () {

        var todayDateMoment = ("2016-02-29");
        var nextBillDateMoment = ("2016-02-24");

        var availableDates = service.getAvailablePayByDates(todayDateMoment, nextBillDateMoment);

        expect(availableDates.length).toBe(0);


    }));

    it('Test moreTimeToPayByDateService - getAvailablePayByDatesLastDateDayAfterTomorrow', (function () {

        var todayDateMoment = ("2015-10-14");
        var nextBillDateMoment = ("2015-10-22");

        var availableDates = service.getAvailablePayByDates(todayDateMoment, nextBillDateMoment);

        expect(availableDates.length).toBe(1);
        expect(availableDates[0]).toBe('2015-10-15');


    }));


    it('Test moreTimeToPayByDateService - getDatesInRange', (function () {

        var todayDateMoment = ("2015-10-01");
        var nextBillDateMoment = ("2015-10-10");

        var availableDates = service.getDatesInRange(todayDateMoment, nextBillDateMoment);

        expect(availableDates.length).toBe(10);
        expect(availableDates[0]).toBe('2015-10-01');
        expect(availableDates[1]).toBe('2015-10-02');
        expect(availableDates[2]).toBe('2015-10-03');
        expect(availableDates[3]).toBe('2015-10-04');
        expect(availableDates[4]).toBe('2015-10-05');
        expect(availableDates[5]).toBe('2015-10-06');
        expect(availableDates[6]).toBe('2015-10-07');
        expect(availableDates[7]).toBe('2015-10-08');
        expect(availableDates[8]).toBe('2015-10-09');
        expect(availableDates[9]).toBe('2015-10-10');
    }));


});