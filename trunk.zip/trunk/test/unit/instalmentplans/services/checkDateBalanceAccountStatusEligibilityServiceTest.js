describe('Service: instalment plan eligibility', function () {

    var service, stateService, $q, $httpBackend, scope;

    //  Define the mock responses

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle

        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    function setupTest (mockData) {
        (inject(function(_$rootScope_, _instalmentPlanEligibilityService_, _ajaxServiceWithToken_, _stateService_, _$q_, _$httpBackend_) {

            scope = _$rootScope_.$new();

            $q = _$q_;

            $httpBackend = _$httpBackend_;

            stateService = _stateService_;

            service = _instalmentPlanEligibilityService_;

            var mockAjaxService = _ajaxServiceWithToken_;

            spyOn(mockAjaxService, 'doGet').and.callFake(function () {

                return {

                    then: function(callback) { return callback(mockData); },

                    catch: function(callback) { return null; },

                    finally: function(callback) { return null; }
                };
            });

            var deferred = _$q_.defer();
            deferred.resolve();
            scope.$digest();
        }));
    }

    it('Test instalmentPlanEligibilityService - isInstalmentPlanEligibility - check instalment eligible', (function () {

        setupTest(instalmentPlanEligibility_ineligible_final_bill_MockData);

        // Make the mock ReST request
        service.getInstalmentPlanEligibility();

        var isInstalmentPlanEligibilityResponse = service.getInstalmentPlan();
        expect(isInstalmentPlanEligibilityResponse.eligible).toBe('N');
        //expect(isInstalmentPlanEligibilityResponse.reasonCode).toBe(constants.ERRORS_INSTALMENT_PLAN_ACCOUNT_NOT_ACTIVE);
    }));

    it('Test instalmentPlanEligibilityService - isInstalmentPlanEligibility - outstanding balance in credit', (function () {

        setupTest(instalmentPlanEligibility_ineligible_final_bill_MockData);

        instalmentPlanEligibility_ineligible_final_bill_MockData.outstandingBalance.amount = 0;

        // Make the mock ReST request
        service.getInstalmentPlanEligibility();

        var isInstalmentPlanEligibilityResponse = service.getInstalmentPlan();
        expect(isInstalmentPlanEligibilityResponse.eligible).toBe('N');
        //expect(isInstalmentPlanEligibilityResponse.reasonCode).toBe(constants.ERRORS_INSTALMENT_PLAN_OUTSTANDING_BALANCE_IN_CREDIT);
    }));

    it('Test instalmentPlanEligibilityService - isInstalmentPlanEligibility - last payment date is NULL', (function () {

        setupTest(instalmentPlanEligibility_ineligible_final_bill_MockData);

        instalmentPlanEligibility_ineligible_final_bill_MockData.paymentDueDate = null;

        // Make the mock ReST request
        service.getInstalmentPlanEligibility();

        var isInstalmentPlanEligibilityResponse = service.getInstalmentPlan();
        expect(isInstalmentPlanEligibilityResponse.eligible).toBe('N');
      //  expect(isInstalmentPlanEligibilityResponse.reasonCode).toBe(constants.ERRORS_INSTALMENT_PLAN_LAST_PAYMENT_DATE_NULL);
    }));

    it('Test instalmentPlanEligibilityService - isInstalmentPlanEligibility - eligible', (function () {

        setupTest(instalmentPlanEligibility_eligible_MockData);

        // Make the mock ReST request
        service.getInstalmentPlanEligibility();

        var isInstalmentPlanEligibilityResponse = service.getInstalmentPlan();
        expect(isInstalmentPlanEligibilityResponse.eligible).toBe('Y');
      //  expect(isInstalmentPlanEligibilityResponse.reasonCode).toBe('');
    }));
});