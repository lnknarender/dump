describe('Service: instalment plan eligibility', function () {

    var service, stateService, $q, $httpBackend, scope;

    //  Define the mock responses

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    function setupTest (mockData) {
        (inject(function(_$rootScope_, _instalmentPlanEligibilityService_, _ajaxServiceWithToken_, _stateService_, _$q_, _$httpBackend_) {

            scope = _$rootScope_.$new();

            $q = _$q_;

            $httpBackend = _$httpBackend_;

            stateService = _stateService_;

            service = _instalmentPlanEligibilityService_;

            var mockAjaxService = _ajaxServiceWithToken_;

            spyOn(mockAjaxService, 'doGet').and.callFake(function () {

                return {

                    then: function(callback) { return callback(mockData); },

                    catch: function(callback) { return null; },

                    finally: function(callback) { return null; }
                };
            });

            var deferred = _$q_.defer();
            deferred.resolve();
            scope.$digest();
        }));
    }

    it('Test instalmentPlanEligibilityService - getInstalmentPlanEligibility', (function () {

        setupTest(instalmentPlanEligibility_ineligible_final_bill_MockData);

        // Make the mock ReST request
        service.getInstalmentPlanEligibility();
        var eligibility = stateService.get("instalmentPlanEligibility");

        /*
         Assert will be done against the state service as the promise for the getInstalmentPlanEligibility
         will not return within a Karma unit test
         */
        expect(eligibility.accountStatus).toBe(null);
        expect(eligibility.minimumPayment.amount).toBe(instalmentPlanEligibility_ineligible_final_bill_MockData.minimumPayment.amount);
        expect(eligibility.minimumPayment.currencyCode).toBe(instalmentPlanEligibility_ineligible_final_bill_MockData.minimumPayment.currencyCode);
        expect(eligibility.nextBillDate).toBe(instalmentPlanEligibility_ineligible_final_bill_MockData.nextBillDate);
        expect(eligibility.eligible).toBe(instalmentPlanEligibility_ineligible_final_bill_MockData.eligible);
        expect(eligibility.reasonsForIneligibility.reason1).toBe(instalmentPlanEligibility_ineligible_final_bill_MockData.reasonsForIneligibility.reason1);
        expect(eligibility.paymentDueDate).toBe(instalmentPlanEligibility_ineligible_final_bill_MockData.paymentDueDate);
        expect(eligibility.credit).toBe(instalmentPlanEligibility_ineligible_final_bill_MockData.credit);
    }));
});