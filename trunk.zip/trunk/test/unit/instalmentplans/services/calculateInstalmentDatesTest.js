describe('Service: calculateInstalmentDates', function () {

    var service, scope;

    //  Define the mock responses

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(inject(function(_$rootScope_, _calculateInstalmentAmounts_) {

        scope = _$rootScope_.$new();


        service = _calculateInstalmentAmounts_;
    }));

    it('Test calculateInstalmentDates - getInstalmentDates weekly', (function () {

        var startDate = "2015-10-01";
        var endDate = "2015-10-30";
        var frequency = '1W';

       var instalmentAmounts = service.getInstalmentDates(startDate, endDate, frequency);

        expect(instalmentAmounts.length).toBe(6);

        expect(instalmentAmounts[0].date).toBe('2015-10-01');
        expect(instalmentAmounts[0].number).toBe(1);

        expect(instalmentAmounts[1].date).toBe('2015-10-08');
        expect(instalmentAmounts[1].number).toBe(2);

        expect(instalmentAmounts[2].date).toBe('2015-10-15');
        expect(instalmentAmounts[2].number).toBe(3);

        expect(instalmentAmounts[3].date).toBe('2015-10-22');
        expect(instalmentAmounts[3].number).toBe(4);

        expect(instalmentAmounts[4].date).toBe('2015-10-29');
        expect(instalmentAmounts[4].number).toBe(5);

        expect(instalmentAmounts[5].date).toBe('2015-10-30');
        expect(instalmentAmounts[5].number).toBe(6);
    }));

    it('Test calculateInstalmentDates - getInstalmentDates weekly', (function () {

        var startDate = "2015-10-01";
        var endDate = "2015-11-10";
        var frequency = '1W';

        var instalmentAmounts = service.getInstalmentDates(startDate, endDate, frequency);

        expect(instalmentAmounts.length).toBe(7);

        expect(instalmentAmounts[0].date).toBe('2015-10-01');
        expect(instalmentAmounts[0].number).toBe(1);

        expect(instalmentAmounts[1].date).toBe('2015-10-08');
        expect(instalmentAmounts[1].number).toBe(2);

        expect(instalmentAmounts[2].date).toBe('2015-10-15');
        expect(instalmentAmounts[2].number).toBe(3);

        expect(instalmentAmounts[3].date).toBe('2015-10-22');
        expect(instalmentAmounts[3].number).toBe(4);

        expect(instalmentAmounts[4].date).toBe('2015-10-29');
        expect(instalmentAmounts[4].number).toBe(5);

        expect(instalmentAmounts[5].date).toBe('2015-11-05');
        expect(instalmentAmounts[5].number).toBe(6);

        expect(instalmentAmounts[6].date).toBe('2015-11-10');
        expect(instalmentAmounts[6].number).toBe(7);
    }));

    it('Test calculateInstalmentDates - getInstalmentDates fortnightly', (function () {

        var startDate = "2015-10-01";
        var endDate = "2015-10-30";
        var frequency = '2W';

        var instalmentAmounts = service.getInstalmentDates(startDate, endDate, frequency);

        expect(instalmentAmounts.length).toBe(4);

        expect(instalmentAmounts[0].date).toBe('2015-10-01');
        expect(instalmentAmounts[0].number).toBe(1);

        expect(instalmentAmounts[1].date).toBe('2015-10-15');
        expect(instalmentAmounts[1].number).toBe(2);

        expect(instalmentAmounts[2].date).toBe('2015-10-29');
        expect(instalmentAmounts[2].number).toBe(3);

        expect(instalmentAmounts[3].date).toBe('2015-10-30');
        expect(instalmentAmounts[3].number).toBe(4);
    }));

    it('Test calculateInstalmentDates - getInstalmentDates fortnightly', (function () {

        var startDate = "2016-1-01";
        var endDate = "2016-6-01";
        var frequency = '1M';

        var instalmentAmounts = service.getInstalmentDates(startDate, endDate, frequency);

        expect(instalmentAmounts.length).toBe(6);
        expect(instalmentAmounts[0].date).toBe('2016-01-01');
        expect(instalmentAmounts[0].number).toBe(1);

        expect(instalmentAmounts[1].date).toBe('2016-02-01');
        expect(instalmentAmounts[1].number).toBe(2);

        expect(instalmentAmounts[2].date).toBe('2016-03-01');
        expect(instalmentAmounts[2].number).toBe(3);

        expect(instalmentAmounts[3].date).toBe('2016-04-01');
        expect(instalmentAmounts[3].number).toBe(4);

        expect(instalmentAmounts[4].date).toBe('2016-05-01');
        expect(instalmentAmounts[4].number).toBe(5);

        expect(instalmentAmounts[5].date).toBe('2016-06-01');
        expect(instalmentAmounts[5].number).toBe(6);
    }));

    it('Test calculateInstalmentDates - getInstalmentDates fortnightly', (function () {

        var startDate = "2016-01-01";
        var endDate = "2016-06-01";
        var frequency = '1M';

        var instalmentAmounts = service.getInstalmentDates(startDate, endDate, frequency);

        expect(instalmentAmounts.length).toBe(6);
        expect(instalmentAmounts[0].date).toBe('2016-01-01');
        expect(instalmentAmounts[0].number).toBe(1);

        expect(instalmentAmounts[1].date).toBe('2016-02-01');
        expect(instalmentAmounts[1].number).toBe(2);

        expect(instalmentAmounts[2].date).toBe('2016-03-01');
        expect(instalmentAmounts[2].number).toBe(3);

        expect(instalmentAmounts[3].date).toBe('2016-04-01');
        expect(instalmentAmounts[3].number).toBe(4);

        expect(instalmentAmounts[4].date).toBe('2016-05-01');
        expect(instalmentAmounts[4].number).toBe(5);

        expect(instalmentAmounts[5].date).toBe('2016-06-01');
        expect(instalmentAmounts[5].number).toBe(6);
    }));

    it('Test calculateInstalmentDates - getInstalmentDates weekly - month and day no zero', (function () {

        var startDate = "2016-2-1";
        var endDate = "2016-3-7";
        var frequency = '1W';

        var instalmentAmounts = service.getInstalmentDates(startDate, endDate, frequency);

        expect(instalmentAmounts.length).toBe(6);
        expect(instalmentAmounts[0].date).toBe('2016-02-01');
        expect(instalmentAmounts[0].number).toBe(1);

        expect(instalmentAmounts[1].date).toBe('2016-02-08');
        expect(instalmentAmounts[1].number).toBe(2);

        expect(instalmentAmounts[2].date).toBe('2016-02-15');
        expect(instalmentAmounts[2].number).toBe(3);

        expect(instalmentAmounts[3].date).toBe('2016-02-22');
        expect(instalmentAmounts[3].number).toBe(4);

        expect(instalmentAmounts[4].date).toBe('2016-02-29');
        expect(instalmentAmounts[4].number).toBe(5);

        expect(instalmentAmounts[5].date).toBe('2016-03-07');
        expect(instalmentAmounts[5].number).toBe(6);
    }));

    it('Test calculateInstalmentDates - getInstalmentDates weekly - month with zero', (function () {

        var startDate = "2016-01-01";
        var endDate = "2016-06-01";
        var frequency = '1W';

        var instalmentAmounts = service.getInstalmentDates(startDate, endDate, frequency);

        expect(instalmentAmounts.length).toBe(23);
        expect(instalmentAmounts[0].date).toBe('2016-01-01');
        expect(instalmentAmounts[0].number).toBe(1);

        expect(instalmentAmounts[1].date).toBe('2016-01-08');
        expect(instalmentAmounts[1].number).toBe(2);

        expect(instalmentAmounts[2].date).toBe('2016-01-15');
        expect(instalmentAmounts[2].number).toBe(3);

        expect(instalmentAmounts[3].date).toBe('2016-01-22');
        expect(instalmentAmounts[3].number).toBe(4);

        expect(instalmentAmounts[4].date).toBe('2016-01-29');
        expect(instalmentAmounts[4].number).toBe(5);

        expect(instalmentAmounts[5].date).toBe('2016-02-05');
        expect(instalmentAmounts[5].number).toBe(6);
    }));


    it('Test calculateInstalmentDates - getInstalmentDatesForMonthlyBill', (function () {

        var endDate = "2016-1-01";

        var instalmentAmounts = service.getInstalmentDatesForMonthlyBill(endDate);

        expect(instalmentAmounts.length).toBe(1);
        expect(instalmentAmounts[0].date).toBe('2016-01-01');
        expect(instalmentAmounts[0].number).toBe(1);
    }));

    it('Test calculateInstalmentDates - getInstalmentDatesForMonthlyBill', (function () {

        var endDate = "2016-01-01";

        var instalmentAmounts = service.getInstalmentDatesForMonthlyBill(endDate);

        expect(instalmentAmounts.length).toBe(1);
        expect(instalmentAmounts[0].date).toBe('2016-01-01');
        expect(instalmentAmounts[0].number).toBe(1);
    }));

    it('Test calculateInstalmentDates - getInstalmentDates monthly 2', (function () {

        var startDate = "2016-12-1";
        var endDate = "2017-02-01";
        var frequency = '1M';

        var instalmentAmounts = service.getInstalmentDates(startDate, endDate, frequency);

        expect(instalmentAmounts.length).toBe(3);


        expect(instalmentAmounts[0].date).toBe('2016-12-01');
        expect(instalmentAmounts[0].number).toBe(1);

        expect(instalmentAmounts[1].date).toBe('2017-01-01');
        expect(instalmentAmounts[1].number).toBe(2);

        expect(instalmentAmounts[2].date).toBe('2017-02-01');
        expect(instalmentAmounts[2].number).toBe(3);


    }));

        it('Test calculateInstalmentDates - getInstalmentDates monthly 2', (function () {

        var startDate = "2016-01-1";
        var endDate = "2017-02-01";
        var frequency = '1M';

        var instalmentAmounts = service.getInstalmentDates(startDate, endDate, frequency);

        expect(instalmentAmounts.length).toBe(14);
        expect(instalmentAmounts[0].date).toBe('2016-01-01');
        expect(instalmentAmounts[0].number).toBe(1);

        expect(instalmentAmounts[1].date).toBe('2016-02-01');
        expect(instalmentAmounts[1].number).toBe(2);

        expect(instalmentAmounts[2].date).toBe('2016-03-01');
        expect(instalmentAmounts[2].number).toBe(3);

        expect(instalmentAmounts[3].date).toBe('2016-04-01');
        expect(instalmentAmounts[3].number).toBe(4);

        expect(instalmentAmounts[4].date).toBe('2016-05-01');
        expect(instalmentAmounts[4].number).toBe(5);

        expect(instalmentAmounts[5].date).toBe('2016-06-01');
        expect(instalmentAmounts[5].number).toBe(6);

        expect(instalmentAmounts[6].date).toBe('2016-07-01');
        expect(instalmentAmounts[6].number).toBe(7);

        expect(instalmentAmounts[7].date).toBe('2016-08-01');
        expect(instalmentAmounts[7].number).toBe(8);

        expect(instalmentAmounts[8].date).toBe('2016-09-01');
        expect(instalmentAmounts[8].number).toBe(9);

        expect(instalmentAmounts[9].date).toBe('2016-10-01');
        expect(instalmentAmounts[9].number).toBe(10);

        expect(instalmentAmounts[10].date).toBe('2016-11-01');
        expect(instalmentAmounts[10].number).toBe(11);

        expect(instalmentAmounts[11].date).toBe('2016-12-01');
        expect(instalmentAmounts[11].number).toBe(12);

        expect(instalmentAmounts[12].date).toBe('2017-01-01');
        expect(instalmentAmounts[12].number).toBe(13);

        expect(instalmentAmounts[13].date).toBe('2017-02-01');
        expect(instalmentAmounts[13].number).toBe(14);

    }));


});