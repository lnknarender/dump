//Unit tests for Instalment plan up front payment

describe('Controller: Instalment plan up front payment', function () {

    var mockRepaymentPlanService, service, stateService;

    //  Define the mock responses
    var repaymentPlanMockData = {upfront: {amount: '99'}};

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle

        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

        _$routeParams_.cak = "ACC_002";
        _$routeParams_.conk = "002";
        _$routeParams_.bac = "0202535714";
    }));

    beforeEach(function() {

        mockRepaymentPlanService = {

            getRepaymentPlan: function() {

                return repaymentPlanMockData;

            }
        };
    });
});