/*
 Unit tests for Make payment controller

 Mock test data is read from an external file. This file(s) are defined
 in karma.conf.js
 */
describe('Instalment plan controller - InstalmentPlanEligibility', function () {

    var scope, location, createController;
    var $window, window;

    connection = {
        "userType": "agent",
        "host": "http://consumner.bt.com/appsbills",
        "version": "/v1",
        "protectedTypeUri": "/protected",
        "publicTypeUri": "/public",
        "controlSpendAlertUrl": "http://www.bt.com/controlSpendAlert?accKey=%ACC_KEY",
        "automatedPaymentUrl": "http://www.bt.com/automatedPayment?accKey=%ACC_KEY"
    };

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    //  Add customer account key to the URL
    function setupAccountKeyOnUrl() {

        (angular.mock.inject(function (_$routeParams_) {

            _$routeParams_.accKey = "35714";
            _$routeParams_.telephone_num = "12345678901";
            _$routeParams_.agentEin = "123456789";
        }));
    }

    //  Add customer account key to the URL
    function setupCakConkBakOnUrl() {

        (angular.mock.inject(function (_$routeParams_) {

            _$routeParams_.cak = "ACC_002";
            _$routeParams_.conk = "002";
            _$routeParams_.bac = "0202535714";
            _$routeParams_.telephone_num = "12345678901";
            _$routeParams_.agentEin = "123456789";
        }));
    }

    beforeEach(inject(function (_$window_, $rootScope, $controller, _$location_, $routeParams, _urlService_, _errorLoggingService_, _instalmentPlanEligibilityService_) {

        location = _$location_;
        scope = $rootScope.$new();
        $window = _$window_;
        window = _$window_;

        //  Create the MakePaymentIndex and pass the mock objects
        createController = function () {
            return $controller('InstalmentPlanEligibility',
               {$scope: scope,
                $location: location,
                $routeParams: $routeParams,
                urlService: _urlService_,
                errorLoggingService: _errorLoggingService_,
                instalmentPlanEligibilityService: _instalmentPlanEligibilityService_
            });
        };
    }));

    it('Testing control spend alert URL for customer', function () {

        setupAccountKeyOnUrl();

        //  Create the controller
        createController();

        //  Assert that the account key has been updated on the control spend alert URL
        expect(scope.getControlSpentAlertUrl).toBe("http://www.bt.com/controlSpendAlert?accKey=35714");
    });

    it('Testing automated payment URL for customer', function () {

        setupAccountKeyOnUrl();

        //  Create the controller
        createController();

        //  Assert that the account key has been updated on the automated payment URL
        expect(scope.getAutomatedPaymentUrl).toBe("http://www.bt.com/automatedPayment?accKey=35714");
    });

    it('Testing control spend alert URL for agent', function () {

        setupCakConkBakOnUrl();

        //  Create the controller
        createController();

        //  Assert that the account key has been updated on the control spend alert URL
        expect(scope.getControlSpentAlertUrl).toBe(undefined);
    });

    it('Testing automated payment URL for agent', function () {

        setupCakConkBakOnUrl();

        //  Create the controller
        createController();

        //  Assert that the account key has been updated on the automated payment URL
        expect(scope.getAutomatedPaymentUrl).toBe(undefined);
    });
});
