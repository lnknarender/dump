/**
 * Created by dev on 10/12/15.
 */
describe('instalment plan date picker', function () {

    var scope, timeout;

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(inject(function(_$rootScope_, _$timeout_) {

        scope = _$rootScope_.$new();

        timeout = _$timeout_;
    }));

    it('Test instalment plan date picker', inject(function () {
//TODO need to check Narender
      /*  InstalmentPlanDatepicker(scope, timeout);

        var maxDate = new Date(2050, 12, 31);

        expect(scope.showButtonBar()).toBeFalsy();
        expect(scope.showWeeks()).toBeFalsy();
        expect(scope.clear()).toBe(undefined);

        scope.toggleWeeks();

        expect(scope.maxDate.toString()).toBe(maxDate.toString());*/
    }));


});