describe('Service: current bill service', function () {

    var service, stateService, $q, $httpBackend, scope;

    //  Define the mock responses
    var ajaxServiceMockData = {"balance": {"amount": 10.0,
                                           "currencyCode": "GBP"},
                               "paymentDueDate": "2014-12-27",
                               "finalBillReceived": "N",
                               "credit": "N"};

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle

        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(inject(function(_$rootScope_, _currentBillService_, _ajaxServiceWithToken_, _stateService_, _$q_, _$httpBackend_) {

        scope = _$rootScope_.$new();

        $q = _$q_;

        $httpBackend = _$httpBackend_;

        stateService = _stateService_;

        service = _currentBillService_;

        var mockAjaxService = _ajaxServiceWithToken_;

        spyOn(mockAjaxService, 'doGet').and.callFake(function () {

            return {

                then: function(callback) { return callback(ajaxServiceMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        var deferred = _$q_.defer();
        deferred.resolve();
        scope.$digest();
    }));

    it('Test currentBillService getBalanceForMakePayment', (function () {

        var balanceForMakePaymentResponse = service.getBalanceForMakePayment();
        balanceForMakePaymentResponse.then(function (result) {

            expect(result.balance.amount).toBe(ajaxServiceMockData.amount);
            expect(result.balance.balance.currencyCode).toBe(ajaxServiceMockData.balance.currencyCode);
            expect(result.balance.paymentDueDate).toBe(ajaxServiceMockData.paymentDueDate);
            expect(result.balance.finalBillReceived).toBe(ajaxServiceMockData.finalBillReceived);
            expect(result.balance.credit).toBe(ajaxServiceMockData.credit);
        });

        //  Also assert that the balance has been stored in stateService
        var currentBalance = stateService.get("currentBillForMakePayment");

        expect(currentBalance.balance.amount).toBe(ajaxServiceMockData.balance.amount);
        expect(currentBalance.balance.currencyCode).toBe(ajaxServiceMockData.balance.currencyCode);
        expect(currentBalance.paymentDueDate).toBe(ajaxServiceMockData.paymentDueDate);
        expect(currentBalance.finalBillReceived).toBe(ajaxServiceMockData.finalBillReceived);
        expect(currentBalance.credit).toBe(ajaxServiceMockData.credit);
    }));
});