/**
 * Created by dev on 9/16/15.
 */

describe ('Billing preference service',function(){

    var service, makePaymentService, scope;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(inject(function(_$rootScope_, _$routeParams_, _$q_, _makePaymentService_) {

        scope = _$rootScope_.$new();

        makePaymentService = _makePaymentService_;
    }));
    it('Testing make payment service - tabPanel', inject(function () {

        //  Set-up expected data to be returned by the service under test
        var tabPanel =[
            {
                'tabLabel':'confirm.account.tab',
                'includeHtml':'templates/makepayment/loggedOutEnterBac.html',
                'tab':constants.CONFIRM_ACCOUNT_TAB
            },{
                'tabLabel':'enter.amount.tab',
                'includeHtml':'templates/makepayment/enterAmount.html',
                'tab':constants.ENTER_AMOUNT_TAB
            },{
                'tabLabel':'make.payment.tab',
                'includeHtml':'templates/makepayment/paymentIframe.html',
                'tab':constants.PAYMENT_IFRAME_TAB
            },{
                'tabLabel':'payment.summary.tab',
                'includeHtml':'templates/makepayment/paymentSuccessful.html',
                'tab':constants.PAYMENT_SUCCESSFUL
            }
        ];

        //  Call the service under test
        var getTabPanel = makePaymentService.getTabpanels();

        //  Assert that the service under test returns the expected values
        expect(getTabPanel).toEqual(tabPanel);
    }));

});