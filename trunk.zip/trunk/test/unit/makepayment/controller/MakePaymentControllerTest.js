/*
 Unit tests for Make payment controller

 Mock test data is read from an external file. This file(s) are defined
 in karma.conf.js
 */
describe('Controller: Make payment controller - MakePaymentIndex', function () {

    var scope, location, createController;
    var mockBillAccountService, mockAccessTokenService;
    var $window, window;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));
/*

    beforeEach(function() {
        window = {width: 1024 };

        module(function($provide) {
            $provide.value('$window', window);
        });
    });
*/

/*    beforeEach(inject(function (_session_, _$window_) {
        $window = _$window_;

        $window.sessionStorage = { // mocking sessionStorage
            getItem: function(key) {
                return this[key];
            }
        };
    }));*/

    beforeEach(inject(function (_$window_, $rootScope, $controller, _$location_, $routeParams, _urlService_, _makePaymentService_, _makePaymentThistleService_, _errorLoggingService_,
                                _currentBillService_, _primaryContactService_, _$timeout_, _kcimEmailConfirmationService_, _paymentFriendlyNameService_, _stateService_, _utilityService_) {

        location = _$location_;
        scope = $rootScope.$new();
        $window = _$window_;
        window = _$window_;

/*
        '$scope', '$location', '$routeParams', 'urlService',
            'makePaymentService','makePaymentThistleService','errorLoggingService','currentBillService',
            'primaryContactService', '$timeout','kcimEmailConfirmationService','paymentFriendlyNameService', 'stateService', 'utilityService'

        $scope, $location, $routeParams, urlService,
            makePaymentService,makePaymentThistleService,errorLoggingService,currentBillService,
            primaryContactService, $timeout,kcimEmailConfirmationService,paymentFriendlyNameService, stateService, utilityService
*/
        //  Create the MakePaymentIndex and pass the mock objects
       createController = function() {
            return $controller('MakePaymentIndex', {$scope: scope,
                                                    $location: location,
                                                    $routeParams: $routeParams,
                                                    urlService: _urlService_,
                                                    makePaymentService: _makePaymentService_,
                                                    makePaymentThistleService: _makePaymentThistleService_,
                                                    errorLoggingService: _errorLoggingService_,
                                                    currentBillService: _currentBillService_,
                                                    primaryContactService: _primaryContactService_,
                                                    $timeout: _$timeout_,
                                                    kcimEmailConfirmationService: _kcimEmailConfirmationService_,
                                                    paymentFriendlyNameService: _paymentFriendlyNameService_,
                                                    stateService: _stateService_,
                                                    utilityService: _utilityService_

            });
        };
    }));

    //  Mock the billing account service (getAccount) and access token service (getToken)
    beforeEach(angular.mock.inject(function (_billAccountService_, _accessTokenService_, _$q_, _$rootScope_) {

        scope = _$rootScope_.$new();

        var deferred = _$q_.defer();
        mockBillAccountService = _billAccountService_;

        spyOn(mockBillAccountService, 'getAccount').and.callFake(function () {

            return {

                then: function(callback) { return callback(billAccountMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        deferred.resolve(billAccountMockData);
        scope.$digest();
        mockAccessTokenService = _accessTokenService_;
        spyOn(mockAccessTokenService, 'getToken').and.callFake(function () {

            return {

                then: function(callback) { return callback(accessTokenMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        deferred.resolve(accessTokenMockData);
        scope.$digest();

        spyOn(mockBillAccountService, 'getJourney').and.callFake(function () {

            return {

                then: function(callback) { return callback(getJourneyMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        deferred.resolve(getJourneyMockData);
        scope.$digest();
    }));

    it('Testing MakePaymentIndex disableButton', function() {

        //  Create the controller
        //createController();

        //scope.disableButton();
    });
});