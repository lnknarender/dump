/*
 Unit tests for Billing Preference controller - ViewBillPrefsCtrl

 Mock test data is read from an external file. This file(s) are defined
 in karma.conf.js
 */
describe('Billing preference controller - ManageBillPrefsCtrl', function () {

    var scope, location, createController;
    var mockBillAccountService, mockAccessTokenService;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(inject(function (_$q_, $rootScope, $controller, _$location_, _errorLoggingService_, _urlService_, _modifyBillPreferencesService_, _billingAccountStatusService_) {

        location = _$location_;
        scope = $rootScope.$new();

        //  Create the ManageBillPrefsCtrl and pass the mock objects
        createController = function() {
            return $controller('ManageBillPrefsCtrl', {$q: _$q_,
                                                       $scope: scope,
                                                       billAccountService: mockBillAccountService,
                                                       $location: location,
                                                       modifyBillPreferencesService: _modifyBillPreferencesService_,
                                                       billingAccountStatusService: _billingAccountStatusService_,
                                                       urlService: _urlService_,
                                                       errorLoggingService: _errorLoggingService_
            });
        };
    }));

    //  Mock the billing account service (getAccount) and access token service (getToken)
    beforeEach(angular.mock.inject(function (_billAccountService_, _accessTokenService_, _$q_, _$rootScope_) {

        scope = _$rootScope_.$new();

        var deferred = _$q_.defer();
        mockBillAccountService = _billAccountService_;

        spyOn(mockBillAccountService, 'getAccount').and.callFake(function () {

            return {

                then: function(callback) { return callback(billAccountMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        deferred.resolve(billAccountMockData);
        scope.$digest();
        mockAccessTokenService = _accessTokenService_;
        spyOn(mockAccessTokenService, 'getToken').and.callFake(function () {

            return {

                then: function(callback) { return callback(accessTokenMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        deferred.resolve(accessTokenMockData);
        scope.$digest();

        spyOn(mockBillAccountService, 'getJourney').and.callFake(function () {

            return {

                then: function(callback) { return callback(getJourneyMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        deferred.resolve(getJourneyMockData);
        scope.$digest();
    }));

    it('Testing ManageBillPrefsCtrl', function() {

        //  Create the controller
        createController();

        //TODO: complete test case
    });
});