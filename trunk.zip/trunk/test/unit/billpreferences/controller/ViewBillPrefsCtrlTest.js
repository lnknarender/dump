/*
  Unit tests for Billing Preference controller - ViewBillPrefsCtrl

  Mock test data is read from an external file. This file(s) are defined
  in karma.conf.js
*/
describe('Billing preference controller - ViewBillPrefsCtrl', function () {

    var scope, location, createController, errorLoggingService, urlService;
    var getModifiedPreferencesChargesService, mockBillAccountService, mockAccessTokenService, cancelEBillService;

    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle
        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(inject(function ($rootScope, $controller, _$location_, _errorLoggingService_, _urlService_, _getModifiedPreferencesChargesService_, _cancelEBillService_) {

        location = _$location_;
        scope = $rootScope.$new();

        errorLoggingService = _errorLoggingService_;
        urlService = _urlService_;
        getModifiedPreferencesChargesService = _getModifiedPreferencesChargesService_;
        cancelEBillService = _cancelEBillService_;

        //  Create the ViewBillPrefsCtrl and pass the mock objects
        createController = function() {
            return $controller('ViewBillPrefsCtrl', {$scope: scope,
                                                     billAccountService: mockBillAccountService,
                                                     $location: location,
                                                     cancelEBillService: cancelEBillService,
                                                     accessTokenService: mockAccessTokenService,
                                                     urlService: urlService,
                                                     errorLoggingService: errorLoggingService,
                                                     getModifiedPreferencesChargesService: getModifiedPreferencesChargesService
            });
        };
    }));

    //  Mock the billing account service (getAccount) and access token service (getToken)
    beforeEach(angular.mock.inject(function (_billAccountService_, _accessTokenService_, _$q_, _$rootScope_) {

        scope = _$rootScope_.$new();

        var deferred = _$q_.defer();
        mockBillAccountService = _billAccountService_;

        spyOn(mockBillAccountService, 'getAccount').and.callFake(function () {

            return {

                then: function(callback) { return callback(billAccountMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        mockAccessTokenService = _accessTokenService_;
        spyOn(mockAccessTokenService, 'getToken').and.callFake(function () {

            return {

                then: function(callback) { return callback(accessTokenMockData); },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        deferred.resolve(billAccountMockData);
        scope.$digest();
    }));

    it('Testing ViewBillPrefsCtrl controller', function() {

        //  Create the controller
        createController();

        //  Assert that the $scope object contains the correct data
        expect(scope.billAccountDetails).toEqual(billAccountMockData);

        expect(scope.language).toEqual('English');
        expect(scope.format).toEqual('braille bill');
        expect(scope.media).toEqual('online and in the post');
    });

    it('Testing ViewBillPrefsCtrl changePreferences', function() {

        //  Create the controller
        createController();

        //  Call the on-click event 'changePreferences' and assert the scope variables
        scope.changePreferences();
        expect(scope.modifyBillAccountDetails.accessToken).toEqual(accessTokenMockData.accessToken);
        expect(scope.modifyBillAccountDetails.media).toEqual(billAccountMockData.media);
        expect(scope.modifyBillAccountDetails.format).toEqual(billAccountMockData.format);
        expect(scope.modifyBillAccountDetails.language).toEqual(billAccountMockData.language);
        expect(scope.modifyBillAccountDetails.cancel.media).toEqual(null);
        expect(scope.modifyBillAccountDetails.cancel.reason.code).toEqual(null);
        expect(scope.modifyBillAccountDetails.cancel.reason.reason).toEqual(null);

        expect(cancelEBillService.getIsCancelEBill()).toBeFalsy();

        //  Assert the HTML redirect path is correct
        expect(location.path()).toEqual('/managebillprefs');
    });

    it('Testing ViewBillPrefsCtrl canceleBilling', function() {

        //  Create the controller
        createController();

        //  Call the on-click event 'canceleBilling' and assert the scope variables
        scope.canceleBilling();
        expect(scope.modifyBillAccountDetails.accessToken).toEqual(accessTokenMockData.accessToken);
        expect(scope.modifyBillAccountDetails.media).toEqual(billAccountMockData.media);
        expect(scope.modifyBillAccountDetails.format).toEqual(billAccountMockData.format);
        expect(scope.modifyBillAccountDetails.language).toEqual(billAccountMockData.language);
        expect(scope.modifyBillAccountDetails.cancel.media).toEqual(null);
        expect(scope.modifyBillAccountDetails.cancel.reason.code).toEqual(null);
        expect(scope.modifyBillAccountDetails.cancel.reason.reason).toEqual(null);

        expect(cancelEBillService.getIsCancelEBill()).toBeTruthy();

        //  Assert the HTML redirect path is correct
        expect(location.path()).toEqual('/managebillprefssummary');
    });
});