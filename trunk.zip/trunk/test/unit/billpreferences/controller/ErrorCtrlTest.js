//  Unit tests for Billing Preference controller - ErrorCtrl
describe('Billing preference controller - ErrorCtrl', function () {

    beforeEach(angular.mock.module('bptaAppl'));

    var scope, location, createController, errorLoggingService, http, resultFromService;

    beforeEach(inject(function ($rootScope, $controller, _$location_, _errorLoggingService_, _$http_) {

        location = _$location_;
        scope = $rootScope.$new();

        errorLoggingService = _errorLoggingService_;
        http = _$http_;

        var errorResult = {"errors": [{"message": "This is an error message",
                                       "code": "12345"}]};

        resultFromService = errorLoggingService.errorToString(errorResult);

        createController = function() {
            return $controller('ErrorCtrl', {$scope: scope,
                                             $http: http,
                                             $location: location,
                                             errorLoggingService: errorLoggingService
            });
        };
    }));

    it('Testing ErrorCtrl controller', function() {

        //  Create the controller
        createController();

        //  Assert that the result from the service errorLoggingService.getErrorMessage() is returned by
        //  the controller. The service has been tested by the service unit tests. So this test only needs
        //  to assert that the controller returns the service result
        expect(scope.errorMessage).toEqual(resultFromService);
    });
});