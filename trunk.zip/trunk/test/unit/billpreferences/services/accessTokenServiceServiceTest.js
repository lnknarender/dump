//Unit tests for State service

describe('Service: accessTokenService', function () {

    var service, stateService, cancellationReasonsService;
    var $q, $httpBackend, scope;
    var deferred1, deferred2;

    //  Define the mock responses
    var accessTokenMockData = {'timeoutSeconds': '1200', 'accessToken': 'b2297kr5v5sledqf6su0qpda9fc0v0ug2do7br'};

    var cancelReasonsMockData = {"code":"1001", "message":"I can't find what I am looking for online."};
/*
    var cancelReasonsMockData = [{"code":"1001", "message":"I can't find what I am looking for online."},
                                 {"code":"1002", "message":"I find the navigation difficult online."},
                                 {"code":"1003", "message":"I can't print from my online account."},
                                 {"code":"1004", "message":"I am concerned about online security and no longer want to have my bills available online."},
                                 {"code":"1010", "message":"Other."}]
*/

    beforeEach(module('bptaAppl', function ($provide, $translateProvider) {

        //  Need to mock the translate language bundle

        $provide.factory('customLoader', function ($q) {
            return function () {
                var deferred = $q.defer();
                deferred.resolve({});
                return deferred.promise;
            };
        });

        $translateProvider.useLoader('customLoader');
    }));

    beforeEach(angular.mock.inject(function (_$routeParams_) {

     _$routeParams_.cak = "ACC_002";
     _$routeParams_.conk = "002";
     _$routeParams_.bac = "0202535714";
     }));

    beforeEach(inject(function(_$rootScope_,  _accessTokenService_, _ajaxService_, _cancellationReasonsService_, _$q_, _$httpBackend_) {

        scope = _$rootScope_.$new();

        $q = _$q_;

        $httpBackend = _$httpBackend_;

        service = _accessTokenService_;

        var mockAjaxServiceWithoutToken = _ajaxService_;

        cancellationReasonsService = _cancellationReasonsService_;

        spyOn(mockAjaxServiceWithoutToken, 'doGet').and.callFake(function (params) {

            return {

                then: function(callback) { 
                    if(params.indexOf("/account/cancellation/reasons/online?a")>-1)
                        return callback(cancelReasonsMockData);
                    else if(params.indexOf("/accesstoken?a")>-1)
                        return callback(accessTokenMockData); 
                },

                catch: function(callback) { return null; },

                finally: function(callback) { return null; }
            };
        });

        var deferred = _$q_.defer();
        deferred.resolve();
        scope.$digest();
    }));

    beforeEach(function() {
        inject(function(_$q_) {
            $q = _$q_;
        });
    });

    beforeEach(function() {
        deferred1 = $q.defer();
        deferred2 = $q.defer();
    });

    beforeEach(angular.mock.inject(function (_stateService_) {

        stateService = _stateService_;
    }));

    it('Test accessTokenService getToken', (function () {

        var response = service.getToken();
        var accessToken = stateService.get("accessToken");

        //  Perform the assert against the state service rather than the return promise. The promise returned by the service under
        //  test a 'real' promise rather than a mock. So this test will not 'see' and act on the returned promise. Further investigation
        //  required in order to test a non-mocked promise.
        expect(accessToken.accessToken).toBe(accessTokenMockData.accessToken);
        expect(accessToken.timeoutSeconds).toBe(accessTokenMockData.timeoutSeconds);

        //  The promises below do not execute as the promise returned by the service under test a 'real' promise rather than a mock.
        //  They have been left in the code to allow further test investigation.
        response.then(function (result) {

            //  This code block does not execute as the service under test is returning a real promise
            console.log("Test accessTokenService getToken - 2.1 In then, result = " + result);
            console.log("Test accessTokenService getToken - 2.2 In then, result.keys = " + Object.keys(result));

            expect(result.timeoutSeconds).toBe(accessTokenMockData.timeoutSeconds);
        });
    }));

    it('Test accessTokenService getCancelReasons', (function () {

        cancellationReasonsService.getCancelReasons();
        var cancelReasons = stateService.get("cancelReasons");

        //  Perform the assert against the state service rather than the return promise. The promise returned by the service under
        //  test a 'real' promise rather than a mock. So this test will not 'see' and act on the returned promise. Further investigation
        //  required in order to test a non-mocked promise.
        expect(cancelReasons.code).toBe(cancelReasonsMockData.code);
        expect(cancelReasons.message).toBe(cancelReasonsMockData.message);
    }));
});