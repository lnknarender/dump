//Unit tests for Billing Preference service
describe('Billing preference service', function () {

    var service, billAccountService, scope;

    var options = [{"media":"Paper",      "format":"Audio CD",     "language":"ENG", "charge":0.0,  "currencyCode":"GBP"},
        {"media":"Dual",       "format":"Blue Bill",    "language":"ENG", "charge":1.59, "currencyCode":"GBP"},
        {"media":"Dual",       "format":"Blue Bill",    "language":"WEL", "charge":1.59, "currencyCode":"GBP"},
        {"media":"Dual",       "format":"Large-Print",  "language":"ENG", "charge":0.0,  "currencyCode":"GBP"},
        {"media":"Paper",      "format":"Braille Bill", "language":"ENG", "charge":0.0,  "currencyCode":"GBP"},
        {"media":"Paper",      "format":"Blue Bill",    "language":"ENG", "charge":1.59, "currencyCode":"GBP"},
        {"media":"Paper",      "format":"Blue Bill",    "language":"WEL", "charge":1.59, "currencyCode":"GBP"},
        {"media":"Paper",      "format":"Large-Print",  "language":"ENG", "charge":0.0,  "currencyCode":"GBP"},
        {"media":"Paper-free", "format":"Blue Bill",    "language":"ENG", "charge":0.0,  "currencyCode":"GBP"},
        {"media":"Paper-free", "format":"Blue Bill",    "language":"WEL", "charge":0.0,  "currencyCode":"GBP"},
        {"media":"Dual",       "format":"Audio CD",     "language":"ENG", "charge":0.0,  "currencyCode":"GBP"},
        {"media":"Dual",       "format":"Braille Bill", "language":"ENG", "charge":0.0,  "currencyCode":"GBP"}];

    var display=  {
        "Paper":"By Post",
        "Paper-free":"Online",
        "Dual":"Online and by Post",
        "Blue Bill":"Standard",
        "Large-Print":"Large Print",
        "Braille Bill":"Braille Bill",
        "Audio CD":"Audio CD",
        "ENG":"English",
        "WEL":"Welsh"
    };
    var delivery = [{'displayLabel':"Paper",'id':'postRadio','value':'Paper'},
        {'displayLabel':"Paper-free",'id':'onlineRadio','value':'Paper-free'} ,
        {'displayLabel':"Dual",'id':'onlineAndPostRadio','value':'Dual'}];
    beforeEach(angular.mock.module('bptaAppl'));

    beforeEach(inject(function(_$rootScope_, _$routeParams_, _$q_, _billAccountService_) {

        scope = _$rootScope_.$new();

        billAccountService = _billAccountService_;
    }));

    it('Testing Cancel eBill setter and getters', inject(function (cancelEBillService) {

        var cancelEBill = "Test";

        cancelEBillService.setIsCancelEBill(cancelEBill);
        expect(cancelEBillService.getIsCancelEBill()).toBe(cancelEBill);
    }));

    it('Testing error logging service', inject(function (errorLoggingService) {

        var errorResult = {"message": "This is an error message"};
        var expectedResult =  "Error \n" + "This is an error message\n";

        var errorText = errorLoggingService.errorToString(errorResult);

        expect(errorText).toBe(expectedResult);

        errorResult = {"errors": [{"message": "This is an error message",
                                   "code": "12345"}]};

        expectedResult =  "Error \n" + "12345 - This is an error message\n";

        errorText = errorLoggingService.errorToString(errorResult);
        expect(errorText).toBe(expectedResult);

    }));

    it('Testing bill account service - delivery method', inject(function () {

        //  Set-up expected data to be returned by the service under test
        var expectedDeliveryMethod = [{'displayLabel':"Paper",     'id':'postRadio',          'value':'Paper','media_tick':true,'selected':'btn-main-selected'},
            {'displayLabel':"Paper-free",'id':'onlineRadio',        'value':'Paper-free','media_tick':false,'selected':'btn-main-unselected'} ,
            {'displayLabel':"Dual",      'id':'onlineAndPostRadio', 'value':'Dual','media_tick':false,'selected':'btn-main-unselected'}];

        //  Call the service under test
        var deliveryMethod = billAccountService.deliveryMethod('Paper');

        //  Assert that the service under test returns the expected values
        expect(deliveryMethod).toEqual(expectedDeliveryMethod);
    }));

    it('Testing bill account service - format rules', inject(function () {

        //  Set-up expected data to be returned by the service under test
        var expectedFormatRules = {'Paper':      {'ENG':  {'Audio CD': 0, 'Braille Bill': 0, 'Blue Bill': 1.59, 'Large-Print': 0},
                                                  'WEL':  {'Blue Bill': 1.59}},
                                                  'Dual': {'ENG': {'Blue Bill': 1.59, 'Large-Print': 0, 'Audio CD': 0, 'Braille Bill': 0 },
                                                           'WEL': {'Blue Bill': 1.59}},
                                                  'Paper-free': {'ENG': {'Blue Bill': 0 },
                                                                 'WEL': {'Blue Bill': 0}}};

        //  Call the service under test
        var formatRules = billAccountService.getFormatRules(options);

        //  Assert that the service under test returns the expected values
        expect(formatRules).toEqual(expectedFormatRules);
    }));

    it('Testing bill account service - check media format rule', inject(function () {

        //  Set-up test data to be passed to the service under test
        var formatSelection = 'Blue Bill';
        var originalMedia = 'Dual';
        var originalLanguage = 'ENG';

        //  Call the service under test
        var mediaFormatRule = billAccountService.checkMediaFormatRule(formatSelection, scope, options, originalMedia, originalLanguage);

        //  Assert that the service under test returns the expected values
        expect(mediaFormatRule).toBeFalsy();
    }));
    it('Testing bill account service - check media format rule', inject(function () {

        //  Set-up test data to be passed to the service under test
        var formatSelection = 'Large-Print';
        var originalMedia = 'Dual';
        var originalLanguage = 'WEL';

        //  Call the service under test
        var mediaFormatRule = billAccountService.checkMediaFormatRule(formatSelection, scope, options, originalMedia, originalLanguage);

        //  Assert that the service under test returns the expected values
        expect(mediaFormatRule).toBeTruthy();
    }));
    it('Testing bill account service - check media format rule', inject(function () {

        //  Set-up test data to be passed to the service under test
        var formatSelection = 'Large-Print';
        var originalMedia = 'Dual';
        var originalLanguage = 'ENG';

        //  Call the service under test
        var mediaFormatRule = billAccountService.checkMediaFormatRule(formatSelection, scope, options, originalMedia, originalLanguage);

        //  Assert that the service under test returns the expected values
        expect(mediaFormatRule).toBeFalsy();
    }));
    it('Testing bill account service - check media format rule', inject(function () {

        //  Set-up test data to be passed to the service under test
        var formatSelection = 'Large-Print';
        var originalMedia = 'Paper-free';
        var originalLanguage = 'WEL';

        //  Call the service under test
        var mediaFormatRule = billAccountService.checkMediaFormatRule(formatSelection, scope, options, originalMedia, originalLanguage);

        //  Assert that the service under test returns the expected values
        expect(mediaFormatRule).toBeTruthy();
    }));
    it('Testing bill account service - check media format rule', inject(function () {

        //  Set-up test data to be passed to the service under test
        var formatSelection = 'Large-Print';
        var originalMedia = 'Paper-free';
        var originalLanguage = 'ENG';

        //  Call the service under test
        var mediaFormatRule = billAccountService.checkMediaFormatRule(formatSelection, scope, options, originalMedia, originalLanguage);

        //  Assert that the service under test returns the expected values
        expect(mediaFormatRule).toBeTruthy();
    }));
    //TODO: create further tests cases based on the above test

    it('Testing bill account service - format method', inject(function () {

        //  Set-up test data to be passed to the service under test
        var originalMedia = 'Dual';
        var originalLanguage = 'ENG';

        //  Call the service under test
        var formatMethod = billAccountService.formatMethod(scope, options, originalMedia, originalLanguage);

        //  Assert that the service under test returns the expected values
        expect(formatMethod[0].displayLabel).toBe('Blue Bill');
        expect(formatMethod[0].id).toBe('Blue Bill');
        expect(formatMethod[0].value).toBe('Blue Bill');
        expect(formatMethod[1].displayLabel).toBe('Large-Print');
        expect(formatMethod[1].id).toBe('Large-Print');
        expect(formatMethod[1].value).toBe('Large-Print');
        expect(formatMethod[2].displayLabel).toBe('Braille Bill');
        expect(formatMethod[2].id).toBe('Braille Bill');
        expect(formatMethod[2].value).toBe('Braille Bill');
        expect(formatMethod[3].displayLabel).toBe('Audio CD');
        expect(formatMethod[3].id).toBe('Audio CD');
        expect(formatMethod[3].value).toBe('Audio CD');

        //  expect(formatMethod[0].mediaAndFormatRule).toBeTruthy();
    }));

    // TODO: Add further test combinations for formatMethod

    it('Testing bill account service - language method', inject(function () {

        //  Set-up expected data to be returned by the service under test
        var expectedLanguageMethod = [{'displayLabel':"ENG",'id':'english','value':'ENG','language_tick':false,'selected':'btn-main-unselected','css':'english'},
            {'displayLabel':"WEL",'id':'welsh','value':'WEL','language_tick':true,'selected':'btn-main-selected','css':'welsh'}];

        //  Call the service under test
        var languageMethod = billAccountService.languageMethod('WEL');

        //  Assert that the service under test returns the expected values
        expect(languageMethod).toEqual(expectedLanguageMethod);
    }));
    it('Testing bill account service - display method', inject(function () {

        //  Set-up expected data to be returned by the service under test
        var expectedDisplayMethod = {
            "Paper":"by post",
            "Paper-free":"online",
            "Dual":"online and in the post",
            "Blue Bill":"standard",
            "Large-Print":"large print",
            "Braille Bill":"braille bill",
            "Audio CD":"audio cd",
            "ENG":"English",
            "WEL":"Welsh"
        };

        //  Call the service under test
        var displayMethod = billAccountService.displayMethod();

        //  Assert that the service under test returns the expected values
        expect(displayMethod).toEqual(expectedDisplayMethod);
    }));


    it('Testing bill account service - showAgentOldOnly Method', inject(function () {

        //  Set-up expected data to be returned by the service under test

        var originalFormat = 'Blue Bill';
        var originalMedia = 'Paper-free';
        var originalLanguage = 'ENG';
        //  Call the service under test
        var displayMethod = billAccountService.showAgentOldOnlyMethod(display,originalMedia,originalFormat,originalLanguage);

        //  Assert that the service under test returns the expected values
        expect(displayMethod[0].displayLabel).toBe('Delivery-Method');
        expect(displayMethod[0].value).toBe('Online');
        expect(displayMethod[1].displayLabel).toBe('Format');
        expect(displayMethod[1].value).toBe('Standard');
        expect(displayMethod[2].displayLabel).toBe('Language');
        expect(displayMethod[2].value).toBe('English');
    }));


    it('Testing bill account service - showAgentOldOnly Method', inject(function () {

        //  Set-up expected data to be returned by the service under test

        var originalFormat = 'Blue Bill';
        var originalMedia = 'Paper-free';
        var originalLanguage = 'WEL';
        //  Call the service under test
        var displayMethod = billAccountService.showAgentOldOnlyMethod(display,originalMedia,originalFormat,originalLanguage);

        //  Assert that the service under test returns the expected values
        expect(displayMethod[0].displayLabel).toBe('Delivery-Method');
        expect(displayMethod[0].value).toBe('Online');
        expect(displayMethod[1].displayLabel).toBe('Format');
        expect(displayMethod[1].value).toBe('Standard');
        expect(displayMethod[2].displayLabel).toBe('Language');
        expect(displayMethod[2].value).toBe('Welsh');
    }));

    it('Testing bill account service - chargeMatrix - option 1', inject(function () {

        //  Set-up expected data to be returned by the service under test

        var chargesApplicability = true;
        var chargesApply = constants.CHARGED;
        var conditionalDate = constants.LESS_TWO_DAYS;

        //  Call the service under test
        var chargeMatrix = billAccountService.chargeMatrix(chargesApplicability, chargesApply, conditionalDate);

        //  Assert that the service under test returns the expected values
        expect(chargeMatrix).toBe(constants.CHARGES_APPLY_LESS_THAN_TWO_DAYS);
    }));

    it('Testing bill account service - chargeMatrix - option 2', inject(function () {

        //  Set-up expected data to be returned by the service under test

        var chargesApplicability = true;
        var chargesApply = constants.CHARGED;
        var conditionalDate = constants.GREATER_TWO_DAYS;

        //  Call the service under test
        var chargeMatrix = billAccountService.chargeMatrix(chargesApplicability, chargesApply, conditionalDate);

        //  Assert that the service under test returns the expected values
        expect(chargeMatrix).toBe(constants.CHARGES_APPLY_GREATER_THAN_TWO_DAYS);
    }));

    it('Testing bill account service - chargeMatrix - option 3', inject(function () {

        //  Set-up expected data to be returned by the service under test

        var chargesApplicability = true;
        var chargesApply = constants.SAVED;
        var conditionalDate = constants.LESS_TWO_DAYS;

        //  Call the service under test
        var chargeMatrix = billAccountService.chargeMatrix(chargesApplicability, chargesApply, conditionalDate);

        //  Assert that the service under test returns the expected values
        expect(chargeMatrix).toBe(constants.SAVINGS_APPLY_LESS_THAN_TWO_DAYS);
    }));

    it('Testing bill account service - chargeMatrix - option 4', inject(function () {

        //  Set-up expected data to be returned by the service under test

        var chargesApplicability = true;
        var chargesApply = constants.SAVED;
        var conditionalDate = constants.GREATER_TWO_DAYS;

        //  Call the service under test
        var chargeMatrix = billAccountService.chargeMatrix(chargesApplicability, chargesApply, conditionalDate);

        //  Assert that the service under test returns the expected values
        expect(chargeMatrix).toBe(constants.SAVING_APPLY_GREATER_THAN_TWO_DAYS);
    }));

    it('Testing bill account service - chargeMatrix - option 5', inject(function () {

        //  Set-up expected data to be returned by the service under test

        var chargesApplicability = false;
        var chargesApply;
        var conditionalDate = constants.LESS_TWO_DAYS;

        //  Call the service under test
        var chargeMatrix = billAccountService.chargeMatrix(chargesApplicability, chargesApply, conditionalDate);

        //  Assert that the service under test returns the expected values
        expect(chargeMatrix).toBe(constants.NO_CHARGES_APPLY_LESS_THAN_TWO_DAYS);
    }));

    it('Testing bill account service - chargeMatrix - option 6', inject(function () {

        //  Set-up expected data to be returned by the service under test

        var chargesApplicability = false;
        var chargesApply;
        var conditionalDate = constants.GREATER_TWO_DAYS;

        //  Call the service under test
        var chargeMatrix = billAccountService.chargeMatrix(chargesApplicability, chargesApply, conditionalDate);

        //  Assert that the service under test returns the expected values
        expect(chargeMatrix).toBe(constants.NO_CHARGES_GREATER_LESS_THAN_TWO_DAYS);
    }));
});
