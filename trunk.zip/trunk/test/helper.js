var q = require('/usr/lib/node_modules/protractor/node_modules/q/q.js');
var FirefoxProfile = require('/usr/lib/node_modules/protractor/node_modules/firefox-profile');

exports.getFirefoxProfile = function() {
    var deferred = q.defer();

    var firefoxProfile = new FirefoxProfile();
    firefoxProfile.setPreference('browser.newtab.url', 'http://127.0.0.1:4444/wd/hub');
    //firefoxProfile.setAssumeUntrustedCertificateIssuer(false);
    firefoxProfile.encoded(function(encodedProfile) {
        var multiCapabilities = [{
            browserName: 'firefox',
            firefox_profile : encodedProfile
        }];
        deferred.resolve(multiCapabilities);
    });

    return deferred.promise;
};