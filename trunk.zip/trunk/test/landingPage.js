var jasmineConnection = require("./properties/jasmineConnection.json");

var LandingPage = (function () {
    function LandingPage() {
        this.cakField = element(By.id("cakInputId"));
        this.accField = element(By.id("conkInputId"));
        this.bacField = element(By.id("bacInputId"));
        this.acckeyField = element(By.id("acckeyInputId"));
        this.agentDNField = element(By.id("agentDNId"));
        this.agentEINField = element(By.id("agentEinId"));
        this.agentButton = element(By.id("agentBtn"));
        this.customerButton = element(By.id("customerBtn"));
        this.loggedOutMakePaymentButton = element(By.id("loggedOutMakePaymentBtn"));
    }

    LandingPage.prototype.visitPage = function () {
        browser.get(jasmineConnection.host);
    };

    LandingPage.prototype.enterCak = function (cak) {
        this.cakField.clear();
        this.cakField.sendKeys(cak);
    };

    LandingPage.prototype.enterConk = function (conk) {
       this. accField.clear();
       this. accField.sendKeys(conk);
    };

    LandingPage.prototype.enterBac = function (bac) {
        this.bacField.clear();
        this.bacField.sendKeys(bac);
    };

    LandingPage.prototype.enterAgentDN = function (agentDN) {
        this.agentDNField.clear();
        this.agentDNField.sendKeys(agentDN);
    };

    LandingPage.prototype.enterAgentEIN = function (agentEIN) {
        this.agentEINField.clear();
        this.agentEINField.sendKeys(agentEIN);
    };

    LandingPage.prototype.enterAcckey = function (acckey) {
        this.acckeyField.clear();
        this.acckeyField.sendKeys(acckey);
    };

    LandingPage.prototype.clickAgentButton = function () {
        this.agentButton.click();
    };

    LandingPage.prototype.clickCustomerButton = function () {
        this.customerButton.click();
    };

    LandingPage.prototype.clickLoggedOutMakePaymentButton = function () {
        this.loggedOutMakePaymentButton.click();
    };

    return LandingPage

})();

module.exports = LandingPage;
