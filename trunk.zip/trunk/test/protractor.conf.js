/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
exports.config = {
	//seleniumAddress:'http://127.0.0.1:4444/wd/hub',
	allScriptsTimeout : 11000,

	suites: {
		billing: 'billing/tests/*Test.js',
		makepayment: 'makepayment/tests/*Test.js',
		instalmentplans: 'instalmentplans/tests/*Test.js'
	},

	capabilities : {
		'browserName' : 'chrome',
		 proxy: {
            proxyType: 'manual',
			noProxy: 'consumer.dev.bt.com',
            httpProxy: 'http://proxy.intra.bt.com:8080',
            sslProxy: 'http://proxy.intra.bt.com:8080'
        }
	},
	chromeOnly : true,
	
	//For firefox
	/*capabilities : {
		'browserName' : 'firefox',
		 proxy: {
            proxyType: 'manual',
            httpProxy: 'http://proxy.intra.bt.com:8080',
            sslProxy: 'http://proxy.intra.bt.com:8080'
        }
	},*/

	//For phantomjs
	/*capabilities: {
		  'browserName': 'phantomjs',
		  'phantomjs.binary.path':'./node_modules/phantomjs/bin/phantomjs',
		  'phantomjs.cli.args':['--logfile=PATH', '--loglevel=DEBUG']
	},*/

	baseUrl : 'http://consumer.dev.bt.com/',

	framework : 'jasmine',

	jasmineNodeOpts : {
		defaultTimeoutInterval : 30000,
		onComplete: null,
        isVerbose: false,
        showColors: true,
        includeStackTrace: false
	},
	onPrepare : function() {		
		require('jasmine-reporters');
		jasmine.getEnv().addReporter(
				new jasmine.JUnitXmlReporter('test/out/', true, true));
	}
};
