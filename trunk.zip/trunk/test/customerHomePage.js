var jasmineConnection = require("./properties/jasmineConnection.json");

var CustomerHomePage = (function () {
    function CustomerHomePage() {
        this.customerMakePayment = element(By.id("customerMakePayment"));
        this.customerBillPrefs = element(By.id("customerBillPrefs"));
        this.customerInstalmentPlan = element(By.id("customerInstalmentPlan"));
        this.customerInstalmentPlan = element(By.id("customersignoutbutton"));
    }

    CustomerHomePage.prototype.visitPage = function () {
        browser.get(jasmineConnection.host);
    };

    CustomerHomePage.prototype.clickCustomerMakePayment = function () {
        this.customerMakePayment.click();
    };

    CustomerHomePage.prototype.clickCustomerBillPrefs = function () {
        this.customerBillPrefs.click();
    };

    CustomerHomePage.prototype.clickCustomerInstalmentPlan = function () {
        this.customerInstalmentPlan.click();
    };

    CustomerHomePage.prototype.clickCustomersignoutbutton = function () {
        this.customersignoutbutton.click();
    };

    return CustomerHomePage

})();

module.exports = CustomerHomePage;
