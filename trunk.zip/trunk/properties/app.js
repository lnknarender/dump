mybtApp = {
   usingMobileApp: true,
   showInstalmentPlanLink: false
}