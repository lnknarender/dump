//The connection properties for this environment
//
//Usually, siteminder will add the sms_user http header for non agent users
//
//For environments without siteminder, if you specify the property
//sms_user, the angular app will put the sms_user http header
//on all its outgoing http connections.

// The useMockData attributes allows mock data file to be used for
// development purposes. This attribute MUST NOT exist in connection
// properties on other environments/platforms.

connection = {
    "useMockData": "true",
    "userType": "agent",
    "host": "http://consumer.bt.com/appsbills",
    "iehost": "http://consumer.bt.com/appsbills",
    "version": "/v1",
    "protectedTypeUri": "/secure",
    "publicTypeUri": "/public",
    "contextBase": "/static/bpta/",
    "bptaLaunchUrl": "/static/bpta",

    "controlSpendAlertUrl": "https://www.bt.com/eIM/cya/alert/showAlertSettings.do?siteArea=con.mya&acKey=%ACC_KEY&ackey=%ACC_KEY&hKey=alertsettings&singleSignOn=true",
    "automatedPaymentUrl": "https://www.bt.com/eIM/cya/managepayment/setup/showSetupPaymentPage.do?ackey=%ACC_KEY",
    "backToMyBtUrl": "https://www.bt.com/appsconsumeraccount/secure/dashboard.do?siteArea=con.mya",
    "viewLatestBill":"https://www.bt.com/eIM/cya/reporting/latestBill.do?hKey=latestbill&isIncMobileInfo=true&ackey=%ACC_KEY",
    "contactUs": "https://bt.custhelp.com/app/contact/?s_intcid=con_sanda:Help%20Home:L1:contactus:L2:contactushome",
    "orderLineRentalPlus": "http://live.agent.nat.bt.com/consumerOrders/control/agenthome?interactionId=1-BLTJM4&custType=Consumer&s_intcid=agent_framework_sales&custId=%CAK&billingAcct=%BAC&telNo=%TEL_NO&contactId=%CONK&hash=6e6470e9abc09680b002911a915e943ee02c66cf&accountStatus=Active"
}