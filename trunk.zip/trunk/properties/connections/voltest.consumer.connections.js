connection = {
    "userType": "customer",
    "host": "/appsbills",
    "iehost": "/appsbills",    
    "version": "/v1",
    "protectedTypeUri": "/secure",
    "publicTypeUri": "/public",
    "contextBase": "/s/apps/appsbills/",
    "bptaLaunchUrl": "/s/apps/appsbills",

    "controlSpendAlertUrl": "https://www.bt.com/eIM/cya/alert/showAlertSettings.do?siteArea=con.mya&acKey=%ACC_KEY&ackey=%ACC_KEY&hKey=alertsettings&singleSignOn=true",
    "automatedPaymentUrl": "https://www.bt.com/eIM/cya/managepayment/setup/showSetupPaymentPage.do?ackey=%ACC_KEY",
    "backToMyBtUrl": "https://www.bt.com/appsconsumeraccount/secure/dashboard.do?siteArea=con.mya",
    "viewLatestBill":"https://www.bt.com/eIM/cya/reporting/latestBill.do?hKey=latestbill&isIncMobileInfo=true&ackey=%ACC_KEY",
    "contactUs": "https://bt.custhelp.com/app/contact/?s_intcid=con_sanda:Help%20Home:L1:contactus:L2:contactushome"
}