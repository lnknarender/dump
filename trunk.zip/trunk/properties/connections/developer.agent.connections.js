// These are environment specific, for each environment the relevent file should be copied into the parent directory
// and renamed to connections.js, the connections file should then be deleted

connection = {
    "userType": "agent",
    "host": "http://localhost:8090/appsbills",
    "iehost": "http://localhost:8090/appsbills",
    "version": "/v1",
    "protectedTypeUri": "/secure",
    "publicTypeUri": "/public",
    "contextBase": "/static/bpta/",
    "bptaLaunchUrl": "/static/bpta",

    "controlSpendAlertUrl": "https://www.bt.com/eIM/cya/alert/showAlertSettings.do?siteArea=con.mya&acKey=%ACC_KEY&ackey=%ACC_KEY&hKey=alertsettings&singleSignOn=true",
    "orderLineRentalPlus": "http://live.agent.nat.bt.com/consumerOrders/control/agenthome?interactionId=1-BLTJM4&custType=Consumer&s_intcid=agent_framework_sales&custId=%CAK&billingAcct=%BAC&telNo=%TEL_NO&contactId=%CONK&hash=6e6470e9abc09680b002911a915e943ee02c66cf&accountStatus=Active"
}