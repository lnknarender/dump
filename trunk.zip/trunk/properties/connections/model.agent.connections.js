connection = {
    "userType": "agent",
    "host": "/appsbills",
    "iehost": "/appsbills",
    "version": "/v1",
    "protectedTypeUri": "/secure",
    "publicTypeUri": "/public",
    "contextBase": "/s/apps/appsbills/",
    "bptaLaunchUrl": "/s/apps/appsbills",

    "controlSpendAlertUrl": "https://www.bt.com/eIM/cya/alert/showAlertSettings.do?siteArea=con.mya&acKey=%ACC_KEY&ackey=%ACC_KEY&hKey=alertsettings&singleSignOn=true"
}