chrome = {
    "chromeBinaryLocation": "file:///C:\\Windows\\Redirected\\Profiles\\StartMenu\\XPAdvisor-U\\Support\\ChromeLaunchTest\\chrome.lnk"
}