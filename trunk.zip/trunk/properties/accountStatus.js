accountStatus = {
    "accountStatus":["Inactive","Closed","Bill Follow Up"],
    "accountSubStatus":["Installment Defaulted","Instalment Defaulted","Pending Termination" ,"Terminated-Ebilling disallowed","Termination Failed-Ebilling disallowed","Fraud Under Investigation","Awaiting Partial Restriction","Partially Restricted-Ebilling disallowed","Awaiting Complete Restriction-Ebilling disallowed","Completely Restricted-Ebilling disallowed","Awaiting Cease Order","Awaiting Termination","Cease Billing Account","Referred to Legal, Referred to DCA","Debt Written Off","Manual Reconnection"]
}