omniture ={

    "generic.error.type": "SE",
    "generic.error.prefix": "Generic error",

    "makePayment.validation.invalidAmount.type": "SE",
    "makePayment.validation.invalidAmount.prefix": "Amount less than 1 pound",

    "makePayment.amount.errorMessage.type": "SE",
    "makePayment.amount.errorMessage.prefix": "Amount less than 1 pound",

    "makePayment.logged.in.excessWarningMessage.type": "SE",
    "makePayment.logged.in.excessWarningMessage.prefix": "Amount less than outstanding",

    "makePayment.logged.in.warningMessageGreaterthan.type": "SE",
    "makePayment.logged.in.warningMessageGreaterthan.prefix": "Amount more than oustanding"

}
